exports.command = function ( ) {
  this.
  pause( 5000 ).
  //click video control button to play  
  click ( ".unimatrix-video-controls-bucket.unimatrix-bucket-center" ).
  pause ( 5000 );
  return this;
};
//this command is for editing the Artifact of all type 
exports.command = function ( artifactType, excelInput, excelColumn, xlName, sheetName, xlRow, xlColumn, failureReasonColumn ) {
  //Access the variable globally defined
  var excel = this.globals.excelCol;
  excel.AG.length = 0;
  var ignoreCase = require ( 'ignore-case' );
  this.useXpath ( ).
  //Wait and click the All contents to Edit the Articles 
  waitForElementVisible ( "//span[contains(@class,'left-sidebar-text ng-binding portal expand')][text()='all content']", 6000, false, function ( allContent ) {
    if ( allContent.value == true ) {
      this.click ( "//span[contains(@class,'left-sidebar-text ng-binding portal expand')][text()='all content']" ).
      //Get the Artifact count before editing Artifacts
      waitForElementVisible ( '//span[@class="artifact-count-text ng-binding"]', 5000, false, function ( artifactCount ) {
        if ( artifactCount.value == true ) {
          this.getText ( '//span[@class="artifact-count-text ng-binding"]', function ( preCount ) {
            //Extract the Artifact count alone from the fetched artifact text & numbers
            var artifactpreCount = preCount.value.substr ( 0, preCount.value.lastIndexOf ( 'A' ) - 1 );
            console.log ( "artifactpreCount", artifactpreCount );
            this.click ( '//input[@id="search_input"]' ).
            //Search the Artifacts to edit
            waitForElementVisible ( '//input[@placeholder="Search by Name"]', 5000, false, function ( searchIcon ) {
              if ( searchIcon.value == true ) {
                //set the keyword to the search Artifact field
                this.clearValue ( '//input[@placeholder="Search by Name"]' ).
                setValue ( '//input[@placeholder="Search by Name"]', excel.D[ excelColumn ] ).
                keys ( this.Keys.ENTER ).
                keys ( this.Keys.ENTER ).
                waitForElementVisible ( '//span/a[contains(@class,"name-container")]/span[@id="' + excel.D[ excelColumn ] + '"]', 5000, false, function ( searchArtifact ) {
                  if ( searchArtifact.value == true ) {
                    this.getAttribute ( '//span/a[contains(@class,"name-container")]/span[@id="' + excel.D[ excelColumn ] + '"]/ancestor::item-cell', "index", function ( searchArtifactIndex ) {
                      //get the count of search result
                      this.elements ( 'xpath', '//span/a[contains(@class,"name-container")]/span[@id="' + excel.D[ excelColumn ] + '"]', function ( searchCount ) {
                        for ( let indexValue = parseInt ( searchArtifactIndex.value ) + 1; indexValue <= searchCount.value.length; indexValue++ ) {
                          this.waitForElementPresent ( "//span[contains(@class,'left-sidebar-text ng-binding portal expand')][text()='all content']", 5000, false, function ( ) {
                            if ( excel.AG.indexOf ( 'FAIL' ) == -1 ) {
                              //Search for the Artifact with Category
                              this.getText ( '//item-cell[' + indexValue + ']/*//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]/following::span[1]', function ( categoryType ) {
                                this.pause ( 3000 );
                                if ( ignoreCase.equals ( categoryType.value, artifactType ) ) {                             
                                  this.getLocationInView ( '//item-cell[' + indexValue + ']/*//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]' ).
                                  click ( '//item-cell[' + indexValue + ']/*//span/a[contains(@class,"name-container" )]/span[@id="' + excel.D[ excelColumn ] + '"]' ).                            
                                  //check the next button redirect to the page to edit a new Artifact
                                  waitForElementVisible ( "//span[@class='title-box ng-binding']", 3000, false, function ( editArtifact ) {
                                    if ( editArtifact.value == true ) {
                                      this.getText ( "//span[@class='title-box ng-binding']", function ( editArtifactName ) {
                                        if ( editArtifactName.value == excel.D[ excelColumn ] ) {
                                          this.getText ( '//div[@class="show-header-wrapper ng-scope"]/span', function ( tabName ) {
                                            if ( ignoreCase.equals ( tabName.value,artifactType ) ) {
                                              if ( excel.B[ excelColumn ] != "" ) {
                                                //Select the Language from the dropdown
                                                this.pause ( 5000 ).
                                                click ( "//span[@ng-if='!expand']" ).
                                                pause ( 5000 ).
                                                click ( '//div[@class="widget-pull-right ng-scope"]/i' ).
                                                pause ( 5000 ).
                                                click ( '//div/toggle-menu/div[1]/i' ).
                                                pause ( 5000 ).
                                                click ( '//div/toggle-menu/div[2]/ul/li[text()[normalize-space()="' + excel.B[ excelColumn ] + '"]]' ).
                                                pause ( 5000 ).
                                                click ( "//span[contains ( .,'ADD' )]" ).
                                                pause ( 5000 ).
                                                getText ( '//div[@class="widget-pull-left"]/span', function ( selectedLang ) {
                                                  if ( ignoreCase.equals ( selectedLang.value, excel.B[ excelColumn ] ) ) {
                                                    //Language selected successfully from the List
                                                    this.verify.ok ( true, "Language selected successfully" );
                                                    artifactpreCount++;
                                                    console.log ( "artifactpreCount",artifactpreCount );                                                    
                                                  }
                                                  else {
                                                    excel.AG.push ( 'FAIL' );
                                                    //write to fail status in excel as fail to select the Articles Language
                                                    this.verify.fail ( selectedLang.value, excel.B[ excelColumn ], 'Fail to select the Artifact Language' );
                                                    this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + selectedLang.value + "'. ExpectedResult: '" + excel.B[ excelColumn ] + "'( Fail to select the Articles Language)" );
                                                  }
                                                } );
                                              }
                                              //Upload the Thumbnail image from the system path
                                              this.waitForElementVisible ( '//div[@class="picture-container ng-scope"]/img', 5000, false, function ( ) {
                                                if ( excel.C[ excelColumn ] != "" && excel.C[ excelColumn ] != "Delete" ) {
                                                  this.pause ( 2000 ).
                                                  setValue ( '//div[@class="controls-container"]//*/span/input', require ( 'path' ).resolve ( excel.C[ excelColumn ] ) ).
                                                  pause ( 5000 ).
                                                  waitForElementPresent ( '//div[@id="my_modal"][@ng-if="imagePresent"]', 5000, false, function ( imageUpload ) {
                                                    if ( imageUpload.value.length != 0 ) {
                                                      this.verify.ok ( true, "Image uploaded successfully" );
                                                    }
                                                    else {
                                                      //write to fail status in excel as fail to upload the Articles Image
                                                      excel.AG.push ( 'FAIL' );
                                                      this.verify.fail ( imageUpload.value.length, 'not equal to zero', 'Fail to upload thumbnail Image' );
                                                      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "Fail to upload thumbnail Image" );
                                                    }
                                                  } );
                                                }
                                                else if ( excel.C[ excelColumn ] == "Delete" ) {
                                                  this.click ( '//span[@class="cell-options-dropdown"]' ).
                                                  pause ( 5000 ).
                                                  //Check the cancel button for uploading the thumbnail image
                                                  waitForElementVisible ( '//div[@class="flyout-menu-small dropdown-menu ng-scope"]//*/ng-transclude/i', 5000, false, function ( imgDeleteOption ) {
                                                    if ( imgDeleteOption.value == true ) {
                                                      this.click ( '//div[@class="flyout-menu-small dropdown-menu ng-scope"]//*/ng-transclude/i' ).
                                                      pause ( 5000 ).
                                                      click ( '//form/div/bx-image/*//toggle-menu/div/ng-include/*//span[@class ="cancel-btn"]' ).
                                                      pause ( 5000 ).
                                                      waitForElementPresent ( '//div[@id="my_modal"][@ng-if="imagePresent"]', 5000, false, function ( cancelBtn ) {
                                                        if ( cancelBtn.value.length == 0 ) {                                                            
                                                          excel.AG.push ( 'FAIL' );
                                                          this.verify.fail ( cancelBtn.value.length, 'not equal to zero', 'Cancel option is not working properly while clicking the delete button in thumbnail image' );
                                                          this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + cancelBtn.value.length + ". ExpectedResult: 'true'( Cancel option is not working properly while clicking the delete button in thumbnail image)" );
                                                        }
                                                      } );
                                                    }
                                                    else {
                                                      excel.AG.push ( 'FAIL' );
                                                      this.verify.fail ( imgDeleteOption.value, 'true', 'Fail to display the delete Button in the Thumbnail image toggle-menu' );
                                                      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + imgDeleteOption.value + ". ExpectedResult: 'true'( Fail to display the delete Button in the Thumbnail image toggle-menu)" );
                                                    }
                                                  } );
                                                  this.click ( '//span[@class="cell-options-dropdown"]' ).
                                                  pause ( 5000 ).
                                                  //Check the Delete button for uploading the thumbnail image
                                                  waitForElementVisible ( '//div[@class="flyout-menu-small dropdown-menu ng-scope"]//*/ng-transclude/i', 5000, false, function ( imgDeleteOptions ) {
                                                    if ( imgDeleteOptions.value == true ) {
                                                      this.click ( '//div[@class="flyout-menu-small dropdown-menu ng-scope"]//*/ng-transclude/i' ).
                                                      pause ( 5000 ).
                                                      click ( '//form/div/bx-image/*//toggle-menu/div/ng-include/*//span[@class ="confirm-btn"]' ).
                                                      pause ( 5000 ).
                                                      waitForElementNotPresent ( '//div[@id="my_modal"][@ng-if="imagePresent"]', 5000, false, function ( deleteBtn ) {
                                                        if ( deleteBtn.value.length != 0 ) {                                                            
                                                          excel.AG.push ( 'FAIL' );
                                                          this.verify.fail ( deleteBtn.value.length, 'not equal to zero', 'Delete option is not working properly while clicking the delete button in thumbnail image' );
                                                          this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "Delete option is not working properly while clicking the delete button in thumbnail image" );
                                                          }                                                            
                                                      } );
                                                    }
                                                    else {
                                                      excel.AG.push ( 'FAIL' );
                                                      this.verify.fail ( imgDeleteOptions.value, 'true', 'Fail to display the delete Button in the Thumbnail image toggle-menu' );
                                                      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + imgDeleteOptions.value + ". ExpectedResult: 'true'( Fail to display the delete Button in the Thumbnail image toggle-menu)" );
                                                    }
                                                  } );
                                                }
                                              } );
                                              //Edit the required label for the as custom commands
                                              this.artifactInput ( artifactType, excelInput, excelColumn, xlName, sheetName, xlRow, xlColumn, failureReasonColumn ).
                                              pause ( 5000 ).
                                              //Check the save button is visible
                                              waitForElementVisible ( "//button[contains ( .,'SAVE')]", 5000, false, function ( saveArticle ) {
                                                if ( excel.AG.indexOf ( 'FAIL' ) == -1 ) {
                                                  if ( saveArticle.value == true ) {
                                                    this.pause ( 5000 ).
                                                    click ( "//button[contains( .,'SAVE' )]" ).
                                                    pause ( 3000 ).
                                                    //Check the flash message display after clicking save button
                                                    waitForElementPresent ( "//header/ng-include/div/span", 1000, false, function ( alertMsg ) {
                                                      if ( alertMsg.value.length != 0 ) {
                                                        //get the flash message to confirm the Artifacts saved successfully
                                                        this.getText ( '//header/ng-include/div/span', function ( getSuccesMsg ) {
                                                          if ( getSuccesMsg.value == "Artifact Saved!" ) {
                                                            this.verify.ok ( true, "Artifact saved successfully" );
                                                            this.click ( "//span[contains(@class,'left-sidebar-text ng-binding portal expand')][text()='all content']" ).
                                                            pause ( 5000 ).
                                                            //Check the count of Artifacts 
                                                            getText ( '//span[@class="artifact-count-text ng-binding"]', function ( postCount ) {
                                                              var artifactpostCount = postCount.value.substr ( 0, postCount.value.lastIndexOf ( 'A' ) - 1 );
                                                              if ( artifactpreCount == artifactpostCount ) {
                                                                console.log ( "artifactpostCount", artifactpostCount );
                                                                excel.AG.push  ( 'FAIL' );
                                                                this.writeToExcelPass ( xlName, sheetName, xlRow, xlColumn );
                                                              }
                                                              else {
                                                                excel.AG.push ( 'FAIL' );
                                                                this.verify.fail ( artifactpostCount, artifactpreCount, 'Fail to edit the Artifacts' );
                                                                this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + artifactpostCount +"'. ExpectedResult: '" + artifactpreCount + "'( Fail to edit the Artifacts)" );
                                                              }
                                                            } );
                                                          }
                                                          else {
                                                            excel.AG.push ( 'FAIL' );
                                                            //write to fail status in excel as fail to edit Articles
                                                            this.verify.fail ( getSuccesMsg.value, "Artifact Saved!", 'Fail to generate the success msg once editing the Artifact' );
                                                            this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult:'" + getSuccesMsg.value + "' ExpectedResult: 'Artifact Saved!'( Fail to generate the success msg once editing the Artifact)" );
                                                          }
                                                        } );
                                                      }
                                                      else {
                                                        excel.AG.push ( 'FAIL' );
                                                        //write to fail status in excel as fail to generate the Flash msg once clicking save Button
                                                        this.verify.fail ( alertMsg.value.length, "not equal to zero", 'Fail to generate the Flash msg once clicking Save Button' );
                                                        this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "Fail to generate the Flash msg once clicking Save Button)" );
                                                      }
                                                    } );
                                                  }
                                                  else {
                                                    excel.AG.push ( 'FAIL' );
                                                    //write to fail status in excel as fail in the visibility of save button in the artifact page
                                                    this.verify.fail ( saveArticle.value, true, 'Fail in the visibility of Save button in the artifact page' );
                                                    this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + saveArticle.value + ". ExpectedResult: 'true'( Fail in the visibility of save button in the artifact page)" );
                                                  }
                                                }
                                              } );                                                
                                            }
                                            else {
                                              excel.AG.push ( 'FAIL' );
                                              //write the status as Fail to display the expected Tab name for the Searched Artifact
                                              this.verify.fail ( tabName.value, artifactType, 'Fail to display the expected Tab name for the Searched Artifact' );
                                              this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + tabName.value + ". ExpectedResult: '" + artifactType + "'( Fail to display the expected Tab name for the Searched Artifact)" );
                                            }
                                          } );
                                        }
                                        else {
                                          excel.AG.push ( 'FAIL' );
                                          //write the status as Fail to display the expected Artifact name after clicking the Searched Artifact
                                          this.verify.fail ( editArtifactName.value, excel.D[ excelColumn ], 'Fail to display the expected Artifact name after clicking the Searched Artifact' );
                                          this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + editArtifactName.value + ". ExpectedResult: '" + excel.D[ excelColumn ] + "'( Fail to display the expected Artifact name after clicking the Searched Artifact)" );
                                        }
                                      } );
                                    }
                                    else {
                                      excel.AG.push ( 'FAIL' );
                                      //write the status as Fail to display the heading for the Searched Artifact
                                      this.verify.fail ( editArtifact.value, true, 'Fail to display the heading for the Searched Artifact' );
                                      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + editArtifact.value + ". ExpectedResult: 'true' ( Fail to display the heading for the Searched Artifact)" );
                                    }
                                  } );   
                                }
                                else if ( indexValue == searchCount.value.length ) {
                                  //write to fail status as Searched Artifact for Artifact category is not present in the list
                                  this.verify.fail ( categoryType.value, 'Article', 'Searched Artifact for category is not present in the list' );
                                  this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + categoryType.value + ". ExpectedResult: 'Article'(Searched Artifact for category is not present in the list)" );
                                }
                              } );
                            }
                          } );
                        }
                      } );
                    } );
                  }
                  else {
                    //write to fail status as searched Artifact is not Present
                    this.verify.fail ( searchArtifact.value, 'true', 'Searched Artifact is not present in the list' );
                    this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + searchArtifact.value + ". ExpectedResult: 'true'(Searched Artifact is not present in the list)" );
                  }
                } );
              }
              else {
                //write to fail status as Search textbox is not visible after clicking All contents
                this.verify.fail ( searchIcon.value, true, 'Search textbox is not visible after clicking All contents' );
                this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + searchIcon.value + ". ExpectedResult: 'true'(Search textbox is not visible after clicking All contents)" );
              }
            } );
          } );
        }
        else {
          //write to fail status as Fail to display the Artifact count in all contents
          this.verify.fail ( artifactCount.value, true, 'Fail to display the Artifact count in all contents' );
          this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + artifactCount.value + ". ExpectedResult: 'true'(Fail to display the Artifact count in all contents)" );
        }
      } );
    }
    else {
      //write to fail status as All content side bar element is not visible
      this.verify.fail ( allContent.value, true, 'All content side bar element is not visible' );
      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + allContent.value + ". ExpectedResult: 'true'(All content side bar element is not visible)" );
    }
  } );
  return this;
};

//this function is for check and add properties in Video URL
var Excel = require ( 'exceljs-rtl' );
var workbook = new Excel.Workbook( );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
exports.command = function ( author, attribution ) {
  var checkResult = this.globals.excelCol.resultCustomData;
  this.pause ( 3000 ).
  waitForElementVisible ( ".attribution-container>a[ng-click='showAddAuthor()']", 9000, false, function ( checkAuthor ) {
    if ( checkAuthor.value == true ) {
      //Check the Authors field is visible
      this.pause ( 7000 ).
      verify.visible ( ".attribution-container>a[ng-click='showAddAuthor()']" ).
      //Click on the Authors dropdown
      click ( ".attribution-container>a[ng-click='showAddAuthor()']" ).
      pause ( 7000 ).useXpath( ).
      verify.visible ( '//input[@placeholder ="Search authors"]' ).
      pause ( 7000 ).
      //Enter the author name in the search field
      setValue ( '//input[@placeholder ="Search authors"]', author.trim( ) ).
      pause ( 7000 ).useXpath( ).
      waitForElementVisible ( "//ul/li/a/span[ text( ) = '"+ author.trim( ) +"']", 9000, false, function ( checkAuthorLst ) {
        if ( checkAuthorLst.value == true ) {
          //Click on the Authors dropdown option
          this.useXpath( ).click ( "//ul/li/a/span[ text( ) = '"+ author.trim( ) +"']" ).
          pause ( 7000 ).useCss( )
          checkResult.push ( 'PASS' );
        }
        else {
          checkResult.push ( 'FAIL' );
          this.pause ( 7000 ).useXpath( ).
          getText ( "//div/div/dialog-include[2]/dialog/section/h1", function ( authorName ) {
            if ( authorName.value == "Add Author" ) {
              this.pause ( 7000 ).useXpath( ).
              verify.visible ( "//div/div/dialog-include[2]/dialog/section/h1/i[@class='ss-icon ss-gizmo close-icon pull-right']" ).
              pause ( 7000 ).
              click ( "//div/div/dialog-include[2]/dialog/section/h1/i[@class='ss-icon ss-gizmo close-icon pull-right']" )
            }
          } );
        }
      } );
      //Select Attribution
      this.pause ( 7000 ).useXpath( ).
      waitForElementVisible ( "//section[2]/ng-include/div[4]/div/div[1]/a[2]/i", 9000, false, function ( attributeValue ) {
        var attributeValueset = attributeValue.value;
        if ( attributeValueset == true ) {
          this.pause ( 7000 ).useCss ( ).
          //Check the attribution field is visible
          verify.visible ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
          pause ( 7000 ).
          //Click on the attribution dropdown option
          click ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
          pause ( 7000 ).useXpath( ).
          //Enter the attribution name in the search field
          setValue ( '//input[@placeholder ="Search attributions"]', attribution.trim( ) ).
          pause ( 7000 ).
          waitForElementVisible ( "//ul/li/a/span[text( )[normalize-space(.)='"+ attribution.trim( ) +"']]", 9000, false, function ( checkAttributeLst ) {
            console.log ( "checkAttributeLst", checkAttributeLst )
            if ( checkAttributeLst.value == true ) {
              this.pause ( 4000 ).
              //Click on the attribution dropdown option
              click ( "//ul/li/a/span[text( )[normalize-space(.)='"+ attribution.trim( ) +"']]" ).
              pause ( 7000 ).useCss ( )
              checkResult.push ( 'PASS' );
            }
            else {
              console.log ( "Attribution is not displayed in the dropdown list", checkAttributeLst.value );
              checkResult.push ( 'FAIL' );
              this.pause ( 7000 ).useXpath( ).
              getText ( "//div/div/dialog-include[1]/dialog/section/h1", function ( attributeName ) {
                if ( attributeName.value == "Add Attribution" ) {
                  this.useXpath( ).verify.visible ( "//div/div/dialog-include[1]/dialog/section/h1/i[@class='ss-icon ss-gizmo close-icon pull-right']" ).
                  pause ( 7000 ).
                  click ( "//div/div/dialog-include[1]/dialog/section/h1/i[@class='ss-icon ss-gizmo close-icon pull-right']" )
                }
              } );
            }
          } );          
        }
        else {          
          this.useXpath().pause( 5000 ).waitForElementVisible("//*/section[2]/ng-include/div[4]/div/div[1]",9000,false, function ( checkAttributeField ) {
            if ( checkAttributeField.value == true ) {
              this.useXpath().pause( 5000 ).waitForElementVisible("//*/section[2]/ng-include/div[4]/div/div[1]/a/i",9000,false, function ( checkPlusSign ) {
                if ( checkPlusSign.value == true ) {
                  this.pause ( 7000 ).useCss ( ).
                  //Check the attribution field is visible
                  verify.visible ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
                  pause ( 7000 ).
                  //Click on the attribution dropdown option
                  click ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
                  pause ( 7000 ).useXpath( ).
                  //Enter the attribution name in the search field
                  setValue ( '//input[@placeholder ="Search attributions"]', attribution.trim( ) ).
                  pause ( 7000 ).
                  waitForElementVisible ( "//ul/li/a/span[text( )[normalize-space(.)='"+ attribution.trim( ) +"']]", 9000, false, function ( checkAttributeList ) {
                    console.log ( "checkAttributeList", checkAttributeList )
                    if ( checkAttributeList.value == true ) {
                      this.pause ( 4000 ).
                      //Click on the attribution dropdown option
                      click ( "//ul/li/a/span[text( )[normalize-space(.)='"+ attribution.trim( ) +"']]" ).
                      pause ( 7000 ).useCss( )
                      checkResult.push ( 'PASS' );
                    }
                    else {
                      console.log ( "Attribution is not displayed in the dropdown list", checkAttributeList.value );
                      checkResult.push ( 'FAIL' );
                      this.pause ( 7000 ).useXpath( ).
                      getText ( "//div/div/dialog-include[1]/dialog/section/h1", function ( attributeName ) {
                        if ( attributeName.value == "Add Attribution" ) {
                          this.useXpath( ).verify.visible ( "//div/div/dialog-include[1]/dialog/section/h1/i[@class='ss-icon ss-gizmo close-icon pull-right']" ).
                          pause ( 7000 ).
                          click ( "//div/div/dialog-include[1]/dialog/section/h1/i[@class='ss-icon ss-gizmo close-icon pull-right']" )
                        }
                      } );
                    }
                  } );
                }
                else {
                  this.useXpath().pause( 5000 ).waitForElementVisible("//*/section[2]/ng-include/div[4]/div/div[1]/p",9000,false, function ( checkAttributeAvail ) {
                    if ( checkAttributeAvail.value == true ) {
                      console.log ( "Attribution is already Exists" );
                      checkResult.push ( 'PASS' );
                    }
                    else {
                      checkResult.push ( 'FAIL' );
                    }
                  } );
                }
              } );
            }
          } );          
        }
      } );
    }
    else {
      console.log ( "Authors is not displayed" );
      checkResult.push ( 'FAIL' );
    }
  } ); 
  return this;
};
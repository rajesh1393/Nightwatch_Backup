//this command is for adding New Artifact of all type 
exports.command = function ( artifactType, excelInput, excelColumn, xlName, sheetName, xlRow, xlColumn, failureReasonColumn ) {
  //Access the variable globally defined
  var excel = this.globals.excelCol;
  var ignoreCase = require ( 'ignore-case' );
  this.useXpath ( ).
  //Wait and click the All contents to add new Artifacts 
  waitForElementVisible ( "//span[contains(@class,'left-sidebar-text expand')][text()='all content']", 6000, false, function ( allContent ) {
    if ( allContent.value == true ) {
      this.click ( "//span[contains(@class,'left-sidebar-text expand')][text()='all content']" ).
      //Get the Artifact count before Adding new Artifacts
      waitForElementVisible ( '//span[@class="artifact-count-text ng-binding"]', 5000, false, function ( artifactCount ) {
        if ( artifactCount.value == true ) {
          this.getText ( '//span[@class="artifact-count-text ng-binding"]', function ( preCount ) {
            //Extract the Artifact count alone from the fetched artifact text & numbers
            var artifactpreCount = preCount.value.substr ( 0, preCount.value.lastIndexOf ( 'A' ) - 1 );
            console.log ( "artifactpreCount", artifactpreCount );
            //Wait and click the Add new button in Artifacts
            this.waitForElementVisible ( "//div[@tooltip='Add New']", 6000, false, function ( plusIcon ) {
              if ( plusIcon.value == true ) {
                this.click ( "//div[@tooltip='Add New']" ).
                pause ( 5000 ).
                //Click the New Artifact button in the list
                click ( "//li[@ng-click='toCreateArtifactForm()']" ).
                pause ( 5000 ).
                //Click the radio button in the listed Artifact types
                waitForElementVisible ( '//div[@class="submit-button-section"]/button[1]', 5000, false, function ( artifactBtn ) {
                  if ( artifactBtn.value == true ) {
                    this.pause ( 5000 ).
                    getLocationInView ( '//div[@class="radio-button"]/label[2][@for="' + artifactType + '"]' ).
                    //Click the Artifact type get from the excel 
                    click ( '//div[@class="radio-button"]/label[2][@for="' + artifactType + '"]' ).
                    keys ( this.Keys.PAGEUP ).pause ( 5000 ).
                    //click the next button after clicking radio button
                    click ( '//div[@class="submit-button-section"]/button[1]' ).
                    pause ( 5000 ).
                    //check the next button redirect to the page to create a new Artifact
                    waitForElementVisible ( "//span[@class='title-box ng-binding']", 3000, false, function ( addNewArtifact ) {
                      if ( addNewArtifact.value == true ) {
                        this.pause ( 5000 ).
                        //Select the Language from the dropdown
                        click ( "//span[@ng-if='!expand']" ).
                        pause ( 5000 ).
                        click ( '//div[@class="languages-scrollbox ng-scope expand"]/div/div[text()="' + excel.A[ excelColumn ] + '"]' ).
                        getText ( '//div[@class="widget-pull-left"]/span', function ( selectedLang ) {
                          if ( ignoreCase.equals ( selectedLang.value, excel.A[ excelColumn ] ) ) {
                            //Language selected successfully from the List
                            this.verify.ok ( true, "Language selected successfully" );
                            //Upload the Thumbnail image from the system path 
                            this.waitForElementVisible ( '//div[@class="picture-container ng-scope"]/img', 5000, false, function ( ) {
                              if ( excel.B[ excelColumn ] != "" ) {
                                this.pause ( 2000 ).
                                setValue ( '//div[@class="controls-container"]//*/span/input', require ( 'path' ).resolve ( excel.B[ excelColumn ] ) ).
                                pause ( 2000 ).
                                waitForElementPresent ( '//div[@id="my_modal"][@ng-if="imagePresent"]', 5000, false, function ( imageUpload ) {
                                  if ( imageUpload.value.length != null ) {
                                    this.verify.ok ( true, "Image uploaded successfully" );
                                  }
                                  else {
                                    //write to fail status in excel as fail to upload the Articles Image
                                    excel.AG.push ( 'FAIL' );
                                    this.verify.fail ( imageUpload.value.length, 'not equal to null', 'Fail to upload thumbnail Image' );
                                    this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + imageUpload.value + ". ExpectedResult: 'true' ( Fail to upload thumbnail Image )" );
                                  }
                                } );
                              }
                            } );
                            //Add the required label for the newly create artifact as custom commands
                            this.artifactInput ( artifactType, excelInput, excelColumn, xlName, sheetName, xlRow, xlColumn, failureReasonColumn ).
                            pause ( 5000 ).
                            //Check the create button is visible
                            waitForElementVisible ( "//button[contains(.,'CREATE' )]", 5000, false, function ( createArticle ) {
                              if ( excel.AG.indexOf ( 'FAIL' ) == -1 ) {
                                if ( createArticle.value == true ) {
                                  this.pause ( 5000 ).
                                  click ( "//button[contains ( .,'CREATE')]" ).
                                  pause ( 3000 ).
                                  //Check the flash message display after clicking create button
                                  waitForElementPresent ( "//header/ng-include/div/span", 500, false, function ( alertMsg ) {
                                    if ( alertMsg.value.length != null ) {
                                      //get the flash message to confirm the Artifacts created successfully
                                      this.getText ( '//header/ng-include/div/span', function ( getSuccesMsg ) {
                                        if ( getSuccesMsg.value == "Artifact Saved!" ) {
                                          this.verify.ok ( true, "Artifact created successfully" );
                                          //Check the "Create At" & "Updated At" field generated once the Artifact created
                                          this.waitForElementVisible ( '//bx-date-input/*/*[text()="Created At"]', 5000, false, function ( createdAtTxtbx ) {
                                            if ( createdAtTxtbx.value == true ) {
                                              this.waitForElementVisible ( '//bx-date-input/*/*[text()="Updated At"]', 5000, false, function ( updatedAtTxtbx ) {
                                                if ( updatedAtTxtbx.value == true ) {
                                                  this.click ( "//span[contains(@class,'left-sidebar-text expand')][text()='all content']" ).
                                                  pause ( 5000 ).
                                                  //Check the count of Artifacts increased 
                                                  getText ( '//span[@class="artifact-count-text ng-binding"]', function ( postCount ) {
                                                    var artifactpostCount = postCount.value.substr ( 0, postCount.value.lastIndexOf ( 'A' ) - 1 );
                                                    if ( artifactpreCount == parseInt ( artifactpostCount ) - 1 ) {
                                                      console.log ( "artifactpostCount", artifactpostCount );
                                                      this.writeToExcelPass ( xlName, sheetName, xlRow, xlColumn );
                                                    }
                                                    else {
                                                      this.verify.fail ( parseInt ( artifactpostCount ) - 1, artifactpreCount, 'Fail to add the Artifacts' );
                                                      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + parseInt ( postCount ) - 1 + "'. ExpectedResult: '" + artifactpreCount + "' ( Fail to add the Artifacts )" );
                                                    }
                                                  } );
                                                }
                                                else {
                                                  //write to failure status in excel as fail to generate the updatedAt time after artifacts created 
                                                  this.verify.fail ( updatedAtTxtbx.value, true, 'Fail to generate the updatedAt time after artifacts created' );
                                                  this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + updatedAtTxtbx.value + ". ExpectedResult: 'true' ( Fail to generate the updatedAt time after artifacts created )" );
                                                }
                                              } );
                                            }
                                            else {
                                              //write to failure status in excel as fail to generate the createdAt time after artifacts created 
                                              this.verify.fail ( createdAtTxtbx.value, true, 'Fail to generate the createdAt time after artifacts created' );
                                              this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + createdAtTxtbx.value + ". ExpectedResult: 'true' ( Fail to generate the createdAt time after artifacts created )" );
                                            }
                                          } );
                                        }
                                        else {
                                          //write to fail status in excel as fail to create new Articles
                                          this.verify.fail ( getSuccesMsg.value, "Artifact Saved!", 'Fail to generate the success msg once creating the Artifact' );
                                          this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult:'" + getSuccesMsg.value + "' ExpectedResult: 'Artifact Saved!' ( Fail to generate the success msg once creating the Artifact )" );
                                        }
                                      } );
                                    }
                                    else {
                                      //write to fail status in excel as fail to generate the Flash msg once clicking Create Button
                                      this.verify.fail ( alertMsg.value.length, "not equal to null", 'Fail to generate the Flash msg once clicking Create Button' );
                                      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "Fail to generate the Flash msg once clicking Create Button )" );
                                    }
                                  } );
                                }
                                else {
                                  //write to fail status in excel as fail in the visibility of Create button in the artifact page
                                  this.verify.fail ( createArticle.value, true, 'Fail in the visibility of Create button in the artifact page' );
                                  this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + createArticle.value + ". ExpectedResult: 'true' ( Fail in the visibility of Create button in the artifact page )" );
                                }
                              }
                            } );
                          }
                          else {
                            //write to fail status in excel as fail to select the Articles Language
                            this.verify.fail ( selectedLang.value, excel.A[ excelColumn ], 'Fail to select the Artifact Language' );
                            this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + selectedLang.value + "'. ExpectedResult: '" + excel.A[ excelColumn ] + "' ( Fail to select the Articles Language )" );
                          }
                        } );
                      }
                      else {
                        //write to fail status in excel as fail to redirect to New Artifact page
                        this.verify.fail ( addNewArtifact.value, true, 'Fail to redirect to New Artifact page' );
                        this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + addNewArtifact.value + ". ExpectedResult: 'true' ( Fail to redirect to New Artifact page )" );
                      }
                    } );
                  }
                  else {
                    //write to fail status as of Timeout issue or fail due to the Artifact next button is not visible
                    this.verify.fail ( artifactBtn.value, true, 'Timeout issue or "Next" button is not visible while creating Artifact' );
                    this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + artifactBtn.value + ". ExpectedResult: 'true' ( Timeout issue or 'Next' button is not visible while creating Artifact )" );
                  }
                } );
              }
              else {
                //write to fail status as of Timeout issue or fail due to the Add Article plus icon is not visible
                this.verify.fail ( plusIcon.value, true, 'Timeout issue or fail due to the Add Article plus icon is not visible' );
                this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + plusIcon.value + ". ExpectedResult: 'true' ( Timeout issue or fail due to the Add Article plus icon is not visible )" );
              }
            } );
          } );
        }
        else {
          //write to fail status as Fail to display the Artifact count in all contents
          this.verify.fail ( artifactCount.value, true, 'Fail to display the Artifact count in all contents' );
          articlesDelete.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + artifactCount.value + ". ExpectedResult: 'true' ( Fail to display the Artifact count in all contents )" );
        }
      } );
    }
    else {
      //write to fail status as All content side bar element is not visible
      this.verify.fail ( allContent.value, true, 'All content side bar element is not visible' );
      this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, "ActualResult: '" + allContent.value + ". ExpectedResult: 'true' ( All content side bar element is not visible )" );
    }
  } );
  return this;
};
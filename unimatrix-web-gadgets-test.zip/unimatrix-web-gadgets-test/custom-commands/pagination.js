//this function is to check the pagination functionality
var currentPagelistNext = [ ];
var currentPagelistPrevious = [ ];
var currentCountNext;
var totalCount;
var paginationCount;
var currentCountPrevious;
exports.command = function ( excelName, sheetName, excelRowCount, excelColumnNumber, excelStatusColumn )  {
  this.
  pause ( 5000 ).
  useXpath ( ).
  //Checking whether the Page has an empty list
  waitForElementVisible ( "//DIV[@class ='pagination ng-scope']", 16000, false, function ( getStatus )  {
    //If the Page conatins list then control flows in if loop and goes on.   
    if ( getStatus.value == true )  {
      this.
      useXpath ( ).
      //Moving controller to the last page of the page 
      moveToElement ( '//div[@class="pagination ng-scope"]/ul/li/a[@class="ng-binding"]', 0, 0 ).
      //Checking the element is present
      waitForElementPresent ( '//div[@class="pagination ng-scope"]/ul/li/a[@class="ng-binding"]', 9000, false ).
      //Getting the Total number of pages to be checked.
      getText ( '//div[@class="pagination ng-scope"]/ul/li/a[@class="ng-binding"]', function ( getResult )  {
        var paginationRaw = getResult.value;
        paginationCount = paginationRaw.slice ( 0, -1 ) 
        this.
        pause ( 10000 ).
        //Checking whether the 1st of the Pagination is displayed.
        waitForElementPresent ( "//A[@ng-if='currentPage == page'][text ( ) ='1']", 10000, false ).
        //Checking whether the 2nd of the Pagination is displayed.
        waitForElementPresent ( "//A[@ng-click='nextPage ( currentPage ) '][text ( ) ='2']", 10000, false ).
        useCss ( ).
        //Checking the total count of the List page
        getText ( '.content-count > strong', function ( currentCountResult )  {
          //Storing the total count in the totalCount variable
          var rawTotalCount = currentCountResult.value;
          totalCount = rawTotalCount.replace ( /[^A-Z0-9]/ig, "" );
        } );
        this.
        //Getting the Total count of the List in the list page
        elements ( "xpath", "//div[@class='content-title']/h2", function ( result )  {
          //Storing the Count in the currentPagelist array.
          currentPagelistNext.push ( result.value.length );
        } );
        //Checking the pagination count is greater than 2
        if ( paginationCount >= 2 )  {
          //Looping untill last page of the Pagination
          for ( var rowCount = 1; rowCount <= paginationCount - 1; rowCount++ )  {
            this.
            pause ( 8000 ).
            useXpath ( ).
            //Clicking the Next page navigation key
            click ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='▻']" ).
            pause ( 10000 ).
            useCss ( ).
            //Getting the Active page number to compare with previous one
            getText ( ".pagination.active.ng-binding.ng-scope", function ( getActiveElement )  {
              var activePageNumber = getActiveElement.value;
              //Checking whether the Next button is Working
              if ( activePageNumber != rowCount )  {
                this.
                useXpath ( ).
                //Checking whether the LastPage button is visible.
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏭']", 10000, false ).
                //Checking whether the Next button is visible.
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='▻']", 10000, false );
              }
              //Checking whether the Last page is not containing the Next button
              else {
                this.
                //Checking whether the Next button is not visible while in last page
                waitForElementNotPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏭']", 10000, false ).
                //Checking whether the Next button is not visible while in last page
                waitForElementNotPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='▻']", 10000, false );
              }
            } );
            this.
            useXpath ( ).
            //Checking whether the Previous button is visible.
            waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='◅']", 5000, false ).
            //Checking whether the First Page button is visible.
            waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏮']", 5000, false ).
            //Appending the Total number of items in a page
            elements ( "xpath", "//div[@class='content-title']/h2", function ( result )  {
              currentPagelistNext.push ( result.value.length );
              function add ( a, b )  {
                return a + b;
              }
              currentCountNext = currentPagelistNext.reduce ( add );
            } );
          }
          this.
          pause ( 5000 ).
          useCss ( ).
          waitForElementPresent ( ".pagination.active.ng-binding.ng-scope", 5000, false ).
          getText ( ".pagination.active.ng-binding.ng-scope", function ( getActiveElement )  {
            var activePageNumber = getActiveElement.value;
            //Checking whether the Pagewise list count is equal to Total count
            if ( activePageNumber == parseInt ( paginationCount ) )  {
              this.
              //Writing the Pass status to excel sheet
              writeToExcelPass ( excelName, sheetName, excelRowCount, excelColumnNumber );
            }
            else {
              this.
              //Writing the Fail status to excel sheet
              writeToExcelFail ( excelName, sheetName, excelRowCount, excelColumnNumber, excelStatusColumn, "Next page button functionality is not working" );
            }
          } );
          //Checking the Previous page functionality
          for ( var previousPage = paginationCount; previousPage > 1; previousPage-- )  {
            this.
            pause ( 8000 ).
            useXpath ( ).
            //Clicking the Next page navigation key
            click ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='◅']" ).
            pause ( 10000 ).
            useCss ( ).
            getText ( ".pagination.active.ng-binding.ng-scope", function ( getActiveElement )  {
              var activePageNumber = getActiveElement.value;
              //Checking whether the Previous button is Working
              if ( activePageNumber == paginationCount )  {
                this.
                useXpath ( ).
                //Checking whether the Next button is not visible while in last page
                waitForElementNotPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏭']", 10000, false ).
                //Checking whether the Next button is not visible while in last page
                waitForElementNotPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='▻']", 10000, false );
              }
              //Checking whether the Last page is not containing the Next button
              else if ( activePageNumber == 1 )  {
                this.
                useXpath ( ).
                //Checking whether the LastPage button is visible.
                waitForElementNotPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='◅']", 10000, false ).
                //Checking whether the Next button is visible.
                waitForElementNotPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏮']", 10000, false ).
                //Checking whether the Next button is visible.
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏭']", 10000, false ).
                //Checking whether the Next button is visible while in last page
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='▻']", 10000, false );
              }
              else {
                this.
                useXpath ( ).
                //Checking whether the Last Page button is visible.
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='◅']", 10000, false ).
                //Checking whether the Next button is visible.
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏮']", 10000, false ).
                //Checking whether the Next button is visible.
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏭']", 10000, false ).
                //Checking whether the Next button is visible.
                waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='▻']", 10000, false );
              }
            } );
          }
          this.
          pause ( 5000 ).
          useCss ( ).
          waitForElementPresent ( ".pagination.active.ng-binding.ng-scope", 500000, false ).
          getText ( ".pagination.active.ng-binding.ng-scope", function ( getActiveElement )  {
            var activePageNumber = getActiveElement.value;
            //Checking whether the Pagewise list count is equal to Total count
            if ( activePageNumber == "1" )  {
              this.
              //Writing the Pass status to excel sheet
              writeToExcelPass ( excelName, sheetName, ++excelRowCount, excelColumnNumber );
            }
            else {
              this.
              //Writing the Fail status to excel sheet
              writeToExcelFail ( excelName, sheetName, ++excelRowCount, excelColumnNumber, excelStatusColumn, "Previous page button functionality is not working" );
            }
          } );
        }
        //If the Pagination count is lessthan 2 then control flows to else loop 
        else {
          this.
          //Writing the Fail status to excel sheet
          writeToExcelFail ( excelName, sheetName, excelRowCount, excelColumnNumber, excelStatusColumn, "Only one page is visible,No more pages to check" );
        }
        this.
        pause ( 10000 ).
        useCss ( ).
        verify.visible ( '.pagination > ul:nth-child ( 1 )  > li:nth-child ( 1 )  > a:nth-child ( 1 ) ' ).
        //Clicking the navigation to firstpage from last page.
        click ( '.pagination > ul:nth-child ( 1 )  > li:nth-child ( 1 )  > a:nth-child ( 1 ) ' ).
        pause ( 5000 ).
        getText ( ".pagination.active.ng-binding.ng-scope", function ( getActiveElement )  {
          var activePageNumber = getActiveElement.value;
          if ( activePageNumber == 1 )  {
            this.
            //Writing the Pass status to excel sheet
            writeToExcelPass ( excelName, sheetName, ++excelRowCount, excelColumnNumber );
          }
          else {
            this.
            //Writing the Fail status to excel sheet
            writeToExcelFail ( excelName, sheetName, ++excelRowCount, excelColumnNumber, excelStatusColumn, "Navigation to first page from last page failed" );
          }
        } );
        this.
        pause ( 5000 ).
        useXpath ( ).
        //Checking the Last page navigation key visibility
        waitForElementPresent ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏭']", 5000, false ).
        //Clicking the Last page navigation key
        click ( "//I[@class='ss-icon ss=gizmo'][text ( ) ='⏭'] " ).
        pause ( 10000 ).
        useCss ( ).
        //Getting the Active page number 
        getText ( ".pagination.active.ng-binding.ng-scope", function ( getActiveElement )  {
          var activePageNumber = getActiveElement.value;
          //Checking whether the Pagination count is equal to Active page number.
          if ( activePageNumber == parseInt ( paginationCount ) )  {
            //Writing the Pass status in the Excel Sheet
            this.
            //Writing the Pass status to excel sheet
            writeToExcelPass ( excelName, sheetName, ++excelRowCount, excelColumnNumber );
          }
          else {
            //Writing the Fail status in Excel sheet
            this.
            //Writing the Fail status to excel sheet
            writeToExcelFail ( excelName, sheetName, ++excelRowCount, excelColumnNumber, excelStatusColumn, "Navigation to last page failed" );
          }
        } );
        return this;
      } );
    }
    else {
      this.
      writeToExcelFail ( excelName, sheetName, ++excelRowCount, excelColumnNumber, excelStatusColumn, "Unable to Test because no pagination numbers found" );
    }
  } ) 
}
//this function is for analytics login and check to change THEME
exports.command = function ( uri, username, password, application ) {
  this.url ( uri ).
  //waiting for Portal body presence
  waitForElementVisible ( 'body', 3000 ).
  //Entering Username in the login page
  setValue ( 'input[ type=email ]', username ).
  //Entering Password in the login page
  setValue ( 'input[ type=password ]', password ).
  //wait and click on submit button in the login page
  waitForElementVisible ( 'input[ name=commit ]', 3000, false ).
  click ( 'input[ name=commit ]' ).  
  //verify the Portal body presence
  verify.elementPresent ( "body" ).
  pause ( 3000 ).
  waitForElementVisible ( '.boxx-resource-server-title', 9000, false ).
  getText ( ".boxx-resource-server-title", function ( getTitle) { 
    if ( getTitle.value == application ) {  
      // wait and verify Current theme presence
      this.pause ( 3000 ).
      useXpath ( ).
      waitForElementVisible ( "/html/body/div[2]/*//div[1]/span[@class='property-name ng-binding']", 15000, false ).
      pause ( 9000 ).
      //Get the Actual Theme in the page
      getText ( "/html/body/div[2]/*//div[1]/span[@class='property-name ng-binding']", function ( checkTheme ) {
        var expectedTheme = "SPORTSROCKET AUTO QA";
        var actualTheme = checkTheme.value;
        console.log ( "ActualTheme: ",actualTheme );
        if ( actualTheme != expectedTheme ) {      
          this.pause ( 3000 ).
          //Verify the Hamburger menu is visible
          verify.visible ( "html/body/div[2]/*//img[@class='hamburger']" ).
          pause ( 3000 ).
          //Click on the Hamburger menu
          click ( "html/body/div[2]/*//img[@class='hamburger']" ).
          pause ( 3000 ).
          //wait and search the themes in the property
          waitForElementVisible ( "/html/body/div[2]/*//input[@type='text']", 3000 , false).
          pause ( 3000 ).
          //Enter the data in the search input field
          setValue ( "/html/body/div[2]/*//input[@type='text']", 'SPORTSROCKET AUTO QA' ).
          pause ( 3000 ).
          waitForElementVisible ( "html/body/div[2]/*//span[2][contains(.,'Sportsrocket Auto QA')]", 9000 , false).
          pause(9000).
          //click on the searched theme
          click ( "html/body/div[2]/*//span[2][contains(.,'Sportsrocket Auto QA')]" ).
          pause ( 3000 ).
          //check and verify the current Theme in the property
          verify.containsText ( "/html/body/div[2]/*//div[1]/span[@class='property-name ng-binding']", "SPORTSROCKET AUTO QA" );
        }        
      } );
    }
    else {
      this.verify.fail ( getTitle.value, "ANALYTICS", 'Error in the Title' );
    }
  } );
  return this;
};
//this command is for adding the label to new Artifact
exports.command = function ( artifactType, excelInput, excelColumn, xlName, sheetName, xlRow, xlColumn, failureReasonColumn ) {
  //Access the variable globally defined
  var excel = this.globals.excelCol;
  var date = Date.now ( );
  if ( excel.AG.indexOf ( 'FAIL' ) == -1 ) {
    //Pass the label to the New Artifact field
    for ( let incrNo = 3; incrNo <= excelInput; incrNo++ ) {
      var objKey = Object.keys ( excel )[ incrNo ];
      var objValue = excel[ objKey ];      
      this.clearValue ( '//form/div//*[@name="'+ objValue[ 0 ] +'"]' );
      //Set the Value to the Artifact of different label
      if ( objValue[0] != "Provider Uid" ) {
        this.setValue ( '//form/div//*[@name="'+ objValue[ 0 ] +'"]', objValue[ excelColumn ] );
      }
      else {
        this.setValue ( '//form/div//*[@name="'+ objValue[ 0 ] +'"]', objValue[ excelColumn ] + date );
      }
      if ( incrNo === excelInput ) {
        //check the visibility of the Categories field and set value
        this.waitForElementVisible ( "//bx-chip-input[@label='Categories']/div/div/div/div/input", 2000, false, function ( artifactCategories ) {
          if ( artifactCategories.value == true ) {
            if ( artifactType != "Isp Video" ) {
              this.click ( "//bx-chip-input[@label='Categories']/div/div/div/div/input" ).             
              pause ( 2000 ).
              clearValue ( "//bx-chip-input[@label='Categories']/div/div/div/div/input" ).
              setValue ( "//bx-chip-input[@label='Categories']/div/div/div/div/input", excel.P[ excelColumn ] ).
              keys ( this.Keys.ENTER );
            }
            else {
             //Set the Categories value and Choose the checkbox for the label "Is live" in Isp video artifact
             this.click ( "//bx-chip-input[@label='Categories']/div/div/div/div/input" ).
             pause ( 2000 ).
             clearValue ( "//bx-chip-input[@label='Categories']/div/div/div/div/input" ).
             setValue ( "//bx-chip-input[@label='Categories']/div/div/div/div/input", excel.AB[ excelColumn ] ).
             keys ( this.Keys.ENTER ).
             getLocationInView ( '//form/div//label[2][@for="Is Live_' + excel.AA[ excelColumn ] + '"]' ).
             click ( '//form/div//label[2][@for="Is Live_' + excel.AA[ excelColumn ] + '"]' ).
             pause ( 2000 );
            }
          }
          else {
            //Write to excel as Fail in the visibility of the Artifact label Categories
            excel.AG.push ( 'FAIL' );
            this.verify.fail ( artifactCategories.value, 'true', 'Fail in the visibility of the Artifact label Categories' );
            this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, 'Fail in the visibility of the Artifact label Categories' );
          }
        } );
        //check the visibility of the Component Uuids field and set value
        this.waitForElementVisible ( "//relationship-widget[1]/bx-chip-input[@class='ng-isolate-scope']/*//input", 2000, false, function ( artifactComponent ) {
          if ( artifactComponent.value == true ) {
            if ( artifactType != "Isp Video" ) {
              this.click ( "//relationship-widget[1]/bx-chip-input[@class='ng-isolate-scope']/*//input" ).
              pause ( 2000 ).
              clearValue ( "//relationship-widget[1]/bx-chip-input[@class='ng-isolate-scope']/*//input" ).
              setValue ( "//relationship-widget[1]/bx-chip-input[@class='ng-isolate-scope']/*//input", excel.Q[ excelColumn ] ).
              keys ( this.Keys.ENTER ).
              keys ( this.Keys.PAGEUP );
            }
            else {
             this.click ( "//relationship-widget[1]/bx-chip-input[@class='ng-isolate-scope']/*//input" ).
             pause ( 2000 ).
             clearValue ( "//relationship-widget[1]/bx-chip-input[@class='ng-isolate-scope']/*//input" ).
             setValue ( "//relationship-widget[1]/bx-chip-input[@class='ng-isolate-scope']/*//input", excel.AC[ excelColumn ] ).
             keys ( this.Keys.ENTER ).
             keys ( this.Keys.PAGEUP );
            }
          }
          else {
            //Write to excel as Fail in the visibility of the Artifact label Component Uuids
            excel.AG.push ( 'FAIL' );
            this.verify.fail ( artifactComponent.value, 'true', 'Fail in the visibility of the Artifact label Component Uuids' );
            this.writeToExcelFail ( xlName, sheetName, xlRow, xlColumn, failureReasonColumn, 'Fail in the visibility of the Artifact label Component Uuids' );
          }
        } );
      }
    }
  }
  this.keys ( this.Keys.PAGEUP );
  return this;
};
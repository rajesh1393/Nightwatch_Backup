//this function is for check and add properties in Video Drag&Drop 
var Excel = require ( 'exceljs' );
var workbook1 = new Excel.Workbook (  );
if  ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var result = [ ];
exports.command = function ( videoTitle, shortTitle, shortDesc, author, attribution, categoryName, shortNote, dragImg, currentCount ) {
  this.pause ( 5000 ).  
  //Wait for Edit the title is visible
  waitForElementVisible ( '.container-head > text-field > input', 5000, false ).
  //Verify the Video Title field is visible
  verify.visible ( ".container-head > text-field > input" ).
  //Clear the Video Title data in the field
  clearValue ( '.container-head > text-field > input' ).
  //Enter the Video Title data in the field
  setValue ( '.container-head > text-field > input', videoTitle ).
  //Check the description display
  verify.visible ( "#wmd-input-0" ).
  //Verify the properties tab is visible
  verify.visible ( ".video-tabs > a[  href='#properties']" ).
  //Click the properties tab
  click ( ".video-tabs > a[ href='#properties' ]" ).
  pause ( 5000 ).
  //Check and enter short name
  verify.visible ( "textarea[ ng-model='artifact.shortName']" ).
  //Clear the Shortname data in the field
  clearValue ( "textarea[ ng-model='artifact.shortName']" ).
  //Enter the Shortname data in the field
  setValue ( "textarea[ ng-model='artifact.shortName']", shortTitle ).
  //Check and enter short description
  verify.visible ( "textarea[ ng-model='artifact.shortDescription']" ).
  //Clear the Short description data in the field
  clearValue ( "textarea[ ng-model='artifact.shortDescription']" ).
  //Enter the Short description data in the field
  setValue ( "textarea[ ng-model='artifact.shortDescription']", shortDesc ).
  pause ( 5000 ).
  //Select Author name
  verify.visible ( ".attribution-container>a[ng-click='showAddAuthor()']" ).
  //Click on the Authors dropdown option
  click ( ".attribution-container>a[ng-click='showAddAuthor()']" ).
  pause ( 5000 ).
  //Enter the search data in the field
  setValue ( ".search-form", author.trim() )
  this.pause ( 5000 ).useXpath ( ).
  //click on the searched Author
  click ( "//ul/li/a/span[ text( ) = '" + author.trim() + "' ]" ).
  pause ( 5000 ).useCss ( ).
  //Get the Attribution values
  getValue ( ".add-icon", function ( attributeExist ) {
    var attributeExistValuse = attributeExist.value;
    if  ( attributeExistValuse === true ) {
      //Verify the Attribution field is visible
      this.verify.visible ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
      //Click on the Attribution dropdown option
      click ( ".attribution-container>a[ng-click='showAddAttribution()']" ).
      pause ( 5000 ).
      //Enter the Attribution name in the field
      setValue ( ".search-form", attribution.trim() ).
      pause ( 5000 ).useXpath ( ).
      //click on the searched Attribution
      click ( "//ul/li/a/span[ text( ) = '" + attribution.trim() + "']" ).
      pause ( 5000 ).useCss ( )
    }
    else {    
    }
    //Wait for categories name field is visible
    this.waitForElementVisible ( '.collections-widget', 5000,false ).
    //Verify categories name field is visible
    verify.visible ( ".collections-widget" ).
    pause ( 5000 ).
    //clear the text in the category field
    clearValue ( ".collections-widget > input" ).
    //Enter the categories name
    setValue ( ".collections-widget > input", categoryName ).
    pause ( 7000 ).    
    verify.visible ( ".suggestion-list-wrap > div:nth-child(1) > div:nth-child(1) > span:nth-child(1)" ).
    //click on the category name from the list
    click ( ".suggestion-list-wrap > div:nth-child(1) > div:nth-child(1) > span:nth-child(1)" ).
    waitForElementVisible ( ".ng-binding.ng-scope", 5000, false ).
    getText ( ".ng-binding.ng-scope", function ( categoriesErrMsg ) {
      var categoriesErrMsgs = categoriesErrMsg.value;
    } );
    //Check and add note
    this.verify.visible ( ".ng-binding.ng-scope" ).
    //Clear the Short Note data in the field
    clearValue ( "textarea[  ng-model='artifact.note' ]" ).
    //Click on the Short Note data in the field
    setValue ( "textarea[  ng-model='artifact.note' ]", shortNote ).
    pause ( 5000 ).
    //Check Thumbnail ADD and Delete
    //verify.visible  ( ".uploaded-image" ).
    getAttribute ( ".uploaded-image", "src", function ( imageCheck ) {
      var imageValue = imageCheck.value;
      var imageStatus = imageCheck.status;
      if  ( imageStatus === 0 ) {
        this.pause ( 5000 )        
      }
      else if  ( img !== 0 ) {
        this.pause ( 5000 ).
        pause ( 5000 ).waitForElementVisible ( ".uploaded-image-container", 5000, false ).
        setValue ( 'span.hidden-input:nth-child(1) > input:nth-child(1)', require ( 'path' ).resolve ( dragImg ) ).
        pause ( 10000 )
      }
      else {
      }
    } );
  } );
  //Check and click save button
  this.verify.visible ( ".btn-active" ).
  pause ( 5000 ).
  //Click on the Save button
  click ( ".btn-active" ).
  pause ( 5000 ).
  //Check and click Distribution Tab
  verify.visible ( ".video-tabs a[ href='#distribution']" ).
  pause ( 5000 ).
  //click on the distribution tab
  click ( ".video-tabs a[ href='#distribution']" ).
  pause ( 5000 ).
  //Search for videos link
  useXpath (  ).
  //verify and click on the videoe menu in CONTENT
  verify.containsText ( "//ul/li/a[ text( ) = 'Videos']" , "Videos" ).
  pause ( 5000 ).
  //Click on the videos menu in CONTENT
  click ( "//ul/li/a[ text( ) = 'Videos']" ).
  useCss ( ).
  pause ( 5000 )  
  return this;
};
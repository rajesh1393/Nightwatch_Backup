//this function is for check and add properties in Authors,Attributions
var Excel = require ( 'exceljs' );
var workbook1 = new Excel.Workbook (  );
if  ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var result = [ ];
exports.command = function ( ShortTitle, ShortDesc, CategoryName, contentNote, thumbnailImg, currentCount ) {  
  //Verify the properties tab
  this.verify.visible ( ".video-tabs > a[ href='#properties']" ).
  pause ( 5000 ).
  //Click on the Properties Tab
  click ( ".video-tabs > a[ href='#properties']" ).
  pause ( 5000 ).
  //Verify the short Title
  verify.visible ( "textarea[ ng-model='artifact.shortName']" ).
  pause ( 5000 ).
  //Clear the Short Title in the field
  clearValue ( "textarea[ ng-model='artifact.shortName']" ).
  pause ( 5000 ).
  //Enter the Short Tile in the Field
  setValue ( "textarea[ ng-model='artifact.shortName']", ShortTitle ).
  pause ( 5000 ).
  //Verify the Short Description
  verify.visible ( "textarea[ ng-model='artifact.shortDescription']" ).
  pause ( 5000 ).
  //Clear the Short Description in the Filed
  clearValue ( "textarea[ ng-model='artifact.shortDescription']" ).
  pause ( 5000 ).
  //Enter the Short Description 
  setValue ( "textarea[ ng-model='artifact.shortDescription']", ShortDesc ).
  pause ( 5000 ).
  //Wait and verify the Categories field
  waitForElementVisible ( '.collections-widget', 5000, false ).
  pause ( 5000 ).
  verify.visible ( ".collections-widget" ).
  pause ( 5000 ).
  //Clear the Categories in the field
  clearValue ( ".collections-widget > input" ).
  pause ( 5000 ).
  //Enter the Categories in the field
  setValue ( ".collections-widget > input", CategoryName ).
  pause ( 5000 ). 
  //Verify the Categories list 
  verify.visible ( ".suggestion-list-wrap > div:nth-child(1) > div:nth-child(1) > span:nth-child(1)" ).
  pause ( 5000 ).
  //Click on the categories Name in the List
  click ( ".suggestion-list-wrap > div:nth-child(1) > div:nth-child(1) > span:nth-child(1)" ).
  pause ( 5000 ).
  waitForElementVisible ( ".ng-binding.ng-scope", 5000, false ).
  getText ( ".ng-binding.ng-scope", function ( validateErrMsg ) {
    var validateAlert = validateErrMsg.value;
    console.log ( "testvalue" + validateAlert )
  } );
  //Verify the Short notes
  this.verify.visible ( ".ng-binding.ng-scope" ).
  pause ( 5000 ).
  //Clear the Short Notes
  clearValue ( "textarea[ ng-model='artifact.note']" ).
  pause ( 5000 ).
  //Enter the Short Notes
  setValue ( "textarea[ ng-model='artifact.note']", contentNote ).
  pause ( 5000 ).
  //Check and click save button
  verify.visible ( ".btn-active" ).
  pause ( 5000 ).
  //Click on the Save Button
  click ( ".btn-active" ).
  pause ( 5000 ).
  //Verify the Distribution Tab
  verify.visible ( ".video-tabs a[ href='#distribution' ]" ).
  pause ( 5000 ).
  //Click on the Distribution Tab
  click ( ".video-tabs a[ href='#distribution' ]" ).
  pause ( 5000 )
  return this;
};
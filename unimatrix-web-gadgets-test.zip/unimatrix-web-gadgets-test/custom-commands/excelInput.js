//this command is for push the ExcelSheet input to an array 
exports.command = function ( xlName, sheetName ) {
  this.pause ( 5000 );
  var excel = this.globals.excelCol;
  if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
    try {
      var workbook = XLSX.readFile ( xlName, { cellStyles: true } );
      console.log("xlName",xlName);
      console.log("sheetName",sheetName);
      var xlSheetName = workbook.Sheets[ ''+ sheetName +'' ];
    }
    catch ( err ) {
      this.verify.fail ( "Please check File name" );
    }
    try {
      //Read values from excel
      for ( z in xlSheetName ) {
        //Read the column 'A' from ExcelSheet
        if ( z.includes ( 'A' ) && !( z.includes ( 'AA' ) ) && !( z.includes ( 'AB' ) ) && !( z.includes ( 'AC' ) ) && !( z.includes ( 'AD' ) ) && !( z.includes ( 'AE' ) ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.A.push ( xlSheetName[ z ].v );
        }
        //Read the column 'B' from ExcelSheet
        if ( z.includes ( 'B' ) && !( z.includes ( 'AB' ) ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }             
          excel.B.push ( xlSheetName[ z ].v );
        }
        //Read the column 'C' from ExcelSheet
        if ( z.includes ( 'C' ) && !( z.includes ( 'AC' ) ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }             
          excel.C.push ( xlSheetName[ z ].v );
        }
        //Read the column 'D' from ExcelSheet
        if ( z.includes ( 'D' ) && !( z.includes ( 'AD' ) ) ) {          
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.D.push ( xlSheetName[ z ].v );
        }
        //Read the column 'E' from ExcelSheet
        if ( z.includes ( 'E' ) && !( z.includes ( 'AE' ) ) ) {          
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.E.push ( xlSheetName[ z ].v );
        }
        //Read the column 'F' from ExcelSheet
        if ( z.includes ( 'F' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.F.push ( xlSheetName[ z ].v );
        }
        //Read the column 'G' from ExcelSheet
        if ( z.includes ( 'G' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.G.push ( xlSheetName[ z ].v );
        }
        //Read the column 'H' from ExcelSheet
        if ( z.includes ( 'H' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.H.push ( xlSheetName[ z ].v );
        }
        //Read the column 'I' from ExcelSheet
        if ( z.includes ( 'I' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.I.push ( xlSheetName[ z ].v );
        }
        //Read the column 'J' from ExcelSheet
        if ( z.includes ( 'J' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.J.push ( xlSheetName[ z ].v );
        }
        //Read the column 'K' from ExcelSheet
        if ( z.includes ( 'K' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.K.push ( xlSheetName[ z ].v );
        }
        //Read the column 'L' from ExcelSheet
        if ( z.includes ( 'L' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.L.push ( xlSheetName[ z ].v );
        }
        //Read the column 'M' from ExcelSheet
        if ( z.includes ( 'M' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.M.push ( xlSheetName[ z ].v );
        }
        //Read the column 'N' from ExcelSheet
        if ( z.includes ( 'N' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.N.push ( xlSheetName[ z ].v );
        }
        //Read the column 'O' from ExcelSheet
        if ( z.includes ( 'O' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.O.push ( xlSheetName[ z ].v );
        }
        //Read the column 'P' from ExcelSheet
        if ( z.includes ( 'P' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.P.push ( xlSheetName[ z ].v );
        }
        //Read the column 'Q' from ExcelSheet
        if ( z.includes ( 'Q' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.Q.push ( xlSheetName[ z ].v );
        }
        //Read the column 'R' from ExcelSheet
        if ( z.includes ( 'R' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.R.push ( xlSheetName[ z ].v );
        }
        //Read the column 'S' from ExcelSheet
        if ( z.includes ( 'S' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.S.push ( xlSheetName[ z ].v );
        }
        //Read the column 'T' from ExcelSheet
        if ( z.includes ( 'T' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.T.push ( xlSheetName[ z ].v );
        }
        //Read the column 'U' from ExcelSheet
        if ( z.includes ( 'U' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.U.push ( xlSheetName[ z ].v );
        }
        //Read the column 'V' from ExcelSheet
        if ( z.includes ( 'V' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.V.push ( xlSheetName[ z ].v );
        }
        //Read the column 'W' from ExcelSheet
        if ( z.includes ( 'W' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.W.push ( xlSheetName[ z ].v );
        }
        //Read the column 'X' from ExcelSheet
        if ( z.includes ( 'X' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.X.push ( xlSheetName[ z ].v );
        }
        //Read the column 'Y' from ExcelSheet
        if ( z.includes ( 'Y' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.Y.push ( xlSheetName[ z ].v );
        }
        //Read the column 'Z' from ExcelSheet
        if ( z.includes ( 'Z' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.Z.push ( xlSheetName[ z ].v );
        }
        //Read the column 'AA' from ExcelSheet
        if ( z.includes ( 'AA' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.AA.push ( xlSheetName[ z ].v );
        }
        //Read the column 'AB' from ExcelSheet
        if ( z.includes ( 'AB' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.AB.push ( xlSheetName[ z ].v );
        }
        //Read the column 'AC' from ExcelSheet
        if ( z.includes ( 'AC' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.AC.push ( xlSheetName[ z ].v );
        }
        //Read the column 'AD' from ExcelSheet
        if ( z.includes ( 'AD' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.AD.push ( xlSheetName[ z ].v );
        }
        //Read the column 'AE' from ExcelSheet
        if ( z.includes ( 'AE' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.AE.push ( xlSheetName[ z ].v );
        }
        //Read the column 'AF' from ExcelSheet
        if ( z.includes ( 'AF' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.AF.push ( xlSheetName[ z ].v );
        }
        //Read the column 'AG' from ExcelSheet
        if ( z.includes ( 'AG' ) ) {
          if ( xlSheetName[ z ].v == "null" ) {
            xlSheetName[ z ].v = "";
          }
          excel.AG.push ( xlSheetName[ z ].v );
        }
      }      
    }
    catch ( err ) 
    {
      //Writing the Failed status in the Excel sheet
      this.verify.fail ( "Unable to load file","Excel file should get updated","Please check the Parameters in Excel Sheet" );
    };
    return this; 
};
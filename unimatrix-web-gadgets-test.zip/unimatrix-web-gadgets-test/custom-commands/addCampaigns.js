//this function is for searchign the Portal Campaign
exports.command = function ( sheetName, excelRow, excelColumn ) {
  var excel = this.globals.excelCol;
  this.pause ( 5000 ).useCss ( ).
  getText ( ".typeName-label.campaign-typeName", function ( pageHeader ) {
    if ( pageHeader.value == "CAMPAIGN" ) {
      this.useXpath ( ).
      clearValue ( "//input[@ng-model='campaign.name']" ).
      setValue ( "//input[@ng-model='campaign.name']", excel.A[ excelColumn ] ).
      click ( '//ul[@class="dropdown-list"]' ).
      pause ( 5000 ).
      click ( '//a[text()[normalize-space(.)="' + excel.B[ excelColumn ] + '"]]' ).
      clearValue ( "//*[@id='campaign-url-pattern']" ).
      setValue ( "//*[@id='campaign-url-pattern']", excel.C[ excelColumn ] ).
      pause ( 5000 ).
      click ( "//div[@class='dropdown-list fixed operator']" ).
      pause ( 5000 ).
      click ( "//li/a[contains( .,'" + excel.D[ excelColumn ] + "')]" ).
      pause ( 5000 ).
      waitForElementVisible ( "//a[contains( .,'ADD CONDITION' )]", 5000, false, function ( campaignsCondition ) {
        if ( campaignsCondition.value == true ) {
          this.click ( "//a[contains( .,'ADD CONDITION' )]" ).
          pause ( 5000 ).
          click ( "//div[@class='list-item-card'][1]" ).
          pause ( 5000 ).
          click ( "//div[@class='list-item-card'][1]/*//a[text()='" + excel.E[ excelColumn ] + "']" ).
          pause ( 5000 ).
          click ( "//div[@class='list-item-card'][2]" ).
          pause ( 5000 ).
          click ( "//div[@class='list-item-card'][2]/*//ul/li/a[text()[normalize-space ()='" + excel.F[ excelColumn ] + "']]" );
          if ( excel.E[ excelColumn ] == "Category" ) {
            this.clearValue ( "//div[@collections='categories']" ).
            setValue ( "//div[@collections='categories']", excel.G[ excelColumn ] );
          }
          else {
            this.clearValue ( "//input[contains( @id,'filterCriteria_value' )]" ).
            setValue ( "//input[contains( @id,'filterCriteria_value' )]", excel.G[ excelColumn ] );
          }
          this.waitForElementVisible ( "//a[contains( .,'Save' )]", 5000, false, function ( saveCampaigns ) {
            if ( saveCampaigns.value == true ) {
              this.click ( "//a[contains( .,'Save' )]" ).
              pause ( 7000 );
              if ( excel.H[ excelColumn ] == "Turn OFF" ) {
                this.getText ( "*//ul[@class='form-toolbar campaign ng-scope']/li[2]/a/span", function ( turnoff ) {
                  if ( turnoff.value == excel.H[ excelColumn ] ) {
                    this.click ( "//div[@class='campaign-label ng-scope']/span" ).
                    click ( "//button[contains( .,'Turn Off' )]" );
                  }
                  this.getText ( "//div[@class='campaign-label ng-scope']/span", function ( inActive ) {
                    this.pause ( 9000 );
                    if ( inActive.value == "INACTIVE" ) {
                      this.click ( "//a[contains( .,'Campaigns' )]" ).
                      pause ( 5000 ).
                      click ( "//a[contains( .,'Inactive' )]" ).
                      pause ( 5000 );
                    }
                    else {
                      this.verify.fail ( inActive.value, "INACTIVE", 'Header status is not valid. should be as "INACTIVE"' );
                      this.writeToExcelFail ( 'boxxspring.xlsx', '"' + sheetName + '"', ++excelRow, 9, 10, "ActualResult: '" + inActive.value + ". ExpectedResult: 'INACTIVE' (Header status is not valid. should be as 'INACTIVE'" );
                    }
                  } );
                } );
              }
              else {
                this.getText ( "*//ul[@class='form-toolbar campaign ng-scope']/li[2]/a/span", function ( turnon ) {
                  if ( turnon.value == excel.H[ excelColumn ] ) {
                    this.click ( "//span[contains( .,'Turn On' )]" ).
                    pause ( 7000 );
                  }
                  this.getText ( "//div[@class='campaign-label ng-scope published']/span", function ( active ) {
                    this.pause ( 5000 );
                    if ( active.value == "ACTIVE" ) {
                      this.click ( "//a[contains( .,'Campaigns' )]" ).
                      pause ( 5000 ).
                      click ( "//a[contains( .,'Active' )]" ).
                      pause ( 5000 );
                    }
                    else {
                      this.verify.fail ( active.value, "ACTIVE", 'Header status is not valid. should be as "ACTIVE"' );
                      this.writeToExcelFail ( 'boxxspring.xlsx', '"' + sheetName + '"', ++excelRow, 9, 10, "ActualResult: '" + active.value + ". ExpectedResult: 'ACTIVE' ( Header status is not valid. should be as 'ACTIVE'" );
                    }
                  } );
                } );
              }
            }
            else {
              //write to fail status as no results found while search the content title
              this.verify.fail ( saveCampaigns.value, "true", 'Loading issue or Save button is not visible' );
              this.writeToExcelFail ( 'boxxspring.xlsx', '"' + sheetName + '"', ++excelRow, 9, 10, "ActualResult: '" + saveCampaigns.value + ". ExpectedResult: 'true' ( Loading issue or Save button is not visible" );
            }
          } );
        }
        else {
          //write to fail status as no results found while search the content title
          this.verify.fail ( campaignsCondition.value, true, 'Timeout issue while clicking the Add condition button in Campaigns' );
          this.writeToExcelFail ( 'boxxspring.xlsx', '"' + sheetName + '"', ++excelRow, 9, 10, "ActualResult: '" + campaignsCondition.value + ". ExpectedResult: 'true' ( Timeout issue while clicking the Add condition button in Campaigns" );
        }
      } );
    }
    else {
      //write to fail status as no results found while search the content title
      this.verify.fail ( pageHeader.value, "Campaign", 'Page header is not valid' );
      this.writeToExcelFail ( 'boxxspring.xlsx', '"' + sheetName + '"', ++excelRow, 9, 10, "ActualResult: '" + pageHeader.value + ". ExpectedResult: 'Campaign' ( Page header is not valid" );
    }
  } );
  return this;
};
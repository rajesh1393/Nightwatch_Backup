exports.command = function ( locator,excelName,sheetName,rowNum,colNum,statusColNum,Reason ) {
	this.pause ( 5000 ).
		waitForElementPresent ( locator,50000,false,function ( getStatus ) {
			if ( getStatus.status == 0) {
				this.
				writeToExcelPass ( excelName,sheetName, rowNum, colNum );
			}
			else {
				this.
				writeToExcelFail ( excelName,sheetName , rowNum, colNum, statusColNum,Reason);
			}	
		} );
	return this;
}
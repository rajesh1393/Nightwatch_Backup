var date = Date.now ( );
var fs = require ( 'fs' );
var scriptTitle = fs.readFileSync ( __dirname + '/../ScriptTitle.txt', 'utf8' );
var splitScriptTitle = scriptTitle.split ( ',' );
var toMail = fs.readFileSync ( __dirname + '/../tomail.txt', 'utf8' );
var ccMail = fs.readFileSync ( __dirname + '/../ccmail.txt', 'utf8' );
var PROFILES = {
  portalx : {
    portalUri: "http://portalx.staging.boxxspring.com/",
    username: "qatest@sportsrocket.com",
    password: "qatest-staging"
  },
  pages: {
    portalUri: "https://pages.staging.boxxspring.com/",
    username: "qatest@sportsrocket.com",
    password: "qatest-staging"
  },
  peoplex: {
    portalUri: "https://peoplex.staging.boxxspring.com/",
    username: "qatest@sportsrocket.com",
    password: "qatest-staging"
  }
}
var excelCol = {
  A: [], B: [], C: [], D: [], E: [], F: [], G: [], H: [], I: [], J: [], K: [], L: [], 
  M: [], N: [], O: [], P: [], Q: [], R: [], S: [], T: [], U: [], V: [], W: [], X: [], 
  Y: [], Z: [], AA: [], AB: [], AC: [], AD: [], AE:[], AF: [], AG: [], AH: [], resultCustomData: []
}
var nodemailer = require ( 'nodemailer' );
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var smtpConfig = {
  host: 'smtp.gmail.com',
  port: 587,
  secure: false, 
  auth: {
    user: 'poornakiruthikaa@gmail.com',
    pass: 'poorna@123'
    }  
  };
var transporter = nodemailer.createTransport ( smtpConfig );
var mailOptions = {
  from: 'poornakiruthikaa@gmail.com', 
  to: toMail,
  cc: ccMail,
  subject: 'SportsrocketQA Test Report', 
  text: 'Test Report', 
  html: {
    path: __dirname + '/../mailOptions - Copy.html'
    },
  attachments: [ { 
    contentType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    },
    {
    path: __dirname + '/../Report.jpg'
    }  
   ]
  };
for ( var title = 0; title != splitScriptTitle.length; title++ ) {
  mailOptions.attachments[ title ].path = __dirname + '/../'+splitScriptTitle[title]+'.xlsx';
}
var HtmlReporter = require ( 'nightwatch-html-reporter' );
var htmlreporter = new HtmlReporter ( {
  openBrowser: true,
  uniqueFilename: true,
  themeName: "compact-gray",
  reportsDirectory: __dirname + '/reports',
  reportFilename: "generatedReport_"+date+".html",
  relativeScreenshots: true,
  hideSuccess: false,
  logLevel: 0
} );

module.exports = { peoplex: PROFILES.peoplex, profilex: PROFILES.portalx, profilepages: PROFILES.pages, excelCol: excelCol,
  transporter: transporter, mailOptions: mailOptions, htmlreporter: htmlreporter }

//this function is for checking the Portal Cancel button functionality
module.exports = {
  tags: ['analyticsCancelButton'],
  before: function(analyticsLogin) {
    //login the portal and check the theme
    var profile = analyticsLogin.globals.analytics;
    analyticsLogin.analyticsLogin ( profile.portalUri, profile.username, profile.password, 'ANALYTICS' );
  },
  after: function(closeBrowser) {
    //End the Browser
    closeBrowser.end();
  },
  beforeEach: function(addXlData, done) {
    setTimeout(function() {
      //get the excel sheet name from the function name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput('analytics.xlsx', sheetName);
      done();
    }, 200);
  },
  afterEach: function(clearXlData, done) {
    setTimeout(function() {
      //clear the input array allocated in the global
      clearXlData.emptyExcelInput();
      done();
    }, 200);
  },
  'AnalyticsCancelButton': function(cancel) {
    //Access the variable globally defined
    var excel = cancel.globals.excelCol;
    if (excel.A.length > 0) {
      console.log("Excel row count: " + excel.A.length);
      //loop the 'n' number of excel input
      for (let excelColumn = 1; excelColumn != excel.A.length; excelColumn++) {
        var excelRow = 1;
        cancel.useXpath();
        if (excel.A[excelColumn] == "Dashboards") {
          //Wait and click the side menu and the respective sub menu in Portal
          cancel.waitForElementVisible("//html/body/div[2]/*//ul[1][@class='sidebar-items ng-scope']/*//li/a[text()[normalize-space(.)='" + excel.B[excelColumn] + "']]", 9000, false, function(dashboardSidebar) {
            if (dashboardSidebar.value == true) {
              //Click on the option in the side menu bar in Portal
              cancel.click("//html/body/div[2]/*//ul[1][@class='sidebar-items ng-scope']/*//li/a[text()[normalize-space(.)='" + excel.B[excelColumn] + "']]").
              pause(3000);
            }
            else {
               excel.D.push("FAIL");
              //write to fail status as of Timeout issue or fail due to the element is not visible
              this.verify.fail(dashboardSidebar.value, true, 'Timeout issue or fail due to the element is not visible');
              cancel.writeToExcelFail('analytics.xlsx', 'AnalyticsCancelButton', ++excelRow, 4, 5, "ActualResult: '" + dashboardSidebar.value + ". ExpectedResult: 'true' ( Timeout issue or fail due to the element is not visible )");
            }
          });
        }
        else if (excel.A[excelColumn] == "Reports") {
          //Wait and click the side menu and the respective sub menu in Portal
          cancel.waitForElementVisible("//html/body/div[2]/*//ul[2][@class='sidebar-items ng-scope']/*//li/a[text()[normalize-space(.)='" + excel.B[excelColumn] + "']]", 9000, false, function(reportSidebar) {
            if (reportSidebar.value == true) {
              //Click on the option in the side menu bar in Portal
              cancel.click("//html/body/div[2]/*//ul[2][@class='sidebar-items ng-scope']/*//li/a[text()[normalize-space(.)='" + excel.B[excelColumn] + "']]").
              pause(3000);
            }
            else {
               excel.D.push("FAIL");
              //write to fail status as of Timeout issue or fail due to the element is not visible
              this.verify.fail(reportSidebar.value, true, 'Timeout issue or fail due to the element is not visible');
              cancel.writeToExcelFail('analytics.xlsx', 'AnalyticsCancelButton', ++excelRow, 4, 5, "ActualResult: '" + reportSidebar.value + ". ExpectedResult: 'true' ( Timeout issue or fail due to the element is not visible )");
            }
          });
        }
        else {
          //Wait and click the side menu and the respective sub menu in Portal
          cancel.getLocationInView("//html/body/div[2]/*//div[@ng-show='collapse." + excel.A[excelColumn] + "']//*/li/a[contains(.,'" + excel.B[excelColumn] + "' )]").
          waitForElementVisible("//html/body/div[2]/*//div[@ng-show='collapse." + excel.A[excelColumn] + "']//*/li/a[contains(.,'" + excel.B[excelColumn] + "' )]", 9000, false, function(filterSidebar) {
            if (filterSidebar.value == true) {
              //Click on the option in the side menu bar in Portal
              cancel.click("//html/body/div[2]/*//div[@ng-show='collapse." + excel.A[excelColumn] + "']//*/li/a[contains(.,'" + excel.B[excelColumn] + "' )]").
              pause(3000);
            }
            else {
              excel.D.push("FAIL");
              //write to fail status as of Timeout issue or fail due to the element is not visible
              this.verify.fail(filterSidebar.value, true, 'Timeout issue or fail due to the element is not visible');
              cancel.writeToExcelFail('analytics.xlsx', 'AnalyticsCancelButton', ++excelRow, 4, 5, "ActualResult: '" + filterSidebar.value + ". ExpectedResult: 'true' ( Timeout issue or fail due to the element is not visible )");
            }
          });
        }
        //check the visibility of the search textbox
        cancel.waitForElementPresent("//div[@class='suggestion-dropdown-wrap']/input", 5000, false, function(searchFieldInput) {
          if (searchFieldInput.status == 0) {
            cancel.clearValue("//div[@class='suggestion-dropdown-wrap']/input").
            setValue("//div[@class='suggestion-dropdown-wrap']/input", excel.C[excelColumn]).
            keys(cancel.Keys.ENTER).
            waitForElementVisible("//h2[@class='ng-binding'][text()[normalize-space(.)='" + excel.C[excelColumn] + "']]", 5000, false, function(searchFieldResult) {
              if (searchFieldResult.status == 0) {
                cancel.pause(5000).
                click("//h2[@class='ng-binding'][text()[normalize-space(.)='" + excel.C[excelColumn] + "']]");
              }
              else {
                //write to fail status as 'No' Result found while search the Title
                this.verify.fail(searchFieldResult.status, 0, 'No Result found while search the Title');
                cancel.writeToExcelFail('boxxspring.xlsx', 'PortalCancelButton', ++excelRow, 4, 5, "ActualResult: '" + searchFieldResult.status + ". ExpectedResult: '0' ( No Result found while search the Title )");
              }
            });
          }
        });
        //check the cancel button functionality and close button in dialog box
        for (let checkCancelButn = 1; checkCancelButn < 3; checkCancelButn++) {
          //check the visibility of the delete button
          cancel.waitForElementPresent("//a[@ng-click='showDeleteVerification()']", 9000, false, function(deleteButton) {
            if (deleteButton.status == 0) {
              cancel.pause(9000).
              click("//a[@ng-click='showDeleteVerification()']");
              if (checkCancelButn === 1) {
                cancel.pause(5000).
                //check the visibility of the cancel button
                waitForElementVisible("//a[@class='link-secondary']", 7000, false).
                click("//a[@class='link-secondary']").
                pause(3000);
              }
              else if (checkCancelButn === 2) {
                cancel.pause(3000).
                //check the visibility of the close button in dialog box
                waitForElementVisible("//i[@ng-click='closeDeleteVerification()']", 5000, false).
                click("//i[@ng-click='closeDeleteVerification()']").
                pause(3000);
              }
              cancel.waitForElementVisible("//div/text-field/input", 5000, false, function(titleValue) {
                if (titleValue.value == true) {
                  //get the headline value
                  cancel.getValue("//div/text-field/input", function(getHeadline) {
                    if (getHeadline.value == excel.C[excelColumn]) {
                      if (checkCancelButn === 2 && excel.D != "FAIL") {
                        //write to excel as PASS if the cancel functsionality working fine
                        cancel.writeToExcelPass('analytics.xlsx', 'AnalyticsCancelButton', ++excelRow, 4);
                      }
                    }
                    else if ( excel.D.indexOf("FAIL") == -1 ) {
                     excel.D.push("FAIL");
                      //write to fail status as Fail to load the same page after clicking Cancel button or close the dialogbox
                      this.verify.fail(getHeadline.value, excel.C[excelColumn], 'Fail to load the same page after clicking Cancel button or close the dialogbox');
                      cancel.writeToExcelFail('analytics.xlsx', 'AnalyticsCancelButton', ++excelRow, 4, 5, "ActualResult: '" + getHeadline.value + ". ExpectedResult: '" + excel.C[excelColumn] + "' ( Fail to load the same page after clicking Cancel button or close the dialogbox )");
                    }
                  });
                }
                else if ( excel.D.indexOf("FAIL") == -1 ) {
                  excel.D.push("FAIL");
                  //write to fail status as Cancel button or close the dialog box icon is not working properly as defined
                  this.verify.fail(titleValue.value, true, 'Cancel button or close the dialog box icon is not working properly as defined');
                  cancel.writeToExcelFail('analytics.xlsx', 'AnalyticsCancelButton', ++excelRow, 4, 5, "ActualResult: '" + titleValue.value + ". ExpectedResult: 'true' ( Cancel button or close the dialog box icon is not working properly as defined )");
                }
              });
            }
            else if ( excel.D.indexOf("FAIL") == -1 ) {
              excel.D.push("FAIL");
              //write to fail status as Error in displaying Delete Button
              this.verify.fail(deleteButton.status, 0, 'Expected submenu fail to display in Analytics sidebar');
              cancel.writeToExcelFail('analytics.xlsx', 'AnalyticsCancelButton', ++excelRow, 4, 5, "Expected submenu fail to display in Analytics sidebar");
            }
          });
        }
      }
    }  
    else {
      //write to excel 'fail' if error in the excelsheet name
      console.log("No input in Excel or Check the Excel Name for the script 'AnalyticsCancelButton'");
    } 
  }
};  
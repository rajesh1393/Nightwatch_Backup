//this function is for add, edit, delete the Reports
module.exports = {
  tags: ['reports'],
  before: function(analyticsLogin) {
    var profile = analyticsLogin.globals.analytics;
    analyticsLogin.analyticsLogin(profile.portalUri, profile.username, profile.password, 'ANALYTICS');
  },
  after: function(closeBrowser) {
    //end the Browser
    closeBrowser.end();
  },
  beforeEach: function(addXlData, done) {
    setTimeout(function() {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput('analytics.xlsx', sheetName);
      done();
    }, 200);
  },
  afterEach: function(clearXlData, done) {
    setTimeout(function() {
      //empty excel input array
      clearXlData.emptyExcelInput();
      done();
    }, 200);
  },
  'AddReports': function(addReports) {
    var excel = addReports.globals.excelCol;
    if (excel.A.length > 0) {
      console.log("Excel row count: " + excel.A.length);
      //loop the 'n' number of excel input
      for (let excelColumn = 1; excelColumn != excel.A.length; excelColumn++) {
        var excelRow = 1;
        addReports.pause(10000).
        useXpath().
        //check the visibility of All option in reports 
        waitForElementVisible("html/body/div[2]/*//ul[2]/*//a[contains(.,'All')]", 3000, false, function(reportsName) {
          if (reportsName.value == true) {
            addReports.acceptAlert ( ).
            click("html/body/div[2]/*//ul[2]/*//a[contains(.,'All')]").
            pause(5000).
            useCss().
            getText('.content-count > strong', function(defaultReportCount) {
              var actualTotal = parseInt(defaultReportCount.value);
              console.log("Count before adding the Reports", actualTotal);
              addReports.waitForElementVisible(".btn.btn-primary.btn-add.ng-binding", 5000, false, function(addReport) {
                if (addReport.value == true) {
                  addReports.click(".btn.btn-primary.btn-add.ng-binding").
                  useXpath().pause(5000).
                  clearValue("//input[@ng-model='report.name']").
                  setValue("//input[@ng-model='report.name']", excel.A[excelColumn]).
                  pause(5000).
                  click("//div[1]/div/a[@ng-click='toggleFilterDropdown()']").
                  pause(5000).
                  click("//ul/li/a[contains(.,'" + excel.B[excelColumn] + "')]");
                  if (excel.B[excelColumn] != "Daily") {
                    addReports.click("//div[2]/div/a[@ng-click='toggleFilterDropdown()']").
                    click("//ul/li/a[contains(.,'" + excel.C[excelColumn] + "')]");
                  }
                  if (excel.D[excelColumn].toUpperCase() == 'YES') {
                    addReports.click("//*[@id='recurring-label']");
                  }
                  var dimensionOption = excel.E[excelColumn].split(",");
                  var metricsOption = excel.G[excelColumn].split(",");
                  for (let dimensionCheckbox = 0; dimensionCheckbox < dimensionOption.length; dimensionCheckbox++) {
                    addReports.click("//label[text()='" + dimensionOption[dimensionCheckbox] + "']");
                  }
                  addReports.setValue("//div[@class='placeholder']", excel.F[excelColumn]);
                  for (let metricsCheckbox = 0; metricsCheckbox < metricsOption.length; metricsCheckbox++) {
                    addReports.click("//label[text()='" + metricsOption[metricsCheckbox] + "']");
                  }
                  addReports.click("//a[@ng-click='save()']").
                  pause(20000).
                  waitForElementVisible("//ul/li[2]//*/span[contains(.,'Complete')]", 30000, false, function(saveReport) {
                    if (saveReport.value == true) {
                      addReports.useXpath().
                      click("//a[contains(.,'Activities')]").
                      waitForElementVisible("//div[@class='table-row-container']", 10000, false, function(activities) {
                        if (activities.value == true) {
                          addReports.acceptAlert().
                          click("html/body/div[2]/*//ul[2]/*//a[contains(.,'All')]").
                          pause(5000).useCss().
                          getText('.content-count > strong', function(reportCount) {
                            var actualCount = parseInt(actualTotal) + 1;
                            console.log("Count after adding the Reports", reportCount.value);
                            if (reportCount.value == actualCount) {
                              addReports.writeToExcelPass('analytics.xlsx', 'AddReports', ++excelRow, 8);
                            }
                            else {
                              this.verify.fail(reportCount.value, actualCount, 'Unable to add the Reports');
                              addReports.writeToExcelFail('analytics.xlsx', 'AddReports', ++excelRow, 8, 9, "ActualResult: '" + reportCount.value + ". ExpectedResult: '" + actualCount + "' ( Unable to add the Reports )");
                            }
                          });
                        }
                        else {
                          this.verify.fail(activities.value, true, 'Fail to generate the report in Activities');
                          addReports.writeToExcelFail('analytics.xlsx', 'AddReports', ++excelRow, 8, 9, "ActualResult: '" + activities.value + ". ExpectedResult: 'true' ( Fail to generate the report in Activities )");
                        }
                      });
                    }
                    else {
                      this.verify.fail(saveReport.value, true, 'Fail to update the analytics report status as complete after saving the reports');
                      addReports.writeToExcelFail('analytics.xlsx', 'AddReports', ++excelRow, 8, 9, "ActualResult: '" + saveReport.value + ". ExpectedResult: 'true' ( Fail to update the analytics report status as complete after saving the reports )");
                    }
                  });
                }
                else {
                  //write to excel as 'fail' while error in clicking the button Add Report
                  this.verify.fail(addReport.value, true, 'Error in clicking the button Add Report');
                  addReports.writeToExcelFail('analytics.xlsx', 'AddReports', ++excelRow, 8, 9, "ActualResult: '" + addReport.value + ". ExpectedResult: 'true' ( Error in clicking the button Add Report )");
                }
              });
            });
          }
          else {
            //write to excel as 'fail' due to timeout issue in the visibility of All option in Reports
            this.verify.fail(reportsName.value, true, "Timeout issue in the visibility of All option in Reports");
            addReports.writeToExcelFail('analytics.xlsx', 'AddReports', ++excelRow, 8, 9, "ActualResult: '" + reportsName.value + ". ExpectedResult: 'true' ( Timeout issue in the visibility of All option in Reports )");
          }
        });
      }
    }
    else {
      console.log ( "No input in Excel or Check the Excel Name for the script 'AddReports'" );
    }
  },
  'EditReports': function(editReports) {
    var excel = editReports.globals.excelCol;
    if (excel.A.length > 0) {
      console.log("Excel row count: " + excel.A.length);
      //loop the 'n' number of excel input
      for (let excelColumn = 1; excelColumn != excel.A.length; excelColumn++) {
        var excelRow = 1;
        editReports.pause(10000).
        useXpath();
      }
    }
    else {
      console.log ( "No input in Excel or Check the Excel Name for the script 'EditReports'" );
    }
  },
  'DeleteReports': function(deleteReports) {
    var excel = deleteReports.globals.excelCol;
    if (excel.A.length > 0) {
      console.log("Excel row count: " + excel.A.length);
      //loop the 'n' number of excel input
      for (let excelColumn = 1; excelColumn != excel.A.length; excelColumn++) {
        var excelRow = 1;
        deleteReports.pause(10000).
        useXpath().
        waitForElementVisible("html/body/div[2]/*//ul[2]/*//a[contains(.,'All')]", 3000, false, function(reportsName) {
          if (reportsName.value == true) {
            deleteReports.acceptAlert ( ).
            click("html/body/div[2]/*//ul[2]/*//a[contains(.,'All')]").
            pause(5000).
            waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 5000, false, function ( searchFieldInput ) {
              if ( searchFieldInput.value == true ) {
                deleteReports.clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", excel.A[ excelColumn ] ).
                pause ( 5000 ).
                //get the Reports count before delete the existing reports
                getText ( "//strong[@class='ng-binding']", function ( getDefaultCount ) {
                  console.log("Count before deleting the Reports", getDefaultCount.value);
                  //check the search text box present in the reports
                  deleteReports.waitForElementPresent ( "//h2[@class='ng-binding'][text ( )='" + excel.A[ excelColumn ] + "']", 5000, false, function ( searchResult ) {
                    if ( searchResult.status == 0 ) {
                      deleteReports.click ( "//h2[@class='ng-binding'][text ( )='" + excel.A[ excelColumn ] + "']" ).
                      pause ( 9000 ).
                      //check the visibility of the heading after clicking the edit reports button 
                      waitForElementVisible ( "//div/text-field/input", 5000, false, function ( reportsHeadline ) {
                        if ( reportsHeadline.value == true ) {
                          //Check the headline of the reports
                          deleteReports.getValue ( "//div/text-field/input", function ( getHeadline ) {
                            if ( getHeadline.value == excel.A[ excelColumn ] ) {
                              deleteReports.waitForElementVisible ( "//a[contains( .,'Delete')]", 5000, false, function ( deleteReport ) {
                                if ( deleteReport.value == true ) {
                                  deleteReports.click ( "//a[contains( .,'Delete')]" ).
                                  pause ( 5000 ).
                                  click ( "//section/button[contains( .,'Delete')]" ).
                                  pause ( 5000 ).
                                  acceptAlert ( ).
                                  waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 6000, false ).
                                  pause ( 3000 ).
                                  clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                                  setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", excel.A[ excelColumn ] ).
                                  pause ( 5000 ).
                                  getText ( "//strong[@class='ng-binding']", function ( getDeleteCount ) {
                                    console.log("Count after deleting the Reports", getDeleteCount.value);
                                    var getFinalCount = parseInt ( getDefaultCount.value ) - 1;
                                    //compare the before & after delete reports count
                                    if ( getFinalCount == getDeleteCount.value ) {
                                      //write to excel as "pass" if the reports deleted successfully
                                      deleteReports.writeToExcelPass ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2 );
                                    }
                                    else {
                                      //write to excel as "fail" if unable to delete the reports
                                      this.verify.fail ( getDeleteCount.value, getFinalCount, 'Fail to delete the existing Reports' );
                                      deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "ActualResult: '" + getDeleteCount.value + ". ExpectedResult: '" + getFinalCount + "' (  Unable to delete the added Reports )" );
                                    }
                                  } );
                                }
                                else {
                                  //write to excel as 'fail if the Delete button is not working properly
                                  this.verify.fail ( deleteReport.value, true, 'Delete button is not working properly' );
                                  deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "ActualResult: '" + deleteReport.value + ". ExpectedResult: 'true' (  Delete button is not working properly )" );
                                }
                              } );
                            }
                            else {
                              //write to excel as 'fail if the Title of the reports mismatch after clicking Edit button
                              this.verify.fail ( getHeadline.value, excel.A[ excelColumn ], 'Title of the Reports mismatch after clicking Edit button' );
                              deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "ActualResult: '" + getHeadline + ". ExpectedResult: '" + excel.A[ excelColumn ] + "' (  Title of the Reports mismatch after clicking Edit button )" );
                            }
                          } );
                        }
                        else {
                          this.verify.fail ( reportsHeadline.value, 'true', 'Timeout loading issue while redirect to the edit page of Reports' );
                          deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "ActualResult: '" + reportsHeadline.value + ". ExpectedResult: 'true' (  Timeout loading issue while redirect to the edit page of Reports )" );
                        }
                      } );
                    }
                    else {
                      //write to excel as 'fail while Unable to delete due to no result found in search
                      deleteReports.getText ( "//strong[@class='ng-binding']", function ( emptyResult ) {
                        if ( emptyResult.value == '0' ) {
                          this.verify.fail ( undefined, undefined, 'Unable to delete due to no result found while search in Reports' );
                          deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "Unable to delete due to no result found while search in Reports" );
                        }
                        else {
                          //write to excel as 'fail while error in the search functionality
                          this.verify.fail ( emptyResult.value, '0', 'Error in the search functionality as it fail to list the relevant data' );
                          deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "ActualResult: '" + emptyResult.value + ". ExpectedResult: '0' (  Error in the search functionality as it fail to list the relevant data )" );
                        }
                      } );
                    }
                  } );
                } );
              }
              else {
                //write to excel as 'fail' while error in the Search text box field
                this.verify.fail ( searchFieldInput.value, true, 'Error in the Search text box field' );
                deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "ActualResult: '" + searchFieldInput.value + ". ExpectedResult: 'true' (  Error in the Search text box field )" );
              }
            } );
          }
          else {
            //write to excel as 'fail' due to timeout issue in the visibility of 'All' in reports
            this.verify.fail ( reportsName.value, true, "Timeout issue in the visibility of 'All' in Reports" );
            deleteReports.writeToExcelFail ( 'analytics.xlsx', 'DeleteReports', ++excelRow, 2, 3, "ActualResult: '" + reportsName.value + ". ExpectedResult: 'true' (  Timeout issue in the visibility of 'All' in Reports )" );
          }
        } );
      }
    }
    else {
      console.log ( "No input in Excel or Check the Excel Name for the script 'DeleteReports'" );
    }
  }

};
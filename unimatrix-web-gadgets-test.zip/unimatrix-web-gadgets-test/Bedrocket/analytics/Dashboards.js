//this function is for add, edit, delete the dashboards
module.exports = {
  tags: [ 'dashboards' ],
  before: function ( analyticsLogin ) {
    var profile = analyticsLogin.globals.analytics;
    analyticsLogin.analyticsLogin ( profile.portalUri, profile.username, profile.password, 'ANALYTICS' );
  },
  after: function ( closeBrowser ) {
    //end the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'analytics.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //empty excel input array
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'AddDashboard': function ( addChart ) {
    //Access the variable globally defined
    var excel = addChart.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
        var excelRow = 1;
        addChart.pause ( 10000 ).
        useXpath ( ).
        waitForElementVisible ( "html/body/div[2]//*//ul[1]/div[2]/ul/li[11]//a[contains(.,'All')]", 15000, false ).
        click ( "html/body/div[2]//*//ul[1]/div[2]/ul/li[11]/a[@class='plus-sign']" ).
        acceptAlert ( ).
        useCss ( ).
        pause ( 2000 ).
        //getting the total of dashboards count from Dashboard listpage
        getText ( '.content-count > strong', function ( defaultDashboardCount ) {
          var actualTotal = parseInt ( defaultDashboardCount.value );
          console.log ( "currentcount", actualTotal );
          addChart.verify.visible ( "ng-include.sidebar:nth-child(2) > nav:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > ul:nth-child(1) > div:nth-child(1) > a:nth-child(2)", "DASHBOARDS" ).
          pause ( 5000 ).
          click ( "ng-include.sidebar:nth-child(2) > nav:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > ul:nth-child(1) > div:nth-child(1) > span:nth-child(3) > a:nth-child(1)" ).
          pause ( 5000 ).
          click ( '.text-input-headline' ).
          pause ( 5000 ).
          setValue ( '.text-input-headline', excel.A[ excelColumn ] ).
          pause ( 5000 ).
          verify.visible ( ".empty-page-description", "Add charts to your dashboard to track different sets of data." ).
          //verifies the Add button visibility
          verify.visible ( '.btn-primary', "Add" ).
          //clicks on Add Chart button
          click ( ".col-3 > button:nth-child(1)" ).
          useXpath ( ).
          pause ( 9000 ).
          //click the Metric dropdown
          click ( "//a[contains(.,'Choose metric')]" ).
          pause ( 9000 ).
          //select the Metric as input from the excel
          click ( "//*[@class='dashboard-dropdown first']/div/ul/li/a[contains(.,'" + excel.B[ excelColumn ] + "')]" ).
          pause ( 9000 ).
          //click the Chart Type dropdown
          click ( "//a[contains(.,'Choose chart type')]" ).
          pause ( 9000 ).
          //select the Chart Type as input from the excel
          click ( "//*[@class='dashboard-dropdown']/div/ul/li/a[contains(.,'" + excel.C[ excelColumn ] + "')]" ).
          pause ( 9000 ).
          //click the segment dropdown
          click ( "//a[contains(.,'Choose segment')]" ).
          pause ( 9000 ).
          //select the segment as input from the excel
          click ( "//*[@class='dashboard-dropdown']/div/ul/li/a[contains(.,'" + excel.D[ excelColumn ] + "')]" ).
          //clicks on Add Chart button
          click ( '//*[@class="centered-content"]/a/button' ).
          pause ( 15000 ).
          //check the Contents displayed after Clicking Add button
          waitForElementVisible ( "//div[contains(@ng-controller,'DashboardComponentController')]", 9000, false, function ( chartContent ) {
            if ( chartContent.value == true ) {
              addChart.
              waitForElementVisible ( "//div/h2[@class='ng-binding']", 9000, false, function ( chartTitle ) {
                if ( chartTitle.value == true ) {
                  addChart.getText ( "//div/h2[@class='ng-binding']", function ( chartHeading ) {
                    var checkChartHeading = chartHeading.value.includes ( "" + excel.B[ excelColumn ] + "" );
                    if ( checkChartHeading == true ) {
                      //click on Save button to Save a Dashboard
                      addChart.click ( "//span[contains(.,'Save')]" ).
                      pause ( 5000 ).
                      moveToElement ( "html/body/div[2]/*[contains(.,'All')]", 0, 0 ).
                      waitForElementPresent ( "html/body/div[2]/*[contains(.,'All')]", 9000, false, function ( getDashboardCount ) {
                        if ( getDashboardCount.status == 0 ) {
                          addChart.
                          click ( "html/body/div[2]/*[contains(.,'All')]" ).
                          useCss ( ).
                          pause ( 15000 ).
                          //Get the count of dashboard after adding the chart
                          waitForElementVisible ( '.container-head > h1 > strong', 10000, false ).
                          getText ( '.container-head > h1 > strong', function ( dashboardCount ) {
                            var actualCount = parseInt ( actualTotal ) + 1;
                            console.log ( "ActualCount", actualCount );
                            //compare the count of the dashboard
                            if ( dashboardCount.value == actualCount ) {
                              addChart.writeToExcelPass ( 'analytics.xlsx', 'AddDashboard', ++excelRow, 5 );
                            }
                            else {
                              //write fail to excel as Unable to add the chart in Dashboard
                              this.verify.fail ( dashboardCount.value, actualCount, 'Unable to add the chart in Dashboard' );
                              addChart.writeToExcelFail ( 'analytics.xlsx', 'AddDashboard', ++excelRow, 5, 6, "ActualResult: '" + dashboardCount.value + ". ExpectedResult: '" + actualCount + "' (  Unable to add the chart in Dashboard )" );
                            }
                          } );
                        }
                        else {
                          //write fail to excel as unable to fetch the count after the chart gets added in Dashboard
                          this.verify.fail ( getDashboardCount.value, 'true', 'Unable to fetch the count after the chart gets added in Dashboard' );
                          addChart.writeToExcelFail ( 'analytics.xlsx', 'AddDashboard', ++excelRow, 5, 6, "ActualResult: '" + getDashboardCount.value + ". ExpectedResult: 'true' ( Unable to fetch the count after the chart gets added in Dashboard )" );
                        }
                      } );
                    }
                    else {
                      //write fail to excel as after adding the Chart title mismatch with the displayed title
                      this.verify.fail ( checkChartHeading, 'true', 'After adding the Chart title mismatch with the displayed title' );
                      addChart.writeToExcelFail ( 'analytics.xlsx', 'AddDashboard', ++excelRow, 5, 6, "ActualResult: '" + checkChartHeading + ". ExpectedResult: 'true' ( After adding the Chart title mismatch with the displayed title )" );
                    }
                  } );
                }
                else {
                  //write fail to excel as after adding its fail to display the chart title in dashboard
                  this.verify.fail ( chartTitle.value, 'true', 'After adding its fail to display the chart title in dashboard' );
                  addChart.writeToExcelFail ( 'analytics.xlsx', 'AddDashboard', ++excelRow, 5, 6, "ActualResult: '" + chartTitle.value + ". ExpectedResult: 'true' ( After adding its fail to display the chart title in dashboard )" );
                }
              } );
            }
            else {
              //write fail to excel as after adding its fail to generate the chart content in dashboard
              this.verify.fail ( chartContent.value, 'true', 'After adding its fail to generate the chart content in dashboard' );
              addChart.writeToExcelFail ( 'analytics.xlsx', 'AddDashboard', ++excelRow, 5, 6, "ActualResult: '" + chartContent.value + ". ExpectedResult: 'true' ( After adding its fail to generate the chart content in dashboard )" );
            }
          } );
        } );
      }
    }
    else {
      console.log ( "No input in Excel or Check the Excel Name for the script 'AddDashboard'" );
    }
  },
  'EditDashboard': function ( editChart ) {
    //Access the variable globally defined
    var excel = editChart.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
        var excelRow = 1;
        editChart.pause ( 10000 ).
        useXpath ( ).
        //check the visibility of dashboard 'All' button 
        waitForElementVisible ( "html/body/div[2]//*//ul[1]/div[2]/ul/li[11]//a[contains( .,'All')]", 3000, false, function ( searchDashboard ) {
          if ( searchDashboard.value == true ) {
            editChart.
            acceptAlert ( ).
            click ( "html/body/div[2]//*//ul[1]/div[2]/ul/li[11]//a[contains( .,'All')]" ).
            //get the dashboard count before edit the existing dashboard
            getText ( "//strong[@class='ng-binding']", function ( getDefaultCount ) {
              editChart.waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 5000, false, function ( searchFieldInput ) {
                if ( searchFieldInput.value == true ) {
                  editChart.clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                  setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", excel.A[ excelColumn ] ).
                  pause ( 5000 ).
                  searchElement(excel.A[excelColumn], ++excelRow, 'analytics.xlsx', 'EditDashboard');
                  if ( excel.C.length==1) {
                      //check the visibility of the heading after clicking the edit dashboard button 
                    editChart.pause(5000).
                    waitForElementPresent ( "//div/text-field/input", 5000, false, function ( dashboardHeadline ) {
                      if ( dashboardHeadline.status == 0 ) {
                        //Check the headline of the dashboard
                        editChart.clearValue ( "//div/text-field/input" ).
                        setValue ( "//div/text-field/input", excel.B[ excelColumn ] ).
                        //edit the created chart in the dashboard 
                        waitForElementPresent ( "//a/i[contains( .,'␡')]", 5000, false, function ( removeChart ) {
                          if ( removeChart.status == 0 ) {
                            editChart.elements ( "xpath", "//a/i[contains( .,'␡')]", function ( chartCount ) {
                              var remveChartCount = chartCount.value.length;
                              for ( let editChartCount = 1; editChartCount <= remveChartCount; editChartCount++ ) {
                                editChart.click ( "//a/i[contains( .,'␡')]" ).
                                pause ( 5000 );
                              }
                            } );
                          }
                        } );
                        editChart.waitForElementNotPresent ( "//a/i[contains( .,'␡')]", 5000, false, function ( removeChart ) {
                          if ( removeChart.status == 0 ) {
                            editChart.waitForElementVisible ( "//div[@class='empty-page-title']", 5000, false, function ( emptyPageTitle ) {
                              if ( emptyPageTitle.value == true ) {
                                editChart.click ( "//a[@ng-click='save()']" ).
                                pause ( 5000 ).
                                click ( "html/body/div[2]//*//ul[1]/div[2]/ul/li[11]//a[contains( .,'All')]" ).
                                pause ( 5000 ).
                                getText ( "//strong[@class='ng-binding']", function ( getEditCount ) {
                                  if ( getDefaultCount.value == getEditCount.value ) {
                                    //write to excel as "pass" if the dashboard edited successfully
                                    editChart.writeToExcelPass ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3 );
                                  }
                                  else {
                                    //write to excel as "fail" if unable to edit the dashboard
                                    this.verify.fail ( getEditCount.value, getDefaultCount.value, 'Fail to edit the existing dashboard' );
                                    editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "ActualResult: '" + getEditCount + ". ExpectedResult: '" + getDefaultCount.value + "' (  Fail to edit the existing dashboard )" );
                                  }
                                } );
                              }
                              else {
                                //write to excel as "fail" if unable to edit the dashboard
                                this.verify.fail ( emptyPageTitle.value, true, 'Fail to edit the added chart' );
                                editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "ActualResult: '" + emptyPageTitle.value + ". ExpectedResult: 'true' (  Fail to edit the added chart )" );
                              }
                            } );
                          }
                          else {
                            //write to excel as fail to remove/close the added dashboard component to track different set of data
                            this.verify.fail ( removeChart.value, 'false', 'Fail to remove/close the added dashboard component to track different set of data' );
                            editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "ActualResult: '" + removeChart.value + ". ExpectedResult: 'false' (  Fail to remove/close the added dashboard component to track different set of data )" );
                          }
                        } );
                      }
                      else {
                        this.verify.fail ( dashboardHeadline.value.length, 'not equal to zero', 'Timeout loading issue while redirect to the edit page of dashboard' );
                        editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "Timeout loading issue while redirect to the edit page of dashboard" );
                      }
                    } );
                  }
                  else {
                    //write to excel as 'fail while Unable to edit due to no result found in search
                    editChart.pause(5000).
                    getText ( "//strong[@class='ng-binding']", function ( emptyResult ) {
                      if ( emptyResult.value == '0' ) {
                        this.verify.fail ( undefined, undefined, 'Unable to edit due to no result found while search in dashboard' );
                        editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "Unable to edit due to no result found while search in dashboard" );
                      }
                      else {
                        //write to excel as 'fail' while error in the search functionality
                        this.verify.fail ( emptyResult.value, '0', 'Error in the search functionality as it fail to list the relevant data' );
                        editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "ActualResult: '" + emptyResult.value + ". ExpectedResult: '0' (  Error in the search functionality as it fail to list the relevant data )" );
                      }
                    } );
                  }                
                }
                else {
                  //write to excel as 'fail while error in the Search text box field
                  this.verify.fail ( searchFieldInput.value, true, 'Error in the Search text box field' );
                  editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "ActualResult: '" + searchFieldInput.value + ". ExpectedResult: 'true' (  Error in the Search text box field )" );
                }
              } );
            } );
          }
          else {
            //write to excel as 'fail' due to timeout issue in the visibility of 'All' in Dashboard
            this.verify.fail ( searchDashboard.value, true, "Timeout issue in the visibility of 'All' in Dashboard" );
            editChart.writeToExcelFail ( 'analytics.xlsx', 'EditDashboard', ++excelRow, 3, 4, "ActualResult: '" + searchDashboard.value + ". ExpectedResult: 'true' (  Timeout issue in the visibility of 'All' in Dashboard )" );
          }
        } );
      }
    }
    else {
      console.log ( "No input in Excel or Check the Excel Name for the script 'EditDashboard'" );
    }
  },
  'DeleteDashboard': function ( deleteChart ) {
    //Access the variable globally defined
    var excel = deleteChart.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
        var excelRow = 1;
        deleteChart.pause ( 10000 ).
        useXpath ( ).
        //check the visibility of dashboard 'All' button 
        waitForElementVisible ( "html/body/div[2]//*//ul[1]/div[2]/ul/li[11]//a[contains( .,'All')]", 3000, function ( searchDashboard ) {
          if ( searchDashboard.value == true ) {
            deleteChart.acceptAlert ( ).
            click ( "html/body/div[2]//*//ul[1]/div[2]/ul/li[11]//a[contains( .,'All')]" ).
            waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 5000, false, function ( searchFieldInput ) {
              if ( searchFieldInput.value == true ) {
                deleteChart.clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", excel.A[ excelColumn ] ).
                pause ( 5000 ).
                //get the dashboard count before delete the existing dashboard
                getText ( "//strong[@class='ng-binding']", function ( getDefaultCount ) {
                  //check the search text box present in the dashboard
                  deleteChart.waitForElementPresent ( "//h2[@class='ng-binding'][text ( )='" + excel.A[ excelColumn ] + "']", 5000, false, function ( searchResult ) {
                    if ( searchResult.status == 0 ) {
                      deleteChart.click ( "//h2[@class='ng-binding'][text ( )='" + excel.A[ excelColumn ] + "']" ).
                      pause ( 9000 ).
                      //check the visibility of the heading after clicking the edit dashboard button 
                      waitForElementVisible ( "//div/text-field/input", 5000, false, function ( dashboardHeadline ) {
                        if ( dashboardHeadline.value == true ) {
                          //Check the headline of the dashboard
                          deleteChart.getValue ( "//div/text-field/input", function ( getHeadline ) {
                            if ( getHeadline.value == excel.A[ excelColumn ] ) {
                              deleteChart.waitForElementVisible ( "//a[contains( .,'Delete')]", 5000, false, function ( deleteDashboard ) {
                                if ( deleteDashboard.value == true ) {
                                  deleteChart.click ( "//a[contains( .,'Delete')]" ).
                                  pause ( 5000 ).
                                  click ( "//section/button[contains( .,'Delete')]" ).
                                  pause ( 5000 ).
                                  acceptAlert ( ).
                                  waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 6000, false ).
                                  pause ( 3000 ).
                                  clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                                  setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", excel.A[ excelColumn ] ).
                                  pause ( 5000 ).
                                  getText ( "//strong[@class='ng-binding']", function ( getDeleteCount ) {
                                    var getFinalCount = parseInt ( getDeleteCount.value ) + 1;
                                    deleteChart.clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" );
                                    //compare the before & after delete dashboard count
                                    if ( getFinalCount == getDefaultCount.value ) {
                                      //write to excel as "pass" if the dashboard deleted successfully
                                      deleteChart.writeToExcelPass ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2 );
                                    }
                                    else {
                                      //write to excel as "fail" if unable to delete the dashboard
                                      this.verify.fail ( getFinalCount, getDefaultCount.value, 'Fail to delete the existing dashboard' );
                                      deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "ActualResult: '" + getFinalCount + ". ExpectedResult: '" + getDefaultCount.value + "' (  Unable to delete the added dashboard )" );
                                    }
                                  } );
                                }
                                else {
                                  //write to excel as 'fail if the Delete button is not working properly
                                  this.verify.fail ( deleteDashboard.value, true, 'Delete button is not working properly' );
                                  deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "ActualResult: '" + deleteDashboard.value + ". ExpectedResult: 'true' (  Delete button is not working properly )" );
                                }
                              } );
                            }
                            else {
                              //write to excel as 'fail if the Title of the Dashboard mismatch after clicking Edit button
                              this.verify.fail ( getHeadline.value, excel.A[ excelColumn ], 'Title of the Dashboard mismatch after clicking Edit button' );
                              deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "ActualResult: '" + getHeadline + ". ExpectedResult: '" + excel.A[ excelColumn ] + "' (  Title of the Dashboard mismatch after clicking Edit button )" );
                            }
                          } );
                        }
                        else {
                          this.verify.fail ( dashboardHeadline.value, 'true', 'Timeout loading issue while redirect to the edit page of dashboard' );
                          deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "ActualResult: '" + dashboardHeadline.value + ". ExpectedResult: 'true' (  Timeout loading issue while redirect to the edit page of dashboard )" );
                        }
                      } );
                    }
                    else {
                      //write to excel as 'fail while Unable to delete due to no result found in search
                      deleteChart.getText ( "//strong[@class='ng-binding']", function ( emptyResult ) {
                        if ( emptyResult.value == '0' ) {
                          this.verify.fail ( undefined, undefined, 'Unable to delete due to no result found while search in dashboard' );
                          deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "Unable to delete due to no result found while search in dashboard" );
                        }
                        else {
                          //write to excel as 'fail while error in the search functionality
                          this.verify.fail ( emptyResult.value, '0', 'Error in the search functionality as it fail to list the relevant data' );
                          deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "ActualResult: '" + emptyResult.value + ". ExpectedResult: '0' (  Error in the search functionality as it fail to list the relevant data )" );
                        }
                      } );
                    }
                  } );
                } );
              }
              else {
                //write to excel as 'fail' while error in the Search text box field
                this.verify.fail ( searchFieldInput.value, true, 'Error in the Search text box field' );
                deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "ActualResult: '" + searchFieldInput.value + ". ExpectedResult: 'true' (  Error in the Search text box field )" );
              }
            } );
          }
          else {
            //write to excel as 'fail' due to timeout issue in the visibility of 'All' in Dashboard
            this.verify.fail ( searchDashboard.value, true, "Timeout issue in the visibility of 'All' in Dashboard" );
            deleteChart.writeToExcelFail ( 'analytics.xlsx', 'DeleteDashboard', ++excelRow, 2, 3, "ActualResult: '" + searchDashboard.value + ". ExpectedResult: 'true' (  Timeout issue in the visibility of 'All' in Dashboard )" );
          }
        } );
      }
    }
    else {
      console.log ( "No input in Excel or Check the Excel Name for the script 'DeleteDashboard'" );
    }
  }
};
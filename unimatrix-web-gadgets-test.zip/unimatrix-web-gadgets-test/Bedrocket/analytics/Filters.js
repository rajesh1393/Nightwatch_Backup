var xlsx = require ( 'xlsx' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'analytics.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'Filters' ];
var filtersType = [ ];
var search = [ ];
module.exports = {
  tags: [ 'filters' ],
  before: function ( analyticsLogin ) {
    var profile = analyticsLogin.globals.analytics;
    analyticsLogin.analyticsLogin ( profile.portalUri, profile.username, profile.password, 'ANALYTICS' );
  },
 'Filters': function ( filters ) {
    //Read values from excel
    for ( z in worksheet ) {
      if ( z[ 1 ] === '!' ) continue;
      //Read FiltersType from excel
      if ( z.includes ( 'A' ) ) {
        filtersType.push ( worksheet[ z ].v );
      }
      //Read input for Search from excel
      if ( z.includes ( 'B' ) ) {
        search.push ( worksheet[ z ].v );
      }
    }
    if ( filtersType.length > 0 ) {
      console.log ( "Excel row count: " + filtersType.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1; excelColumn != filtersType.length; excelColumn++ ) {
        var excelRow = 1;
        filters.pause ( 10000 ).
        useXpath ( ).
        moveTo( "html/body/div[2]//*//ul[3]/div/ul/li/a[contains(.,'"+ filtersType[ excelColumn ] +"')]", 0, 0 ).
        //check the visibility of filter to select 
        waitForElementVisible ( "html/body/div[2]//*//ul[3]/div/ul/li/a[contains(.,'"+ filtersType[ excelColumn ] +"')]", 3000, false, function ( filtersTitle ) {
          if ( filtersTitle.value == true ) {
            filters.click ( "html/body/div[2]//*//ul/div/ul/li/a[contains(.,'"+ filtersType[ excelColumn ] +"')]" ).
            pause ( 10000 ).
            waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 5000, false, function ( searchFieldInput ) {
              if ( searchFieldInput.value == true ) {
                filters.clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", search[ excelColumn ] ).
                pause ( 5000 ).
                //get the dashboard count before search 
                getText ( "//strong[@class='ng-binding']", function ( getDefaultCount ) {
                  //check the search text box present in the dashboard
                  filters.waitForElementPresent ( "//h2[@class='ng-binding'][text()='"+ search[ excelColumn ] +"']", 5000, false, function (
                    searchResult ) {
                    if ( searchResult.status == 0 ) {
                      filters.click ( "//h2[@class='ng-binding'][text()='" + search[ excelColumn ] + "']" );
                      filters.writeToExcelPass('analytics.xlsx', 'Filters', ++excelRow, 3 );
                    } 
                    else {
                      //write to excel as 'fail' while Unable to search due to no result found 
                      filters.getText ( "//strong[@class='ng-binding']", function ( emptyResult ) {
                        if ( emptyResult.value == '0' ) {
                          this.verify.fail ( undefined, undefined, 'Fail to search due to no result found' );
                          filters.writeToExcelFail ( 'analytics.xlsx', 'Filters', ++excelRow, 3, 4, "Unable to search due to no result found" );
                        } 
                        else {
                          //write to excel as 'fail' while error in the search functionality
                          this.verify.fail ( emptyResult.value, '0',
                            'Error in the search functionality as it fail to list the relevant data' );
                          filters.writeToExcelFail ( 'analytics.xlsx', 'Filters', ++excelRow, 3, 4, "ActualResult: '" +
                            emptyResult.value + ". ExpectedResult: '0' ( Error in the search functionality as it fail to list the relevant data )" );
                        }
                      } );
                    }
                  } );
                } );
              } 
              else {
                //write to excel as 'fail' while error in the Search text box field
                this.verify.fail ( searchFieldInput.value, true, 'Error in the Search text box field' );
                filters.writeToExcelFail ( 'analytics.xlsx', 'Filters', ++excelRow, 3, 4, "ActualResult: '" + searchFieldInput.value + ". ExpectedResult: 'true' ( Error in the Search text box field )" );
              }
            } );
          } 
          else {
            //write to excel as 'fail' due to timeout issue in the visibility of 'Filters' in Dashboard
            this.verify.fail ( filtersType.value, true, "Timeout issue in the visibility of filters in Dashboard" );
            filters.writeToExcelFail ( 'analytics.xlsx', 'Filters', ++excelRow, 3, 4, "ActualResult: '" + filtersType.value + ". ExpectedResult: 'true' ( Timeout issue in the visibility of filters in Dashboard )" );
          }
        } );
      }
    }
    //close the browser
    filters.end ( );
  }
};
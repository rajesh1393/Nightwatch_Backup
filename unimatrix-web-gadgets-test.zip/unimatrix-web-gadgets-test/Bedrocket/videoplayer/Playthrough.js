//this function is for checking the playthrough functionality in videoplayer
var xlsx = require ( 'xlsx' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'videoplayer.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'Playthrough' ];
var url = [ ];
module.exports = {
  tags: [ 'playthrough' ],
  'Playthrough': function ( playthrough ) {
    //Read values from Excel File
    for ( z in worksheet ) {
      if ( z[ 0 ] === '!' ) continue;
      //Read URL from the Excel file
      if ( z.includes ( 'A' ) ) {
        url.push ( worksheet[ z ].v );
      }
    }
    if ( url.length > 0 ) {
      console.log ( "Excel row count: " + url.length );
      for ( var excelColumn = 1, excelRow = 1; excelColumn != url.length; excelColumn++ ) {
        playthrough.url ( url[ excelColumn ] ).
        url ( function ( getUrl ) {
          //Check the string "endslate=true&playthrough=true" present in URL 
          var urlstr = getUrl.value;
          var urlData = urlstr.match ( /endslate=true&playthrough=true/g );
          if ( urlData == "endslate=true&playthrough=true" ) {
            playthrough.playvideo ( ).
            //move the slider to the end of the video time
            slider ( ".unimatrix-video-time-slider-progress-bar-handle", 1008, 0 ).
            pause ( 10000 ).
            waitForElementNotVisible ( ".unimatrix-video-controls-bucket.unimatrix-bucket-footer  > .unimatrix-video-seek-buttons-forward.unimatrix-button", 5000, false, function ( playerFrwdBtn ) {
              //Check the video reach to the end of the slider
              if ( playerFrwdBtn.value == false ) {
                playthrough.
                pause ( 8000 ).
                waitForElementVisible ( "div.endslate-related-container", 8000, false, function ( endslateResponse ) {
                  if ( endslateResponse.value == true ) {
                    playthrough.pause ( 5000 ).
                    //Check the next level of video playing automatically
                    waitForElementNotPresent ( "div.endslate-related-container", 7000, false, function ( playthroughResponse ) {
                      if ( playthroughResponse.value.length == 0 ) {
                        this.verify.ok ( true, "Playthrough functionality is working" );
                        //write the pass status in excel sheet as the playthrough functionality working as defined
                        playthrough.writeToExcelPass ( 'videoplayer.xlsx', 'Playthrough', ++excelRow, 2 );
                      }
                      else {
                        this.verify.fail ( playthroughResponse.value, 'true', "Playthrough functionality is not working" );
                        //write the fail status in excel sheet as the error in playthrough functionality 
                        playthrough.writeToExcelFail ( 'videoplayer.xlsx', 'Playthrough', ++excelRow, 2, 3, "Error in the Loading of Next level Videos automatically ( Playthrough functionality is not working )" );
                      }
                    } );
                  }
                  else {
                    this.verify.fail ( endslateResponse.value, true,
                      "Player doesn't display the next relevant item after reach the end of the video" );
                    //write the fail status in excel sheet as the error in displaying the next level videos automatically
                    playthrough.writeToExcelFail ( 'videoplayer.xlsx', 'Playthrough', ++excelRow, 2, 3, "ActualResult: '" +
                      endslateResponse.value +
                      "'.ExpectedResult: 'True' ( Player doesn't display the next relevant item after reach the end of the video ) " );
                  }
                } );
              }
              else {
                this.verify.fail ( playerFrwdBtn.value, false, "Fail to reach the end of the video" );
                //write the fail status in excel sheet as the player fail to reach the end of the video 
                playthrough.writeToExcelFail ( 'videoplayer.xlsx', 'Playthrough', ++excelRow, 2, 3, "ActualResult: '" + playerFrwdBtn.value +
                  "'.ExpectedResult: 'false' Player doesn't reach the end of the video " );
              }
            } );
          }
          else {
            this.verify.fail ( urlData, "playthrough=true", "Player doesn't support playthrough option" );
            //write the fail status in excel sheet as the player fail to support playthrough option
            playthrough.writeToExcelFail ( 'videoplayer.xlsx', 'Playthrough', ++excelRow, 2, 3, "ActualResult: '" + urlData +
              "'.ExpectedResult: 'playthrough=true' ( Player doesn't support playthrough option )" );
          }
        } );
      }
    }
    playthrough.end ( );
  },
};
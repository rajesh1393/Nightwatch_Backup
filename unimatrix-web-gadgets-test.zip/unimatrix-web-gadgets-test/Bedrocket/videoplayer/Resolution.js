//this function is for checking the Resolution functionality in videoplayer
var xlsx = require ( 'xlsx' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'videoplayer.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'Resolution' ];
var url = [ ];
var pixel = [ ];
module.exports = {
  tags: [ 'resolution' ],
  'Player-Resolution': function ( resolution ) {
    //Read values from Excel File
    for ( z in worksheet ) {
      if ( z[ 0 ] === '!' ) continue;
      //Read URL
      if ( z.includes ( 'A' ) ) {
        url.push ( worksheet[ z ].v );
      }
      //Read HD pixel
      if ( z.includes ( 'B' ) ) {
        pixel.push ( worksheet[ z ].v );
      }
    }
    if ( url.length > 0 ) {
      console.log ( "Excel row count: " + url.length );
      for ( let excelColumn = 1, excelRow = 1; excelColumn != url.length; excelColumn++ ) {
        resolution.url ( url[ excelColumn ] ).
        playvideo ( ).
        keys ( resolution.Keys.ENTER ).
        waitForElementVisible ( ".unimatrix-video-controls-bucket.unimatrix-bucket-footer > .unimatrix-source-group-button.unimatrix-button", 9000, function ( sourceGroupBtn ) {
          if ( sourceGroupBtn.value == true ) {
            resolution.click ( ".unimatrix-video-controls-bucket.unimatrix-bucket-footer > .unimatrix-source-group-button.unimatrix-button" ).
            useXpath ( ).
            waitForElementVisible ( "//li[contains(text(),'" + pixel[ excelColumn ] + "')]", 9000, function ( videoQuality ) {
              if ( videoQuality.value == true ) {
                resolution.moveToElement ( "//div[@class='unimatrix-modal modal-video-quality align-right']//*/li[contains ( text ( ),'" + pixel[ excelColumn ] + "' )]", 0, 0 ).
                pause ( 5000 ).
                click ( "//div[@class='unimatrix-modal modal-video-quality align-right']//*/li[contains ( text ( ),'" + pixel[ excelColumn ] + "' )]" ).
                pause ( 5000 ).
                useCss ( ).
                //Check the video start playing from the beginning after selecting the pixel
                getText ( ".unimatrix-video-current-time-display > span", function ( currenttime ) {
                  if ( currenttime.value == '00:00' ) {
                    this.verify.ok ( "Refresh and Playing from the beginning after selecting the pixel" );
                    resolution.pause ( 9000 ).
                    //Verify the selected pixel and the video pixel are same
                    getText ( ".unimatrix-modal.modal-video-quality.align-right>ul>li.selected", function ( playerResolution ) {
                      if ( playerResolution.value == pixel[ excelColumn ] ) {
                        resolution.writeToExcelPass ( 'videoplayer.xlsx', 'Resolution', ++excelRow, 3 );
                      }
                      else {
                        this.verify.fail ( playerResolution.value, pixel[ excelColumn ], "Video Quality option not working properly" );
                        //write fail status in excel sheet as the Video Quality option not working properly
                        resolution.writeToExcelFail ( 'videoplayer.xlsx', 'Resolution', ++excelRow, 3, 4, "Video Quality option for selecting video pixel not working properly" );
                      }
                    } );
                  }
                  else {
                    this.verify.fail ( currenttime.value, '00:00', "Fail to refresh the player after selecting the Video Quality" );
                    //write fail status in excel sheet as the Video fail to refresh after selecting the Video Quality
                    resolution.writeToExcelFail ( 'videoplayer.xlsx', 'Resolution', ++excelRow, 3, 4, "Fail to refresh the player after selecting the Video Quality" );
                  }
                } );
              }
              else {
                this.verify.fail ( videoQuality.value, 'true', "Video Quality of " + pixel[ excelColumn ] + " is not visible" );
                //write fail status in excel sheet as the Video Quality is not visible
                resolution.writeToExcelFail ( 'videoplayer.xlsx', 'Resolution', ++excelRow, 3, 4, "Video Quality of " + pixel[ excelColumn ] + " is not visible" );
              }
            } );
          }
          else {
            this.verify.fail ( sourceGroupBtn.value, 'true', "Video settings button is not visible" );
            //write fail status in excel sheet as the Video settings button is not visible
            resolution.writeToExcelFail ( 'videoplayer.xlsx', 'Resolution', ++excelRow, 3, 4, "Video settings button is not visible" );
          }
        } );
      }
    }
    resolution.end ( );
  },
};
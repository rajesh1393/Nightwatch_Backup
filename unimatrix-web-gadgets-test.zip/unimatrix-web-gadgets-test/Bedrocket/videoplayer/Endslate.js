//this function is to check the Endslate functionality in videoplayer 
var xlsx = require ( 'xlsx' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined') XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'videoplayer.xlsx' );
var worksheet = workbook.Sheets[ 'Endslate' ];
var url = [ ];
module.exports = {
  tags: [ 'endslate' ],
  'Endslate': function ( endslate ) {
    //Read values from Excel File
    for ( z in worksheet ) {
      if ( z[ 0 ] === '!' ) continue;
      //Read URL from excel sheet
      if ( z.includes ( 'A' ) ) {
        url.push ( worksheet[ z ].v );
      }
    }
    if ( url.length > 0 ) {
      console.log ( "Excel row count: " + url.length );
      for ( var excelColumn = 1, excelRow = 1; excelColumn < url.length; excelColumn++ ) {
        endslate.url ( url[ excelColumn ] ).
        url ( function ( getUrl ) {
          //Check the string "endslate=true" present in URL 
          var urlstr = getUrl.value;
          var urlData = urlstr.match ( /endslate=true/g );
          if ( urlData == "endslate=true" ) {
            endslate.playvideo ( ).
            //move the slider to the end of the video time
            slider ( ".unimatrix-video-time-slider-progress-bar-handle", 1008, 0 ).
            pause ( 10000 ).
            waitForElementNotVisible ( ".unimatrix-video-controls-bucket.unimatrix-bucket-footer  > .unimatrix-video-seek-buttons-forward.unimatrix-button", 5000, false, function ( playerFrwdBtn ) {
              if ( playerFrwdBtn.value == false ) {
                //Check the video reach to the end of the slider
                endslate.pause ( 5000 ).
                //Check the gadgets-endslate visibility 
                waitForElementVisible ( "div.endslate-related-container", 5000, false, function ( endslateResponse ) {
                  if ( endslateResponse.value == true ) {
                    this.verify.ok ( true, "Endslate functionality is working" );
                    endslate.writeToExcelPass ( 'videoplayer.xlsx', 'Endslate', ++excelRow, 2 );
                  }
                  else {
                    //check the videoplayer display the next level of relevant videos
                    endslate.writeToExcelFail ( 'videoplayer.xlsx', 'Endslate', ++excelRow, 2, 3,
                      "Player doesn't display the Next level Videos and the Endslate functionality is not working" );
                  }
                } );
              }
              else {
                //check the videoplayer reach the end of the video which matches with the player duration time
                this.verify.fail ( playerFrwdBtn.value, true,
                  "Timeout issue as the player doesn't reach the end of the video to check the endslate functionality" );
                endslate.writeToExcelFail ( 'videoplayer.xlsx', 'Endslate', ++excelRow, 2, 3, "ActualResult: '" + playerFrwdBtn.value +
                  "'.ExpectedResult: 'True' ( Timeout issue as the player doesn't reach the end of the video to check the endslate functionality ) " );
              }
            } );            
          }
          else {
            //check the videoplayer support the endslate option
            this.verify.fail ( urlData, "endslate=true", "Player doesn't support endslate option" );
            endslate.writeToExcelFail ( 'videoplayer.xlsx', 'Endslate', ++excelRow, 2, 3, "ActualResult: '" + urlData +
              "'.ExpectedResult: 'endslate=true' ( Player doesn't support endslate option )" );
          }
        } );
      }
    }
    endslate.end ( );
  },
};
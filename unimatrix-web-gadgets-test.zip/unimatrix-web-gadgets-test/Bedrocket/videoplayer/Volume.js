//this function is to check the volume in videoplayer 
var xlsx = require ( 'xlsx' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'videoplayer.xlsx' );
var worksheet = workbook.Sheets[ 'Volume' ];
var playerurl = [ ];
var volumelevel = [ ];
var result = [ ];
module.exports = {
  tags: [ 'volume' ],
  'Volume': function ( volume ) {
    //Read values from Excel File
    for ( z in worksheet ) {
      if ( z[ 0 ] === '!' ) continue;
      //Read URL from excel sheet
      if ( z.includes ( 'A' ) ) {
        playerurl.push ( worksheet[ z ].v );
      }
      //Read volumelevel from excelsheet
      if ( z.includes ( 'B' ) ) {
        volumelevel.push ( worksheet[ z ].v );
      }
    }
    if ( playerurl.length > 0 ) {
      console.log ( "Excel row count: " + playerurl.length );
      for ( let excelColumn = 1, excelRow = 1; excelColumn <= playerurl.length - 1; excelColumn++ ) {
        var urlStr = playerurl[ excelColumn ];
        var urlData = urlStr.match ( /volume=/ );
        var urlVolumeLevel = urlStr.substring ( urlStr.indexOf ( '=' ) + 1 );
        volume.
        url ( playerurl[ excelColumn ] ).
        playvideo ( ).
        keys ( volume.Keys.ENTER ).
        waitForElementPresent ( ".unimatrix-video-volume-button.unimatrix-button", 5000, false, function ( checkVolumeButton ) {
          if ( checkVolumeButton.value.length != null ) {
            volume.getAttribute ( ".unimatrix-video-volume-handle", "style", function ( defaultVolume ) {
              if ( urlData == "volume=" ) {
                var defaultVolumeLevel = defaultVolume.value.substring ( 8, defaultVolume.value.indexOf ( 'px' ) ) * 1.0417;
                var defaultVolLevel = parseFloat ( defaultVolumeLevel.toFixed(2) )
                if ( defaultVolLevel == urlVolumeLevel ) {
                  volume.verify.ok ( true, "Volume level equal to the volume in the URL" );
                  volume.url ( urlStr + '&autoplay=true&endslate=true&playthough=true' );
                }
                else {
                  result.push ( 'FAIL' );
                  this.verify.fail ( defaultVolLevel, urlVolumeLevel, "By default, video doesn't play with maximum volume" );
                  volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + defaultVolLevel + "' ExpectedResult: '" + urlVolumeLevel + "'(By default, video doesn't play with maximum volume)" );
                }
              }
              else {
                if ( defaultVolume.value == "bottom: 96px;" ) {
                  volume.verify.ok ( true, "Player Volume in maximum level" );
                  volume.url ( urlStr + '?autoplay=true&endslate=true&playthough=true' );
                }
                else {
                  result.push ( 'FAIL' );
                  this.verify.fail ( defaultVolume.value, "bottom: 96px;", "By default, video doesn't play with maximum volume" );
                  volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + defaultVolume.value + "'.ExpectedResult: 'bottom: 96px;'(By default, video doesn't play with maximum volume)" );
                }
              }
            } );
          }
          else {
            result.push ( 'FAIL' );
            this.verify.fail ( checkVolumeButton.value, true, "Player fail to display the volume button" );
            volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + checkVolumeButton.value + "'.ExpectedResult: 'true'(Player fail to display the volume button)" );
          }
        } );
        volume.
        pause ( 5000 ).
        getAttribute ( ".unimatrix-video-volume-handle", "style", function ( volumeAfterPageRefresh ) {
          if ( ! ( result.indexOf ( 'FAIL' ) >= 0 ) ) {
            var volumeAfterRefresh = volumeAfterPageRefresh.value.substring ( 8, volumeAfterPageRefresh.value.indexOf ( 'px' ) ) * 1.0417;
            if ( parseFloat ( volumeAfterRefresh.toFixed(2) ) == urlVolumeLevel || volumeAfterPageRefresh.value == "bottom: 96px;" ) {
              volume.verify.ok ( true, "Volume level remains same after refreshing player" );
              volume.keys ( volume.Keys.ENTER ).
              waitForElementPresent ( ".unimatrix-video-controls", 9000, false, function ( ) {
                if ( playerurl[ excelColumn ].match(/volume=0/) == true ) { }
                else {
                  volume.click ( ".unimatrix-video-volume-button.unimatrix-button" );
                }
              } );
              volume.
              waitForElementPresent ( ".unimatrix-video-controls > div > div.muted.lowVolume", 15000, false, function ( checkMuteButton ) {
                if ( checkMuteButton.value.length != 0 ) {
                  volume.getAttribute ( ".unimatrix-video-volume-handle", "style", function ( checkMute ) {
                    if ( checkMute.value == "bottom: 0px;" ) {
                      volume.verify.ok ( true, "Player-volume mute is working" );
                      volume.click ( ".unimatrix-video-controls > div > div.muted.lowVolume" ).
                      pause ( 5000 ).
                      moveToElement ( ".unimatrix-video-volume-container > div[style='" + volumeAfterPageRefresh.value + "']", 0, 0 ).
                      pause ( 2000 ).
                      mouseButtonDown ( 0 ).
                      pause ( 2000 ).
                      moveToElement ( ".unimatrix-video-volume-container > div[style='" + volumeAfterPageRefresh.value + "']", 0, volumelevel[ excelColumn ] ).
                      pause ( 2000 ).
                      mouseButtonUp ( 0 ).
                      getAttribute ( ".unimatrix-video-volume-handle", "style", function ( checkVolumeHandler ) {
                        if ( checkVolumeHandler.value != volumeAfterPageRefresh.value ) {
                          this.verify.ok ( true, "Player-volume handler drag and drop working fine" );
                          volume.click ( ".unimatrix-video-volume-button.unimatrix-button" ).
                          click ( ".unimatrix-video-volume-button.unimatrix-button" ).
                          getAttribute ( ".unimatrix-video-volume-handle", "style", function ( volumeHandlePosition ) {
                            if ( checkVolumeHandler.value == volumeHandlePosition.value ) {
                              this.verify.ok ( true, "Before and after mute level of volume constant" );
                              volume.slider ( ".unimatrix-video-time-slider-progress-bar-handle", 1008, 0 ).
                              keys ( volume.Keys.ENTER ).
                              pause ( 15000 ).
                              waitForElementPresent ( ".related-artifact-item", 15000, false, function ( playerScrubberBar ) {
                                if ( playerScrubberBar.value.length != null ) {
                                  volume.pause ( 10000 ).
                                  keys ( volume.Keys.ENTER ).
                                  waitForElementPresent ( ".unimatrix-video-control-bar", 9000, false, function ( videoPlaythrough ) {
                                    if ( videoPlaythrough.value.length != null ) {
                                      volume.getAttribute ( ".unimatrix-video-volume-handle", "style", function ( autoplayVolume ) {
                                        if ( volumeHandlePosition.value == autoplayVolume.value ) {
                                          volume.verify.ok ( true, "Volume for the next relevant video working fine" );
                                          volume.writeToExcelPass ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3 );
                                        }
                                        else {
                                          this.verify.fail ( autoplayVolume.value, volumeHandlePosition.value, "Volume varies in the upcoming relevant video" );
                                          volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + autoplayVolume.value + "'.ExpectedResult: '" + volumeHandlePosition.value + "'(Volume varies in the upcoming relevant video)" );
                                        }
                                      } );
                                    }
                                    else {
                                      this.verify.fail ( videoPlaythrough.value, true, "Error in loading the next relevant video for checking volume" );
                                      volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + videoPlaythrough.value + "'.ExpectedResult: 'true'(Error in loading the next relevant video for checking volume)" );
                                    }
                                  } );
                                }
                                else {
                                  this.verify.fail ( playerScrubberBar.value, 'true', "Scrubber bar is not working properly" );
                                  volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + playerScrubberBar.value + "'.ExpectedResult: 'true'(Scrubber bar is not working properly while drags forward to check volume of next relevant video )" );
                                }
                              } );
                            }
                            else {
                              this.verify.fail ( checkVolumeHandler.value, volumeHandlePosition.value, "Before and after mute level of volume varies" );
                              volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + checkVolumeHandler.value + "'.ExpectedResult: '" + volumeHandlePosition.value + "'(Before and after mute level of volume varies)" );
                            }
                          } );
                        }
                        else {
                          this.verify.fail ( checkVolumeHandler.value, "Not equal to bottom: 96px;", "Error in the drag & drop of the volume handler" );
                          volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + checkVolumeHandler.value + "'.ExpectedResult: 'Not equal to bottom: 96px;'(Error in the drag & drop of the volume handler)" );
                        }
                      } );
                    }
                    else {
                      this.verify.fail ( checkMute.value, "bottom: 0px;", "Error in the Player-volume mute" );
                      volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + checkMute.value + "'.ExpectedResult: 'bottom: 0px;'(Error in the Player-volume mute)" );
                    }
                  } );
                }
                else {
                  this.verify.fail ( checkMuteButton.value, 'true', "Timeout issue or the Mute icon is not visible" );
                  volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + checkMuteButton.value + "'.ExpectedResult: 'true' ( Timeout issue or the Mute icon is not visible )" );
                }
              } );
            }
            else {
              this.verify.fail ( volumeAfterPageRefresh.value, urlVolumeLevel, "Volume level mismatch with the data in the URL after refresh the player" );
              volume.writeToExcelFail ( 'videoplayer.xlsx', 'Volume', ++excelRow, 3, 4, "ActualResult: '" + volumeAfterPageRefresh.value + "'.ExpectedResult: '" + urlVolumeLevel + "'(Volume level mismatch with the data in the URL after refresh the player)" );
            }
          }
        } );
        result.length = 0;
      }
    }
    volume.end ( );
  }
}
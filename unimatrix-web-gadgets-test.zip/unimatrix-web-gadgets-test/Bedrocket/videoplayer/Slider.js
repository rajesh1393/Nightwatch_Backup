//this function is for checking the slider in the videoplayer
var xlsx = require ( 'xlsx' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'videoplayer.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'Slider' ];
var url = [ ];
var date = new Date ( );
module.exports = {
  tags: [ 'slider' ],
  'Slider': function ( timeslider ) {
    //Read values from Excel File
    for ( z in worksheet ) {
      if ( z[ 0 ] === '!' ) continue;
      //Read URL from excel file
      if ( z.includes ( 'A' ) ) {
        url.push ( worksheet[ z ].v );
      }
    }
    if ( url.length > 0 ) {
      console.log ( "Excel row count: " + url.length );
      for ( var excelColumn = 1, excelRow = 1; excelColumn != url.length; excelColumn++ ) {
        timeslider.url ( url[ excelColumn ] ).
        playvideo ( ).
        keys ( timeslider.Keys.ENTER ).
        //moveToElement (".unimatrix-video-control-bar", 0, 0).
        //pause( 9000 ).
        waitForElementVisible ( ".unimatrix-video-time-slider-container", 5000 ).
        pause ( 5000 ).
        //Get the video player current time 
        getText ( ".unimatrix-video-current-time-display > span", function ( getCurrentTime ) {
          var videoPlaytime = getCurrentTime.value;
          timeslider.
          slider ( ".unimatrix-video-time-slider-progress-bar-handle", 300, 0 ).
          //Get the video player current time after drag and drop
          getText ( ".unimatrix-video-current-time-display > span", function ( getForwardTime ) {
            var videoForwardPlaytime = getForwardTime.value;
            //Check the video moves forward functionality
            console.log ("videoPlaytime",videoPlaytime);
            console.log ("videoForwardPlaytime",videoForwardPlaytime);
            if ( videoPlaytime < videoForwardPlaytime ) {
              this.verify.ok ( true, 'Video moves forward successfully' );
              timeslider.
              slider ( ".unimatrix-video-time-slider-progress-bar-handle", 1, 0 ).
              //Check the video moves backward functionality
              getText ( ".unimatrix-video-current-time-display > span", function ( getBackwardTime ) {
                var videoBackwardPlaytime = getBackwardTime.value;
                if ( videoForwardPlaytime > videoBackwardPlaytime ) {
                	this.verify.ok ( true, 'Video moves backward successfully' );
									timeslider.waitForElementVisible ( ".unimatrix-video-controls-bucket.unimatrix-bucket-footer > .unimatrix-video-seek-buttons-forward.unimatrix-button", 5000, false, function ( forwardBtn ) {
									  if ( forwardBtn.value == true ) {
									  	timeslider.click ( ".unimatrix-video-seek-buttons-forward.unimatrix-button" ).
									  	getText ( ".unimatrix-video-current-time-display > span", function ( forwardFifteenSec ) {
          							var videoForwardFifteenSec = forwardFifteenSec.value;
          							console.log ( "videoForwardFifteenSec", videoForwardFifteenSec );
												var startArrFrwd = videoBackwardPlaytime.split ( ':' );
												startArrFrwd[ 0 ] = ( startArrFrwd[ 0 ] ) ? parseInt ( startArrFrwd[ 0 ], 10 ) : 0
												startArrFrwd[ 1 ] = ( startArrFrwd[ 1 ] ) ? parseInt ( startArrFrwd[ 1 ], 10 ) : 0
												date.setMinutes ( startArrFrwd[ 0 ] + 0 );
												date.setSeconds ( startArrFrwd[ 1 ] + 15 );
												var frwdMinutes = ( "0" + date.getMinutes ( ) ).slice ( -2 );
												var frwdSeconds = ( "0" + date.getSeconds ( ) ).slice ( -2 );
												var skipFrwdFifteenSec = frwdMinutes +":"+ frwdSeconds;
												console.log ( "skipFrwdFifteenSec", skipFrwdFifteenSec );
												if ( videoForwardFifteenSec == skipFrwdFifteenSec ) {
													timeslider.waitForElementVisible ( ".unimatrix-video-controls-bucket.unimatrix-bucket-footer > .unimatrix-video-seek-buttons-backward.unimatrix-button", 5000, false, function ( backwardBtn ) {
									  				if ( backwardBtn.value == true ) {
									  					timeslider.click ( ".unimatrix-video-seek-buttons-backward.unimatrix-button" ).
									  					getText ( ".unimatrix-video-current-time-display > span", function ( backwardFifteenSec ) {
          											var videoBackwardFifteenSec = backwardFifteenSec.value;
					        							console.log ( "videoBackwardFifteenSec", videoBackwardFifteenSec );
																var startArrBckwrd = videoForwardFifteenSec.split ( ':' );
																startArrBckwrd[ 0 ] = ( startArrBckwrd[ 0 ] ) ? parseInt ( startArrBckwrd[ 0 ], 10 ) : 0
																startArrBckwrd[ 1 ] = ( startArrBckwrd[ 1 ] ) ? parseInt ( startArrBckwrd[ 1 ], 10 ) : 0
																date.setMinutes ( startArrBckwrd[ 0 ] - 0 );
																date.setSeconds ( startArrBckwrd[ 1 ] - 15 );
																var bckwrdMinutes = ( "0" + date.getMinutes ( ) ).slice ( -2 );
																var bckwrdSeconds = ( "0" + date.getSeconds ( ) ).slice ( -2 );
																var skipbckwrdFifteenSec = bckwrdMinutes + ":" + bckwrdSeconds;
																console.log ( "skipbckwrdFifteenSec", skipbckwrdFifteenSec );	     													
																if ( videoBackwardFifteenSec == skipbckwrdFifteenSec ) {
																	timeslider.writeToExcelPass ( 'videoplayer.xlsx', 'Slider', ++excelRow, 2 );
																}
																else {
																	this.verify.fail ( videoBackwardFifteenSec, skipbckwrdFifteenSec, 'Videoplayer fail to move 15 sec backward' );
																	timeslider.writeToExcelFail ( 'videoplayer.xlsx', 'Slider', ++excelRow, 2, 3, "ActualResult: '" + videoBackwardFifteenSec +"'. ExpectedResult: '" + skipbckwrdFifteenSec +"'( Videoplayer fail to move 15 sec backward )" );
																}
															} );
														}
														else {
															this.verify.fail ( backwardBtn.value, true, 'Video seek button to backward 15 sec not present' );
															timeslider.writeToExcelFail ( 'videoplayer.xlsx', 'Slider', ++excelRow, 2, 3, "ActualResult: '" + backwardBtn.value +"'. ExpectedResult: 'true'( Video seek button to backward 15 sec not present" );												
														}
													} );
												}
												else {
													this.verify.fail ( videoForwardFifteenSec, skipFrwdFifteenSec, 'Videoplayer fail to move 15 sec forward' );
													timeslider.writeToExcelFail ( 'videoplayer.xlsx', 'Slider', ++excelRow, 2, 3, "ActualResult: '" + videoForwardFifteenSec +"'. ExpectedResult: '" + skipFrwdFifteenSec +"'( Videoplayer fail to move 15 sec forward )" );
												}
											} );
										}
										else {
											this.verify.fail ( forwardBtn.value, true, 'Video seek button to forward 15 sec not present' );
											timeslider.writeToExcelFail ( 'videoplayer.xlsx', 'Slider', ++excelRow, 2, 3, "ActualResult: '" + forwardBtn.value +"'. ExpectedResult: 'true'( Video seek button to forward 15 sec not present" );												
										}
									} );
                }
                else {
                  this.verify.fail ( undefined, undefined, 'Videoplayer fail to move backward' );
                  timeslider.writeToExcelFail ( 'videoplayer.xlsx', 'Slider', ++excelRow, 2, 3, "ActualResult: '" + videoForwardPlaytime +
                    "' <= '" + videoBackwardPlaytime + "'. ExpectedResult: '" + videoForwardPlaytime + "' > '" + videoBackwardPlaytime +
                    "' ( Player fail to move backward in progress bar )" );
                }
              } );
            }
            else {
              this.verify.fail ( undefined, undefined, "Videoplayer fail to move forward" );
              timeslider.writeToExcelFail ( 'videoplayer.xlsx', 'Slider', ++excelRow, 2, 3, "ActualResult: '" + videoPlaytime + "' >= '" +
                videoPlaytime + "'. ExpectedResult: '" + videoPlaytime + "' < '" + videoForwardPlaytime +
                "' ( Player fail to move forward in progress bar )" );
            }
          } );
        } );
      }
    }
    timeslider.end ( );
  }
};
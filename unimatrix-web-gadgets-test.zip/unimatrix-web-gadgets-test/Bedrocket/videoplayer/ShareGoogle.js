//this function is for sharing the video in Google
var xlsx = require ( 'xlsx' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'videoplayer.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'ShareGoogle' ];
var url = [ ];
var username = [ ];
var password = [ ];
module.exports = {
  tags: [ 'shareGoogle' ],
  'ShareGoogle': function ( google ) {
    //Read values from Excel File
    for ( z in worksheet ) {
      if ( z[ 0 ] === '!' ) continue;
      //Read URL from Excel File
      if ( z.includes ( 'A' ) ) {
        url.push ( worksheet[ z ].v );
      }
      //Read Username from Excel File
      if ( z.includes ( 'B' ) ) {
        username.push ( worksheet[ z ].v );
      }
      //Read Password from Excel File
      if ( z.includes ( 'C' ) ) {
        password.push ( worksheet[ z ].v );
      }
    }
    if ( url.length > 0 ) {
      console.log ( "Excel row count: " + url.length );
      for ( let excelColumn = 1; excelColumn != url.length; excelColumn++ ) {
        var excelRow = 1;
        //click the video control button to play using custom commands      
        google.share ( url[ excelColumn ] ).
        pause ( 5000 ).
        //click the google icon to share the video
        waitForElementVisible ( ".unimatrix-video-sharing-google", 1000, false, function ( googleIcon ) {
          if ( googleIcon.value == true ) {
            google.          
            click ( ".unimatrix-video-sharing-google" ).
            pause ( 5000 ).
            //switch to the new secondary browser window
            pause ( 6000 ).
            //sign in with the google account using email
            waitForElementPresent ( "#identifierId", 6000, false, function ( googleLogin ) {
              if ( googleLogin.status == 0 ) {
                google.
                setValue ( "#identifierId", username[ excelColumn ] ).
                pause ( 5000 ).
                useXpath ( ).
                click ( "//span[contains(.,'Next')]" ).
                pause ( 5000 ).
                waitForElementNotPresent ( "//div[contains(.,'Enter a valid email or phone number')]", 5000, false, function ( googleLoginError ) {
                  if ( googleLoginError.value == false ) {
                    google.
                    //check the password field is visible
                    waitForElementVisible ( "//input[@type='password']", 2000, false ).
                    //sign in with the google account using password
                    setValue ( "//input[@type='password']", password[ excelColumn ] ).
                    pause (2000 ).
                    //click submit button to sign in
                    click ( "//span[contains(.,'Next')]" ).
                    pause ( 2000 ).
                    waitForElementNotPresent ( "//div[contains(.,'Wrong password. Try again.')]", 1000, false, function ( googlePwdError ) {
                      if ( googlePwdError.status == -1 ) {
                        google.pause ( 5000 ).
                        //check the relevant video title display in google
                        getAttribute ( "//div[@id='W6BtUc']/a", "href", function ( videoTitle ) {
                          var googleVideoTitle = videoTitle.value;
                          if ( url[ excelColumn ] == googleVideoTitle ) {
                            google.waitForElementVisible ("//div[@class='O0WRkf zZhnYe e3Duub C0oVfc']", 5000, false, function ( postBtn ) {
                              if ( postBtn.value == true ) {                              
                                google.                          
                                //click post button to share the video after signin
                                click ( "//div[@class='O0WRkf zZhnYe e3Duub C0oVfc']" ).                                
                                waitForElementPresent ("//div/div[@id='J9Hpafc0']", 5000, false, function ( postMsg ) {
                                  if ( postMsg.value.length != null ) {
                                    google.deleteCookies ( ).
                                    writeToExcelPass ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4 ).
                                    verify.ok ( true, "Post to Google+" );  
                                  }
                                  else {
                                    google.deleteCookies ( ).                             
                                    //video title display in google page mismatch with the videoplayer title 
                                    writeToExcelFail ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4, 5, "Fail to post the video in Google" );
                                    this.verify.fail ( postMsg.value.length, 'Not equal to null', "Fail to post the video in Google" );                          
                                  }
                                } );
                              }
                              else {
                                google.deleteCookies ( ).                             
                                //Write to excel fail as the Post button is not visible   
                                writeToExcelFail ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4, 5, "Fail to display the post button in the Google" );
                                this.verify.fail ( postBtn.value, 'true', "Fail to display the post button in the Google" );              
                              }
                            } );
                          }                     
                          else {
                            google.deleteCookies ( ).                             
                            //video title display in google page mismatch with the videoplayer title 
                            writeToExcelFail ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4, 5, "Video title mismatch with the Video player title while share to Google" );
                            this.verify.fail ( googleVideoTitle, url[ excelColumn], "Video title mismatch with the Video player title while share to Google" );                          
                          }
                        } );
                      }
                      else {
                        google.
                        useXpath ( ).
                        //get the error message for the invalid password
                        getText ( "//div[contains(.,'Wrong password. Try again.')]", function ( googlePwdErrorMsg ) {
                          this.verify.fail ( "Invalid Password", "Valid Password", googlePwdErrorMsg.value );        
                          google.writeToExcelFail ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4, 5, "ActualResult: '" + googlePwdErrorMsg.value +
                            "'. Expected Result: 'Valid Password'" );
                        } );
                      }
                    } );
                  }
                  else {
                    google.
                    //get the error message for the invalid email
                    getText ( "//div[contains(.,'Enter a valid email or phone number')]", function ( googleLoginErrorMsg ) {
                      google.
                      writeToExcelFail ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4, 5, "ActualResult: '" + googleLoginErrorMsg.value +
                        "'. Expected Result: 'Valid Email-Id'" );
                      this.verify.fail ( "Error in Email-Id", "Valid Email-Id", googleLoginErrorMsg.value );                    
                    } );
                  }
                } );
              }
              else {
                google.
                writeToExcelFail ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4, 5, "ActualResult: '" + googleLogin.status +
                  "'. Expected Result: 'Google Email ID to be visible'" );
                this.verify.fail ( "Error in the Google Email Id element to be visible", "Google Email ID to be visible", googleLogin.status );
              }
            } );
          }
          else {
            //return the failure status as the google icon is not present in the video share option
            google.writeToExcelFail ( 'videoplayer.xlsx', 'ShareGoogle', ++excelRow, 4, 5, "ActualResult: '" + googleIcon.value +
              "'. Expected Result: 'true' ( Google icon is not visible while share the video ) " );
          }
        } );
      }
    }
    google.end ( );
  },
};
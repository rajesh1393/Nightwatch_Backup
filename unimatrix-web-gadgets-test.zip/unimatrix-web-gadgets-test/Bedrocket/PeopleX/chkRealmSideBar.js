//Checking the Title section in AllContent page Page
module.exports = {
  tags: [ 'chkRealmSideBar' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.peoplex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'peoplex.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkRealmSideBarFun': function ( checkRealmSideBar ) {
    var excel = checkRealmSideBar.globals.excelCol;
    for ( let inc = 1; inc <= 1; inc++ ) {
      try {
        checkRealmSideBar.
        useXpath ( ).
        //Checking whether the Realm name is displayed in Top title bar
        waitForElementPresent ( "//DIV[@class='current-realm-text ng-binding']", 5000, false, function ( chkPresentPage ) {
          if ( chkPresentPage.value != false ) {
            checkRealmSideBar.
            //Clicking the Realm name to toggle out the realm side bar
            click ( "//DIV[@class='current-realm-text ng-binding']" ).
            //Checking whether the realm name side bar is toggle open
            waitForElementPresent ( "(//DIV[@class='right-sidebar-container auto-untoggle ng-scope expand'])[1]",5000,false,function ( chkSideBarExpandStatus ) {
              if ( chkSideBarExpandStatus.value != false ){
                checkRealmSideBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2 );
              }
              else {
                checkRealmSideBar.
                //Updaitng the Fail status in Excel sheet
                writeToExcelFail ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2, 3, "Realm name sidebar is not getting expanding after clicking on the Realm name" );
              }
            } );
            checkRealmSideBar.
            //Checking whether the Search field is displayed in the Realm side bar
            waitForElementPresent ( "//div/input[@placeholder='Search Realms']", 5000, false, function ( chkSearchField ) { 
              if ( chkSearchField.value != false ){
                checkRealmSideBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2 );
              }
              else {
               checkRealmSideBar.
                //Updaitng the Fail status in Excel sheet
                writeToExcelFail ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2, 3, "Search field is not diplayed in the Realm side bar" );
              }
            } );
            checkRealmSideBar.
            //Checking whether the Realm name logo is displayed 
            waitForElementPresent ( "//DIV[@class='current-realm-logo ng-binding ng-scope people']", 5000, false, function ( chkIndexRealmName ) {
              if ( chkIndexRealmName.value != false ) {
                checkRealmSideBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2 );
              }
              else {
                checkRealmSideBar.
                //Updaitng the Fail status in Excel sheet
                writeToExcelFail ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2, 3, "Realm name Logo is not diplayed in the Realm side bar" );
              }
            } );
          }
          else {
            checkRealmSideBar.
            //Updating the Fail status in the Excel sheet
            writeToExcelFail ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2, 3, "Page not redirected to All contents Page" );
          }
        } );
       } catch ( e ) {
        checkRealmSideBar.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'peoplex.xlsx', 'chkRealmSideBarFun', ++inc, 2, 3, "Execution of the script terminated due to "+e+" reason");
      }
    }
  }
}
module.exports = {
    tags: ['chkSaveBtnInEditPage'],
    before: function ( portalLogin ) {
        var profile = portalLogin.globals.peoplex;
        portalLogin.loginPeoplex ( profile.portalUri, profile.username, profile.password );
    },
    after: function ( closeBrowser ) {
        //End the Browser
        closeBrowser.end ( );
    },
    //Assigning the Excel values to global excel variables
    beforeEach: function ( addXlData, done ) {
        setTimeout ( function ( ) {
            //get the excel sheet name
            var sheetName = addXlData.currentTest.name;
            //read values from excel
            addXlData.excelInput ( 'peoplex.xlsx', sheetName );
            done ( );
        }, 200 );
    },
    //Clearing the Global excel values after each function
    afterEach: function ( clearXlData, done ) {
        setTimeout ( function ( ) {
            clearXlData.emptyExcelInput ( );
            done ( );
        }, 200 );
    },
    'chkSaveBtnInEditPageFun': function ( chkUI ) {
        //Navigating to All people Page.
        try {
            var excel = chkUI.globals.excelCol;
            for ( let inc =1 ; inc <= excel.C.length-1 ; inc++ ) {
            chkUI.
            useXpath ( ).
            //Checking whether the All people menu is displayed
            waitForElementPresent ( "//A/span[text()='all people']", 5000, false, function ( chkVsisbility ) {
                if ( chkVsisbility.value != false ) {
                    chkUI.
                    //Clicking the All people menu from the side bar
                    click ( "//A/span[text()='all people']" ).
                    //checking the Title of the page is displayed as "All People"
                    waitForElementPresent ( "//SPAN[@ng-if='!detailsPage'][text()='All People']", 5000, false, function ( chkTitle ) {
                        if ( chkTitle.value != false ) {
                            chkUI.
                            //Checking whether the Title of the Page is displayed
                            waitForElementPresent ( "//SPAN[@ng-if='!detailsPage'][text()='All People']", 5000, false, function ( chkInviteBtn ) {
                                if ( chkInviteBtn.value != false ) {
                                    chkUI.
                                    //Clicking the Search Icon in All People page
                                    click ( "//INPUT[@id='search_input']" ).
                                    //Entering the Values in the Search field
                                    setValue ( "//INPUT[@id='search_input']", excel.B[inc] ).
                                    //Triggering Enter button from Keyboard
                                    pause ( 8000 ).
                                    //Clicking on the Text field
                                    keys ( chkUI.Keys.NULL );
                                    chkUI.
                                    // Hitting the Enter key after entering the text in the search field
                                    keys ( chkUI.Keys.ENTER );   
                                    chkUI.
                                    waitForElementPresent ( "//SPAN[@class='user-name-label ng-binding'][text()='"+excel.B[inc]+"']/parent::div", 5000, false, function ( chkSearchResult ) {
                                        if ( chkSearchResult.value != false ) {
                                            chkUI.
                                            pause ( 3000 ).
                                            //Clicking the Search result
                                            click ( "//SPAN[@class='user-name-label ng-binding'][text()='"+excel.B[inc]+"']/parent::div" ).
                                            //Checking whether the control is navigated to the Access Page
                                            waitForElementPresent ( "//SPAN[@class='access'][text()='access']", 5000, false, function ( chkPagaTitle ) {
                                                if ( chkPagaTitle.value != false ) {
                                                    chkUI.
                                                    pause ( 5000 ).
                                                    //Clicking on the various access level and Checking the Save button is Enabled
                                                    waitForElementPresent ( '//button[@class="save-button save-inactive"]', 5000, false, function ( chkSaveBtn ) {
                                                        if ( chkSaveBtn.value != false ) {
                                                            if ( excel.C[inc] == "Portal,Pages" ) {
                                                            if ( excel.D[inc] == "Read Only" ) {
                                                                chkUI.
                                                                //Clicking the Read Only access in the Access page
                                                                click ( "(//SPAN[@class='radio-text'][text()='Read Only'])[1]" );
                                                            }
                                                            else if ( excel.D[inc] == "Full Access" ) {
                                                                chkUI.
                                                                //Clicking the Read Only access in the Access page
                                                                click ( "(//SPAN[@class='radio-text'][text()='Full Access'])[1]" );
                                                            }
                                                            else if ( excel.D[inc] == "No Access" ) {
                                                                chkUI.
                                                                //Clicking the Read Only access in the Access page
                                                                click ( "(//SPAN[@class='radio-text'][text()='No Access'])[1]" );
                                                            }
                                                        }
                                                        else {
                                                             if ( excel.D[inc] == "Read Only" ) {
                                                                chkUI.
                                                                //Clicking the Read Only access in the Access page
                                                                click ( "(//SPAN[@class='radio-text'][text()='Read Only'])[2]" );
                                                            }
                                                            else if ( excel.D[inc] == "Full Access" ) {
                                                                chkUI.
                                                                //Clicking the Read Only access in the Access page
                                                                click ( "(//SPAN[@class='radio-text'][text()='Full Access'])[2]" );
                                                            }
                                                            else if ( excel.D[inc] == "No Access" ) {
                                                                chkUI.
                                                                //Clicking the Read Only access in the Access page
                                                                click ( "(//SPAN[@class='radio-text'][text()='No Access'])[2]" );
                                                            }
                                                        }
                                                        chkUI.
                                                        pause ( 3000 ).
                                                        //Checking whether the Save button is geeting enabled
                                                        waitForElementPresent ( "//BUTTON[@class='save-button'][text()='SAVE']", 5000, false, function ( chkSaveBtnStatus ) {
                                                            if ( chkSaveBtnStatus.value != false ) {
                                                                chkUI.
                                                                //Updating the Pass status in the Excel sheet
                                                                writeToExcelPass ( 'peoplex.xlsx', 'chkSaveBtnInEditPageFun', 2, 5 );
                                                            }
                                                            else {
                                                                chkUI.
                                                                //Updating the Fail status in the Excel sheet
                                                                writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInEditPageFun", 2, 5, 6, "Save Button is not getting enabled" );

                                                            }
                                                        } );
                                                    }
                                                        else {
                                                            chkUI.
                                                            //Updating the fail status in the Excel sheet
                                                            writeToExcelFail( "peoplex.xlsx", "chkSaveBtnInEditPageFun", 2, 5, 6,"Save button is in Enabled state without changing any access" );
                                                        }
                                                    } );
                                                }
                                                else {
                                                    chkUI.
                                                    //Updating the fail status in the Excel sheet
                                                    writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInEditPageFun", 2, 5, 6,"Control is not navigated to the Access Page" );
                                                }
                                            } );
                                        }
                                    } );                                    
                                } else {
                                    chkUI.
                                    //Updating the Fail status to Excel sheet
                                    writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInEditPageFun", 2, 5, 6, "Invite button is not displayed" );
                                }
                            } );
                        } else {
                            chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInEditPageFun", 2, 5, 6, "Title of the page is not displayed in the Create People page" );
                        }
                    } );
                }
                else { 
                    chkUI.
                    //Updating the Fail status to Excel sheet
                    writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInEditPageFun", 2, 5, 6, "Title of the page is not displayed in the Create People page" );
                }
            } );
        }
        } catch ( e ) {
            chkUI.
            //Updating the Fail status to Excel sheet
            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInEditPageFun", 2, 5, 6, "Execution of the script terminated due to " + e + " reson" );
        }
    }
}

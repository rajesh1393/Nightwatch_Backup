module.exports = {
  tags: ['createNewUser'],
  before: function(peopleLogin) {
    var profile = peopleLogin.globals.peoplex;
    peopleLogin.loginPage(profile.portalUri, profile.username, profile.password);
  },
  after: function(closeBrowser) {
    //End the Browser
    closeBrowser.end();
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function(addXlData, done) {
    setTimeout(function() {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput('peoplex.xlsx', sheetName);
      done();
    }, 200);
  },
  //Clearing the Global excel values after each function
  afterEach: function(clearXlData, done) {
    setTimeout(function() {
      clearXlData.emptyExcelInput();
      done();
    }, 200);
  },
  'createNewUser': function(newUser) {
    //Access the variable globally defined
    var excel = newUser.globals.excelCol;
    if (excel.A.length > 0) {
      console.log("Excel row count: " + excel.A.length);
      //loop the 'n' number of excel input
      for (let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++) {
        //Checking whether the All people menu is displayed
        newUser.useXpath().
        waitForElementPresent("//A/span[text()='all people']", 5000, false, function(allPeople) {
          if (allPeople.value != false) {
            newUser.click("//A/span[text()='all people']").
            waitForElementPresent("//I[@ng-if='!detailsPage']", 5000, false, function(plusButton) {
              if (plusButton.value != false) {
                newUser.click("//I[@ng-if='!detailsPage']").
                //checking the Title of the page is displayed as "All People"
                waitForElementPresent("//SPAN[@class='title-box'][text()='New User']", 5000, false, function(chkTitle) {
                  if (chkTitle.value != false) {
                    //Clicking the Add Icon in the list page to navigate to the Add People Page
                    newUser.
                    //Updating the Pass status to Excel sheet
                    writeToExcelPass("peoplex.xlsx", "createNewUser", 3, 2).
                    //Checking whether the Cancel button is displayed
                    waitForElementPresent("//BUTTON[@class='cancel-button'][text()='CANCEL']", 5000, false, function(chkCancelBtnWithoutdata) {
                      if (chkCancelBtnWithoutdata.value != false) {
                        newUser.click("//BUTTON[@class='cancel-button'][text()='CANCEL']").
                        waitForElementPresent("//I[@ng-if='!detailsPage']", 5000, false, function(chkCancelBtnWithData) {
                          if (chkCancelBtnWithData.value != false) {
                            newUser.click("//I[@ng-if='!detailsPage']").
                            pause(5000).
                            setValue("//input[@name='userFirstName']", excel.C[excelColumn]).
                            setValue("//input[@name='userLastName']", excel.D[excelColumn]).
                            setValue("//input[@name='userEmail']", excel.E[excelColumn]).
                            pause(5000).
                            click("//BUTTON[@class='cancel-button'][text()='CANCEL']").
                            waitForElementPresent("//I[@ng-if='!detailsPage']", 5000, false, function(chkBtn) {
                              if (chkBtn.value != false) {
                                newUser.click("//I[@ng-if='!detailsPage']").
                                pause(5000).
                                waitForElementPresent("//button[contains(@class,'cta-button')][@disabled='disabled']", 5000, false, function(chkInviteBtnDisabled) {
                                  if (chkInviteBtnDisabled.value == true) {
                                    newUser.
                                    setValue("//input[@name='userFirstName']", excel.C[excelColumn]).
                                    clear("//input[@name='userFirstName']", excel.C[excelColumn]).
                                    waitForElementPresent("//span[contains(.,'Please provide a first name.')]", 5000, false,function(chkFrstNameAlert) {
                                      if (chkFrstNameAlert.value == true) {
                                        setValue("//input[@name='userLastName']", excel.D[excelColumn]).
                                        clear("//input[@name='userLastName']", excel.D[excelColumn]).
                                        waitForElementPresent("//span[contains(.,'Please provide a last name.')]", 5000, false,function(chkLastNameAlert) {
                                          if (chkLastNameAlert.value == true) {
                                            newUser.setValue("//input[@name='userEmail']", excel.E[excelColumn]).
                                            clear("//input[@name='userEmail']", excel.E[excelColumn]).
                                            waitForElementPresent("//span[contains(.,'Please provide a valid email address.')]", 5000, false, function(chkEmailAlert) {
                                              if (chkEmailAlert.value == true) {
                                                newUser.
                                                setValue("//input[@name='userFirstName']", excel.C[excelColumn]).
                                                setValue("//input[@name='userLastName']", excel.D[excelColumn]).
                                                setValue("//input[@name='userEmail']", excel.E[excelColumn]).
                                                pause(5000).
                                                waitForElementPresent("//button[@ng-click='addNewUser( newUser )']", 5000, false,function(chkInviteBtn) {
                                                  if (chkInviteBtn.value == true) {

                                                    



















                                                    }
                                                    else {
                                                      //chkEmailAlert
                                                    }
                                                  });
                                              }
                                              else {
                                                //chkLastNameAlert
                                              }
                                            });
                                        }
                                        else {
                                          //chkFrstNameAlert
                                        }
                                      });
                                  }
                                  else {
                                    //chkInviteBtnDisabled
                                  }
                                });
                              }
                              else {
                                //chkBtn
                              }
                            });
                          }
                          else {
                            //chkCancelBtnWithData
                          }
                        });
                      }
                      else {
                        //chkCancelBtnWithData
                      }
                    });
                  }
                  else {
                    //chkCancelBtnWithoutdata
                  }
                });
              }
              else {
                //chkTitle
              }
            });
          }
          else {
            //plusButton
          }
        });
      }
      else {
        //allPeople
      }
    }
  }
}
else {
  //write to excel 'fail' if error in the excelsheet name
  console.log("No input in Excel or Check the Excel Name for the script 'newUser'");
}
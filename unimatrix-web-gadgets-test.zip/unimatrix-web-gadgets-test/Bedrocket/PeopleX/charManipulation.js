//this command is for adding the label to new Artifact
exports.command = function ( maxCharlocation, txtFieldLocation, excelInput, errMsgLocation ) {
  var allowedCharCount;
  var actualCharCount;
  var inputCharCount = excelInput.length ( );
  this.
  waitForElementPresent ( maxCharlocation, 5000, false, function ( chkVisibility ){
    this.
    getText( maxCharlocation,function ( getmaxCount ) {
      allowedCharCount = getmaxCount.value;
      allowedCharCount = allowedCharCount.substring(allowedCharCount.index("/") + 1 );
      console.log(allowedCharCount);
    } );
    this.
    waitForElementPresent ( txtFieldLocation, 5000, false, function ( chkFieldVisibility ) {
      this.
      setValue ( txtFieldLocation, excelInput ).
      pause ( 5000 ).
      getText( maxCharlocation,function ( getmaxCount ) {
      actualCharCount = getmaxCount.value;
      actualCharCount = actualCharCount.substr(0, actualCharCount.indexOf('/')); 
      actualCharCount = actualCharCount.replace(/\D/g,'');
      console.log(actualCharCount);
      if ( actualCharCount == inputCharCount ) {
        console.log ( "Pass" )
      }
      else if ( inputCharCount > allowedCharCount ) { 
        this.
        waitForElementPresent ( errMsgLocation, 5000, false, function ( chkErrMsg ) {
          if ( chkErrMsg.value != false ) {
            console.log ( "Error message displayed successfully" );
          }
          else {
            console.log ( "Error message not displayed" );
          }
        } );
      }
    } );
    } );
  } );
};
module.exports = {
  tags: [ 'chkTopBarInApps-Peoplex' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.peoplex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'peoplex.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkTopBarInPeoplex': function ( chkTopBar ) {
    //Setting up the Page object model
    var excel = chkTopBar.globals.excelCol;
    chkTopBar.
    useXpath  ( ).
    //Navigating to the Peoplex under Apps menu in Side bar.
    waitForElementPresent ( "(//A[@ng-click='callClickFunction( option )'])[1]", 5000, false, function ( chkElemVisibility ) {
      if ( chkElemVisibility.value != false ) {
        chkTopBar.
        //Clicking the Apps menu from the Sidebar of the application
        click ( "(//A[@ng-click='callClickFunction( option )'])[1]" ).
        //Clicking the Peoplex under Apps manu in the sidebar of the application
        click ( "(//DIV[@class='submenu-list-item ng-binding people'])[1]" ).
        //Checking whether the control is navigated to folders page.
        waitForElementPresent ( "//SPAN[@ng-if='!detailsPage'][text()='PeopleX']", 5000, false, function ( chkPageNavi ) {
          if ( chkPageNavi.value != false ) {
            chkTopBar.
            //Checking whether the Portal text is displayed in the Top bar of the app
            waitForElementPresent ( "//SPAN[@ng-if='!detailsPage'][text()='PeopleX']", 5000, false, function ( chkPlatform ) {
              if ( chkPlatform.value != false ) {
                chkTopBar.
                getText ( "//SPAN[@ng-if='!detailsPage'][text()='PeopleX']", function ( getPlatFormText ) {
                  if ( getPlatFormText.value == "PeopleX" ) {
                    chkTopBar.
                    //Updating the Pass status in Excel sheet
                    writeToExcelPass ( "peoplex.xlsx", "chkTopBarInPeoplex", 2, 2 )
                  } else {
                    chkTopBar.
                    //Updating the Fial status in the Excel sheet
                    writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 2, 2, 3, "Portal text is not displayed as Portal in the Top bar of the application" )
                  }
                } );
              } else {
                chkTopBar.
                //Updating the Fial status in the Excel sheet
                writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 2, 2, 3, "Portal text is not displayed in the Top bar of the application" )
              }
            } );
            chkTopBar.
            //Checking whether the Pages link icon is displayed in Top bar of the app
            waitForElementPresent ( "//I[@class='app-icon pages-app-icon']", 5000, false, function ( chkPlatform ) {
              if ( chkPlatform.value != false ) {
                chkTopBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( "peoplex.xlsx", "chkTopBarInPeoplex", 3, 2 )
              } else {
                chkTopBar.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 3, 2, 3, "Pages icon is not displayed in the Top bar of the application" )
              }
            } );
            chkTopBar.
            //Checking whether the People link icon is displayed in Top bar of the app
            waitForElementPresent ( "//I[@class='app-icon people-app-icon']", 5000, false, function ( chkPlatform ) {
              if ( chkPlatform.value != false ) {
                chkTopBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( "peoplex.xlsx", "chkTopBarInPeoplex", 4, 2 )
              } else {
                chkTopBar.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 4, 2, 3, "People icon is not displayed in the Top bar of the application" )
              }
            } );
            chkTopBar.
            //Checking whether the Realm Name is is displayed in Top bar of the app
            waitForElementPresent ( "//DIV[@class='current-realm-text ng-binding']", 5000, false, function ( chkPlatform ) {
              if ( chkPlatform.value != false ) {
                chkTopBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( "peoplex.xlsx", "chkTopBarInPeoplex", 5, 2 )
              } else {
                chkTopBar.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 5, 2, 3, "Realm name is not displayed in the Top bar of the application" )
              }
            } );
            chkTopBar.
            //Checking whether the Realm Name Logo is displayed in Top bar of the app
            waitForElementPresent ( "//SPAN[@class='profile-name ng-binding']", 5000, false, function ( chkPlatform ) {
              if ( chkPlatform.value != false ) {
                chkTopBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( "peoplex.xlsx", "chkTopBarInPeoplex", 6, 2 )
              } else {
                chkTopBar.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 6, 2, 3, "Realm name Logo is not displayed in the Top bar of the application" )
              }
            } );
            chkTopBar.
            //Checking whether the Username Name is is displayed in Top bar of the app
            waitForElementPresent ( "//SPAN[@class='profile-name ng-binding']", 5000, false, function ( chkPlatform ) {
              if ( chkPlatform.value != false ) {
                chkTopBar.
                getText ( "//SPAN[@class='profile-name ng-binding']", function ( getPlatFormText ) {
                  if ( getPlatFormText.value == "QA Test Staging" ) {
                    chkTopBar.
                    //Updating the Pass status in Excel sheet
                    writeToExcelPass ( "peoplex.xlsx", "chkTopBarInPeoplex", 7, 2 )
                  } else {
                    console.log ( "Fail", "Username is not displayed as QA Test Staging in the Top bar of the application" )
                    chkTopBar.
                    //Updating the Fail status in the Excel sheet
                    writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 7, 2, 3, "Username is not displayed as QA Test Staging in the Top bar of the application" )
                  }
                } );
              } else {
                chkTopBar.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 7, 2, 3, "Username is not displayed in the Top bar of the application" )
              }
            } );
            chkTopBar.
            //Checking whether the Username Name vertical ellipse is is displayed in Top bar of the app
            waitForElementPresent ( "//SPAN[@class='profile-ellipsis']", 5000, false, function ( chkPlatform ) {
              if ( chkPlatform.value != false ) {
                chkTopBar.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( "peoplex.xlsx", "chkTopBarInPeoplex", 8, 2 )
              } else {
                chkTopBar.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 8, 2, 3, "Username vertical is not displayed in the Top bar of the application" )
              }
            } );
          } else {
            chkTopBar.
            //Updating the Fail status in the Excel sheet
            writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 2, 2, 3, "Unable to navigate to folders page" )
          }
        } );
      } else {
        chkTopBar.
        //Updating the Fail status in the Excel sheet
        writeToExcelFail ( "peoplex.xlsx", "chkTopBarInPeoplex", 2, 2, 3, "Unable to navigate to folders page" )
      }
    } );
  }
}
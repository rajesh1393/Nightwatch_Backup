module.exports = {
    tags: ['chkSaveBtnInAddPage'],
    before: function ( portalLogin ) {
        var profile = portalLogin.globals.peoplex;
        portalLogin.loginPeoplex ( profile.portalUri, profile.username, profile.password );
    },
    after: function ( closeBrowser ) {
        //End the Browser
        closeBrowser.end ( );
    },
    //Assigning the Excel values to global excel variables
    beforeEach: function ( addXlData, done ) {
        setTimeout ( function ( ) {
            //get the excel sheet name
            var sheetName = addXlData.currentTest.name;
            //read values from excel
            addXlData.excelInput ( 'peoplex.xlsx', sheetName );
            done ( );
        }, 200 );
    },
    //Clearing the Global excel values after each function
    afterEach: function ( clearXlData, done ) {
        setTimeout ( function ( ) {
            clearXlData.emptyExcelInput ( );
            done ( );
        }, 200 );
    },
    'chkSaveBtnInAddPageFun': function ( chkUI ) {
        //Navigating to All people Page.
        try {
            chkUI.
            useXpath ( ).
            //Checking whether the All people menu is displayed
            waitForElementPresent ( "//A/span[text()='all people']", 5000, false, function ( chkVsisbility ) {
                if ( chkVsisbility.value != false ) {
                    chkUI.
                    //Clicking the All people menu from the side bar
                    click ( "//A/span[text()='all people']" ).
                    //checking the Title of the page is displayed as "All People"
                    waitForElementPresent ( "//SPAN[@ng-if='!detailsPage'][text()='All People']", 5000, false, function ( chkTitle ) {
                        if ( chkTitle.value != false ) {
                            chkUI.
                            //Clicking the Add Icon in the list page to navigate to the Add People Page
                            click ( "//I[@ng-if='!detailsPage']" ).
                            //Checking whether the Invite button is displayed
                            waitForElementPresent ( "//BUTTON[@class='cta-button disabled']", 5000, false, function ( chkInviteBtn ) {
                                if ( chkInviteBtn.value != false ) {
                                    chkUI.
                                    //Updating the Pass status to Excel sheet
                                    writeToExcelPass ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 11, 2 );
                                } else {
                                    chkUI.
                                    //Updating the Fail status to Excel sheet
                                    writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 11, 2, 3, "Invite button is not displayed" );
                                }
                            } );
                        } else {
                            chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 2, 2, 3, "Title of the page is not displayed in the Create People page" );
                        }
                    } );
                    chkUI.
                    //Checking whether the title of the First name field is displayed as "First Name"
                    waitForElementPresent ( "(//LABEL[text()='First Name'])", 5000, false, function ( chkFieldTitle ) {
                        if ( chkFieldTitle.value != false ) {
                            chkUI.
                            getText ( "(//LABEL[text()='First Name'])", function ( getTitle ) {
                                if ( getTitle.value == "First Name" ) {
                                    chkUI.
                                    //Clicking on the Firstname field
                                    click ( "(//LABEL[text()='First Name'])" ).
                                    //Entering the Appropriate details in the First name field
                                    setValue ( "(//INPUT[@required=''])[1]", "Ganesh" );
                                }
                            } );
                        } else {
                            chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 3, 2, 3, "First nem text field is displayed" );
                        }
                    } );
                    chkUI.
                    //Checking whether the title of the First name field is displayed as "First Name"
                    waitForElementPresent ( "(//LABEL[text()='Last Name'])", 5000, false, function ( chkFieldTitle ) {
                        if ( chkFieldTitle.value != false ) {
                            chkUI.
                            getText ( "(//LABEL[text()='Last Name'])", function ( getTitle ) {
                                if ( getTitle.value == "Last Name" ) {
                                    chkUI.
                                    //Clioking on the Last Name Text field.
                                    click ( "(//LABEL[text()='Last Name'])" ).
                                    //Sending the values to the Last Name field
                                    setValue ( "(//INPUT[@required=''])[2]", "kumar" );
                                    console.log("iminifloop")
                                }
                            } );
                        } else {
                            chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 3, 2, 3, "Last name title is not displayed" );
                        }
                    } );
                    chkUI.
                    //Checking whether the title of the First name field is displayed as "First Name"
                    waitForElementPresent ( "(//LABEL[text()='Email'])", 5000, false, function ( chkFieldTitle ) {
                        if ( chkFieldTitle.value != false ) {
                            chkUI.
                            getText ( "(//LABEL[text()='Email'])", function ( getTitle ) {
                                if ( getTitle.value == "Email" ) {
                                    chkUI.
                                    //Clicking the Email text field
                                    click ( "(//LABEL[text()='Email'])" ).
                                    //Sending the TRext to the email field
                                    setValue ( "(//INPUT[@required=''])[3]", "ganeshkumar@angleritech.com" );
                                }
                            } );
                        } else {
                            chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 3, 2, 3, "Email field title is not displayed" );
                        }
                    } );
                    chkUI.
                    //Checking whether the Invite button is displayed
                    waitForElementPresent ( "//BUTTON[@class='cta-button'][text()='INVITE']", 5000, false, function ( chkInviteBtn ) {
                        if ( chkInviteBtn.value != false ) {
                            chkUI.
                            //Updating the Pass status to Excel sheet
                            writeToExcelPass ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 3, 2 );
                        } else {
                            chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 3, 2, 3, "Invite button is not displayed" );
                        }
                    } );
                } else {
                    chkUI.
                    //Updating the Fail status to Excel sheet
                    writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 2, 2, 3, "Title of the page is not displayed in People index page" );
                }
            } );
        } catch ( e ) {
            chkUI.
            //Updating the Fail status to Excel sheet
            writeToExcelFail ( "peoplex.xlsx", "chkSaveBtnInAddPageFun", 2, 2, 3, "Execution of the script terminated due to " + e + " reson" );
        }
    }
}
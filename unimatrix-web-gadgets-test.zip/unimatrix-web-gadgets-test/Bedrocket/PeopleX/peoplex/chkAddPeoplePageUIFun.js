module.exports = {
  tags: ['chkAddPeoplePageUIFun'],
  before: function(peopleLogin) {
    var profile = peopleLogin.globals.peoplex;
    peopleLogin.loginPage(profile.portalUri, profile.username, profile.password);
  },
  after: function(closeBrowser) {
    //End the Browser
    closeBrowser.end();
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function(addXlData, done) {
    setTimeout(function() {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput('peoplex.xlsx', sheetName);
      done();
    }, 200);
  },
  //Clearing the Global excel values after each function
  afterEach: function(clearXlData, done) {
    setTimeout(function() {
      clearXlData.emptyExcelInput();
      done();
    }, 200);
  },
  'chkAddPeoplePageUI': function(chkUI) {
    //Navigating to All people Page.
    try {
    chkUI.
    useXpath().
    //Checking whether the All people menu is displayed
    waitForElementPresent("//A/span[text()='all people']", 5000, false, function(chkVsisbility) {
      if(chkVsisbility.value != false) {
        chkUI.
        //Clicking the All people menu from the side bar
        click("//A/span[text()='all people']").
        //checking the Title of the page is displayed as "All People"
        waitForElementPresent("//SPAN[@ng-if='!detailsPage'][text()='All People']", 5000, false, function(chkTitle) {
          if(chkTitle.value != false) {
            //Clicking the Add Icon in the list page to navigate to the Add People Page
            chkUI.
            //Updating the Pass status to Excel sheet
            writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 2, 2);
            chkUI.
            //Clicking the Add Icon in the list page to navigate to the Add People Page
            click("//I[@ng-if='!detailsPage']").
            //Checking whether the control is navigated to the Create People Page
            waitForElementPresent("//SPAN[@class='title-box'][text()='New User']", 5000, false, function(chkTitleCreatePage) {
              if(chkTitleCreatePage.value != false) {
                chkUI.
                //Updating the Pass status to Excel sheet
                writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 3, 2);
                chkUI.
                //Checking whether the First name text field is displayed
                waitForElementPresent("(//INPUT[@name='userFirstName'])", 5000, false, function(chkFirstUNFld) {
                  if(chkFirstUNFld.value != false) {
                    chkUI.
                    //Updating the Pass status to Excel sheet
                    writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 4, 2);
                    chkUI.
                    //Checking whether the title of the First name field is displayed as "First Name"
                    waitForElementPresent("(//LABEL[text()='First Name'])", 5000, false, function(chkFieldTitle) {
                      if(chkFieldTitle.value != false) {
                        chkUI.
                        getText("(//LABEL[text()='First Name'])", function(getTitle) {
                          if(getTitle.value == "First Name") {
                            chkUI.
                            //Updating the Pass status to Excel sheet
                            writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 5, 2);
                          } else {
                            chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 5, 2,3, "First name title is not displayed as First Name");
                          }
                        });
                      } else {
                        chkUI.
                        //Updating the Fail status to Excel sheet
                        writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 5, 2,3, "First nem text field is displayed");
                      }
                    });
                  } else {
                    chkUI.
                    //Updating the Fail status to Excel sheet
                    writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 4, 2,3, "First Name text field is not displayed in the Create People page");
                  }
                });
                chkUI.
                //Checking whether the Last name text field is displayed
                waitForElementPresent("(//INPUT[@name='userLastName'])", 5000, false, function(chkFirstUNFld) {
                  if(chkFirstUNFld.value != false) {
                    chkUI.
                    //Updating the Pass status to Excel sheet
                    writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 6, 2);
                    chkUI.
                    //Checking whether the title of the First name field is displayed as "First Name"
                    waitForElementPresent("(//LABEL[text()='Last Name'])", 5000, false, function(chkFieldTitle) {
                      if(chkFieldTitle.value != false) {
                        chkUI.
                        getText("(//LABEL[text()='Last Name'])", function(getTitle) {
                          if(getTitle.value == "Last Name") {
                            chkUI.
                            //Updating the Pass status to Excel sheet
                            writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 7, 2);
                          } else {
                             chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 7, 2, 3, "Last name title is not displayed as First Name");
                          }
                        });
                      } else {
                         chkUI.
                         //Updating the Fail status to Excel sheet
                         writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 7, 2, 3, "Last name title is not displayed");
                      }
                    });
                  } else {
                    chkUI.
                    //Updating the Fail status to Excel sheet
                    writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 6, 2, 3, "Last Name text field is not displayed in the Create People page");
                  }
                });
                chkUI.
                //Checking whether the email text field is displayed
                waitForElementPresent("(//INPUT[@name='userEmail'])", 5000, false, function(chkFirstUNFld) {
                  if(chkFirstUNFld.value != false) {
                    chkUI.
                    //Updating the Pass status to Excel sheet
                    writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 8, 2);
                    chkUI.
                    //Checking whether the title of the First name field is displayed as "First Name"
                    waitForElementPresent("(//LABEL[text()='Email'])", 5000, false, function(chkFieldTitle) {
                      if(chkFieldTitle.value != false) {
                        chkUI.
                        getText("(//LABEL[text()='Email'])", function(getTitle) {
                          if(getTitle.value == "Email") {
                            chkUI.
                            //Updating the Pass status to Excel sheet
                            writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 9, 2);
                          } else {
                             chkUI.
                            //Updating the Fail status to Excel sheet
                            writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 9, 2, 3,"Email id title is not displayed as Email" );
                          }
                        });
                      } else {
                        chkUI.
                        //Updating the Fail status to Excel sheet
                        writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 9, 2, 3,"Email field title is not displayed" );
                      }
                    });
                  } else {
                     chkUI.
                    //Updating the Pass status to Excel sheet
                    writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 8, 2, 3,"Email text field is not displayed in the Create People page");
                  }
                });
                chkUI.
                //Checking whether the Cancel button is displayed
                waitForElementPresent("//BUTTON[@class='cancel-button'][text()='CANCEL']", 5000, false, function(chkCancelBtn) {
                  if(chkCancelBtn.value != false) {
                    chkUI.
                    //Updating the Pass status to Excel sheet
                    writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 10, 2);
                  } else {
                    chkUI.
                    //Updating the Fail status to Excel sheet
                    writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 10, 2, 3, "Cancel button is not displayed");
                  }
                });
                chkUI.
                //Checking whether the Invite button is displayed
                waitForElementPresent("//BUTTON[@class='cta-button disabled']", 5000, false, function(chkInviteBtn) {
                  if(chkInviteBtn.value != false) {
                    chkUI.
                    //Updating the Pass status to Excel sheet
                    writeToExcelPass("peoplex.xlsx", "chkAddPeoplePageUI", 11, 2);
                  } else {
                    chkUI.
                    //Updating the Fail status to Excel sheet
                    writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 11, 2, 3, "Invite button is not displayed" );
                  }
                });
              } else {
                chkUI.
               //Updating the Fail status to Excel sheet
               writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 2, 2, 3, "Title of the page is not displayed in the Create People page" );
              }
            });
          } else {
            chkUI.
            //Updating the Fail status to Excel sheet
            writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 2, 2, 3, "Title of the page is not displayed in People index page" );
          }
        });
      } else {
        chkUI.
        //Updating the Fail status to Excel sheet
        writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 2, 2, 3, "Unable to locate All People from the side bar of the application" );
      }
    });
    }
    catch ( e ) {
      chkUI.
      //Updating the Fail status to Excel sheet
      writeToExcelFail("peoplex.xlsx", "chkAddPeoplePageUI", 2, 2, 3, "Execution of the script terminated due to "+e+" reson" );
    }
  }
}
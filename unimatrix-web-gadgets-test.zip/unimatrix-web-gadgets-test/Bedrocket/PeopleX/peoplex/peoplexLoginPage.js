var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require( 'xlsx' );
var workbook = XLSX.readFile ( 'peoplex.xlsx', {
	cellStyles: true
} );
var email = [];
var forgotPassEmail = [];
var pass = [];
var LoginElements = workbook.Sheets [ 'peoplexLogin' ];
module.exports = {
	tags:[ 'peoplexLogin' ],
	'peoplexLogin': function ( client ) {
		//Navigating to login page of the application
		client.url ( 'https://peoplex.staging.boxxspring.com' );
	},
	'Checking the elements visibility': function ( client ) {
		client.
		useXpath ( ).
		//Checking the Elements visibility in Login page
		//Checking whether the Username field is displayed
		waitForElementVisible ( '//INPUT[@id="username"]',5000,false ).
		//Checking whether the Password field is displayed
		waitForElementVisible ( '//INPUT[@id="password"]',5000,false ).
		//Checking whether the Submit button is displayed
		waitForElementVisible ( "//INPUT[@type='submit']",5000,false ).
		//Checking whether the Forgot password link is displayed
		waitForElementVisible ( "//A[text()='Forgot password?']",5000,false )
	},
	//Checking the Login functionality with Valid credentials
	'checking the login functionality with valid Credentials' : function ( validLogin ) {
		//Variables to store the Test data Email,Password
		email = [];
		pass = [];
		//Extracting the Values from the Excel sheet
		for ( z in LoginElements ) {
			if ( z [ 0 ] === '!' ) continue;
      //Read Username from Excel
      if ( z.includes ( 'D' ) ) {
      	email.push ( LoginElements[ z ].v );
      }
      //Read URL title from Excel
      if ( z.includes ( 'E' ) ) {
      	pass.push ( LoginElements[ z ].v );
      }
  }
  for ( let inc = 1; inc <= 1; inc++) {
  	validLogin.
  	setValue ( '//INPUT[@id="username"]', email[inc] ).
  	setValue ( '//INPUT[@id="password"]',pass[inc] ).
  	click ( "//INPUT[@type='submit']" ).
  	pause ( 15000 ).
  	waitForElementPresent ( "//DIV[@class='logo-text ng-binding']",35000, false ).
		//Checking whether the Home page element is visible
		waitForElementVisible ( "//DIV[@class='logo-text ng-binding']",150000,false,function ( getHomePage ) {
			if ( getHomePage.value == true && getHomePage.status == 0 ) {
				validLogin.
				click ( "//SPAN[@class='profile-ellipsis']" ).
				waitForElementPresent ( "//LI[@ng-click='destroySession()']",5000,false ).
				click ( "//LI[@ng-click='destroySession()']" ).
				//Writing the Pass status in Excel sheet
				writeToExcelPass ( 'peoplex.xlsx' , 'peoplexLogin' , 2 , 7 );
			}
			else {
				validLogin.
				click ( "//SPAN[@class='profile-ellipsis']" ).
				waitForElementPresent ( "//LI[@ng-click='destroySession()']" ,5000,false ).
				click ( "//LI[@ng-click='destroySession()']" ).
				//writing the Fail status in Excel sheet
				writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' , 2 , 7, 8, "Unable to login with Credentials provided" );
			}

		});
	}
},
'checking the login functionality with inValid Credentials' : function ( inValidInput ) {
	email = [];
	pass = [];
	for ( z in LoginElements ) {
		if ( z [ 0 ] === '!' ) continue;
      //Read advertisement Title from Excel
      if ( z.includes ( 'D' ) ) {
      	email.push ( LoginElements[ z ].v );
      }
      //Read URL title from Excel
      if ( z.includes ( 'E' ) ) {
      	pass.push ( LoginElements[ z ].v );
      }
  }
  for ( let inc = 2; inc <= 2; inc++) { 
  	inValidInput.
  	useXpath ( ).
  	setValue ( '//INPUT[@id="username"]',email [ inc ]).
  	setValue ( '//INPUT[@id="password"]',pass [ inc ] ).
  	click ( "//INPUT[@type='submit']" ).
  	pause ( 3000 ).
		//Checking for Error message is displayed
		waitForElementVisible ( "//P[@class='error']", 15000, false, function ( getErr ) {
			if(getErr.value == true && getErr.status == 0){
				inValidInput.
				getText ( "//P[@class='error']",function( getErrMsg ) {
					if ( getErrMsg.value == "⚠There is no user with this email address." ) {
						inValidInput.
						//Writing the Pass status in Excel sheet
						writeToExcelPass ( 'peoplex.xlsx' , 'peoplexLogin' , 3 , 7 );
					}
					else {
						inValidInput.
						//writing the Fail status in Excel sheet
						writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' , 3 , 7, 8 ) ;
					}
				} );
			}
			else
			{
				inValidInput.
				//writing the Fail status in Excel sheet
				writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' , 3 , 7, 8,"Error message not displayed till 15 sec" ) ;
			}
		} );
	}
},
'checking the login functionality with User name alone' : function ( loginUserNameAlone ) {
	email = [];
	pass = [];
	for ( z in LoginElements ) {
		if ( z [ 0 ] === '!' ) continue;
      //Read advertisement Title from Excel
      if ( z.includes ( 'D' ) ) {
      	email.push ( LoginElements[ z ].v );
      }
      //Read URL title from Excel
      if ( z.includes ( 'E' ) ) {
      	pass.push ( LoginElements[ z ].v );
      }
  }
  for ( let inc = 3; inc <= 3; inc++) { 
  	loginUserNameAlone.
  	clearValue ( '//INPUT[@id="username"]' ).
  	clearValue ( '//INPUT[@id="password"]' ).
  	setValue ( '//INPUT[@id="username"]',email [ inc ] ).
  	click ( "//INPUT[@type='submit']" );
  	loginUserNameAlone.
		//Checking whether the Home page element is not displayed
		waitForElementNotPresent ( "//DIV[@class='logo-text ng-binding']",5000,false,function( getHomePage ) {
			if ( getHomePage.status == 0 ) {
				loginUserNameAlone.
				//Writing the Pass status in Excel sheet
				writeToExcelPass ( 'peoplex.xlsx' , 'peoplexLogin' , 4 , 7 );
			}
			else {
				loginUserNameAlone.
				//writing the Fail status in Excel sheet
				writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' , 4 , 7, 8,"Logging In without User name itself" );
			}
		} );
	}
	
},
'checking the login functionality with password alone' : function ( loginPassAlone ) {
	email = [];
	pass = [];
	for ( z in LoginElements ) {
		if ( z [ 0 ] === '!' ) continue;
      //Read advertisement Title from Excel
      if ( z.includes ( 'D' ) ) {
      	email.push ( LoginElements[ z ].v );
      }
      //Read URL title from Excel
      if ( z.includes ( 'E' ) ) {
      	pass.push ( LoginElements[ z ].v );
      }
  }
  for ( let inc = 3; inc <= 3; inc++) { 
  	loginPassAlone.
  	clearValue ( '//INPUT[@id="username"]' ).
  	clearValue ( '//INPUT[@id="password"]' ).
  	setValue ( '//INPUT[@id="password"]',pass [ inc ] ).
  	click ( "//INPUT[@type='submit']" );
  	loginPassAlone.
		//Checking whether the Home page element is not displayed
		waitForElementNotPresent ( "//DIV[@class='logo-text ng-binding']",5000,false,function ( getHomePage ) {
			if ( getHomePage.status == 0 ) {
				loginPassAlone.
				//Writing the Pass status in Excel sheet
				writeToExcelPass ( 'peoplex.xlsx' , 'peoplexLogin' , 5 , 7 );
			}
			else {
				loginPassAlone.
				//writing the Fail status in Excel sheet
				writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' ,5 , 7, 8,"Logging In without User name itself" );
			}
		} );
	} 
	
},
'checking the login functionality without username and password' : function ( withoutUNPass ) {
	withoutUNPass.
	clearValue ( '//INPUT[@id="username"]' ).
	clearValue ( '//INPUT[@id="password"]' ).
	click ( "//INPUT[@type='submit']" );
	withoutUNPass.
		//Checking whether the Home page element is not displayed
		waitForElementNotPresent ( "//DIV[@class='logo-text ng-binding']",5000,false,function ( getHomePage ) {
			if ( getHomePage.status == 0 ) {
				withoutUNPass.
				//Writing the Pass status in Excel sheet
				writeToExcelPass ( 'peoplex.xlsx' , 'peoplexLogin' , 6 , 7 );
			}
			else {
				withoutUNPass.
				//writing the Fail status in Excel sheet
				writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' , 6 , 7, 8,"Logging In without User name and Password itself" );
			}
		} );
	},
	'checking the Forgot Password functionality' : function ( forgotPassFunctionality ) {
		email = [];
		pass = [];
		for ( z in LoginElements ) {
			if ( z [ 0 ] === '!' ) continue;
      //Read advertisement Title from Excel
      if ( z.includes ( 'D' ) ) {
      	email.push ( LoginElements [ z ].v );
      }
  }
  for ( inc = 4; inc <= 4 ; inc++ ){
  	forgotPassFunctionality.
  	waitForElementPresent ( "//A[text()='Forgot password?']",15000,false ).
  	click ( "//A[text()='Forgot password?']" ).
  	waitForElementPresent ( '//INPUT[@id="username"]',15000,false ).
  	setValue ( '//INPUT[@id="username"]', email [ inc ]).
  	click (  "//INPUT[@type='submit']" ).
		//Checking whether the success message is displayed
		waitForElementVisible ( "//P[@class='green-text'][text()='A link to reset your password was sent to qatest@sportsrocket.com ']",5000,false,function ( getMsg ) {
			if ( getMsg.value == true && getMsg.status == 0) {
				forgotPassFunctionality.	
			//Writing the Pass status in Excel sheet
			writeToExcelPass ('peoplex.xlsx' , 'peoplexLogin' , 7 , 7 );
		}  		
		else {
			forgotPassFunctionality.
			//writing the Fail status in Excel sheet
			writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' , 7 , 7, 8,"Logging In without User name and Password itself" );

		}
	} );
		forgotPassFunctionality.click ( "//A[@class='form-link'][text()='Back']" );
	}
},
'checking the Forgot Password functionality with unregistered email' : function ( invalidForgetPassFunctionality ) {
	email = [];
	pass = [];
	for ( z in LoginElements ) {
		if ( z [ 0 ] === '!' ) continue;
     	 //Read advertisement Title from Excel
     	 if ( z.includes ( 'D' ) ) {
     	 	email.push ( LoginElements[ z ].v );
     	 }
     	}
     	for ( let inc = 5; inc <= 5; inc++) { 
     		invalidForgetPassFunctionality.
     		click ( "//A[text()='Forgot password?']" ).
     		waitForElementPresent ( '//INPUT[@id="username"]',5000,false ).
     		clearValue ( '//INPUT[@id="username"]' ).
     		setValue ( '//INPUT[@id="username"]',email [ inc ] ).
     		click (  "//INPUT[@type='submit']" ).
		//Checking whether the success message is displayed
		waitForElementVisible ( "//P[@class='error']",5000,false,function ( getMsg ) {
			if ( getMsg.value == true && getMsg.status == 0) {
				invalidForgetPassFunctionality.	
			//Writing the Pass status in Excel sheet
			writeToExcelPass ( 'peoplex.xlsx' , 'peoplexLogin' , 8 , 7 );
		}  		
		else{
			invalidForgetPassFunctionality.
			//writing the Fail status in Excel sheet
			writeToExcelFail ( 'peoplex.xlsx' , 'peoplexLogin' , 8 , 7, 8,"Logging In without User name and Password itself" );

		}
	} );
		invalidForgetPassFunctionality.end();
	}
}
};
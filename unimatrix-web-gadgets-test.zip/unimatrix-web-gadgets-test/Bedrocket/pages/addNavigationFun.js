var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: ['addNavigationFun'],
  before: function ( pagesLogin ) {
    //Login to the Pages with valid credentials
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkAddNavigationFun': function ( addNavi ) {
    var excel = addNavi.globals.excelCol;
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {
      try {
        addNavi.
        useXpath ( ).
        pause ( 5000 ).
        //Checking whether the page is in Navigation page
        waitForElementNotPresent ( "//SPAN[@class='ng-binding'][text()='navigation']", 5000, false, function ( chkVisibility ) {
          console.log ( chkVisibility )
          if ( chkVisibility.value == false ) {
            addNavi.
            //Clicking the Navigation menu from the sidebar of the application
            click ( "//SPAN[@ng-class='[ appColorScheme, { expand: expand, selected: currentSidebarOption == option.name } ]'][text()='navigation']" ).
            pause ( 5000 ).
            click ( "//I[@class='add-icon']" );

          } else {
            addNavi.
            //Clicking the Add icon in the Pages landing page
            click ( "//I[@class='add-icon']" );
          }
          addNavi.
          //Clicking the Add icon in the Pages landing page
          //Checking whether the Toggle menu is displayed after clicking on the Add button
          waitForElementPresent ( "//DIV[@class='flyout-menu-large dropdown-menu navigations ng-scope']", 5000, false, function ( chkVisibility ) {
            if ( chkVisibility.value != false ) {
              addNavi.
              //Clicking the Add Navigation Option in the Toggle menu
              click ( "(//LI)[2]" ).
              //Checking whether the page is navigated to Create Navigation page
              waitForElementPresent ( "//BUTTON[@class='cta-button'][text()='CREATE']", 5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                  addNavi.
                  //Setting the input data from excel sheet in the input field
                  setValue ( "//INPUT[@required='']", excel.B[incrementer] ).
                  //Clicking the Create button in the create page
                  click ( "//BUTTON[@class='cta-button'][text()='CREATE']" ).
                  pause ( 5000 ).
                  //Checking whether the page is navigated to the Navigation index page and new Navigation is added
                  waitForElementPresent ( "//P[@id='" + excel.B[incrementer] + "']", 5000, false, function ( chkAddedNavi ) {
                    if ( chkAddedNavi.value == false ) {
                      addNavi.
                      //Updating the fail status in the Excel sheet
                      writeToExcelFail ( 'pages.xlsx', 'chkAddNavigationFun', ++incrementer, 3, 4, "Added Navigation not found in Navigation Index page" );
                    } else {
                      addNavi.
                      //Updating the pass status in the Excel sheet
                      writeToExcelPass ( 'pages.xlsx', 'chkAddNavigationFun', ++incrementer, 3 );
                    }
                  } );
                } else {
                  addNavi.
                  //Updating the fail status in Excel sheet with appropriate status
                  writeToExcelFail ( 'pages.xlsx', 'chkAddNavigationFun', ++incrementer, 3, 4, "Unable to navigate to Add navigate page" );
                }
              } );
            }
          } );
        } );
      } catch ( e ) {
        addNavi.
        //Updating the fail status in Excel sheet with appropriate status
        writeToExcelFail ( 'pages.xlsx', 'chkAddNavigationFun', ++incrementer, 3, 4, "Script terminated unexpectedly" );
      }
    }
  }
}
var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: ['chkSortFunInPages'],
  before: function ( pagesLogin ) {
    //Login to the Pages with valid credentials
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkSortFunInPages': function ( chkSortFun ) {
    var excel = chkSortFun.globals.excelCol;
      try {
        chkSortFun.
        useXpath ( ).
        pause ( 5000 ).
        //Checking whether the page is in pages module
        waitForElementPresent ( "//SPAN[@class='ng-binding'][text()='pages']", 15000, false, function ( chkVisibility ) {
          if ( chkVisibility.value == false ) {
            chkSortFun.
            pause ( 5000 ).
            //Clicking the Pages menu from the side bar Navigation from the application
            click ( "//SPAN[@ng-class='[ appColorScheme, { expand: expand, selected: currentSidebarOption == option.name } ]'][text()='pages']" ).
            pause ( 5000 );
          }
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {

          chkSortFun.
          //Checking whether the Toggle menu icon is clickable
          waitForElementPresent ( "//I[@ng-click='toggleElement( $event )']",5000,false,function ( chkVisibility ) {
            if ( chkVisibility.value != false ) {
            chkSortFun.
              //Clicking the Sorting Toggle menu
            click ( "//I[@ng-click='toggleElement( $event )']" );
            //Validating the Input menu from the Excel sheet
            if ( excel.B[incrementer] == "NameAscending" ) {
              chkSortFun.
              //Clicking the Name menu from the Toggle menu
              click ( "(//LI[@class='auto-untoggle sort-li'])[1]" ).
              pause ( 10000 ).
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              //Checking whether the Name menu is selected in the Toggle menu
              waitForElementPresent ( "//I[@class='flyout-icon check-icon auto-untoggle ng-scope']",5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                chkSortFun.
                //Updating the Pass status in the Excel sheet
                writeToExcelPass ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3 );
                }
                else {
                chkSortFun.
                //Updating the fail status in the Excel sheet
                writeToExcelFail ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3, 4 ,"Name ascending is not selected" );
                }
              } );
            }
            //Validating the Input menu from the Excel sheet
            else if ( excel.B[incrementer] == "DateAddedAscending" ) {
              chkSortFun.
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Clicking the Date added menu from the Toggle menu
              click ( "(//LI[@class='auto-untoggle sort-li'])[2]" ).
              pause ( 10000 ).
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              //Checking whether the Date added menu is selected from the Toggle menu
              waitForElementPresent ( "//I[@class='flyout-icon check-icon auto-untoggle ng-scope']",5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                chkSortFun.
                //Updating the Pass status in the Excel sheet
                writeToExcelPass ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3 );
                }
                else {
                chkSortFun.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3, 4 ,"Date ascending is not selected" );
                }
              } );
            }
            //Validating the Input menu from the Excel sheet
            else if ( excel.B[incrementer] == "LastModifiedAscending" ) {
              chkSortFun.
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Clicking the Last modified from the Toggle menu
              click ( "(//LI[@class='auto-untoggle sort-li'])[3]" ).
              pause ( 10000 ).
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              //Checking whether the Last modified menu is selected from the Toggle menu
              waitForElementPresent ( "//I[@class='flyout-icon check-icon auto-untoggle ng-scope']",5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                chkSortFun.
                //Updating the Excel sheet in the Excel sheet
                writeToExcelPass ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3 );
                }
                else {
                chkSortFun.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3, 4 ,"Date ascending is not selected" );
                }
              } );
            }
            //Validating the Input menu from the Excel sheet
             else if ( excel.B[incrementer] == "NameDescending" ) {
              chkSortFun.
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Clicking the Name Descending from the Toggle menu
              click ( "(//LI[@class='auto-untoggle sort-li'])[1]" ).
              pause ( 10000 ).
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Clicking the Descending order down arrow symbol in the Toggle menu 
              click ( "//I[@class='flyout-icon-right up-arrow-icon auto-untoggle ng-scope']" ).
              pause ( 10000 ).
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Checking whether the Descending order down arrow symbol is displayed in the Toggle menu
              waitForElementPresent ( "//I[@class='flyout-icon-right down-arrow-icon auto-untoggle ng-scope']",5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                chkSortFun.
                //Updating the Pass status in the Excel sheet
                writeToExcelPass ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3 );
                }
                else {
                chkSortFun.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3, 4 ,"Name descending is not selected" );
                }
              } );
            }
            //Validating the Input menu from the Excel sheet
            else if ( excel.B[incrementer] == "DateAddedDescending" ) {
              chkSortFun.
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Clicking the Date modified descending symbol from the Toggle menu
              click ( "(//LI[@class='auto-untoggle sort-li'])[2]" ).
              pause ( 10000 ).
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Checking whether the Descending order down arrow symbol is displayed in the Toggle menu
              waitForElementPresent ( "//I[@class='flyout-icon-right down-arrow-icon auto-untoggle ng-scope']",5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                chkSortFun.
                //Updating the Pass status in the Excel sheet
                writeToExcelPass ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3 );
                }
                else {
                chkSortFun.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3, 4 ,"Name descending is not selected" );
                }
              } );
            }
            //Validating the Input menu from the Excel sheet
            else if ( excel.B[incrementer] == "LastModifiedDescending" ) {
              chkSortFun.
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Clicking the Last modified descending symbol from the Toggle menu
              click ( "(//LI[@class='auto-untoggle sort-li'])[3]" ).
              pause ( 10000 ).
              //Clicking the Sorting Toggle menu
              click ( "//I[@ng-click='toggleElement( $event )']" ).
              pause ( 3000 ).
              //Checking whether the Descending order down arrow symbol is displayed in the Toggle menu
              waitForElementPresent ( "//I[@class='flyout-icon-right down-arrow-icon auto-untoggle ng-scope']",5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                chkSortFun.
                //Updating the Pass status in the Excel sheet
                writeToExcelPass ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3 );
                }
                else {
                chkSortFun.
                //Updating the fail status in the Excel sheet
                writeToExcelFail ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3, 4 ,"Name descending is not selected" );
                }
              } );
            }
            }
          } );
            }
          } );
      }
      catch ( e ) {
        chkSortFun.
        //Updating the fail status in Excel sheet with appropriate status
        writeToExcelFail ( 'pages.xlsx', 'chkSortFunInPages', ++incrementer, 3, 4 ,"Script terminated unexpectedly" );
      }
    }
  }
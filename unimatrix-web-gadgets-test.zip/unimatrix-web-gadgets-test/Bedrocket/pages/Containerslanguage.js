//this function is for checking languages in the Containers page
var excelRow, excelColumn = 1;
var splitLanguage = [ ];           
var splitShortLanguage = [ ]; 
module.exports = {
  tags: [ 'containersLanguage' ],
  before: function ( pagesLogin ) {
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },  

 'ContainersLanguage': function ( containerAddLanguage ) {
    var excel = containerAddLanguage.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        containerAddLanguage.useXpath ( ).pause ( 4000 ).
        //Wait for the Containers menu is visible in the Containers
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]", 4000, false, function ( checkContainersMenu ) {
          if ( checkContainersMenu.value == true ) {
            containerAddLanguage.useXpath ( ).pause ( 4000 ).
            //Click on the Containers menu in the Containers
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the Containers index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                containerAddLanguage.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the Containers index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the Containers index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the Containers index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( containerAddLanguage.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on Containers index page
                waitForElementVisible ( "//language-dropdown/div/toggle-menu/i", 4000, false, function ( checkLanguageArrow ) {
                  if ( checkLanguageArrow.value == true ) {
                    containerAddLanguage.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on Containers index page
                    click ( "//language-dropdown/div/toggle-menu/i" ).
                    pause ( 4000 ). 
                    getLocationInView ( "//div/toggle-menu/div/ng-include/div/ul/li[contains(.,'"+excel.B[ excelColumn ]+"')]" ).
                    pause ( 4000 ).             	               	
                  	//Wait for the change button is visible in the Containers detail page
                    waitForElementVisible ( "//div/toggle-menu/div/ng-include/div/ul/li[contains(.,'"+excel.B[ excelColumn ]+"')]", 9000, false, function ( checkChangeLanguage ) {
                      if ( checkChangeLanguage.value == true ) {
                        containerAddLanguage.useXpath ( ).pause ( 6000 ).
                        //Click on the change button in the Containers detail page
                        click ( "//div/toggle-menu/div/ng-include/div/ul/li[contains(.,'"+excel.B[ excelColumn ]+"')]" ).
                        pause ( 4000 ).                        
                        //Wait for the Delete button is visible in the vertical ellipsis option on Containers index page
                        waitForElementVisible ( "(//ng-transclude/div/div/div/div[1]/div[1]/div[1])[1]", 4000, false, function ( checkSearchedResult ) {
                          if ( checkSearchedResult.value == true ) {
                            containerAddLanguage.useXpath ( ).pause ( 4000 ).
                            //Get the short language text in the Containers listing page
                            getText ( "(//ng-transclude/div/div/div/div[1]/div[1]/div[1])[1]", function ( titleName ) { 
                              console.log("titleName:",titleName)
                              console.log("excel.A[ excelColumn ]:",excel.A[ excelColumn ])
                              if ( titleName.value == excel.A[ excelColumn ] ) {
                                //Write the Excel to FAIL Result and Reason
                                containerAddLanguage.writeToExcelPass ( 'pages.xlsx', 'ContainersLanguage', excelRow, 3 );
                            	}
                            	else {
                                //Write the Excel to FAIL Result and Reason
                                this.verify.fail ( titleName.value, true, 'Containers actual Renamed Data is not visible' );
                                containerAddLanguage.writeToExcelFail ( 'pages.xlsx', 'ContainersLanguage', excelRow, 3, 4, "ActualResult: '"+titleName.value+". ExpectedResult: '"+excel.A[excelColumn]+"'" );
                              }
                          	} );
                          }
                          else {
                            //Write the Excel to FAIL Result and Reason
														this.verify.fail ( checkSearchedResult.value, true, 'Timeout issue or fail due to Containers Edit Button is not displayed in the page' );
														containerAddLanguage.writeToExcelFail ( 'pages.xlsx', 'ContainersLanguage', excelRow, 3, 4, "Containers Edit Button is not displayed in the page" );
                          }
                        } );
                                         
                      }
                      else {                          
                        //Write the Excel to FAIL Result and Reason
                				this.verify.fail ( checkChangeLanguage.value, true, 'Timeout issue or fail due to the Change Button is not displayed' );
                				containerAddLanguage.writeToExcelFail ( 'pages.xlsx', 'ContainersLanguage', excelRow, 3, 4, "Change Button is not displayed" );                            
                      }
                    } );	                    
	  	                                                   
	                }
	                else {
	                  //Write the Excel to FAIL Result and Reason
	                  this.verify.fail ( checkLanguageArrow.value, true, 'Timeout issue or fail due to the Containers Edit Button is not visible' );
	                  containerAddLanguage.writeToExcelFail ( 'pages.xlsx', 'ContainersLanguage', excelRow, 3, 4, "Containers Edit functionality is not working as expected" );
	                }
	              } );                    
	            }
	            else {
	              //Write the Excel to FAIL Result and Reason
	              this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Containers Search Button is not visible' );
	              containerAddLanguage.writeToExcelFail ( 'pages.xlsx', 'ContainersLanguage', excelRow, 3, 4, "Containers Search button is not displayed in the page" );
	            }
	          } );            
	         }
	         else {       
	         	//Write the Excel to FAIL Result and Reason    
	          this.verify.fail ( checkContainersMenu.value, true, 'Timeout issue or fail due to the Containers Menu is not displayed in the leftside menu bar' );
	          containerAddLanguage.writeToExcelFail ( 'pages.xlsx', 'ContainersLanguage', excelRow, 3, 4, "Containers Menu is not displayed in the leftside menu bar" );
	        }
	      } );
	    }
	  }
  },	
};
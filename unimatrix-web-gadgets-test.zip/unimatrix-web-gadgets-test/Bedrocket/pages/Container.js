//this function is for add,edit,rename,delete the PAGES
var excelRow, excelColumn = 1;
var splitName = [ ];           
var splitOption = [ ]; 
module.exports = {
  tags: [ 'containers' ],
  before: function ( pagesLogin ) {
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },  
 'ContainerAdd': function ( containerAdd ) {
  var excel = containerAdd.globals.excelCol;
  if ( excel.A.length > 0 ) {
    //loop the 'n' number of excel input
    for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
      excelRow++;
      containerAdd.useXpath ( ).pause ( 4000 ).
      //Wait for the containers menu is visible in the pages
      waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]", 4000, false, function ( checkContainerMenu ) {
        if ( checkContainerMenu.value == true ) {
          containerAdd.useXpath ( ).pause ( 4000 ).
          //Click on the containers menu in the containers
          click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]" ).
          pause ( 4000 ). 
          //Get the Total count in the pages on pages index
          getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( currentCountResult ) {
            if ( currentCountResult.status != -1 ) {
              var currentCount = currentCountResult.value;
              currentCount = currentCount.split ( 'Containers' );
              containerAdd.useXpath ( ).pause ( 4000 ).            
              //Wait for Plus Button is visible in the Containers index page
              waitForElementVisible ( "//ng-include[1]/div/toggle-menu/i", 4000, false, function ( checkPlusBtn ) {
                if ( checkPlusBtn.value == true ) {
                  containerAdd.useXpath ( ).pause ( 4000 ).
                  //Click on the Plus Button in the Containers index page
                  click ( "//ng-include[1]/div/toggle-menu/i" ).
                  pause ( 2000 ).                                  
                  //Wait for the Container Menu is visible in the Plus dropdown option on containers index page
                  waitForElementVisible ( "//*/li[contains(.,'New Container')]", 4000, false, function ( checkAddContainer ) {
                    if ( checkAddContainer.value == true ) {
                      containerAdd.useXpath ( ).pause ( 4000 ).
                      //Click on the Container Menu in the Plus dropdown option on containers index page
                      click ( "//*/li[contains(.,'New Container')]" ).
                      pause ( 4000 ).                     	
              				//Wait for the Caption is visible in the Add Container pop-up screen
              				waitForElementVisible ( "//*[@id='my_modal-new_container_form_flyout']/div/div[1]/p", 4000, false, function ( checkCaption ) {
                  			if ( checkCaption.value == true ) {
              						containerAdd.useXpath ( ).pause ( 4000 ).
              						//Get the value in the caption in the Add Container pop-up screen
              						getText ( "//*[@id='my_modal-new_container_form_flyout']/div/div[1]/p", function ( getCaption ) {
                						if ( getCaption.value == "ADD CONTAINER" ) {
                							containerAdd.useXpath ( ).pause ( 4000 ).	
                							//Wait for the Text input field is visible in the Add Container pop-up screen 	                            								
                							waitForElementVisible ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input", 4000, false, function ( checkTextInput ) {
                								if ( checkTextInput.value == true ) {
                									containerAdd.useXpath ( ).pause ( 4000 ).
                									//Clear the data in the Text input field in the Add Container pop-up screen 
                									clearValue ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input" ).
                									pause ( 4000 ).
                									//Enter the data in the Text input field in the Add Container pop-up screen
                									setValue ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input", excel.A[ excelColumn ] ).
                									pause ( 4000 ).
                									//Wait for the Radio option is visible in the Add Container pop-up screen
                									waitForElementVisible ( "//div/div[@class='integrations-select']/span[contains(.,'"+excel.B[ excelColumn ]+"')]", 4000, false, function ( checkoptions ) {
                										if ( checkoptions.value == true ) {		                            											
                											containerAdd.useXpath ( ).pause ( 4000 ).
                											//Click on the Radio option in the Add Container pop-up screen
                											click ( "//div/div[@class='integrations-select']/span[contains(.,'"+excel.B[ excelColumn ]+"')]" ).
                											pause ( 4000 ).		
                											//Get the location for the save button in the Add Container pop-up screen                            												
                											getLocationInView ( "//*[@id='my_modal-new_container_form_flyout']/div/div[3]/button" ).
                											pause ( 4000 ).
                											//Wait for the the save button is visible in the Add Container pop-up screen   
                											waitForElementVisible ( "//*[@id='my_modal-new_container_form_flyout']/div/div[3]/button", 4000, false, function ( checkSaveBtn ) {
                												if ( checkSaveBtn.value == true ) {
                													containerAdd.useXpath ( ).pause ( 4000 ).		
                													//Click on the save button in the Add Container pop-up screen                            														
                													click ( "//*[@id='my_modal-new_container_form_flyout']/div/div[3]/button" ).
                													pause ( 4000 ).		  
                													//Get the location for the created container in the Add Container listing page                           														
                													getLocationInView ( "//ng-transclude/div/div[contains(.,'"+excel.A[ excelColumn ]+"')]/div/div[1]/div[1]/div[1]" ).
                													pause ( 4000 ).
                													//Wait for the created container is visible in the Add Container listing page   
                													waitForElementVisible ( "//ng-transclude/div/div[contains(.,'"+excel.A[ excelColumn ]+"')]/div/div[1]/div[1]/div[1]", 4000, false, function ( checkAddedContainer ) {
                  													if ( checkAddedContainer.value == true ) {
                                              containerAdd.useXpath ( ).pause ( 4000 ).
                                              //Get the Total count in the pages on pages index
                                              getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( actualCountResult ) {
                                                if ( actualCountResult.status != -1 ) {
                                                  var actualCount = actualCountResult.value;
                                                  actualCount = actualCount.split ( 'Containers' );
                                                  var expectedCount = ( +currentCount[0] + 1 ) 
                                                  if ( actualCount[0] == expectedCount ) {
                                                    //Write the Excel to PASS Result and Reason
                                                    containerAdd.writeToExcelPass ( 'pages.xlsx', 'ContainerAdd', excelRow, 3 );
                                                  }
                                                  else {
                                                    //Write the Excel to FAIL Result and Reason
                                                    this.verify.fail ( actualCountResult.value, 'true', 'actual value is not displayed in the page' );                                                      
                                                    containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "ActualResult: '"+ actualCount +"' in the Total Count After created New container. ExpectedResult: should be'" + expectedCount + "' in the Total Count" );
                                                  }
                                                }
                                                else {
                                                  //Write the Excel to FAIL Result and Reason
                                                  this.verify.fail ( actualCountResult.value, true, 'Timeout issue or fail due to the container actual count is not visible' );
                                                  containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "ActualResult: '"+actualCountResult.value+". ExpectedResult: the container actual count is not visible' )" );
                                                }
                                              } );                    													
                  													}
                  													else {
                    													//Write the Excel to FAIL Result and Reason
    				                            			this.verify.fail ( checkAddedContainer.value, true, 'Timeout issue or fail due to the he container Add Panel is not visible' );
    				                            			containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Container Add Panel is not visible in the page" );
                   													}
                													} );
                												}
                												else {                                        
                                          containerAdd.useXpath ( ).pause ( 4000 ).
                                          //Verify the Cancel button is visible in the container pop-up form
                                          verify.visible ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ).
                                          pause ( 4000 ).
                                          //Click on the Cancel button in the container pop-up form
                                          click ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ) 
                													//Write the Excel to FAIL Result and Reason
                													this.verify.fail ( checkSaveBtn.value, true, 'Timeout issue or fail due to the container Save Button is not visible in the page' );
                													containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Container Save Button is not visible in the page" );
                 												}
                											} );
                  									}
                  									else {
                                      containerAdd.useXpath ( ).pause ( 4000 ).
                                      //Verify the Cancel button is visible in the container pop-up form
                                      verify.visible ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ).
                                      pause ( 4000 ).
                                      //Click on the Cancel button in the container pop-up form
                                      click ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ) 
                  										//Write the Excel to FAIL Result and Reason
                											this.verify.fail ( checkoptions.value, true, 'Timeout issue or fail due to the Container Radio Button is not visible in the page' );
                											containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Container Radio Button is not visible in the page" );
                  									}
                  								} );
                								}
                								else {
                                  containerAdd.useXpath ( ).pause ( 4000 ).
                                  //Verify the Cancel button is visible in the container pop-up form
                                  verify.visible ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ).
                                  pause ( 4000 ).
                                  //Click on the Cancel button in the container pop-up form
                                  click ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ) 
                									//Write the Excel to FAIL Result and Reason
                									this.verify.fail ( checkTextInput.value, true, 'Timeout issue or fail due to the Container Text field is not visible in the page' );
                									containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Container Text field is not visible in the page" );
                 								}
                							} );
                						}
                						else {
                              containerAdd.useXpath ( ).pause ( 4000 ).
                              //Verify the Cancel button is visible in the container pop-up form
                              verify.visible ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ).
                              pause ( 4000 ).
                              //Click on the Cancel button in the container pop-up form
                              click ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ) 
                							//Write the Excel to FAIL Result and Reason
                							this.verify.fail ( getCaption.value, true, 'Timeout issue or fail due to the Container Caption Label is unable to get' );
                							containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Container Caption Label is unable to get" );
                						}
                					} );
                				}
                				else {
                          containerAdd.useXpath ( ).pause ( 4000 ).
                          //Verify the Cancel button is visible in the container pop-up form
                          verify.visible ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ).
                          pause ( 4000 ).
                          //Click on the Cancel button in the container pop-up form
                          click ( "//*[@id='close_modal-new_container_form_flyout'][contains(.,'CANCEL')]" ) 
                					//Write the Excel to FAIL Result and Reason
                					this.verify.fail ( checkCaption.value, true, 'Timeout issue or fail due to the Container Caption Label is not visible in the page' );
                					containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Container Caption Label is not visible in the page" );
                				}
                			} );	                        		                   	                                     
                    }
                    else {
                      //Write the Excel to FAIL Result and Reason
                      this.verify.fail ( checkAddContainer.value, true, 'Timeout issue or fail due to the Add container Button is not visible' );
                      containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Add container Button is not visible in the page" );
                    }
                  } );                    
                }
              	else {
                  //Write the Excel to FAIL Result and Reason
                  this.verify.fail ( checkPlusBtn.value, true, 'Timeout issue or fail due to the Plus Button is not displayed in the listing page' );
                  containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Plus Button is not displayed in the listing page" );
                }
              } );
            }
            else {
              //Write the Excel to FAIL Result and Reason
              this.verify.fail ( currentCountResult.value, true, 'Timeout issue or fail due to the current Count Result is not visible' );
              containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, " current Count Result as '"+currentCountResult.value+" in the listing page' )" );
            } 
          } );           
        }
        else {       
       	  //Write the Excel to FAIL Result and Reason    
          this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Container Menu is not visible' );
          containerAdd.writeToExcelFail ( 'pages.xlsx', 'ContainerAdd', excelRow, 3, 4, "Container Menu is not visible in the leftside menubar" );
        }
    	} );
  	}
	}
},
	
'ContainerRename': function ( containerRename ) {
  var excel = containerRename.globals.excelCol;
  if ( excel.A.length > 0 ) {
  	//loop the 'n' number of excel input
  	for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
    	excelRow++;
    	containerRename.useXpath ( ).pause ( 4000 ).
    	//Wait for the pages menu is visible in the pages
   		waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]", 4000, false, function ( checkContainerMenu ) {
      	if ( checkContainerMenu.value == true ) {
        	containerRename.useXpath ( ).pause ( 4000 ).
        	//Click on the pages menu in the pages
        	click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]" ).
       		pause ( 4000 ).            
        	//Wait for search field is visible in the pages index page
       		waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
          	if ( checkSearchBtn.value == true ) {
            	containerRename.useXpath ( ).pause ( 4000 ).
            	//Click on the search field in the pages index page
              click ( "//*[@id='search_input']" ).
              pause ( 2000 ).
              //Clear the data in the search field in the pages index page
              clearValue ( "//*[@id='search_input']" ).
              pause ( 2000 ).
              //Enter the data in the search field in the pages index page
              setValue ( "//*[@id='search_input']", excel.A[excelColumn] ).
              useCss ( ).pause ( 2000 ).
              //Press return key
              keys ( containerRename.Keys.ENTER ).
              useXpath ( ).pause ( 4000 ).  
              //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
							waitForElementVisible ( "//div[contains(.,'"+excel.A[ excelColumn ]+"')]/span/toggle-menu/span", 4000, false, function ( checkVerticalBtn ) {
						  	if ( checkVerticalBtn.value == true ) {
						  		containerRename.useXpath ( ).pause ( 4000 ). 
						  		//Click on the Edit button in the pages
						  		click ( "//div[contains(.,'"+excel.A[ excelColumn ]+"')]/span/toggle-menu/span" ).
						  		pause ( 4000 ).							  		
				  				//Wait for the container is visible in the listing page
				  				waitForElementVisible ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::ng-include/*//li/i", 4000, false, function ( checkRenameBtn ) {
				  					if ( checkRenameBtn.value == true ) {
				  						containerRename.useXpath ( ).pause ( 4000 ). 
                      //Click on the rename button in the container page 
                      click ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::ng-include/*//li/i" ).
                      pause ( 4000 ).
		                	//Wait for the Delete button is visible in the vertical ellipsis option on container index page
		                	waitForElementVisible ( "//*/renameable-input/input", 4000, false, function ( checkRenameField ) {
		                 	  if ( checkRenameField.value == true ) {
		                    	containerRename.useXpath ( ).pause ( 4000 ).
                          //Clear the data in the rename field 
                          clearValue ( "//*/renameable-input/input" ).
                          pause ( 4000 ).
                          //Enter the data in the rename field 
                          setValue ( "//*/renameable-input/input", excel.B[ excelColumn ] ).
                          pause ( 4000 ).
                          //click on the label in the page
		                    	click ( "//div/ng-include[1]/div/div/span" ).
                          pause ( 4000 ).
                          //Wait for the search field is visible in the containers listing page
                          waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchfield ) {
                            if ( checkSearchfield.value == true ) {
                              containerRename.useXpath ( ).pause ( 4000 ).
                              //Click on the search field in the pages index page
                              click ( "//*[@id='search_input']" ).
                              pause ( 2000 ).
                              //Clear the data in the search field in the pages index page
                              clearValue ( "//*[@id='search_input']" ).
                              pause ( 2000 ).
                              //Enter the data in the search field in the pages index page
                              setValue ( "//*[@id='search_input']", excel.B[ excelColumn ] ).
                              useCss ( ).pause ( 2000 ).
                              //Press return key
                              keys ( containerRename.Keys.ENTER ).		
                              useXpath( ).pause ( 2000 ).	                    			
		                    			//Get the Location for the container in the listing page
		                    			getLocationInView ( "//*/div[@class='container-title ng-binding'][contains(.,'"+excel.B[ excelColumn ]+"')]" ).
              								pause ( 4000 ).	
              								//Wait for the Renamed container is visible in the listing page				                								
              								waitForElementVisible ( "//*/div[@class='container-title ng-binding'][contains(.,'"+excel.B[ excelColumn ]+"')]", 4000, false, function ( checkRenamedContainer ) {
              									if ( checkRenamedContainer.value == true ) {							                									
																	//Write the Excel to FAIL Result and Reason
          												containerRename.writeToExcelPass ( 'pages.xlsx', 'ContainerRename', excelRow, 3 );
          											}
          											else {
            											//Write the Excel to FAIL Result and Reason
		                            	this.verify.fail ( checkRenamedContainer.value, true, 'Actual Container Renamed Data is not visible in the listing page' );
		                            	containerRename.writeToExcelFail ( 'pages.xlsx', 'ContainerRename', excelRow, 3, 4, "Actual Container Renamed Data is not visible in the listing page" );
           											}
		                					} );     													                														                							
			                    	}
			                    	else {
			                    		//Write the Excel to FAIL Result and Reason
	                    				this.verify.fail ( checkSearchfield.value, true, 'Timeout issue or fail due to the Search Field is not visible' );
	                    				containerRename.writeToExcelFail ( 'pages.xlsx', 'ContainerRename', excelRow, 3, 4, "Search Field is not visible in the page" );
			                    	}
			                    } );                
		                    }
		                    else {
		                    	//Write the Excel to FAIL Result and Reason
	                    		this.verify.fail ( checkRenameField.value, true, 'Timeout issue or fail due to the Rename Field is not visible in the listing page' );
	                    		containerRename.writeToExcelFail ( 'pages.xlsx', 'ContainerRename', excelRow, 3, 4, "Rename Field is not visible in the listing page" );
	                      }	
	                    } );                                     
	                  }
	                  else {
	                    //Write the Excel to FAIL Result and Reason
	                    this.verify.fail ( checkRenameBtn.value, true, 'Timeout issue or fail due to Rename Button is not visible' );
	                    containerRename.writeToExcelFail ( 'pages.xlsx', 'ContainerRename', excelRow, 3, 4, "Rename Button is not displayed in the listing page" );
	                  }
	                } );			              										
	              }
	              else {
	              	//Write the Excel to FAIL Result and Reason
	                this.verify.fail ( checkVerticalBtn.value, true, 'Timeout issue or fail due to the Vertical Eclipsis Button is not displayed in the listing page' );
	                containerRename.writeToExcelFail ( 'pages.xlsx', 'ContainerRename', excelRow, 3, 4, "Vertical Eclipsis Button is not displayed in the listing page" );
	              } 
	            } );                  
            }
          	else {
              //Write the Excel to FAIL Result and Reason
              this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
              containerRename.writeToExcelFail ( 'pages.xlsx', 'ContainerRename', excelRow, 3, 4, "Pages Search option is not visible in the container listng page" );
            }
          } );            
        }
        else {       
       	  //Write the Excel to FAIL Result and Reason    
          this.verify.fail ( checkContainerMenu.value, true, 'Timeout issue or fail due to the Containers Menu is not visible in the leftside menu bar' );
          containerRename.writeToExcelFail ( 'pages.xlsx', 'ContainerRename', excelRow, 3, 4, "Containers Menu is not visible in the leftside menu bar" );
        }
    	} );
  	}
	}
},

'ContainerEdit': function ( editContainer ) {
    var excel = editContainer.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        editContainer.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]", 4000, false, function ( checkContainerMenu ) {
          if ( checkContainerMenu.value == true ) {
            editContainer.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                editContainer.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( editContainer.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//div/div/div/div[1]/div[1]/div[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
                  if ( checkEditBtn.value == true ) {
                    editContainer.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on pages index page
                    click ( "//div/div/div/div[1]/div[1]/div[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                    pause ( 4000 ). 
                    //Wait for the Pages Structure tab is visible in the pages details page
                    waitForElementVisible ( "//div[@class='description-input']/input", 4000, false, function ( checkDescription ) {
                    	if ( checkDescription.value == true ) {
                    		editContainer.useXpath ( ).pause ( 4000 ).
                    		//Click on the Page Structure tab in the pages details page
                    		click ( "//div[@class='description-input']/input" ).	
                    		pause ( 4000 ).
                        //Clear the value in the description field
                    		clearValue ( "//div[@class='description-input']/input" ).
                    		pause ( 4000 ).
                        //Enter the value in the description field
                    		setValue ( "//div[@class='description-input']/input", excel.B[ excelColumn ] ).	                    
		                    pause ( 4000 ) 
		                    var splitContainer = [ ]; 	
                        //Splitting the data and stored in the array	                                                        
		                    splitContainer = excel.C[ excelColumn ].split(':'); 		                    
		                    for ( let getSplitedData = 0; getSplitedData<splitContainer.length; getSplitedData++ ) {
		                    	if ( ( excel.E[ excelColumn ] != "FAIL" ) && ( excel.F[ excelColumn ] == null ) ) {
		                    		editContainer.useXpath ( ).pause ( 4000 ).  		                    		
		                    		//Wait for Edit button is visible in the pages container listing page                 				
		                    		waitForElementVisible ( "//*/i[@class='edit-list-icon']", 4000, false, function ( checkEditIcon ) {
                    					if ( checkEditIcon.value == true ) {
                    						editContainer.useXpath ( ).pause ( 4000 ).
                    						//Click on the Edit button in the pages container listing page
                    						click ( "//*/i[@class='edit-list-icon']" ).
                    						pause ( 4000 ).
                                //Wait for the media gallery is visible in the page
                    						waitForElementVisible ( "//div[1]/div/div[3]/div[1]/div[2]/div/media-gallery/div/div/div[1]/span", 9000, false, function ( checkCaption ) {
                    							if ( checkCaption.value == true ) {
                    								editContainer.useXpath ( ).pause ( 4000 ).
                                    //Get the text value in the media gallery list page
                    								getText ( "//div[1]/div/div[3]/div[1]/div[2]/div/media-gallery/div/div/div[1]/span", function ( captionText ) {
                    									if ( captionText.value == "Media Gallery" ) {
                    										editContainer.useXpath ( ).pause ( 4000 ).
                                        //Wait for the toggle menu is visible in the media gallery page
                    										waitForElementVisible ( "//div[1]/div/div[3]/div[1]/div[2]//media-gallery//div[2]/div[1]/div[1]/toggle-menu/div[1]/i", 9000, false, function ( checkCaratIcon ) {
                    											if ( checkCaratIcon.value == true ) {
                    												editContainer.useXpath ( ).pause ( 4000 ).
                                            //Click on the toggle menu in the media gallery page
                    												click ( "//div[1]/div/div[3]/div[1]/div[2]//media-gallery//div[2]/div[1]/div[1]/toggle-menu/div[1]/i" ).
                    												pause ( 4000 ).
                                            //Wait for the dropdown option is visible in the media-gallery page
                    												waitForElementVisible ( "//div/div[1]/div/div[3]//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]", 9000, false, function ( checkdrpdwn ) {
                    													if ( checkdrpdwn.value == true ) {
                    														editContainer.useXpath ( ).pause ( 4000 ).
                                                //Click on the dropdown option in the media-gallery page
                    														click ( "//div/div[1]/div/div[3]//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                    														pause ( 6000 ).
								                    						//Verify the Search categories input field in the pages container edit page
								                    						waitForElementVisible ( "(//input[@id='search_input'])[2]", 9000, false, function ( checksearchField ) {
								                    							if ( checksearchField.value == true ) {
								                    								editContainer.useXpath ( ).pause ( 4000 ).								                    						
										                    						//Clear the data in the search categories input field in the edit container page
										                    						clearValue ( "(//input[@id='search_input'])[2]" ).		                    						
										                    						pause ( 4000 ).
										                    						//Enter the data in the search categories input field in the edit container page
										                    						setValue ( "(//input[@id='search_input'])[2]", splitContainer[ getSplitedData ] ).										                    							
										                    						useCss ( ).pause ( 4000 ).       
																			              //Press return key           
																			              keys ( editContainer.Keys.ENTER ).
																			              useXpath ( ).pause ( 4000 ).                     						
										                    						//Get location for the categories listed in the dropdown
										                    						getLocationInView ( "//span[contains(.,'"+splitContainer[ getSplitedData ]+"')]" ).
										                    						pause ( 4000 ).
                                                    //move to the element for respective categories
										                    						moveToElement ( "//span[contains(.,'"+splitContainer[ getSplitedData ]+"')]/ancestor::div/media-gallery/div/div/div[2]/div[2]/div/div/div/div[3]", 10, 10 ).
										                    						pause ( 4000 ).
                                                    //Wait for the Select button is visible in the page
										                    						waitForElementVisible ( "//div/media-gallery/div/div/div[2]/div[2]/div/div/div[1]/div[1]/div", 9000, false, function ( checkSelectBtn ) {
										                    							if ( checkSelectBtn.value == true ) {
										                    								editContainer.useXpath ( ).pause ( 4000 ).		
                                                        //Click on the select button in the page									                    								
												                    						click ( "//div/media-gallery/div/div/div[2]/div[2]/div/div/div[1]/div[1]/div" ).
												                    						pause ( 4000 ).
                                                        //Wait for the Tick mark is visible in the page
												                    						waitForElementVisible ( "//media-gallery/div/div/div[2]/div[2]/div/div/div[1]/div[1]/i", 9000, false, function ( checkTickMark ) {
												                    							if ( checkTickMark.value == true ) {
												                    							editContainer.useXpath ( ).pause ( 4000 ).
														                    						//Wait for the categories list dropdown option is visible in the
														                    						waitForElementVisible ( "//div/div[1]/div/div[3]//div[3]/div[2]/button[1]", 4000, false, function ( checkSaveBtn ) {
														                    							if ( checkSaveBtn.value == true ) {
														                    								editContainer.useXpath ( ).pause ( 4000 ).
														                    								//Click on the categories listed dropdown option in the edit page
														                    								click ( "//div/div[1]/div/div[3]//div[3]/div[2]/button[1]" ).
														                    								pause ( 4000 ).
                                                                //Wait for the Added Item is visible in the listing page
														                    								waitForElementVisible ( "//div//content-carousel//ng-include/div[1]/div", 9000, false, function ( checkAddedItem ) {   
														                    									if ( checkAddedItem.value == true ) { 
																		                    						//Write the Excel to PASS Result and Reason
																		                                editContainer.writeToExcelPass ( 'pages.xlsx', 'ContainerEdit', excelRow, 5 );
																	                                }
																	                                else {
																	                                	//Write the Excel to FAIL Result and Reason
															                                  		this.verify.fail ( checkAddedItem.value, 'true', 'Added Item is not displayed in the Container listing page' );
															                                  		editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Added Item is not displayed in the Container listing page" );
																	                                }
																                                } );
																		                          }
																	                            else {
																	                              editContainer.useXpath ( ).pause ( 4000 ).
															                                	//Click on the Cancel button in the pages container edit page
															                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
															                    							pause ( 4000 )
															                                  //Write the Excel to FAIL Result and Reason
															                                  this.verify.fail ( checkSaveBtn.value, 'true', 'Save Button is still existing Active' );
															                                  editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Save Button is still In-Active" );
															                                }
															                    					} );
															                    				}
															                    				else {
															                    					editContainer.useXpath ( ).pause ( 4000 ).
													                                	//Click on the Cancel button in the pages container edit page
													                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
													                    							pause ( 4000 )
													                                  //Write the Excel to FAIL Result and Reason
													                                  this.verify.fail ( checkTickMark.value, 'true', 'Tick mark is not visible in the selected artifact' );
													                                  editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Tick mark is not visible in the selected artifact" );
															                    				}
															                    			} );
												                    					}
												                    					else {
												                    						editContainer.useXpath ( ).pause ( 4000 ).
											                                	//Click on the Cancel button in the pages container edit page
											                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
											                    							pause ( 4000 )
											                                  //Write the Excel to FAIL Result and Reason
											                                  this.verify.fail ( checkSelectBtn.value, 'true', 'Select button is not visible in the selected artifact' );
													                              editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Select button is not visible in the selected artifact" );
																											}
												                    				} );
										                    					}
										                    					else {
										                    						editContainer.useXpath ( ).pause ( 4000 ).
									                                	//Click on the Cancel button in the pages container edit page
									                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
									                    							pause ( 4000 )
									                                  //Write the Excel to FAIL Result and Reason
									                                  this.verify.fail ( checksearchField.value, 'true', 'Search Field is not visible in the media gallery pop-up' );
											                              editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Search Field is not visible in the media gallery pop-up" );
											                   					}
										                    				} );
								                    					}
								                    					else {
								                    						editContainer.useXpath ( ).pause ( 4000 ).
							                                	//Click on the Cancel button in the pages container edit page
							                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
							                    							pause ( 4000 )
							                                  //Write the Excel to FAIL Result and Reason
							                                  this.verify.fail ( checkdrpdwn.value, 'true', 'Dropdown option is not visible in the media gallery pop-up' );
									                              editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Dropdown option is not visible in the media gallery pop-up" );
											                   			}
								                    				} );
                    											}
                    											else {
                    												editContainer.useXpath ( ).pause ( 4000 ).
					                                	//Click on the Cancel button in the pages container edit page
					                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
					                    							pause ( 4000 )
					                                  //Write the Excel to FAIL Result and Reason
					                                  this.verify.fail ( checkCaratIcon.value, 'true', 'Carat icon is not visible in the media gallery pop-up' );
							                              editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Carat icon is not visible in the media gallery pop-up" );
											                   	}
                    										} );
					                    				}
				                  						else {
				                  							editContainer.useXpath ( ).pause ( 4000 ).
			                                	//Click on the Cancel button in the pages container edit page
			                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
			                    							pause ( 4000 )
			                                  //Write the Excel to FAIL Result and Reason
			                                  this.verify.fail ( captionText.value, 'true', 'Carat icon is not visible in the media gallery pop-up' );
					                              editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Caption Text is not visible in the media gallery pop-up" );
											               	}          
				                						} );
				              						}
				              						else {
				              							editContainer.useXpath ( ).pause ( 4000 ).
	                                	//Click on the Cancel button in the pages container edit page
	                    							click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
	                    							pause ( 4000 )
	                                  //Write the Excel to FAIL Result and Reason
	                                  this.verify.fail ( checkCaption.value, 'true', 'Caption label is not visible in the media gallery pop-up' );
			                              editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Caption label is not visible in the media gallery pop-up" );
											     				} 
				            						} ); 	
	                    				}
	                    				else {
	                    					//Write the Excel to FAIL Result and Reason
	          										this.verify.fail ( checkEditIcon.value, true, 'Timeout issue or fail due to the Container Edit screen Edit_Icon is not visible' );
	          										editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Container Edit screen, Edit_Icon is not displayed" );
	        										}
	                    			} );                  												                    	
			                    } 			                    
		                    } 
	                    }
	                    else {
	                    	//Write the Excel to FAIL Result and Reason
	                  		this.verify.fail ( checkDescription.value, true, 'Timeout issue or fail due to the Description field is not displayed in the page' );
	                  		editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Description field is not displayed in the page" );
	                    }	
	                  } );
				                                          
                  }
                  else {
                    //Write the Excel to FAIL Result and Reason
                    this.verify.fail ( checkEditBtn.value, true, 'Timeout issue or fail due to Container Edit option is not visible after searched' );
                    editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Container Edit option is not visible after searched" );
                  }
                } );                    
              }
            	else {
                //Write the Excel to FAIL Result and Reason
                this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search option is not visible in the page' );
                editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Pages Search option is not visible in the page" );
              }
            } );            
          }
          else {       
         	  //Write the Excel to FAIL Result and Reason    
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Containers Menu is not visible in the leftside menubar' );
            editContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerEdit', excelRow, 5, 6, "Containers Menu is not visible in the leftside menubar" );
          }
      	} );
    	}
		}
	},
	
	'ContainerDelete': function ( deleteContainer ) {
    var excel = deleteContainer.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        deleteContainer.useXpath ( ).pause ( 4000 ).
        //Wait for the Container menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]", 4000, false, function ( checkContainerMenu ) {
          if ( checkContainerMenu.value == true ) {
            deleteContainer.useXpath ( ).pause ( 4000 ).
            //Click on the Container menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]" ).
            pause ( 4000 ).      
            //Get the Total count in the Container on pages index
	          getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( currentCountResult ) {
	            if ( currentCountResult.status != -1 ) {
	              var currentCount = currentCountResult.value;
	              currentCount = currentCount.split ( 'Containers' );
	              deleteContainer.useXpath ( ).pause ( 4000 ).       
		            //Wait for search field is visible in the Container index page
		            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
		              if ( checkSearchBtn.value == true ) {
		                deleteContainer.useXpath ( ).pause ( 4000 ).
		                //Click on the search field in the Container index page
		                click ( "//*[@id='search_input']" ).
		                pause ( 2000 ).
		                //Clear the data in the search field in the Container index page
		                clearValue ( "//*[@id='search_input']" ).
		                pause ( 2000 ).
		                //Enter the data in the search field in the Container index page
		                setValue ( "//*[@id='search_input']", excel.A[excelColumn] ).
		                useCss ( ).pause ( 2000 ).
		                //Press return key
		                keys ( deleteContainer.Keys.ENTER ).
		                useXpath ( ).pause ( 4000 ).    
		                //Wait for vertical ellipsis is visible in the Container listing page                    		
                		waitForElementVisible ( "//div[contains(.,'"+excel.A[excelColumn]+"')]/span/toggle-menu/span", 4000, false, function ( checkVerticalBtn ) {
                			if ( checkVerticalBtn.value == true ) {
                				deleteContainer.useXpath ( ).pause ( 4000 ).
                				//Click on the vertical ellipsis button in the pages container listing page 
                				click ( "//div[contains(.,'"+excel.A[excelColumn]+"')]/span/toggle-menu/span" ).
                				pause ( 4000 ).  
                				//Wait for the remove button is visible in the pages container listing page                    				
                				waitForElementVisible ( "//span[contains(.,'"+excel.A[excelColumn]+"')]/descendant::ng-transclude/div[contains(.,'Delete')]", 4000, false, function ( checkContainerDeleteBtn ) {
                					if ( checkContainerDeleteBtn.value == true ) {
                						deleteContainer.useXpath ( ).pause ( 4000 ).
                						//Click on the remove button in the pages container listing page
                						click ( "//span[contains(.,'"+excel.A[excelColumn]+"')]/descendant::ng-transclude/div[contains(.,'Delete')]" ).
                						pause ( 4000 ).
                						//Wait for the pop-up delete button is visible in the pages container page
                						waitForElementVisible ( "//span[contains(.,'"+excel.A[excelColumn]+"')]/descendant::div/div[@class='modal-content']/span[1]", 4000, false, function ( checkPopupDelete ) {
                							if ( checkPopupDelete.value == true ) {
                								deleteContainer.useXpath ( ).pause ( 4000 ).
                								//Click on the pop-up delete button in the pages container page
                								click ( "//span[contains(.,'"+excel.A[excelColumn]+"')]/descendant::div/div[@class='modal-content']/span[1]" ).
                								pause ( 4000 ).
                                //Verify the Container menu in the leftside menu bar
                								verify.visible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]" ).
                                pause ( 2000 ).
                                //Click on the container menu in the leftside bar
                                click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'containers')]" ).
                								pause ( 4000 ).
                                //Verify the Total count in the Container index page
                                verify.visible ( "//div/ng-include[2]/div/div/div[1]/span/span" ).
                                pause ( 3000 ).
										            //Get the Total count in the Container on pages index
											          getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( actualCountResult ) {
											            if ( actualCountResult.status != -1 ) {
											              var actualCount = actualCountResult.value;
											              actualCount = actualCount.split ( 'Containers' );
											              var expectedCount = ( +currentCount[0] - 1 ) 
                                    if ( actualCount[0] == expectedCount ) {
                                    	deleteContainer.useXpath ( ).pause ( 4000 ). 
	                										//Wait for the container name should not present in the pages container page
	                										waitForElementNotPresent ( "//div[1]/div/div[1]/div[1]/div[contains(.,'"+excel.A[excelColumn]+"')]", 4000, false, function ( checkContainerName ) {
	                											if ( checkContainerName.value.length == 0 ) {
	                  											//Write the Excel to PASS Result and Reason
	                                    		deleteContainer.writeToExcelPass ( 'pages.xlsx', 'ContainerDelete', excelRow, 2 );
                                  			}
                                 				else {
                                					//Write the Excel to FAIL Result and Reason
                                  				this.verify.fail ( checkContainerName.value, 'true', 'Deleted Container is still existing' );
                                  				deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "Deleted Container is still Existing in the container listing page" );
                                				}
                											} );                                      
                                    }
                                    else {
                                    	//Write the Excel to FAIL Result and Reason
                                  		this.verify.fail ( actualCountResult.value, 'true', 'Actual and Expected count value is mismatched' );
                                  		deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "ActualResult: '"+ actualCount +"' in the Total Count After deleted container. ExpectedResult: Total Count label should be'" + expectedCount + "' in the the container listing page" );
                                		}
                                  }
                                  else {
                                    //Write the Excel to FAIL Result and Reason
                                    this.verify.fail ( actualCountResult.value, 'true', 'actual value is not displayed in the page' );                                                      
                                    deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "ActualResult: '"+ actualCountResult.value +"' is displayed in container page. ExpectedResult: Total Count label should be in the container listing page" );
                                  } 
                                } );                                    
                							}
                							else {
                								//Write the Excel to FAIL Result and Reason
			                      		this.verify.fail ( checkPopupDelete.value, true, 'Timeout issue or fail due to the Pages Container popup Delete button is not visible' );
			                      		deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "Pages Container popup Delete button is not displayed in the page" );
                							}
                						} );
                					}
                					else {                    						
                						//Write the Excel to FAIL Result and Reason
			                      this.verify.fail ( checkContainerDeleteBtn.value, true, 'Timeout issue or fail due to the Pages Container Delete button is not visible' );
			                      deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "Pages Container Delete button is not displayed" );
                					}
                				} );
                			}
                			else {                    				
                				//Write the Excel to FAIL Result and Reason
	                      this.verify.fail ( checkVerticalBtn.value, true, 'Timeout issue or fail due to the Container Vertical Ellipsis Button is not visible' );
	                      deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "Container Vertical Ellipsis Button is not visible in the page" );
                 			}
                		} );       	                         
	                }
	              	else {
	                  //Write the Excel to FAIL Result and Reason
	                  this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
	                  deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "Pages Search option is not displayed in the listing page" );
	                }
	              } ); 
	            }
	            else {
	            	//Write the Excel to FAIL Result and Reason
	              this.verify.fail ( currentCountResult.value, true, 'Timeout issue or fail due to the Container total count label is not visible' );
	              deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, " Container total count label displayed as '"+currentCountResult.value+" in the listing page' )" );
	            } 
	          } );          
          }
          else {       
         	  //Write the Excel to FAIL Result and Reason    
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to Pages Menu is not displayed in the Leftside menubar' );
            deleteContainer.writeToExcelFail ( 'pages.xlsx', 'ContainerDelete', excelRow, 2, 3, "Pages Menu is not displayed in the Leftside menubar" );
          }
      	} );
    	}
		}
	},  
};
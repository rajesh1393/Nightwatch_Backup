var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
var getIndexValue;
var totalElements = 0;
module.exports = {
  tags: [ 'chkIndexNoInPagesFun' ],
  before: function ( pagesLogin ) {
    //Login to the Pages with valid credentials
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkIndexNoInPagesFun': function ( chkIndexFun ) {
    var excel = chkIndexFun.globals.excelCol;
    for ( let incrementer = 1; incrementer <= excel.A.length - 1; incrementer++ ) {
      try {
        chkIndexFun.
        useXpath ( ).
        pause ( 5000 ).
        //Checking whether the page is in Navigation page
        waitForElementPresent ( "//SPAN[@class='ng-binding'][text()='pages']", 5000, false, function ( chkVisibility ) {
          if ( chkVisibility.value == false ) {
            chkIndexFun.
            pause ( 5000 ).
            //Clicking the Pages menu from the side bar Navigation from the application
            click ( "//SPAN[@ng-class='[ appColorScheme, { expand: expand, selected: currentSidebarOption == option.name } ]'][text()='pages']" ).
            pause ( 5000 );
          } 
          chkIndexFun.
            //Checking whether the Index number is displayed in the Pages list page
            waitForElementPresent ( '//span[@class="artifact-count-text ng-binding"]', 5000, false, function ( chkVisibility ) {
              if ( chkVisibility.value != false ) {
                chkIndexFun.
                //Geeting the Indexvalue displayed in the List page
                getText ( '//span[@class="artifact-count-text ng-binding"]', function ( getIndexVal ) {
                  getIndexValue = getIndexVal.value.replace(/\D/g,'');
                  //Manipulating the Value for which the loop has to run
                  loopRunner = getIndexValue/25;
                  //Getting the total number of pages present in the page
                  this.elements ( 'xpath', '//page-cell', function ( searchCount ) {
                  //Updating the Pages count per page in the totalElements variable
                  totalElements += parseInt(searchCount.value.length);
                   } );
                  for ( var i = 1; i <= Math.round ( loopRunner ); i++ ) {
                    chkIndexFun.
                    pause ( 8000 ).
                    //Clicking the Pagination next button in pages list page
                    click ( "//SPAN[@class='single-right-arrow']" ).
                    pause ( 8000 );
                    this.elements ( 'xpath', '//page-cell', function ( searchCount ) {
                    //Updating the Pages count per page in the totalElements variable
                    totalElements += parseInt(searchCount.value.length);
                   } );
                  }
                  chkIndexFun.
                  pause ( 5000 ).
                  //Checking whether the total count of the pages is equals to the total number of pages
                  waitForElementPresent ( "//SPAN[@class='ng-binding'][text()='pages']", 5000, false ,function ( chkVisibility ) {
                    if ( getIndexValue == totalElements ) {
                      chkIndexFun.
                      //Updating the Pass status in the Excel sheet
                      writeToExcelPass ( 'pages.xlsx', 'chkIndexNoInPagesFun',  2, 2);
                    }
                    else {
                      chkIndexFun.
                      //Updating the Fail status in Excel sheet
                      writeToExcelFail ( 'pages.xlsx', 'chkIndexNoInPagesFun', 2, 2, 3 ,"Index value displayed in the list page is "+getIndexValue+" and total count is "+totalElements+"" );
                    }
                  } );
                } );
              }
            } );
          } );
      }
      catch ( e ) {
        chkIndexFun.
        //Updating the fail status in Excel sheet with appropriate status
        writeToExcelFail ( 'pages.xlsx', 'chkIndexNoInPagesFun', 2, 2, 3 ,"Script terminated unexpectedly" );
      }
    }
  }
}
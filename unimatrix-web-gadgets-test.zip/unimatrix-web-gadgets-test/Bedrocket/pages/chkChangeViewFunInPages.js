var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkChangeViewFunInPages' ],
  before: function ( pagesLogin ) {
    //Login to the Pages with valid credentials
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkChangeViewFunInPages': function ( chkSortFun ) {
    var excel = chkSortFun.globals.excelCol;
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {
      try {
        chkSortFun.
        useXpath ( ).
        pause ( 15000 ).
        waitForElementNotPresent ( "//DIV[@class='no-content-container ng-scope']", 15000, false, function ( chkNoData ) {
        console.log(chkNoData)
        if ( chkNoData.value == false ) {
        chkSortFun.
        //Checking whether the page is in pages module
        waitForElementPresent ( "//SPAN[@class='ng-binding'][text()='pages']", 5000, false, function ( chkVisibility ) {
          if ( chkVisibility.value == false ) {
            chkSortFun.
            pause ( 5000 ).
            //Clicking the Pages menu from the side bar Navigation from the application
            click ( "//SPAN[@ng-class='[ appColorScheme, { expand: expand, selected: currentSidebarOption == option.name } ]'][text()='pages']" ).
            pause ( 5000 );
          } 
          chkSortFun.
            //Checking whether Search field is displayed
            waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkVisibility ) {
              if ( chkVisibility.value != false ) {
              //Clicking the Search Input field
              if ( excel.B[incrementer]=="ListView" ) {
              chkSortFun.
              //Clicking the List view in the pages module
              click ( "//I[@ng-if='pageDetails.listView']" ).
              //Checking whether the pages are displayed in the List view
              waitForElementPresent ( "//NG-TRANSCLUDE[@class='list_display']", 15000, false, function ( chkListView ) {
                if ( chkListView.value != false ) {
                  chkSortFun.
                  //Updating the Pass status in The excel sheet
                  writeToExcelPass ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 );
                }
                else {
                  chkSortFun.
                  //Updating the Fail status in the Excel sheet
                  writeToExcelFail ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 ,"Unable to check whether the page is displayed in List view" );
                }
              } );
            }
            else if ( excel.B[incrementer]=="GridView" ) {
              chkSortFun.
              //Clicking the Grid view icon in the pages
              click ( "//I[@ng-if='pageDetails.gridView']" ).
              //Checking whether the pages are displayed in the Grid view
              waitForElementPresent ( "//NG-TRANSCLUDE[@class='grid_display']", 15000, false, function ( chkListView ) {
                if ( chkListView.value != false ) {
                  chkSortFun.
                  //Updating the Pass status in The excel sheet
                  writeToExcelPass ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 );
                }
                else {
                  chkSortFun.
                  //Updating the Fail status in the Excel sheet
                  writeToExcelFail ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 ,"Unable to check whether the page is displayed in Grid view" );
                }
              } );
            }
            else {
              chkSortFun.
              //Updating the fail status in Excel sheet with appropriate status
              writeToExcelFail ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 ,"Please update the Input in excel sheet" );
            }
            }
            else {
              chkSortFun.
              //Updating the fail status in Excel sheet with appropriate status
              writeToExcelFail ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 ,"Unable to navigate to Pages module" );
            }
          } );
          } );

          } 
          else {
            chkSortFun.
            //Updating the fail status in Excel sheet with appropriate status
            writeToExcelFail ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 ,"No contents in Pages module" );
          }
        } );
      }

      catch ( e ) {
        chkSortFun.
        //Updating the fail status in Excel sheet with appropriate status
        writeToExcelFail ( 'pages.xlsx', 'chkChangeViewFunInPages', ++incrementer, 3, 4 ,"Script terminated unexpectedly" );
      }
    }
  }
}
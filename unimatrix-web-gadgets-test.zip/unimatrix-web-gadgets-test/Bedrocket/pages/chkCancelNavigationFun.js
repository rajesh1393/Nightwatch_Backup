var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: ['chkCancelNavigationFun'],
  before: function ( pagesLogin ) {
    //Login to the Pages with valid credentials
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkCancelNavigationFun': function ( chkCancelBtn ) {
    var excel = chkCancelBtn.globals.excelCol;
    try {
      chkCancelBtn.
      useXpath ( ).
      pause ( 5000 ).
        //Checking whether the page is in Navigation page
        waitForElementNotPresent ( "//SPAN[@class='ng-binding'][text()='navigation']", 5000, false, function ( chkVisibility ) {
          if ( chkVisibility.value == false ) {
            chkCancelBtn.
            pause ( 5000 ).
            //Clicking the Navigation menu from the sidebar of the application
            click ( "//SPAN[@ng-class='[ appColorScheme, { expand: expand, selected: currentSidebarOption == option.name } ]'][text()='navigation']" ).
            pause ( 5000 ).
            //Clicking the Add icon in the Pages landing page
            click ( "//I[@class='add-icon']" );
          } else {
            chkCancelBtn.
            //Clicking the Add icon in the Pages landing page
            click ( "//I[@class='add-icon']" );
          }
            chkCancelBtn.
            //Checking whether the Dropdown menu is displayed
            waitForElementPresent ( "//DIV[@class='flyout-menu-large dropdown-menu navigations ng-scope']", 5000, false, function ( chkVisibility ) {
            if ( chkVisibility.value != false ) {
              chkCancelBtn.
              //Clicking the Add Navigation Option in the Toggle menu
              click ( "(//LI)[2]" ).
              //Checking whether the page is navigated to Create Navigation page
              waitForElementPresent ( "//BUTTON[@class='cta-button'][text()='CREATE']", 5000, false, function ( chkVisibility ) {
                if ( chkVisibility.value != false ) {
                  chkCancelBtn.
                  //Clicking the Cancel button in the create page
                  click ( "//BUTTON[@class='cancel-button'][text()='CANCEL']" ).
                  pause ( 5000 ).
                  //Checking whether the page is navigated to the Navigation index page and new Navigation is added
                  waitForElementPresent ( "//SPAN[@class='ng-binding'][text()='navigation']", 5000, false, function ( chkAddedNavi ) {
                    if ( chkAddedNavi.value == false ) {
                      chkCancelBtn.
                      //Updating the fail status in the Excel sheet
                      writeToExcelFail ( 'pages.xlsx', 'chkCancelNavigationFun', 2, 2, 3, "Page is not redirected to Navigation list page after clicking on the Cancel button" );
                    } else {
                      chkCancelBtn.
                      //Updating the pass status in the Excel sheet
                      writeToExcelPass ( 'pages.xlsx', 'chkCancelNavigationFun', 2, 2 );
                    }
                  } );
                } else {
                  chkCancelBtn.
                  //Updating the fail status in Excel sheet with appropriate status
                  writeToExcelFail ( 'pages.xlsx', 'chkCancelNavigationFun', 2, 2, 3, "Unable to navigate to Add navigate page" );
                }
              } );
            }
          } );
        } );
      } catch ( e ) {
        chkCancelBtn.
        //Updating the fail status in Excel sheet with appropriate status
        writeToExcelFail ( 'pages.lxsx', 'chkCancelNavigationFun', 2, 2, 3,"Script terminated unexpectedly" );
      }
    }
  }
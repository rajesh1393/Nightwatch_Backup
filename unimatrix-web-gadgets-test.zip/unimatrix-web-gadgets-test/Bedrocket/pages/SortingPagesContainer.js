//this function is for sorting the Pages Container
var excelRow, excelColumn = 1;
var splitName = [ ];           
var splitOption = [ ]; 
var invertData = [ ];
module.exports = {
  tags: ['sortingPagesContainer'],
  before: function ( pagesLogin ) {
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },  
 'SortingPagesContainer': function ( sortingPagesContainer ) {
  var excel = sortingPagesContainer.globals.excelCol;
    if ( excel.A.length > 1 ) {    	
      for ( let excelColumn = 1, rowCount = 1; excelColumn < excel.A.length; excelColumn++ ) {
        rowCount++;
        sortingPagesContainer.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Pages Menu in Sidebar
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkMenuName ) {
        	valueSwipe = excel.C[ excelColumn ]
					switch ( valueSwipe ) {
				    case "asc":
				      invertData = "des"
				      break;
				    case "desc":
				      invertData = "asc"
				      break;
				  }
          if ( checkMenuName.value == true ) {
            sortingPagesContainer.pause ( 4000 ).useXpath ( ).
            //Verify the Pages Menu is visible in the sidebar
            verify.visible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).
            //Click on the Pages Menu in sidebar
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).             
           //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                sortingPagesContainer.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( sortingPagesContainer.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
                  if ( checkEditBtn.value == true ) {
                    sortingPagesContainer.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on pages index page
                    click ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                    pause ( 4000 ). 
                    //Wait for the Pages Structure tab is visible in the pages details page
                    waitForElementVisible ( "//a[1]/div[contains(.,'page structure')]", 4000, false, function ( checkStructureTab ) {
                      if ( checkStructureTab.value == true ) {
                        sortingPagesContainer.useXpath ( ).pause ( 4000 ).
                        //Click on the Page Structure tab in the pages details page
                        click ( "//a[1]/div[contains(.,'page structure')]" ).                       
                        pause ( 4000 )               
                        sortingPagesContainer.useXpath ( ).pause ( 4000 ).
                        //Get the Location for the container in the listing page
                        getLocationInView ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]" ).
                        pause ( 4000 ).   
                        //Wait for the container name field is visible in the pages container listing page                   
                        waitForElementVisible ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]", 4000, false, function ( checkContainerName ) {
                          if ( checkContainerName.value == true ) {                                                                                                
                            sortingPagesContainer.useXpath ( ).pause ( 4000 ). 
                            //Click on the container name in the pages container listing page                           
                            click ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]" ).
                            pause ( 4000 ).
                            //Wait for Pages name box is visible in the listing page
                            waitForElementVisible ("//div[2]//div[3]/div[1]/div[1]/sort-menu-text/div/span[2]", 9000, false, function ( checkSortIcon ) {
                              if ( checkSortIcon.value == true ) {
                                sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                //Click on the sort list option is visible in the dropdown option
                                click ("//div[2]//div[3]/div[1]/div[1]/sort-menu-text/div/span[2]").
                                pause ( 4000 ).
                                //Wait for the sort list option in the dropdown list
                                waitForElementVisible ( "//sort-menu-text/div[2]/ng-include/div/ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]", 9000, false, function ( checkSortLst ) {
                                	if ( checkSortLst.value == true ) {
                                		if ( excel.D[ excelColumn ] == 'Name' ) {
                                      sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                      //Wait and check for Tick mark label not present in the page
                                      waitForElementNotPresent ( "//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]/i[@class='flyout-icon check-icon auto-untoggle ng-scope']",9000, false, function ( checkTick ) {
                                        if ( checkTick.value.length == 0 ) {
                                          sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Verify the sort list option is visible in the dropdown option
                                          verify.visible ( "//sort-menu-text/div[2]/ng-include/div/ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 ).
                                          //Click on the sort list option in the dropdown option
                                          click ( "//sort-menu-text/div[2]/ng-include/div/ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 )                                          
                                        }                      
                                      } );
                                			sortingPagesContainer.pause ( 4000 ).useXpath ( ).                   
                                      //Wait for the arrow button is visible in the dropdown option
                                			waitForElementVisible ( "(//div/ul/li/i)[2]", 9000, false, function ( checkArrow ) {
                                				if ( checkArrow.value == true ) {
                                					sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Get the attribute value for arrow button in the dropdown option
                                					getAttribute ( "(//div/ul/li/i)[2]","ng-click",function ( valueNgClick ) {
                                						var clickedValue = valueNgClick.value;                						
                                						clickedValue = clickedValue.substring ( 22, 26 );                                      						         						
                											      if ( clickedValue == invertData ) {
                                							sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Get the Text for the title in the listing page
                                							getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                                var actualTitleNM = checkFirstTitle.value
                                								if ( actualTitleNM == excel.E[ excelColumn ] ) {
                                									//Write the Excel to PASS Result and Reason
                                           				sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                								}
                                								else {
                                									this.verify.fail ( actualTitleNM, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleNM +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                								}
                                							} );
                                						}
                                						else {
                                							sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Click on the arrow button
                                							click("(//div/ul/li/i)[2]").
                                							pause(4000).
                                              //Wait for the searched result data is visible in the page
                                							waitForElementVisible ( "//content-carousel/div/div[3]/ng-include/div[1]/p", 9000, false ).
                                							pause ( 4000 ).
                                              //Get the Text for the title in the listing page
                                							getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                                var actualTitleNM = checkFirstTitle.value
                                								if ( actualTitleNM == excel.E[ excelColumn ] ) {
                                									//Write the Excel to PASS Result and Reason
                                           				sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                								}
                                								else {
                                									this.verify.fail ( actualTitleNM, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleNM +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                								}
                                							} );
                                						}
                                					} );                					
                                				}
                                			} );
                                		}
                                		else if ( excel.D[ excelColumn ] == 'Date Added' ) {
                                			sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                      //Wait and check for Tick mark label not present in the page
                                      waitForElementNotPresent ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]/i[@class='flyout-icon check-icon auto-untoggle ng-scope']",9000, false, function ( checkTickDate ) {
                                        if ( checkTickDate.value.length == 0 ) {
                                          sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Verify the sort list option is visible in the dropdown option
                                          verify.visible ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 ).
                                          //Click on the sort list option in the dropdown option
                                          click ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 ).
                                          //Verify for Sorting option is visible in the pages listing page
                                          verify.visible ( "//ng-include[2]/div/div/div[3]/sort-menu/i" ).
                                          pause ( 4000 ).
                                          //Click on the sort list option is visible in the dropdown option
                                          click ("//ng-include[2]/div/div/div[3]/sort-menu/i")
                                        }                       
                                      } );
                                			sortingPagesContainer.pause ( 4000 ).useXpath ( ).                  
                                      //Wait for the arrow button is visible in the dropdown option
                                			waitForElementVisible ( "(//div/ul/li/i)[2]", 9000, false, function ( checkArrow ) {
                                				if ( checkArrow.value == true ) {
                                					sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Get the attribute value for arrow button in the dropdown option
                                					getAttribute ( "(//div/ul/li/i)[2]","ng-click", function ( valueNgClick ) {
                                						var clickedValue = valueNgClick.value;
                                						clickedValue = clickedValue.substring ( 22, 26 );
                											      if ( clickedValue == invertData ) {
                                							sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Get the Text for the title in the listing page
                                							getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                                var actualTitleDA = checkFirstTitle.value
                                								if ( actualTitleDA == excel.E[ excelColumn ] ) {
                                									//Write the Excel to PASS Result and Reason
                                           				sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                								}
                                								else {
                                									this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleDA +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                								}
                                							} );
                                						}
                                						else {
                                							sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Click on the arrow button
                                							click("(//div/ul/li/i)[2]").
                                							pause ( 4000 ).
                                              //Wait for the searched result data is visible in the page
                                							waitForElementVisible ( "//content-carousel/div/div[3]/ng-include/div[1]/p", 9000, false ).
                                							pause ( 4000 ).
                                              //Get the Text for the title in the listing page
                                							getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                                var actualTitleDA = checkFirstTitle.value
                                								if ( actualTitleDA == excel.E[ excelColumn ] ) {
                                									//Write the Excel to PASS Result and Reason
                                           				sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                								}
                                								else {
                                									this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleDA +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                								}
                                							} );
                                						}
                                					} );                					
                                				}
                                			} );
                                		}
                                    else if ( excel.D[ excelColumn ] == 'Manual' ) {
                                      sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                      //Wait and check for Tick mark label not present in the page
                                      waitForElementNotPresent ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]/i[@class='flyout-icon check-icon auto-untoggle ng-scope']",9000, false, function ( checkTickDate ) {
                                        if ( checkTickDate.value.length == 0 ) {
                                          sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Verify the sort list option is visible in the dropdown option
                                          verify.visible ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 ).
                                          //Click on the sort list option in the dropdown option
                                          click ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 ).
                                          //Verify for Sorting option is visible in the pages listing page
                                          verify.visible ( "//ng-include[2]/div/div/div[3]/sort-menu/i" ).
                                          pause ( 4000 ).
                                          //Click on the sort list option is visible in the dropdown option
                                          click ("//ng-include[2]/div/div/div[3]/sort-menu/i")
                                        }                       
                                      } );
                                      sortingPagesContainer.pause ( 4000 ).useXpath ( ).                  
                                      //Wait for the arrow button is visible in the dropdown option
                                      waitForElementVisible ( "(//div/ul/li/i)[2]", 9000, false, function ( checkArrow ) {
                                        if ( checkArrow.value == true ) {
                                          sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Get the attribute value for arrow button in the dropdown option
                                          getAttribute ( "(//div/ul/li/i)[2]","ng-click", function ( valueNgClick ) {
                                            var clickedValue = valueNgClick.value;
                                            clickedValue = clickedValue.substring ( 22, 26 );
                                            if ( clickedValue == invertData ) {
                                              sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Get the Text for the title in the listing page
                                              getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                                var actualTitleDA = checkFirstTitle.value
                                                if ( actualTitleDA == excel.E[ excelColumn ] ) {
                                                  //Write the Excel to PASS Result and Reason
                                                  sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                                }
                                                else {
                                                  this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleDA +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                                }
                                              } );
                                            }
                                            else {
                                              sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Click on the arrow button
                                              click("(//div/ul/li/i)[2]").
                                              pause ( 4000 ).
                                              //Wait for the searched result data is visible in the page
                                              waitForElementVisible ( "//content-carousel/div/div[3]/ng-include/div[1]/p", 9000, false ).
                                              pause ( 4000 ).
                                              //Get the Text for the title in the listing page
                                              getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                                var actualTitleDA = checkFirstTitle.value
                                                if ( actualTitleDA == excel.E[ excelColumn ] ) {
                                                  //Write the Excel to PASS Result and Reason
                                                  sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                                }
                                                else {
                                                  this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleDA +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                                }
                                              } );
                                            }
                                          } );                          
                                        }
                                      } );
                                    }
                                		else if ( excel.D[ excelColumn ] == 'Last Modified' ) {
                                			sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                      //Wait and check for Tick mark label not present in the page
                                      waitForElementNotPresent ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]/i[@class='flyout-icon check-icon auto-untoggle ng-scope']",9000, false, function ( checkTickModified ) {
                                        if ( checkTickModified.value.length == 0 ) {
                                          sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Verify the sort list option is visible in the dropdown option
                                          verify.visible ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 ).
                                          //Click on the sort list option in the dropdown option
                                          click ( "//div[3]/sort-menu//ul/li[contains(.,'"+excel.D[ excelColumn ]+"')]" ).
                                          pause ( 4000 ).
                                          //Verify for Sorting option is visible in the pages listing page
                                          verify.visible ( "//ng-include[2]/div/div/div[3]/sort-menu/i" ).
                                          pause ( 4000 ).
                                          //Click on the sort list option is visible in the dropdown option
                                          click ("//ng-include[2]/div/div/div[3]/sort-menu/i")
                                        }                       
                                      } );
                                			sortingPagesContainer.pause ( 4000 ).useXpath ( ).                 
                                      //Wait for the arrow button is visible in the dropdown list
                                			waitForElementVisible ( "(//div/ul/li/i)[2]", 9000, false, function ( checkArrow ) {
                                				if ( checkArrow.value == true ) {
                                					sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                          //Get the attribute value for arrow button in the dropdown option
                                					getAttribute ( "(//div/ul/li/i)[2]","ng-click",function ( valueNgClick ) {
                                						var clickedValue = valueNgClick.value;
                                						clickedValue = clickedValue.substring ( 22, 26 );
                											      if ( clickedValue == invertData ) {
                                							sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Get the Text for the title in the listing page
                                							getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                								var actualTitleLM = checkFirstTitle.value
                                                if ( actualTitleLM == excel.E[ excelColumn ] ) {
                                									//Write the Excel to PASS Result and Reason
                                           				sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                								}
                                								else {
                                									this.verify.fail ( actualTitleLM, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleLM +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                								}
                                							} );
                                						}
                                						else {
                                							sortingPagesContainer.pause ( 4000 ).useXpath ( ).
                                              //Click on the arrow button
                                							click("(//div/ul/li/i)[2]").
                                							pause(4000).
                                              //Wait for the searched result data is visible in the page
                                							waitForElementVisible ( "//content-carousel/div/div[3]/ng-include/div[1]/p", 9000, false ).
                                							pause ( 4000 ).
                                              //Get the Text for the title in the listing page
                                							getText ( "//content-carousel/div/div[3]/ng-include/div[1]/p", function ( checkFirstTitle ) {
                                                var actualTitleLM = checkFirstTitle.value
                                								if ( actualTitleLM == excel.E[ excelColumn ] ) {
                                									//Write the Excel to PASS Result and Reason
                                           				sortingPagesContainer.writeToExcelPass ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6 );
                                								}
                                								else {
                                									this.verify.fail ( actualTitleLM, 'true', 'Fail to display the first title in the listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Actual Title as:'"+ actualTitleLM +"'in the Pages listing page. Expected Title is:'"+ excel.E[ excelColumn ] +"' in the Destination listing page" );
                                								}
                                							} );
                                						}
                                					} );                					
                                				}
                                			} );
                                		}
                                		else {
                                			this.verify.fail ( checkSortLst.value, 'true', 'Sort Element is not avail in the list' );
                                      //Write the Excel to FAIL Result and Reason
                                			sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Sort Element is not avail in the list" );
                                		}
                                	}
                                } );            
                              }
                              else {
                              	this.verify.fail ( checkSortIcon.value, 'true', 'Sort Icon is not displayed in the listing page' );
                                //Write the Excel to FAIL Result and Reason
                                sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Sort Icon is not displayed in the listing page" );
                              }
                            } );
                          }
                          else {
                            this.verify.fail ( checkContainerName.value, 'true', 'Container Name is not displayed in Container listing page' );
                            //Write the Excel to FAIL Result and Reason
                            sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Container Name is not displayed in Container listing page" );
                          }
                        } );
                      }
                      else {
                        this.verify.fail ( checkStructureTab.value, 'true', 'Structure Tab menu is not displayed in Pages Detail page' );
                        //Write the Excel to FAIL Result and Reason
                        sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Structure Tab menu is not displayed in Pages Detail page" );
                      }
                    } );
                  }
                  else {
                    this.verify.fail ( checkEditBtn.value, 'true', 'Edit Button is not displayed in Pages listing page' );
                    //Write the Excel to FAIL Result and Reason
                    sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Edit Button is not displayed in Pages listing page" );
                  }
                } );
              }
              else {
                this.verify.fail ( checkSearchBtn.value, 'true', 'Search Button is not displayed in Pages listing page' );
                //Write the Excel to FAIL Result and Reason
                sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Search Button is not displayed in Pages listing page" );
              }
            } );
          }
          else {
          	this.verify.fail ( checkMenuName.value, 'true', 'Pagess menu is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            sortingPagesContainer.writeToExcelFail ( 'pages.xlsx', 'SortingPagesContainer', rowCount, 6, 7, "Pagess menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    sortingPagesContainer.end ( );
  }
}
//this function is for add,edit,rename,delete the PAGES and Containers in Pages
var excelRow, excelColumn = 1;
var splitName = [ ];           
var splitOption = [ ]; 
module.exports = {
  tags: ['pages'],
  before: function ( pagesLogin ) {
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'PagesAdd': function ( pagesAdd ) {
    //Access the variable globally defined
    var excel = pagesAdd.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesAdd.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the page 
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesAdd.useXpath ( ).pause ( 4000 ).
            //Click on the Pages menu in the page
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).
            //Get the Total count in the pages on pages index
            getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                var currentCount = currentCountResult.value;
                currentCount = currentCount.split ( 'Pages' );
                pagesAdd.useXpath ( ).pause ( 4000 ). 
                //Wait for the toggle button is vsisble in the pages index               
                waitForElementVisible ( "//ng-include[1]/div/toggle-menu/i", 4000, false, function ( checkToggleBtn ) {
                  if ( checkToggleBtn.value == true ) {
                    pagesAdd.useXpath ( ).pause ( 4000 ).
                    //Click on the toggle button in the pages index
                    click ( "//ng-include[1]/div/toggle-menu/i" ).
                    pause ( 4000 ).
                    //Wait for the toggle menu is visible in the pages index
                    waitForElementVisible ( "//toggle-menu/div/span/div/ul/li[contains(.,'New Page')]", 4000, false, function ( checkToggleMenu ) {
                      if ( checkToggleMenu.value == true ) {
                        pagesAdd.useXpath ( ).pause ( 4000 ).
                        //Click on the toggle menu in the pages index
                        click ( "//toggle-menu/div/span/div/ul/li[contains(.,'New Page')]" ).
                        pause ( 4000 ).
                        //Wait for the pages title field is visible in the create pages
                        waitForElementVisible ( "//div/div/ng-view/div/div[1]/div/span/span", 4000, false, function ( checkNewCaption ) {
                          if ( checkNewCaption.value == true ) {
                            pagesAdd.useXpath ( ).pause ( 4000 ).
                            //Get the caption value in the create pages
                            getText ("//div/div/ng-view/div/div[1]/div/span/span", function ( getCaption ) {
                              if ( getCaption.value == "New Page") {
                              	pagesAdd.useXpath ( ).pause ( 4000 ).
                                //Wait for the the pages title field in the create pages
                                waitForElementVisible ( "//div/div[2]/div/form/div[1]/input", 4000, false, function ( checkPageTitle ) {
                                  if ( checkPageTitle.value == true ) {
                                    pagesAdd.useXpath ( ).pause ( 4000 ).
                                    //Clear the pages title field in the create pages
                                    clearValue ( "//div/div[2]/div/form/div[1]/input" ).
                                    pause ( 2000 ).
                                    //Enter the value in pages title field on the create pages
                                    setValue ( "//div/div[2]/div/form/div[1]/input", excel.B[ excelColumn ] ).
                                    pause ( 3000 ).
                                    //Wait for the the pages Description field in the create pages
                                    waitForElementVisible ( "//div/div[2]/div/form/div[2]/input", 4000, false, function ( checkPageDescription ) {
                                      if ( checkPageDescription.value == true ) {
                                        pagesAdd.useXpath ( ).pause ( 4000 ).
                                        //Clear the pages Description field in the create pages
                                        clearValue ( "//div/div[2]/div/form/div[2]/input" ).
                                        pause ( 2000 ).
                                        //Enter the value in pages Description field on the create pages
                                        setValue ( "//div/div[2]/div/form/div[2]/input", excel.C[ excelColumn ] ).
                                        pause ( 3000 ).
                                        //Wait for the the pages create button in the create pages
                                        waitForElementVisible ( "//button[contains(.,'CREATE')]", 4000, false, function ( checkCreateBtn ) {
                                          if ( checkCreateBtn.value == true ) {
                                            pagesAdd.useXpath ( ).pause ( 4000 ).
                                            //Click on the pages create button in the create pages
                                            click ( "//button[contains(.,'CREATE')]" ).
                                            pause ( 3000 ).
                                            //Wait for the Alert message is visible in the pages
                                            waitForElementVisible ( "//universal-app-shell/ng-include[1]/header/ng-include/div/span[1]", 4000, false, function ( checkAlertMsg ) {
                                              if ( checkAlertMsg.value == true ) {
                                                pagesAdd.useXpath ( ).
                                                //Get the Value of the alert message in the page                   
                                                getText ( "//universal-app-shell/ng-include[1]/header/ng-include/div/span[1]", function ( textGetting ) {
                                                  if ( textGetting.value == 'Saved!' ) {
                                                    pagesAdd.useXpath ( ).pause ( 4000 ).
                                                    //Wait for Pages menu is visible in the sidebar
                                                    waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false ).
                                                    pause ( 4000 ).
                                                    //Click on the Pages menu in sidebar
                                                    click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
                                                    pause ( 4000 ).useXpath ( ).
                                                    //Verify the Total count label is visible in the Folder page
                                                    verify.visible ( "//div/ng-include[2]/div/div/div[1]/span/span" ).
                                                    pause ( 4000 ).
                                                    //Get Actual Total Count after created in the Content 
                                                    getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( actualCountResult ) {
                                                      if ( actualCountResult.status != -1 ) {
                                                        var actualCount = actualCountResult.value;                                                     
                                                        actualCount = actualCount.split ( 'Pages' );
                                                        expectedCount = ( +currentCount[0] + 1 ) 
                                                        if ( actualCount[0] == expectedCount ) {
                                                          //Write the Excel to PASS Result and Reason
                                                          pagesAdd.writeToExcelPass ( 'pages.xlsx', 'PagesAdd', excelRow, 4 );
                                                        }
                                                        else {
                                                        	//Write the Excel to FAIL Result and Reason
                                                          this.verify.fail ( actualCountResult.value, 'true', 'actual value is not displayed in the page' );                                                      
                                                          pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After created New pages. ExpectedResult: should be'" + expectedCount + "' in the Total Count" );
                                                        }
                                                      }
                                                    } );
                                                  }
                                                  else {
                                                  	//Write the Excel to FAIL Result and Reason
                                                    this.verify.fail ( textGetting.value, 'true', 'Text value is not displayed in the page' );                                                
                                                    pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "Actual alert message as: '"+ textGetting.value +"',After Created New pages. ExpectedResult: should be 'Saved!'" );
                                                  }
                                                } );
                                              }
                                              else {
                                              	//Write the Excel to FAIL Result and Reason
                                                this.verify.fail ( checkAlertMsg.value, 'true', 'Add New button is not displayed in the page' );                                            
                                                pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "Saved message is not displayed in the page" );
                                              }
                                            } );
                                          }
                                          else {
                                          	//Write the Excel to FAIL Result and Reason
                                            this.verify.fail ( checkCreateBtn.value, true, 'Timeout issue or fail due to the Pages create button is not visible' );
                                            pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ checkCreateBtn.value +". ExpectedResult: the Pages create button should be visible' )" );
                                          }
                                        } );
                                      }
                                      else {
                                      	//Write the Excel to FAIL Result and Reason
                                        this.verify.fail ( checkPageDescription.value, true, 'Timeout issue or fail due to the Pages create button is not visible' );
                                        pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ checkPageDescription.value +". ExpectedResult: the Pages Description should be visible' )" );
                                      }
                                    } );
                                  }
                                  else {
                                  	//Write the Excel to FAIL Result and Reason
                                    this.verify.fail ( checkPageTitle.value, true, 'Timeout issue or fail due to the Pages Title is not visible' );
                                    pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ checkPageTitle.value +". ExpectedResult: the Pages Title should be visible' )" );
                                  }
                                } );
                              }
                              else {
                                //Write the Excel to FAIL Result and Reason
                                this.verify.fail ( getCaption.value, true, 'Timeout issue or fail due to the Pages Caption is not available' );
                                pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ getCaption.value +". ExpectedResult: the Pages caption should be available' )" );
                              }
                            } );
                          }
                          else {
                          	//Write the Excel to FAIL Result and Reason
                            this.verify.fail ( checkNewCaption.value, true, 'Timeout issue or fail due to the Pages Titles is not visible' );
                            pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ checkNewCaption.value +". ExpectedResult: the Pages Titles should be visible' )" );
                          }
                        } );
                      }
                      else {
                      	//Write the Excel to FAIL Result and Reason
                        this.verify.fail ( checkToggleMenu.value, true, 'Timeout issue or fail due to the Pages Toggle Menu is not visible' );
                        pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ checkToggleMenu.value +". ExpectedResult: the Pages Toggle Menu should be visible' )" );
                      }
                    } );
                  }
                  else {
                  	//Write the Excel to FAIL Result and Reason
                    this.verify.fail ( checkToggleBtn.value, true, 'Timeout issue or fail due to the Pages + Toggle Button is not visible' );
                    pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ checkToggleBtn.value +". ExpectedResult: the Pages + Toggle Button should be visible' )" );
                  }
                } );
              }
              else {              	
                //Write the Excel to FAIL Result and Reason
                this.verify.fail ( currentCount, true, 'Timeout issue or fail due to the Pages current Count is not visible' );
                pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ currentCount +". ExpectedResult: the Pages current count should be visible' )" );
              }
            } );
          }
          else {
            //Write the Excel to FAIL Result and Reason
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages menu is not visible' );
            pagesAdd.writeToExcelFail ( 'pages.xlsx', 'PagesAdd', excelRow, 4, 5, "ActualResult: '"+ checkPagesMenu.value +". ExpectedResult: the Pages menu should be visible' )" );            
          }
        } );
      }
    }
  },

 'PagesAddContainer': function ( pagesAddContainer ) {
    var excel = pagesAddContainer.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesAddContainer.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesAddContainer.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                pagesAddContainer.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( pagesAddContainer.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
                  if ( checkEditBtn.value == true ) {
                    pagesAddContainer.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on pages index page
                    click ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                    pause ( 4000 ). 
                    //Click on the Page Structure Tab in the Pages Container listing page                           
                    click ( "//*[@id='my_modal-new_container_form']/div" ).
                    pause ( 4000 )                                        
                    splitName = excel.B[ excelColumn ].split(':'); 
                    splitOption = excel.C[ excelColumn ].split(':');
                    //loop the 'n' number of splitted input
                    for ( let getSplitedData = 0; getSplitedData<splitName.length; getSplitedData++ ) {
                    	if ( ( excel.D[ excelColumn ] != "FAIL" ) && ( excel.E[ excelColumn ] == null ) ) {
	                    	pagesAddContainer.useXpath ( ).pause ( 4000 ).
		                    //Wait for Add container button is visible in the Pages Add Container screen
		                    waitForElementVisible ( "//*[@id='open_modal-new_container_form']", 4000, false, function ( checkAddContainerBtn ) {
		                      if ( checkAddContainerBtn.value == true ) {
		                    		pagesAddContainer.useXpath ( ).pause ( 4000 ).
		                    		//Click on the Add Container button in the Pages Add Container screen
		                    		click ( "//*[@id='open_modal-new_container_form']" ).
		                    		pause ( 4000 ).
		                    		//Wait for the Add Panel is visible in the Pages Add Container screen
		                    		waitForElementVisible ( "//*[@id='my_modal-new_container_form']/div", 4000, false, function ( checkAddPanel ) {
		                        	if ( checkAddPanel.value == true ) {
		                    				pagesAddContainer.useXpath ( ).pause ( 4000 ).
		                    				//Click on the Add Panel in the Pages Add Container pop-up screen
		                    				click ( "//*[@id='my_modal-new_container_form']/div" ).
		                    				pause ( 4000 ).

		                    				//Wait for the Caption is visible in the Pages Add Container pop-up screen
		                    				waitForElementVisible ( "//*[@id='my_modal-new_container_form']/div/div[1]/div[1]/p", 4000, false, function ( checkCaption ) {
		                        			if ( checkCaption.value == true ) {
		                    						pagesAddContainer.useXpath ( ).pause ( 4000 ).
		                    						//Get the value in the caption in the Pages Add Container pop-up screen
		                    						getText ( "//*[@id='my_modal-new_container_form']/div/div[1]/div[1]/p", function ( getCaption ) {
		                        						if ( getCaption.value == "ADD NEW CONTAINER" ) {
		                        							pagesAddContainer.useXpath ( ).pause ( 4000 ).	
		                        							//Wait for the Text input field is visible in the Pages Add Container pop-up screen 	                            								
		                        							waitForElementVisible ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input", 4000, false, function ( checkTextInput ) {
		                        								if ( checkTextInput.value == true ) {
		                        									pagesAddContainer.useXpath ( ).pause ( 4000 ).
		                        									//Clear the data in the Text input field in the Pages Add Container pop-up screen 
		                        									clearValue ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input" ).
		                        									pause ( 4000 ).
		                        									//Enter the data in the Text input field in the Pages Add Container pop-up screen
		                        									setValue ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input", splitName[ getSplitedData ] ).
		                        									pause ( 4000 ).
		                        									//Wait for the Radio option is visible in the Pages Add Container pop-up screen
		                        									waitForElementVisible ( "//div/div[@class='integrations-select']/span[contains(.,'"+splitOption[ getSplitedData ]+"')]", 4000, false, function ( checkoptions ) {
		                        										if ( checkoptions.value == true ) {		                            											
		                        											pagesAddContainer.useXpath ( ).pause ( 4000 ).
		                        											//Click on the Radio option in the Pages Add Container pop-up screen
		                        											click ( "//div/div[@class='integrations-select']/span[contains(.,'"+splitOption[ getSplitedData ]+"')]" ).
		                        											pause ( 4000 ).		
		                        											//Get the location for the save button in the Pages Add Container pop-up screen                            												
		                        											getLocationInView ( "//div[4]/button[contains(.,'ADD')]" ).
		                        											pause ( 4000 ).
		                        											//Wait for the the save button is visible in the Pages Add Container pop-up screen   
		                        											waitForElementVisible ( "//div[4]/button[contains(.,'ADD')]", 4000, false, function ( checkSaveBtn ) {
		                        												if ( checkSaveBtn.value == true ) {
		                        													pagesAddContainer.useXpath ( ).pause ( 4000 ).		
		                        													//Click on the save button in the Pages Add Container pop-up screen                            														
		                        													click ( "//div[4]/button[contains(.,'ADD')]" ).
		                        													pause ( 4000 ).		  
		                        													//Get the location for the created container in the Pages Add Container listing page                           														
		                        													getLocationInView ( "//div[2]/div[contains(.,'"+splitName[ getSplitedData ]+"')]/div/div[1]/div[1]/div[2]" ).
		                        													pause ( 4000 ).
		                        													//Wait for the created container is visible in the Pages Add Container listing page   
		                        													waitForElementVisible ( "//div[2]/div[contains(.,'"+splitName[ getSplitedData ]+"')]/div/div[1]/div[1]/div[2]", 4000, false, function ( chechAddedContainer ) {
		                          													if ( chechAddedContainer.value == true ) {
		                            													//Write the Excel to FAIL Result and Reason
		                          														pagesAddContainer.writeToExcelPass ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4 );
		                          													}
		                          													else {
		                            													//Write the Excel to FAIL Result and Reason
												                            			this.verify.fail ( chechAddedContainer.value, true, 'Timeout issue or fail due to the saved container is not visible' );
												                            			pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+chechAddedContainer.value+". ExpectedResult: the saved container should be visible' )" );
		                           													}
		                        													} );
		                        												}
		                        												else {
                                                      pagesAddContainer.useXpath ( ).pause ( 4000 ).
                                                      //Verify the Cancel button is visible in the container pop-up form
                                                      verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                                      pause ( 4000 ).
                                                      //Click on the Cancel button in the container pop-up form
                                                      click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
		                        													//Write the Excel to FAIL Result and Reason
		                        													this.verify.fail ( checkSaveBtn.value, true, 'Timeout issue or fail due to the Pages Save Button is not visible' );
		                        													pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkSaveBtn.value+". ExpectedResult: the Pages Save button should be visible' )" );
		                         												}
		                        											} );
		                          									}
		                          									else {
                                                  pagesAddContainer.useXpath ( ).pause ( 4000 ).
                                                  //Verify the Cancel button is visible in the container pop-up form
                                                  verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                                  pause ( 4000 ).
                                                  //Click on the Cancel button in the container pop-up form
                                                  click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
		                          										//Write the Excel to FAIL Result and Reason
		                        											this.verify.fail ( checkoptions.value, true, 'Timeout issue or fail due to the Pages Radio Button is not visible' );
		                        											pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkoptions.value+". ExpectedResult: the Pages Radio button should be visible' )" );
		                          									}
		                          								} );
		                        								}
		                        								else {
                                              pagesAddContainer.useXpath ( ).pause ( 4000 ).
                                              //Verify the Cancel button is visible in the container pop-up form
                                              verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                              pause ( 4000 ).
                                              //Click on the Cancel button in the container pop-up form
                                              click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
		                        									//Write the Excel to FAIL Result and Reason
		                        									this.verify.fail ( checkTextInput.value, true, 'Timeout issue or fail due to the Pages Text field is not visible' );
		                        									pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkTextInput.value+". ExpectedResult: the Pages Text field should be visible' )" );
		                         								}
		                        							} );
		                        						}
		                        						else {
                                          pagesAddContainer.useXpath ( ).pause ( 4000 ).
                                          //Verify the Cancel button is visible in the container pop-up form
                                          verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                          pause ( 4000 ).
                                          //Click on the Cancel button in the container pop-up form
                                          click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
		                        							//Write the Excel to FAIL Result and Reason
		                        							this.verify.fail ( getCaption.value, true, 'Timeout issue or fail due to the Pages Caption Label is unable to get' );
		                        							pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+getCaption.value+". ExpectedResult: the Pages Caption Label should unable to get' )" );
		                        						}
		                        					} );
		                        				}
		                        				else {
                                      pagesAddContainer.useXpath ( ).pause ( 4000 ).
                                      //Verify the Cancel button is visible in the container pop-up form
                                      verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                      pause ( 4000 ).
                                      //Click on the Cancel button in the container pop-up form
                                      click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
		                        					//Write the Excel to FAIL Result and Reason
		                        					this.verify.fail ( checkCaption.value, true, 'Timeout issue or fail due to the Pages Caption Label is not visible' );
		                        					pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkCaption.value+". ExpectedResult: the Pages Caption Label should be visible' )" );
		                        				}
		                        			} );
		                        		}
		                        		else {
		                        			//Write the Excel to FAIL Result and Reason
		                        			this.verify.fail ( checkAddPanel.value, true, 'Timeout issue or fail due to the Pages Add Panel is not visible' );
		                        			pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkAddPanel.value+". ExpectedResult: the Pages Add Panel should be visible' )" );
		                         		}
		                        	} );
		                        }
		                        else {
		                        	//Write the Excel to FAIL Result and Reason
		                        	this.verify.fail ( checkAddContainerBtn.value, true, 'Timeout issue or fail due to the Pages Add Container Button is not visible' );
		                        	pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkAddContainerBtn.value+". ExpectedResult: the Pages Add Container Button should be visible' )" );
		                        }
		                      } );
		                    } 		                    
	                    } 	                                     
                    }
                    else {
                      //Write the Excel to FAIL Result and Reason
                      this.verify.fail ( checkEditBtn.value, true, 'Timeout issue or fail due to the Pages Edit Button is not visible' );
                      pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkEditBtn.value+". ExpectedResult: the Pages Edit Button should be visible' )" );
                    }
                  } );                    
                }
              	else {
                  //Write the Excel to FAIL Result and Reason
                  this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
                  pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
                }
              } );            
	          }
	          else {       
	         	  //Write the Excel to FAIL Result and Reason    
	            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
	            pagesAddContainer.writeToExcelFail ( 'pages.xlsx', 'PagesAddContainer', excelRow, 4, 5, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
	          }
        	} );
      	}
			}
		},
	'PagesRename': function ( pagesRename ) {
    var excel = pagesRename.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesRename.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesRename.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                pagesRename.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( pagesRename.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//div[contains(.,'"+excel.A[ excelColumn ]+"')]/span/toggle-menu/span", 4000, false, function ( checkVerticalBtn ) {
                  if ( checkVerticalBtn.value == true ) {
                    pagesRename.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on pages index page
                    click ( "//div[contains(.,'"+excel.A[ excelColumn ]+"')]/span/toggle-menu/span" ).
                    pause ( 4000 ). 
                    waitForElementVisible ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::ng-include/*//li/i", 4000, false, function ( checkRenameBtn ) {
                    	if ( checkRenameBtn.value == true ) {
                    		pagesRename.useXpath ( ).pause ( 4000 ).
                    		//Click on the rename button in the pages listing page
                    		click ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::ng-include/*//li/i" ).		                    
		                    pause ( 4000 ).
		                    //Wait for the rename field is visible in the pages listing page
		                    waitForElementVisible ( "//*/span[@class='page-name-label']/renameable-input/input", 4000, false, function ( checkRenameField ) {
		                    	if ( checkRenameField.value == true ) {
		                    		pagesRename.useXpath ( ).pause ( 4000 ).
		                    		//Clear the rename field value in the pages listing page
		                    		clearValue ( "//*/span[@class='page-name-label']/renameable-input/input" ).
		                    		pause ( 3000 ).
		                    		//Enter the value in the rename field on the pages listing page
		                    		setValue ( "//*/span[@class='page-name-label']/renameable-input/input", excel.B[ excelColumn ] ).
		                    		pause ( 4000 ). 
		                    		//Click on the label in the pages listing page
		                    		click ( "//div/ng-include[1]/div/div/span" ).
		                    		pause ( 4000 ).
		                    		//Wait for the search field is visible in the pages listing page
		                    		waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchfield ) {
              								if ( checkSearchfield.value == true ) {
	                								pagesRename.useXpath ( ).pause ( 4000 ).
	                								//Click on the search field in the pages index page
									                click ( "//*[@id='search_input']" ).
									                pause ( 2000 ).
									                //Clear the data in the search field in the pages index page
									                clearValue ( "//*[@id='search_input']" ).
									                pause ( 2000 ).
									                //Enter the data in the search field in the pages index page
									                setValue ( "//*[@id='search_input']", excel.B[ excelColumn ] ).
									                useCss ( ).pause ( 2000 ).
									                //Press return key
									                keys ( pagesRename.Keys.ENTER ).
									                useXpath ( ).pause ( 4000 ). 
									                //Wait for the searched result is visible in the pages listing page   
	                								waitForElementVisible ( "//a/span[@class='page-name-label ng-binding ng-scope']", 4000, false, function ( checkSearchResult ) {
	                									if ( checkSearchResult.value == true ) {
			                								pagesRename.useXpath ( ).pause ( 4000 ).
			                								//Get the pages Name in the searched result on the pages listing page
			                								getText ( "//a/span[@class='page-name-label ng-binding ng-scope']", function ( checkResultLabel ) {
			                									var resultLabel = excel.B[excelColumn] 
			                									if ( checkResultLabel.value == resultLabel.toUpperCase() ) {
																					//Write the Excel to FAIL Result and Reason
	            														pagesRename.writeToExcelPass ( 'pages.xlsx', 'PagesRename', excelRow, 3 );
	            													}
	            													else {
	              													//Write the Excel to FAIL Result and Reason
				                            			this.verify.fail ( checkResultLabel.value, true, 'Pages actual Renamed Data is not visible' );
				                            			pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkResultLabel.value+". ExpectedResult: '"+excel.B[excelColumn]+"'" );
	             													}
				                							} );
	                									}
	                									else {
	                										//Write the Excel to FAIL Result and Reason
	                    								this.verify.fail ( checkSearchResult.value, true, 'Timeout issue or fail due to the Pages Search Result is not visible' );
	                    								pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkSearchResult.value+". ExpectedResult: the Pages Search Result should be visible' )" );
	                      						}
	                								} );
	                							}
	                							else {
	                								//Write the Excel to FAIL Result and Reason
	                    						this.verify.fail ( checkSearchfield.value, true, 'Timeout issue or fail due to the Pages Search field is not displayed' );
	                    						pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkSearchfield.value+". ExpectedResult: the Pages Search field should be displayed' )" );
	                      				}
	                						} );
			                    	}
			                    	else {
			                    		//Write the Excel to FAIL Result and Reason
	                    				this.verify.fail ( checkRenameField.value, true, 'Timeout issue or fail due to the Pages Rename Field is not visible' );
	                    				pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkRenameField.value+". ExpectedResult: 'true'( Timeout issue or fail due to the Pages Rename Field is not visible' )" );
			                    	}
			                    } ); 		                    
			                   
		                    }
		                    else {
		                    	//Write the Excel to FAIL Result and Reason
	                    		this.verify.fail ( checkRenameBtn.value, true, 'Timeout issue or fail due to the Pages targeting tab is not visible' );
	                    		pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkRenameBtn.value+". ExpectedResult: the Pages targeting tab should be visible' )" );
	                      }	
	                    } );                                     
	                  }
	                  else {
	                    //Write the Excel to FAIL Result and Reason
	                    this.verify.fail ( checkVerticalBtn.value, true, 'Timeout issue or fail due to the Pages Edit is not visible' );
	                    pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkVerticalBtn.value+". ExpectedResult: the Pages Edit should be visible' )" );
	                  }
	                } );                    
	              }
	            	else {
	                //Write the Excel to FAIL Result and Reason
	                this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
	                pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
	              }
	            } );            
	          }
	          else {       
	         	  //Write the Excel to FAIL Result and Reason    
	            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
	            pagesRename.writeToExcelFail ( 'pages.xlsx', 'PagesRename', excelRow, 3, 4, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
	          }
	      	} );
	    	}
			}
		},
'PagesContainerRename': function ( pagesContainerRename ) {
  var excel = pagesContainerRename.globals.excelCol;
  if ( excel.A.length > 0 ) {
  	//loop the 'n' number of excel input
  	for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
    	excelRow++;
    	pagesContainerRename.useXpath ( ).pause ( 4000 ).
    	//Wait for the pages menu is visible in the pages
   		waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
      	if ( checkPagesMenu.value == true ) {
        	pagesContainerRename.useXpath ( ).pause ( 4000 ).
        	//Click on the pages menu in the pages
        	click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
       		pause ( 4000 ).            
        	//Wait for search field is visible in the pages index page
       		waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
          	if ( checkSearchBtn.value == true ) {
            	pagesContainerRename.useXpath ( ).pause ( 4000 ).
            	//Click on the search field in the pages index page
              click ( "//*[@id='search_input']" ).
              pause ( 2000 ).
              //Clear the data in the search field in the pages index page
              clearValue ( "//*[@id='search_input']" ).
              pause ( 2000 ).
              //Enter the data in the search field in the pages index page
              setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
              useCss ( ).pause ( 2000 ).
              //Press return key
              keys ( pagesContainerRename.Keys.ENTER ).
              useXpath ( ).pause ( 4000 ).  
              //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
							waitForElementVisible ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
						  	if ( checkEditBtn.value == true ) {
						  		pagesContainerRename.useXpath ( ).pause ( 4000 ). 
						  		//Click on the Edit button in the pages
						  		click ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
						  		pause ( 4000 ).
						  		//Click on the Page Structure tab in the pages container listing page   
						  		click ( "//div/ng-view/div/div[2]/div[1]/a[1]/div" ).            
						  		pause ( 4000 ).
						  		//Get the Location for the container in the listing page
						  		getLocationInView ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]" ).
						  		pause ( 4000 ).
				  				//Wait for the container is visible in the listing page
				  				waitForElementVisible ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]", 4000, false, function ( checkContainerName ) {
				  					if ( checkContainerName.value == true ) {
				  						pagesContainerRename.useXpath ( ).pause ( 4000 ). 
		                	//Wait for the Delete button is visible in the vertical ellipsis option on pages index page
		                	waitForElementVisible ( "//div[contains(.,'"+excel.B[ excelColumn ]+"')]/span/toggle-menu/span", 4000, false, function ( checkVerticalBtn ) {
		                 	  if ( checkVerticalBtn.value == true ) {
		                    	pagesContainerRename.useXpath ( ).pause ( 4000 ).
		                    	//Click on the the Delete button in the vertical ellipsis option on pages index page
		                    	click ( "//div[contains(.,'"+excel.B[ excelColumn ]+"')]/span/toggle-menu/span" ).
		                    	pause ( 4000 ). 
		                    	//Wait for the Rename option is visible in the pages container listing page
		                    	waitForElementVisible ( "//span[contains(.,'"+excel.B[ excelColumn ]+"')]/descendant::ng-include/*//li/i", 4000, false, function ( checkRenameBtn ) {
		                    		if ( checkRenameBtn.value == true ) {
		                    			pagesContainerRename.useXpath ( ).pause ( 4000 ).	 
		                    			//Click on the Rename option in the pages container listing page                   			
		                    			click ( "//span[contains(.,'"+excel.B[ excelColumn ]+"')]/descendant::ng-include/*//li/i" ).		                    
				                   	  pause ( 4000 ).
				                   	  //Wait for the Reame field is vsible in the container listing page
				                   		waitForElementVisible ( "//div[@class='container-title ng-binding ng-hide']/following-sibling::renameable-input/input", 4000, false, function ( checkRenameField ) {
				                    		if ( checkRenameField.value == true ) {
  			                    			pagesContainerRename.useXpath ( ).pause ( 4000 ).
  				                    			//Clear the data in the Container Name field in the Pages container listing page
  				                    			clearValue ( "//div[@class='container-title ng-binding ng-hide']/following-sibling::renameable-input/input" ).
  				                    			pause ( 3000 ).
  				                    			//Enter the data in the Container Name field in the Pages container listing page
  				                    			setValue ( "//div[@class='container-title ng-binding ng-hide']/following-sibling::renameable-input/input", excel.C[ excelColumn ] ).
  				                    			pause ( 4000 ). 
  				                    			//Click on the rename field in the pages container listing page
  				                    			click ( "//div[@class='container-title ng-binding ng-hide']/following-sibling::renameable-input/input" ).
  				                    			pause ( 4000 ).
  				                    			//Click on the Toggle button in the pages container listing page
  				                    			click ( "//div[@class='container-details']" ).
  				                    			pause ( 4000 ).
  				                    			//Get the Location for the container in the listing page
  				                    			getLocationInView ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.C[ excelColumn ]+"')]" ).
  		              								pause ( 4000 ).	
  	                								//Wait for the Renamed container is visible in the listing page				                								
  	                								waitForElementVisible ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.C[ excelColumn ]+"')]", 4000, false, function ( checkRenamedContainer ) {
  	                									if ( checkRenamedContainer.value == true ) {							                									
  																			//Write the Excel to FAIL Result and Reason
  	            												pagesContainerRename.writeToExcelPass ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4 );
  	            											}
		            											else {
		              											//Write the Excel to FAIL Result and Reason
					                            	this.verify.fail ( checkResultLabel.value, true, 'Pages actual Renamed Data is not visible' );
					                            	pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkRenamedContainer.value+"'. ExpectedResult: '"+excel.C[ excelColumn ]+"'" );
		             											}
					                					} );     													                														                							
						                    	}
						                    	else {
						                    		//Write the Excel to FAIL Result and Reason
				                    				this.verify.fail ( checkRenameField.value, true, 'Timeout issue or fail due to the Pages Rename Field is not visible' );
				                    				pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkRenameField.value+". ExpectedResult: the Pages Rename Field should be visible' )" );
						                    	}
						                    } );                
					                    }
					                    else {
					                    	//Write the Excel to FAIL Result and Reason
				                    		this.verify.fail ( checkRenameBtn.value, true, 'Timeout issue or fail due to the Pages targeting tab is not visible' );
				                    		pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkRenameBtn.value+". ExpectedResult: the Pages targeting tab should be visible' )" );
				                      }	
				                    } );                                     
				                  }
				                  else {
				                    //Write the Excel to FAIL Result and Reason
				                    this.verify.fail ( checkVerticalBtn.value, true, 'Timeout issue or fail due to the Pages Eclipsis is not visible' );
				                    pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkVerticalBtn.value+". ExpectedResult: the Pages Vertical Eclipsis should be visible' )" );
				                  }
				                } );
			                } 
			                else {
			                	//Write the Excel to FAIL Result and Reason
                				this.verify.fail ( checkContainerName.value, true, 'Timeout issue or fail due to the Pages Container Name is not visible' );
               					pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkContainerName.value+". ExpectedResult: the Pages Container Name should be visible' )" );	              		
			                }
			              } );											
		              }
		              else {
		              	//Write the Excel to FAIL Result and Reason
		                this.verify.fail ( checkEditBtn.value, true, 'Timeout issue or fail due to the Pages Edit is not visible' );
		                pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkEditBtn.value+". ExpectedResult: the Pages Edit should be visible' )" );
		              } 
		            } );                  
              }
            	else {
                //Write the Excel to FAIL Result and Reason
                this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
                pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
              }
            } );            
          }
          else {       
         	  //Write the Excel to FAIL Result and Reason    
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
            pagesContainerRename.writeToExcelFail ( 'pages.xlsx', 'PagesContainerRename', excelRow, 4, 5, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
          }
      	} );
    	}
		}
	},

	'PagesContainerEdit': function ( pagesContainerEdit ) {
    var excel = pagesContainerEdit.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesContainerEdit.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesContainerEdit.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                pagesContainerEdit.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( pagesContainerEdit.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
                  if ( checkEditBtn.value == true ) {
                    pagesContainerEdit.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on pages index page
                    click ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                    pause ( 4000 ). 
                    //Wait for the Pages Structure tab is visible in the pages details page
                    waitForElementVisible ( "//a[1]/div[contains(.,'page structure')]", 4000, false, function ( checkStructureTab ) {
                    	if ( checkStructureTab.value == true ) {
                    		pagesContainerEdit.useXpath ( ).pause ( 4000 ).
                    		//Click on the Page Structure tab in the pages details page
                    		click ( "//a[1]/div[contains(.,'page structure')]" ).		                    
		                    pause ( 4000 ) 		           
                 				pagesContainerEdit.useXpath ( ).pause ( 4000 ).
												//Get the Location for the container in the listing page
                        getLocationInView ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]" ).
                        pause ( 4000 ).   
                        //Wait for the container name field is visible in the pages container listing page                   
                       	waitForElementVisible ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]", 4000, false, function ( checkContainerName ) {
                         	if ( checkContainerName.value == true ) {                                                                                                
	                          pagesContainerEdit.useXpath ( ).pause ( 4000 ). 
	                          //Click on the container name in the pages container listing page                           
	                          click ( "//div[2]/div/div/div[1]/div[1]/div[2][contains(.,'"+excel.B[ excelColumn ]+"')]" ).
	                          pause ( 4000 )
		                        var splitContainer = [ ];   
		                        //Splitting the data and stored in the array                                                          
		                        splitContainer = excel.D[ excelColumn ].split(':');                         
		                        for ( let getSplitedData = 0; getSplitedData<splitContainer.length; getSplitedData++ ) {
		                          if ( ( excel.E[ excelColumn ] != "FAIL" ) && ( excel.F[ excelColumn ] == null ) ) {
		                            pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                            //Wait for description field is visible in the pages                              
		                            waitForElementVisible ( "//div[@class='description-input']/input", 9000, false, function ( checkDescription ) {
		                              if ( checkDescription.value == true ) {                                   
		                                pagesContainerEdit.useXpath ( ).pause ( 4000 ).    
		                                //Clear the data in the description field in the pages container edit page 
		                                clearValue ( "//div[@class='description-input']/input" ).
		                                pause ( 4000 ).
		                                //Enter the data in the description field in the pages container edit page 
		                                setValue ( "//div[@class='description-input']/input", excel.C[ excelColumn ] ).
		                                pause ( 4000 ).                          
		                                //Wait for Edit button is visible in the pages container listing page                         
		                                waitForElementVisible ( "//*/i[@class='edit-list-icon']", 4000, false, function ( checkEditIcon ) {
		                                  if ( checkEditIcon.value == true ) {
		                                    pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                    //Click on the Edit button in the pages container listing page
		                                    click ( "//*/i[@class='edit-list-icon']" ).
		                                    pause ( 4000 ).
		                                    //Wait for the media gallery is visible in the page
		                                    waitForElementVisible ( "//div[1]/div/div[3]/div[1]/div[2]/div/media-gallery/div/div/div[1]/span", 9000, false, function ( checkCaption ) {
		                                      if ( checkCaption.value == true ) {
		                                        pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                        //Get the text value in the media gallery list page
		                                        getText ( "//div[1]/div/div[3]/div[1]/div[2]/div/media-gallery/div/div/div[1]/span", function ( captionText ) {
		                                          if ( captionText.value == "Media Gallery" ) {
		                                            pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                            //Wait for the toggle menu is visible in the media gallery page
		                                            waitForElementVisible ( "//div[1]/div/div[3]/div[1]/div[2]//media-gallery//div[2]/div[1]/div[1]/toggle-menu/div[1]/i", 9000, false, function ( checkCaratIcon ) {
		                                              if ( checkCaratIcon.value == true ) {
		                                                pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                //Click on the toggle menu in the media gallery page
		                                                click ( "//div[1]/div/div[3]/div[1]/div[2]//media-gallery//div[2]/div[1]/div[1]/toggle-menu/div[1]/i" ).
		                                                pause ( 4000 ).
		                                                //Wait for the dropdown option is visible in the media-gallery page
		                                                waitForElementVisible ( "//div/div[1]/div/div[3]//ul/li[contains(.,'"+excel.E[ excelColumn ]+"')]", 9000, false, function ( checkdrpdwn ) {
		                                                  if ( checkdrpdwn.value == true ) {
		                                                    pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                    //Click on the dropdown option in the media-gallery page
		                                                    click ( "//div/div[1]/div/div[3]//ul/li[contains(.,'"+excel.E[ excelColumn ]+"')]" ).
		                                                    pause ( 6000 ).
		                                                    //Verify the Search categories input field in the pages container edit page
		                                                    waitForElementVisible ( "(//input[@id='search_input'])[1]", 9000, false, function ( checksearchField ) {
		                                                      if ( checksearchField.value == true ) {
		                                                        pagesContainerEdit.useXpath ( ).pause ( 4000 ).                                                
		                                                        //Clear the data in the search categories input field in the edit container page
		                                                        clearValue ( "(//input[@id='search_input'])[1]" ).                                    
		                                                        pause ( 4000 ).
		                                                        //Enter the data in the search categories input field in the edit container page
		                                                        setValue ( "(//input[@id='search_input'])[1]", splitContainer[ getSplitedData ] ).                                                      
		                                                        useCss ( ).pause ( 4000 ).       
		                                                        //Press return key           
		                                                        keys ( pagesContainerEdit.Keys.ENTER ).
		                                                        useXpath ( ).pause ( 4000 ).                                
		                                                        //Get location for the categories listed in the dropdown
		                                                        //span[contains(.,'"+splitContainer[ getSplitedData ]+"')]/ancestor::div/media-gallery/div/div/div[2]/div[2]/div[2]/div/div/div/div[2]
		                                                        getLocationInView ( "//div/media-gallery/div/div/div[2]/div[2]//div[2]/following-sibling::span[contains(.,'"+splitContainer[ getSplitedData ]+"')]" ).
		                                                        pause ( 4000 ).
		                                                        moveToElement ( "//div/media-gallery/div/div/div[2]/div[2]//div[2]", 10, 10 ).
		                                                        pause ( 4000 ).
		                                                        waitForElementVisible ( "//media-gallery/*//span[text()='SELECT']", 9000, false, function ( checkSelectBtn ) {
		                                                          if ( checkSelectBtn.value == true ) {
		                                                            pagesContainerEdit.useXpath ( ).pause ( 4000 ).                                                          
		                                                            click ( "//media-gallery/*//span[text()='SELECT']" ).
		                                                            pause ( 4000 ).
		                                                            waitForElementVisible ( "//media-gallery//*/i[@class='image_select_icon']", 9000, false, function ( checkTickMark ) {
		                                                              if ( checkTickMark.value == true ) {
		                                                              pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                                //Wait for the categories list dropdown option is visible in the
		                                                                waitForElementVisible ( "//media-gallery/div/div/div[3]/div[2]/button[contains(.,'ADD')]", 4000, false, function ( checkSaveBtn ) {
		                                                                  if ( checkSaveBtn.value == true ) {
		                                                                    pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                                    verify.visible ( "//media-gallery/div/div/div[3]/div[2]/button[contains(.,'ADD')]" ).
		                                                                    pause ( 4000 ).
		                                                                    //Click on the categories listed dropdown option in the edit page
		                                                                    click ( "//media-gallery/div/div/div[3]/div[2]/button[contains(.,'ADD')]" ).
		                                                                    pause ( 4000 ). 
		                                                                    waitForElementNotPresent ( "//media-gallery/div/div/div[3]/div[2]/button[contains(.,'ADD')]", 9000, false, function ( checkSaveAvail ) {
			                                                                    console.log("checkSaveAvail",checkSaveAvail)
			                                                                    if ( checkSaveAvail.value.length == 0) {
				                                                                    pagesContainerEdit.useXpath ( ).pause ( 4000 ).
				                                                                    waitForElementVisible ( "//div//content-carousel//ng-include/div[1]/div", 9000, false, function ( checkAddedItem ) {   
				                                                                      if ( checkAddedItem.value == true ) { 
				                                                                        //Write the Excel to PASS Result and Reason
				                                                                        pagesContainerEdit.writeToExcelPass ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6 );
				                                                                      }
				                                                                      else {
				                                                                        //Write the Excel to FAIL Result and Reason
				                                                                        this.verify.fail ( checkAddedItem.value, 'true', 'Added Item is not displayed in the Container listing page' );
				                                                                        pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Added Item is not displayed in the Container listing page" );
				                                                                      }
				                                                                    } );
			                                                                    }
			                                                                    else {
			                                                                    	//Write the Excel to FAIL Result and Reason
				                                                                    this.verify.fail ( checkSaveAvail.value, 'true', 'Save Button is not working in the Container popup window' );
				                                                                    pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Save Button is not working in the Container popup window" );
				                                                                  }
		                                                                    } );
		                                                                  }
		                                                                  else {
		                                                                    pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                                    //Click on the Cancel button in the pages container edit page
		                                                                    click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                                                    pause ( 4000 )
		                                                                    //Write the Excel to FAIL Result and Reason
		                                                                    this.verify.fail ( checkSaveBtn.value, 'true', 'Save Button is still existing Active' );
		                                                                    pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Save Button is still In-Active" );
		                                                                  }
		                                                                } );
		                                                              }
		                                                              else {
		                                                                pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                                //Click on the Cancel button in the pages container edit page
		                                                                click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                                                pause ( 4000 )
		                                                                //Write the Excel to FAIL Result and Reason
		                                                                this.verify.fail ( checkTickMark.value, 'true', 'Tick mark is not visible in the selected artifact' );
		                                                                pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Tick mark is not visible in the selected artifact" );
		                                                              }
		                                                            } );
		                                                          }
		                                                          else {
		                                                            pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                            //Click on the Cancel button in the pages container edit page
		                                                            click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                                            pause ( 4000 )
		                                                            //Write the Excel to FAIL Result and Reason
		                                                            this.verify.fail ( checkSelectBtn.value, 'true', 'Select button is not visible in the selected artifact' );
		                                                            pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Select button is not visible in the selected artifact" );
		                                                          }
		                                                        } );
		                                                      }
		                                                      else {
		                                                        pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                        //Click on the Cancel button in the pages container edit page
		                                                        click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                                        pause ( 4000 )
		                                                        //Write the Excel to FAIL Result and Reason
		                                                        this.verify.fail ( checksearchField.value, 'true', 'Search Field is not visible in the media gallery pop-up' );
		                                                        pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Search Field is not visible in the media gallery pop-up" );
		                                                      }
		                                                    } );
		                                                  }
		                                                  else {
		                                                    pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                    //Click on the Cancel button in the pages container edit page
		                                                    click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                                    pause ( 4000 )
		                                                    //Write the Excel to FAIL Result and Reason
		                                                    this.verify.fail ( checkdrpdwn.value, 'true', 'Dropdown option is not visible in the media gallery pop-up' );
		                                                    pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Dropdown option is not visible in the media gallery pop-up" );
		                                                  }
		                                                } );
		                                              }
		                                              else {
		                                                pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                                //Click on the Cancel button in the pages container edit page
		                                                click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                                pause ( 4000 )
		                                                //Write the Excel to FAIL Result and Reason
		                                                this.verify.fail ( checkCaratIcon.value, 'true', 'Carat icon is not visible in the media gallery pop-up' );
		                                                pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Carat icon is not visible in the media gallery pop-up" );
		                                              }
		                                            } );
		                                          }
		                                          else {
		                                            pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                            //Click on the Cancel button in the pages container edit page
		                                            click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                            pause ( 4000 )
		                                            //Write the Excel to FAIL Result and Reason
		                                            this.verify.fail ( captionText.value, 'true', 'Carat icon is not visible in the media gallery pop-up' );
		                                            pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Caption Text is not visible in the media gallery pop-up" );
		                                          }          
		                                        } );
		                                      }
		                                      else {
		                                        pagesContainerEdit.useXpath ( ).pause ( 4000 ).
		                                        //Click on the Cancel button in the pages container edit page
		                                        click ( "//ng-include[2]/div[2]/div[2]//media-gallery//div[3]/div[2]/button[2]" ).
		                                        pause ( 4000 )
		                                        //Write the Excel to FAIL Result and Reason
		                                        this.verify.fail ( checkCaption.value, 'true', 'Caption label is not visible in the media gallery pop-up' );
		                                        pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Caption label is not visible in the media gallery pop-up" );
		                                      } 
		                                    } );  
		                                  }
		                                  else {
		                                    //Write the Excel to FAIL Result and Reason
		                                    this.verify.fail ( checkEditIcon.value, true, 'Timeout issue or fail due to the Container Edit screen Edit_Icon is not visible' );
		                                    pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Container Edit screen, Edit_Icon is not displayed" );
		                                  }
		                                } );
		                              }
		                              else {
		                                //Write the Excel to FAIL Result and Reason
		                                this.verify.fail ( checkDescription.value, true, 'Timeout issue or fail due to the Container Edit screen Description is not visible' );
		                                pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Container Edit screen, Description is not displayed" );
		                              } 
		                            } );                                                               
		                          }                           
		                        } 
													}
													else {
													  //Write the Excel to FAIL Result and Reason
                            this.verify.fail ( checkContainerName.value, true, 'Timeout issue or fail due to the Container Name is not visible' );
                            pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "Container Name is not displayed" );                        
													}
												} );
	                    }
	                    else {
	                    	//Write the Excel to FAIL Result and Reason
                    		this.verify.fail ( checkTargatTab.value, true, 'Timeout issue or fail due to the Pages targeting tab is not visible' );
                    		pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "ActualResult: '"+checkTargatTab.value+". ExpectedResult: the Pages targeting tab should be visible' )" );
                      }	
                    } );                                     
                  }
                  else {
                    //Write the Excel to FAIL Result and Reason
                    this.verify.fail ( checkEditBtn.value, true, 'Timeout issue or fail due to the Pages Edit is not visible' );
                    pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "ActualResult: '"+checkEditBtn.value+". ExpectedResult: the Pages Edit should be visible' )" );
                  }
                } );                    
              }
            	else {
                //Write the Excel to FAIL Result and Reason
                this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
                pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
              }
            } );            
          }
          else {       
         	  //Write the Excel to FAIL Result and Reason    
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
            pagesContainerEdit.writeToExcelFail ( 'pages.xlsx', 'PagesContainerEdit', excelRow, 6, 7, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
          }
      	} );
    	}
		}
	},

	'PagesEdit': function ( pagesEdit ) {
    var excel = pagesEdit.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesEdit.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesEdit.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                pagesEdit.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( pagesEdit.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
                  if ( checkEditBtn.value == true ) {
                    pagesEdit.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on pages index page
                    click ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                    pause ( 4000 ). 
                    //Wait for the page targeting tab in the pages detail page
                    waitForElementVisible ( "//a[2]/div[contains(.,'page targeting')]", 4000, false, function ( checkTargatTab ) {
                    	if ( checkTargatTab.value == true ) {
                    		pagesEdit.useXpath ( ).pause ( 4000 ).
                    		//Click on the page targeting tab in the pages detail page
                    		click ( "//a[2]/div[contains(.,'page targeting')]" ).		                    
		                    pause ( 4000 ) 
		                    var splitAllowedIn = [ ];   
		                    var splitRestrictedIn = [ ]; 
		                    var splitAllowedName = [ ];   
						            var splitRestrictName = [ ];                                    
		                    splitAllowedIn = excel.B[ excelColumn ].split(':'); 
		                    splitRestrictedIn = excel.C[ excelColumn ].split(':'); 
		                    //Loop n number of splitted inputs
		                    for ( let getSplitedData = 0; getSplitedData<splitAllowedIn.length; getSplitedData++ ) {
		                    	if ( ( excel.D[ excelColumn ] != "FAIL" ) && ( excel.E[ excelColumn ] == null ) ) {
		                    		pagesEdit.useXpath ( ).pause ( 4000 ). 
		                    		//Wait for the allowed in field is visible in the pages targeting page                   		
		                    		waitForElementVisible ( "//ng-include[3]/div/div[1]/region-chip-input/div/input", 4000, false, function ( checkAllowedIn ) {
		                    			if ( checkAllowedIn.value == true ) {		                    						                    				                                     
						                    splitAllowedName = splitAllowedIn[ getSplitedData ].split('('); 
						                    splitRestrictName = splitRestrictedIn[ getSplitedData ].split('('); 
		                    				pagesEdit.useXpath ( ).pause ( 4000 ).
		                    				//Enter the value in the allowed in field is visible in the pages targeting page
		                    				setValue("//ng-include[3]/div/div[1]/region-chip-input/div/input",splitAllowedName[0]).		                    				
		                    				pause ( 4000 ).  	
		                    				//Wait for the listed in the dropdown option in the pages targeting page	                    			
		                    				waitForElementVisible ( "//div/div[1]/region-chip-input/div/div/ul/li[contains(.,'"+splitAllowedIn[ getSplitedData ]+"')]", 4000, false ).
		                    				pause ( 3000 ).
		                    				//Click on the data listed in the dropdown option in the pages targeting page
		                    				click ( "//div/div[1]/region-chip-input/div/div/ul/li[contains(.,'"+splitAllowedIn[ getSplitedData ]+"')]").
		                    				pause ( 4000 ). 
		                    				//Wait for the restricted in field is visible in the pages targeting page                				
		                    				waitForElementVisible ( "//ng-include[3]/div/div[2]/region-chip-input/div/input", 4000, false, function ( checkRestrictedIn ) {
		                    					if ( checkRestrictedIn.value == true ) {
		                    						pagesEdit.useXpath ( ).pause ( 4000 ).
		                    						//Enter the value in the restricted in field is visible in the pages targeting page
		                    						setValue("//ng-include[3]/div/div[2]/region-chip-input/div/input",splitRestrictName[0]).		                    						
		                    						pause ( 4000 ).
		                    						//Wait for the listed data in the dropdown option in the pages targeting page
		                    						waitForElementVisible ( "//div/div[2]/region-chip-input/div/div/ul/li[contains(.,'"+splitRestrictedIn[ getSplitedData ]+"')]", 4000, false ).
		                    						pause ( 3000 ).
		                    						//Click on the data listed in the dropdown option in the pages targeting page
		                    						click ( "//div/div[2]/region-chip-input/div/div/ul/li[contains(.,'"+splitRestrictedIn[ getSplitedData ]+"')]").
		                    						pause ( 4000 ).
		                    						//Wait and check for the save button is active in the pages targeting page 
		                    						waitForElementVisible ( "//button[@class='cta-button right']", 4000, false, function ( checkSaveActive ) {
		                    							if ( checkSaveActive.value == true ) {
		                    								pagesEdit.useXpath ( ).pause ( 4000 ).
		                    								//Click on the active save button in the pages targeting page
		                    								click ( "//button[@class='cta-button right']" ).
		                    								pause ( 4000 ).
		                    								//Get the text value for the allowed in field on the pages targeting page
		                    								getText("//div/div[1]/region-chip-input/div/div", function ( allowedInValue ) {
		                    									var allowValue = allowedInValue.value;
		                    									if ( allowValue.trim() == splitAllowedName[0].trim() ) {
		                    										pagesEdit.useXpath ( ).pause ( 4000 ).
		                    										//Get the text value for the restricted in field on the pages targeting page
		                    										getText("//div/div[2]/region-chip-input/div/div", function ( restrictedInValue ) {
		                    											if ( restrictedInValue.value == splitRestrictName[0].trim() ) {
		                    												pagesEdit.useXpath ( ).pause ( 4000 ).
		                    												//Wait for the Inactive save button should not visible in the pages targeting page
					                    									waitForElementNotPresent ( "//button[@class='cta-button right']", 4000, false, function ( checkSaveInactive ) {
					                    									if ( checkSaveInactive.value.length == 0 ) {
						                    									//Write the Excel to PASS Result and Reason
						                                      pagesEdit.writeToExcelPass ( 'pages.xlsx', 'PagesEdit', excelRow, 4 );
						                                    }
					                                     	else {
					                                    		//Write the Excel to FAIL Result and Reason
					                                      	this.verify.fail ( checkSaveInactive.value, 'true', 'Save Button is still existing Active' );
					                                      	pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "Save Button is still existing Active" );
					                                    	}
					                    								} );
					                    							}
					                    							else {
					                    								//Write the Excel to FAIL Result and Reason
							                      					this.verify.fail ( restrictedInValue.value, true, 'Timeout issue or fail due to the Pages Restricted In Value is not displayed correctly' );
							                      					pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+restrictedInValue.value+". ExpectedResult:'"+splitRestrictName[0]+"'" );
		                    		   							}
					                    						} );
			                    							}
			                    							else {
			                    								//Write the Excel to FAIL Result and Reason
							                      		this.verify.fail ( allowedInValue.value, true, 'Timeout issue or fail due to the Pages allowedIn Value is not displayed correctly' );
							                      		pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+allowedInValue.value+"' ExpectedResult:'"+splitAllowedName[0]+"'" );                    								
			                    							}
			                    						} );
		                    							}
		                    							else {
		                    								//Write the Excel to FAIL Result and Reason
							                      		this.verify.fail ( checkSaveActive.value, true, 'Timeout issue or fail due to the Pages Save_Active button is not visible' );
							                      		pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+checkSaveActive.value+". ExpectedResult: the Pages Save_Active button should be visible' )" );
		                    							}
		                    						} );
		                    					}
		                    					else {                    						
		                    						//Write the Excel to FAIL Result and Reason
							                      this.verify.fail ( checkRestrictedIn.value, true, 'Timeout issue or fail due to the Restricted_In is not visible' );
							                      pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+checkRestrictedIn.value+". ExpectedResult: the Pages Restricted_In should be visible' )" );
		                    					}
		                    				} );
		                    			}
		                    			else {                    				
		                    				//Write the Excel to FAIL Result and Reason
					                      this.verify.fail ( checkAllowedIn.value, true, 'Timeout issue or fail due to the Allowed_In is not visible' );
					                      pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+checkAllowedIn.value+". ExpectedResult: the Allowed_In should be visible' )" );
		                    
		                    			}
		                    		} );	                    	
				                    } 				                    
			                    } 
		                    }
		                    else {
		                    	//Write the Excel to FAIL Result and Reason
                      		this.verify.fail ( checkTargatTab.value, true, 'Timeout issue or fail due to the Pages targeting tab is not visible' );
                      		pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+checkTargatTab.value+". ExpectedResult: the Pages targeting tab should be visible' )" );
                        }	
	                    } );                                     
                    }
                    else {
                      //Write the Excel to FAIL Result and Reason
                      this.verify.fail ( checkEditBtn.value, true, 'Timeout issue or fail due to the Pages Edit is not visible' );
                      pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+checkEditBtn.value+". ExpectedResult: the Pages Edit should be visible' )" );
                    }
                  } );                    
                }
              	else {
                  //Write the Excel to FAIL Result and Reason
                  this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
                  pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
                }
              } );            
	          }
	          else {       
	         	  //Write the Excel to FAIL Result and Reason    
	            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
	            pagesEdit.writeToExcelFail ( 'pages.xlsx', 'PagesEdit', excelRow, 4, 5, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
	          }
        	} );
      	}
			}
		},

	'PagesContainerDelete': function ( pagesDeleteContainer ) {
    var excel = pagesDeleteContainer.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( pagesDeleteContainer.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Remove button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
                  if ( checkEditBtn.value == true ) {
                    pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
                    //Click on the the Remove button in the vertical ellipsis option on pages index page
                    click ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                    pause ( 4000 ). 
                    //Click on the Page Structure Tab in the Pages Container listing page                           
                    click ( "//*[@id='my_modal-new_container_form']/div" ).
                    pause ( 4000 ) 
                    var splitDeleteName = [ ];                                       
                    splitDeleteName = excel.B[ excelColumn ].split(':'); 
                    //Loop n number of sliptted inputs
                    for ( let getSplitedData = 0; getSplitedData<splitDeleteName.length; getSplitedData++ ) {
                    	if ( ( excel.C[ excelColumn ] != "FAIL" ) && ( excel.D[ excelColumn ] == null ) ) {
                    		pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
                    		//Wait for vertical ellipsis is visible in the pages container listing page                    		
                    		waitForElementVisible ( "//div[contains(.,'"+splitDeleteName[ getSplitedData ]+"')]/span/toggle-menu/span", 4000, false, function ( checkVerticalBtn ) {
                    			if ( checkVerticalBtn.value == true ) {
                    				pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
                    				//Click on the vertical ellipsis button in the pages container listing page 
                    				click ( "//div[contains(.,'"+splitDeleteName[ getSplitedData ]+"')]/span/toggle-menu/span" ).
                    				pause ( 4000 ).  
                    				//Wait for the remove button is visible in the pages container listing page                    				
                    				waitForElementVisible ( "//span[contains(.,'"+splitDeleteName[ getSplitedData ]+"')]/descendant::ng-transclude/div[contains(.,'Remove')]", 4000, false, function ( checkContainerDeleteBtn ) {
                    					if ( checkContainerDeleteBtn.value == true ) {
                    						pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
                    						//Click on the remove button in the pages container listing page
                    						click ( "//span[contains(.,'"+splitDeleteName[ getSplitedData ]+"')]/descendant::ng-transclude/div[contains(.,'Remove')]" ).
                    						pause ( 4000 ).
                    						//Wait for the pop-up delete button is visible in the pages container page
                    						waitForElementVisible ( "//span[contains(.,'"+splitDeleteName[ getSplitedData ]+"')]/descendant::div/div[@class='modal-content']/span[1]", 4000, false, function ( checkPopupDelete ) {
                    							if ( checkPopupDelete.value == true ) {
                    								pagesDeleteContainer.useXpath ( ).pause ( 4000 ).
                    								//Click on the pop-up delete button in the pages container page
                    								click ( "//span[contains(.,'"+splitDeleteName[ getSplitedData ]+"')]/descendant::div/div[@class='modal-content']/span[1]" ).
                    								pause ( 4000 ).
                    								//Wait for the container name should not present in the pages container page
                    								waitForElementNotPresent ( "//div[1]/div/div[1]/div[1]/div[contains(.,'"+splitDeleteName[ getSplitedData ]+"')]", 4000, false, function ( checkContainerName ) {
                    									if ( checkContainerName.value.length == 0 ) {
	                    									//Write the Excel to PASS Result and Reason
	                                      pagesDeleteContainer.writeToExcelPass ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3 );
	                                    }
                                     	else {
                                    		//Write the Excel to FAIL Result and Reason
                                      	this.verify.fail ( checkContainerName.value, 'true', 'Deleted Container is still existing' );
                                      	pagesDeleteContainer.writeToExcelFail ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3, 4, "Deleted Container is still Existing" );
                                    	}
                    								} );
                    							}
                    							else {
                    								//Write the Excel to FAIL Result and Reason
					                      		this.verify.fail ( checkPopupDelete.value, true, 'Timeout issue or fail due to the Pages Container popup Delete button is not visible' );
					                      		pagesDeleteContainer.writeToExcelFail ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3, 4, "ActualResult: '"+checkPopupDelete.value+". ExpectedResult: the Pages Container popup Delete button should be visible' )" );
                    							}
                    						} );
                    					}
                    					else {                    						
                    						//Write the Excel to FAIL Result and Reason
					                      this.verify.fail ( checkContainerDeleteBtn.value, true, 'Timeout issue or fail due to the Pages Container Delete button is not visible' );
					                      pagesDeleteContainer.writeToExcelFail ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3, 4, "ActualResult: '"+checkContainerDeleteBtn.value+". ExpectedResult: the Pages Container Delete button should be visible' )" );
                    					}
                    				} );
                    			}
                    			else {                    				
                    				//Write the Excel to FAIL Result and Reason
			                      this.verify.fail ( checkVerticalBtn.value, true, 'Timeout issue or fail due to the Container Vertical Ellipsis Button is not visible' );
			                      pagesDeleteContainer.writeToExcelFail ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3, 4, "ActualResult: '"+checkVerticalBtn.value+". ExpectedResult: the Container Vertical Ellipsis Button should be visible' )" );
                     			}
                    		} );	                    	
	                    } 		                    
                    } 	                                     
                  }
                  else {
                    //Write the Excel to FAIL Result and Reason
                    this.verify.fail ( checkEditBtn.value, true, 'Timeout issue or fail due to the Pages Edit is not visible' );
                    pagesDeleteContainer.writeToExcelFail ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3, 4, "ActualResult: '"+checkEditBtn.value+". ExpectedResult: the Pages Edit should be visible' )" );
                  }
                } );                    
              }
            	else {
                //Write the Excel to FAIL Result and Reason
                this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
                pagesDeleteContainer.writeToExcelFail ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3, 4, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
              }
            } );            
          }
          else {       
         	  //Write the Excel to FAIL Result and Reason    
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
            pagesDeleteContainer.writeToExcelFail ( 'pages.xlsx', 'PagesContainerDelete', excelRow, 3, 4, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
          }
      	} );
    	}
		}
	},


  'PagesDelete': function ( pagesDelete ) {
    var excel = pagesDelete.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesDelete.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesDelete.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).
            //Get the value of the total in the pages index page
            getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                var currentCount = currentCountResult.value;
                currentCount = currentCount.split ( 'Pages' );
                pagesDelete.useXpath ( ).pause ( 4000 ).
                //Wait for search field is visible in the pages index page
                waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
                  if ( checkSearchBtn.value == true ) {
                    pagesDelete.useXpath ( ).pause ( 4000 ).
                    //Click on the search field in the pages index page
                    click ( "//*[@id='search_input']" ).
                    pause ( 2000 ).
                    //Clear the data in the search field in the pages index page
                    clearValue ( "//*[@id='search_input']" ).
                    pause ( 2000 ).
                    //Enter the data in the search field in the pages index page
                    setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                    useCss ( ).pause ( 2000 ).
                    //Press return key
                    keys ( pagesDelete.Keys.ENTER ).
                    useXpath ( ).pause ( 4000 ).
                    //Wait for the vertical ellipsis button is visible in the pages index page
                    waitForElementVisible ( "//span[@class='options-container'][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkverticleBtn ) {
                      if ( checkverticleBtn.value == true ) {
                        pagesDelete.useXpath ( ).pause ( 4000 ).
                        //Click on vertical ellipsis button in the pages index page
                        click ( "//span[@class='options-container'][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                        pause ( 3000 ).
                        //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                        waitForElementVisible ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::ng-transclude/div/i", 4000, false, function ( checkDeletBtn ) {
                          if ( checkDeletBtn.value == true ) {
                            pagesDelete.useXpath ( ).pause ( 4000 ).
                            //Click on the the Delete button in the vertical ellipsis option on pages index page
                            click ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::ng-transclude/div/i" ).
                            pause ( 4000 ).
                            //Wait for the Delete popup button is visible in the vertical ellipsis option on pages index page
                            waitForElementVisible ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::div/div[@class='modal-content']/span[1]", 4000, false, function ( checkDeletPopBtn ) {
                              if ( checkDeletPopBtn.value == true ) {
                                pagesDelete.useXpath ( ).pause ( 4000 ).
                                //Click on the the Delete popup button in the vertical ellipsis option on pages index page
                                click ( "//span[contains(.,'"+excel.A[ excelColumn ]+"')]/descendant::div/div[@class='modal-content']/span[1]" ).
                                pause ( 4000 ).
                                //Wait for the pages menu is visible in the pages
                                waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false ).
                                pause ( 4000 ).
                                //Click on the pages menu in the pages
                                click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
                                pause ( 5000 ).
                                //Get the value of the actual total in the pages index page
                                getText ( "//div/ng-include[2]/div/div/div[1]/span/span", function ( actualCountResult ) {
                                  if ( actualCountResult.status != -1 ) {
                                    var actualCount = actualCountResult.value;
                                    actualCount = actualCount.split ( 'Pages' );
                                    expectedCount = ( +currentCount[0] - 1 ) 
                                    if ( actualCount[0] == expectedCount ) {
                                      //Write the Excel to PASS Result and Reason
                                      pagesDelete.writeToExcelPass ( 'pages.xlsx', 'PagesDelete', excelRow, 2 );
                                    }
                                    else {
                                    	//Write the Excel to FAIL Result and Reason
                                      this.verify.fail ( actualCount, 'true', 'Total Count is not displayed in the Pages listing page' );
                                      pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "ActualResult: '"+actualCount+"' in the Total Count After Added New Folder. ExpectedResult: should be'" + expectedCount + "' in the Total Count" );
                                    }
                                  }
                                  else {
                                  	//Write the Excel to FAIL Result and Reason
                                    this.verify.fail ( actualCountResult.value, 'true', 'Total Count is not displayed in the Pages listing page' );
                                    pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "Total Count is not displayed in the Pages listing page" );
                                  }
                                } );
                              }
                              else {
                              	//Write the Excel to FAIL Result and Reason
                                this.verify.fail ( checkDeletPopBtn.value, true, 'Timeout issue or fail due to the Pages Delete popup Button is not visible' );
                                pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "ActualResult: '"+checkDeletPopBtn.value+". ExpectedResult: the Pages Delete popup Button should be visible' )" );
                              }
                            } );
                          }
                          else {
                          	//Write the Excel to FAIL Result and Reason
                            this.verify.fail ( checkDeletBtn.value, true, 'Timeout issue or fail due to the Pages Delete Button is not visible' );
                            pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "ActualResult: '"+checkDeletBtn.value+". ExpectedResult: the Pages Delete Button should be visible' )" );
                          }
                        } );
                      }
                      else {
                      	//Write the Excel to FAIL Result and Reason
                        this.verify.fail ( checkverticleBtn.value, true, 'Timeout issue or fail due to the Pages verticle elipsis Button is not visible' );
                        pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "ActualResult: '"+checkverticleBtn.value+". ExpectedResult: the Pages verticle elipsis Button should be visible' )" );
                      }
                    } );
                  }
                  else {
                  	//Write the Excel to FAIL Result and Reason
                    this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
                    pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
                  }
                } );
              }
              else {
              	//Write the Excel to FAIL Result and Reason
                this.verify.fail ( currentCountResult.value, true, 'Timeout issue or fail due to the Pages current Count Result is not visible' );
                pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "ActualResult: '"+currentCountResult.value+". ExpectedResult: the Pages current Count Result should be visible' )" );
              }
            } );
          }
          else {    
          	//Write the Excel to FAIL Result and Reason       
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
            pagesDelete.writeToExcelFail ( 'pages.xlsx', 'PagesDelete', excelRow, 2, 3, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
          }
        } );
      }
    }
  },
};
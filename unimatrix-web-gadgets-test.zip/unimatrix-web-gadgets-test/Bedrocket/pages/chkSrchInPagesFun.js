var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkSrchInPagesFun' ],
  before: function ( pagesLogin ) {
    //Login to the Pages with valid credentials
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkSrchFunInPages': function ( chkSrhFun ) {
    var excel = chkSrhFun.globals.excelCol;
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {
      try {
        chkSrhFun.
        useXpath ( ).
        pause ( 5000 ).
        //Checking whether the page is in Navigation page
        waitForElementPresent ( "//SPAN[@class='ng-binding'][text()='pages']", 5000, false, function ( chkVisibility ) {
          if ( chkVisibility.value == false ) {
            chkSrhFun.
            pause ( 5000 ).
            //Clicking the Pages menu from the side bar Navigation from the application
            click ( "//SPAN[@ng-class='[ appColorScheme, { expand: expand, selected: currentSidebarOption == option.name } ]'][text()='pages']" ).
            pause ( 5000 );
          } 
          chkSrhFun.
            //Checking whether Search field is displayed
            waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkVisibility ) {
              if ( chkVisibility.value != false ) {
                chkSrhFun.
              //Clicking the Search Input field
              click ( "//INPUT[@id='search_input']" ).
              //Clearing the values present in the Search field
              clearValue ( "//INPUT[@id='search_input']" ).
              //Entering the Values from the Excel sheet to the search field
              setValue ( "//INPUT[@id='search_input']", excel.B[incrementer] ).
              //Hitting the Enter key from Keyboard
              keys ( chkSrhFun.Keys.ENTER ).
              //Checking whether the search results are appropriate
              waitForElementPresent ( "//SPAN[@id='"+excel.B[incrementer]+"']", 15000, false, function ( chkVisibility ) {
                if ( chkVisibility.value == false ) {
                  chkSrhFun.
                  waitForElementPresent ( "//SPAN[@class='no-content-main-text'][text()='No search results!']", 15000, false, function ( chkErrMsgVisibility ) {
                    if ( chkErrMsgVisibility.value.length != null ){
                      chkSrhFun.
                      //Updating the fail status in the Excel sheet
                      writeToExcelFail ( 'pages.xlsx', 'chkSrchFunInPages', ++incrementer, 3, 4, "No search results! is displayed in the page" );
                    }
                    else {
                      chkSrhFun.
                      //Updating the Fail status in the Excel sheet
                      writeToExcelFail ( 'pages.xlsx', 'chkSrchFunInPages', ++incrementer, 3, 4, "No search results! is not displayed in the page" );
                    }
                  } );
                } else {
                  chkSrhFun.
                  //Updating the fail status in Excel sheet with appropriate status
                  writeToExcelPass ( 'pages.xlsx', 'chkSrchFunInPages', ++incrementer, 3 );
                }
              } );
            }
          } );
          } );
      }
      catch ( e ) {
        chkSrhFun.
        //Updating the fail status in Excel sheet with appropriate status
        writeToExcelFail ( 'pages.xlsx', 'chkSrchFunInPages', ++incrementer, 3, 4 ,"Script terminated unexpectedly" );
      }
    }
  }
}
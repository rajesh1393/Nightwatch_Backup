//this function is for Checking the Pages TypeName and Language in PAGES
var excelRow, excelColumn = 1;
var splitLanguage = [ ];           
var splitShortLanguage = [ ]; 
module.exports = {
  tags: [ 'pagesTypeNameAndLanguage' ],
  before: function ( pagesLogin ) {
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },  

 'PagesTypeNameAndLanguage': function ( pagesAddLanguage ) {
    var excel = pagesAddLanguage.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesAddLanguage.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesAddLanguage.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                pagesAddLanguage.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( pagesAddLanguage.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).  
                //Wait for the pages title is visible in the pages
                waitForElementVisible ( "(//div[@class='page-info-container']/div/a/span)[1]", 9000, false, function ( checkPagesTitle ) {
                  if ( checkPagesTitle.value == true ) {  
                    pagesAddLanguage.useXpath ( ).pause ( 4000 ).
                    //Get the pages title in the pages
                    getText ( "//page-cell[1]/div/div[1]/div[1]/a/span[3]", function ( pagesTitle ) { 
                      var pagesNameTitle = pagesTitle.value
                      if ( pagesNameTitle.trim() == excel.A[ excelColumn ] ) {
                        pagesAddLanguage.useXpath ( ).pause ( 4000 ).             
                        //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                        waitForElementVisible ( "//page-cell[1]/div/div[1]/div[1]/a/span[3]", 4000, false, function ( checkshortLanguageTxt ) {
                          if ( checkshortLanguageTxt.value == true ) {
                            pagesAddLanguage.useXpath ( ).pause ( 4000 ).
                            //Get the short language text in the pages listing page
                            getText ( "//page-cell[1]/div/div[1]/div[1]/a/span[3]", function ( shortLanguageTxt ) { 
                              if ( shortLanguageTxt.value == excel.B[ excelColumn ] ) {
                                //Write the Excel to FAIL Result and Reason
                                pagesAddLanguage.writeToExcelPass ( 'pages.xlsx', 'PagesTypeNameAndLanguage', excelRow, 3 );
                            	}
                            	else {
                                //Write the Excel to FAIL Result and Reason
                                this.verify.fail ( shortLanguageTxt.value, true, 'ShortHand language name is incorrect in the listing page' );
                                pagesAddLanguage.writeToExcelFail ( 'pages.xlsx', 'PagesTypeNameAndLanguage', excelRow, 3, 4, "ShortHand language - ActualResult: '"+shortLanguageTxt.value+". ExpectedResult: '"+excel.B[excelColumn]+"'" );
                              }
                          	} );
                          }
                          else {
                            //Write the Excel to FAIL Result and Reason
                            this.verify.fail ( checkshortLanguageTxt.value, true, 'ShortHand language name is not displayed in the listing page' );
                            pagesAddLanguage.writeToExcelFail ( 'pages.xlsx', 'PagesTypeNameAndLanguage', excelRow, 3, 4, "ShortHand language name is not displayed in the listing page" );
                          }
                        } );
                      }
                      else {
                        //Write the Excel to FAIL Result and Reason
                        this.verify.fail ( pagesTitle.value, true, 'Pages Title is not visible in the listing page' );
                        pagesAddLanguage.writeToExcelFail ( 'pages.xlsx', 'PagesTypeNameAndLanguage', excelRow, 3, 4, "Pages Title ActualResult: '"+pagesTitle.value+". ExpectedResult: '"+excel.A[excelColumn]+"'" );
                      }
                    } );
                  }
                  else {
                    //Write the Excel to FAIL Result and Reason
                    this.verify.fail ( checkPagesTitle.value, true, 'After Searched,Pages Title is not displayed in the listing page' );
                    pagesAddLanguage.writeToExcelFail ( 'pages.xlsx', 'PagesTypeNameAndLanguage', excelRow, 3, 4, "After Searched,Pages Title is not displayed in the listing page" );
                  }
                } );	                                      
	            }
	            else {
	              //Write the Excel to FAIL Result and Reason
	              this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
	              pagesAddLanguage.writeToExcelFail ( 'pages.xlsx', 'PagesTypeNameAndLanguage', excelRow, 3, 4, "Pages Search button is not displayed in the page" );
	            }
	          } );            
	         }
	         else {       
	         	//Write the Excel to FAIL Result and Reason    
	          this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not displayed in the leftside menu bar' );
	          pagesAddLanguage.writeToExcelFail ( 'pages.xlsx', 'PagesTypeNameAndLanguage', excelRow, 3, 4, "Pages Menu is not displayed in the leftside menu bar" );
	        }
	      } );
	    }
	  }
  },	
};
var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkFilterByLanguageInPages' ],
  before: function ( pagesLogin ) {
    //Login to the Pages with valid credentials
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'FilterByLanguageInPages': function ( chkFilterFun ) {
    var excel = chkFilterFun.globals.excelCol;
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {
      try {
        chkFilterFun.
        useXpath ( ).
        pause ( 5000 ).
        //Checking whether the page is in Navigation page
        waitForElementPresent ( "//SPAN[@class='ng-binding'][text()='pages']", 5000, false, function ( chkVisibility ) {
          console.log ( chkVisibility )
          if ( chkVisibility.value == false ) {
            chkFilterFun.
            pause ( 5000 ).
            //Clicking the Pages menu from the side bar Navigation from the application
            click ( "//SPAN[@ng-class='[ appColorScheme, { expand: expand, selected: currentSidebarOption == option.name } ]'][text()='pages']" ).
            pause ( 5000 );
          } 
          chkFilterFun.
            //Checking whether Search field is displayed
            waitForElementPresent ( "//DIV[@ng-if='artifactsPage']", 5000, false, function ( chkVisibility ) {
              if ( chkVisibility.value != false ) {
                chkFilterFun.
                waitForElementPresent ( "//I[@class='index-header-icon category-carrot']", 5000, false, function ( chkCarrot ) {
                  if ( chkCarrot.value != false ) {
                    chkFilterFun.
                    //Cliking on the Filter by Language drop down in Pages list page
                    click ( "//I[@class='index-header-icon category-carrot']" ).
                    //Checking whether the menu is displayed after clicking on the Drop down icon
                    waitForElementPresent ( "//DIV[@class='flyout-menu-large dropdown-menu ng-scope']",5000, false, function ( chkMenuVisibility ) {
                    if ( chkMenuVisibility.value != false ) {
                    chkFilterFun.
                    //Cliking on the Filter by Language drop down in Pages list page
                    click ( "//li[text()[normalize-space(.)='"+excel.B[incrementer]+"']]" ).
                    pause ( 5000 ).
                    //Checking whether the Pages list gets updated with respect to filter
                    getText ( "//SPAN[@class='current-category-type ng-binding']", function ( getLanguageName ) {
                      if ( getLanguageName.value ==excel.B[incrementer] ) {
                      chkFilterFun.
                      //Updating the Pass status in the Excel sheet
                      writeToExcelPass( 'pages.xlsx', 'FilterByLanguageInPages', ++incrementer, 3 );
                      }
                      else {
                      chkFilterFun.
                      //Updating the fail status in Excel sheet with appropriate status
                      writeToExcelFail ( 'pages.xlsx', 'FilterByLanguageInPages', ++incrementer, 3, 4 ,"After changing the Language it is not refleced in the language field" );
                      }
                    })
                    }
                    else {
                      chkFilterFun.
                      //Updating the fail status in Excel sheet with appropriate status
                      writeToExcelFail ( 'pages.xlsx', 'FilterByLanguageInPages', ++incrementer, 3, 4 ,"Language menu is not displayed after clicking on the Drop down icon" );
                    }
                    })
                  }
                  else {
                    chkFilterFun.
                    //Updating the fail status in Excel sheet with appropriate status
                    writeToExcelFail ( 'pages.xlsx', 'FilterByLanguageInPages', ++incrementer, 3, 4 ,"Drop down icon is not displayed in the Pages list page" );
                  }
                })
            }
            else {
                chkFilterFun.
                //Updating the fail status in Excel sheet with appropriate status
                writeToExcelFail ( 'pages.xlsx', 'FilterByLanguageInPages', ++incrementer, 3, 4 ,"Unable to find filter by language option in Pages list page" );
            }
          } );
          } );
      }
      catch ( e ) {
        chkFilterFun.
        //Updating the fail status in Excel sheet with appropriate status
        writeToExcelFail ( 'pages.xlsx', 'FilterByLanguageInPages', ++incrementer, 3, 4 ,"Script terminated unexpectedly" );
      }
    }
  }
}
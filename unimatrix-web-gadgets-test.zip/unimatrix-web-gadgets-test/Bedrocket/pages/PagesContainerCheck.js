//this function is for checking Pages container
var excelRow, excelColumn = 1;
var splitName = [ ];           
var splitOption = [ ]; 
module.exports = {
  tags: ['pagesContainerCheck'],
  before: function ( pagesLogin ) {
    var profile = pagesLogin.globals.profilepages;
    pagesLogin.loginPage ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'pages.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },

 'PagesContainerCheck': function ( pagesContainerCheck ) {
    var excel = pagesContainerCheck.globals.excelCol;
    if ( excel.A.length > 0 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        pagesContainerCheck.useXpath ( ).pause ( 4000 ).
        //Wait for the pages menu is visible in the pages
        waitForElementVisible ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]", 4000, false, function ( checkPagesMenu ) {
          if ( checkPagesMenu.value == true ) {
            pagesContainerCheck.useXpath ( ).pause ( 4000 ).
            //Click on the pages menu in the pages
            click ( "//div[@class='left-sidebar-option ng-scope']/a/span[contains(.,'pages')]" ).
            pause ( 4000 ).            
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", excel.A[ excelColumn ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( pagesContainerCheck.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                    
                //Wait for the Delete button is visible in the vertical ellipsis option on pages index page
                waitForElementVisible ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]", 4000, false, function ( checkEditBtn ) {
                  if ( checkEditBtn.value == true ) {
                    pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                    //Click on the the Delete button in the vertical ellipsis option on pages index page
                    click ( "//*/a/span[1][contains(.,'"+excel.A[ excelColumn ]+"')]" ).
                    pause ( 4000 ). 
                    //Click on the Page Structure Tab in the Pages Container listing page                           
                    click ( "//*[@id='my_modal-new_container_form']/div" ).
                    pause ( 4000 )                                        
                    splitName = excel.B[ excelColumn ].split(':'); 
                    splitOption = excel.C[ excelColumn ].split(':');
                    //loop the 'n' number of splitted input
                    for ( let getSplitedData = 0; getSplitedData<splitName.length; getSplitedData++ ) {
                      if ( ( excel.E[ excelColumn ] != "FAIL" ) && ( excel.F[ excelColumn ] == null ) ) {
                        pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                        //Wait for Add container button is visible in the Pages Add Container screen
                        waitForElementVisible ( "//*[@id='open_modal-new_container_form']", 4000, false, function ( checkAddContainerBtn ) {
                          if ( checkAddContainerBtn.value == true ) {
                            pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                            //Click on the Add Container button in the Pages Add Container screen
                            click ( "//*[@id='open_modal-new_container_form']" ).
                            pause ( 4000 ).
                            //Wait for the Add Panel is visible in the Pages Add Container screen
                            waitForElementVisible ( "//*[@id='my_modal-new_container_form']/div", 4000, false, function ( checkAddPanel ) {
                              if ( checkAddPanel.value == true ) {
                                pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                //Click on the Add Panel in the Pages Add Container pop-up screen
                                click ( "//*[@id='my_modal-new_container_form']/div" ).
                                pause ( 4000 ).
                                //Wait for the Caption is visible in the Pages Add Container pop-up screen
                                waitForElementVisible ( "//*[@id='my_modal-new_container_form']/div/div[1]/div[1]/p", 4000, false, function ( checkCaption ) {
                                  if ( checkCaption.value == true ) {
                                    pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                    //Get the value in the caption in the Pages Add Container pop-up screen
                                    getText ( "//*[@id='my_modal-new_container_form']/div/div[1]/div[1]/p", function ( getCaption ) {
                                      if ( getCaption.value == "ADD NEW CONTAINER" ) {
                                        pagesContainerCheck.useXpath ( ).pause ( 4000 ).  
                                        //Wait for the Text input field is visible in the Pages Add Container pop-up screen                                               
                                        waitForElementVisible ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input", 4000, false, function ( checkTextInput ) {
                                          if ( checkTextInput.value == true ) {
                                            pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                            //Clear the data in the Text input field in the Pages Add Container pop-up screen 
                                            clearValue ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input" ).
                                            pause ( 4000 ).
                                            //Enter the data in the Text input field in the Pages Add Container pop-up screen
                                            setValue ( "//*/div[2]/form/ng-include/div/div[1]/div[2]/input", splitName[ getSplitedData ] ).
                                            pause ( 4000 ).
                                            //Wait for the Radio option is visible in the Pages Add Container pop-up screen
                                            waitForElementVisible ( "//div/div[@class='integrations-select']/span[contains(.,'"+splitOption[ getSplitedData ]+"')]", 4000, false, function ( checkoptions ) {
                                              if ( checkoptions.value == true ) {                                                     
                                                pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                //Click on the Radio option in the Pages Add Container pop-up screen
                                                click ( "//div/div[@class='integrations-select']/span[contains(.,'"+splitOption[ getSplitedData ]+"')]" ).
                                                pause ( 4000 ).   
                                                //Get the location for the save button in the Pages Add Container pop-up screen                                                   
                                                getLocationInView ( "//div[4]/button[contains(.,'ADD')]" ).
                                                pause ( 4000 ).
                                                //Wait for the the save button is visible in the Pages Add Container pop-up screen   
                                                waitForElementVisible ( "//div[4]/button[contains(.,'ADD')]", 4000, false, function ( checkSaveBtn ) {
                                                  if ( checkSaveBtn.value == true ) {
                                                    pagesContainerCheck.useXpath ( ).pause ( 4000 ).    
                                                    //Click on the save button in the Pages Add Container pop-up screen                                                       
                                                    click ( "//div[4]/button[contains(.,'ADD')]" ).
                                                    pause ( 4000 ).     
                                                    //Get the location for the created container in the Pages Add Container listing page                                                      
                                                    getLocationInView ( "//div[2]/div[contains(.,'"+splitName[ getSplitedData ]+"')]/div/div[1]/div[1]/div[2]" ).
                                                    pause ( 4000 ).
                                                    //Wait for the created container is visible in the Pages Add Container listing page   
                                                    waitForElementVisible ( "//div[2]/div[contains(.,'"+splitName[ getSplitedData ]+"')]/div/div[1]/div[1]/div[2]", 4000, false, function ( chechAddedContainer ) {
                                                      if ( chechAddedContainer.value == true ) {
                                                        pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                        //Click on the Add container list in the listing page
                                                        click ( "//div[2]/div[contains(.,'"+splitName[ getSplitedData ]+"')]/div/div[1]/div[1]/div[2]" ).
                                                        pause ( 4000 ).
                                                        //Wait for the pencil icon is visible in the page
                                                        waitForElementVisible ( "//div[2]/div/div/div[1]/div[3]/div/div[1]/i", 9000, false, function ( checkPencilIcon ) {
                                                          if ( checkPencilIcon.value == true ) {
                                                            pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                            //Wait for the other container button is visible in the page
                                                            waitForElementVisible ( "//*[@id='open_modal-add_to_other_pages_modal']", 9000, false, function ( checkOtherContainerBtn ) {
                                                            if ( checkOtherContainerBtn.value == true ) {
                                                              pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                              //Wait for the Delete button is visible in the page
                                                              waitForElementVisible ( "//div[2]/div/div/div[1]/div[3]/div/div[3]/pages-modal/ng-transclude", 9000, false, function ( checkDeleteBtn ) {
                                                                if ( checkDeleteBtn.value == true ) {
                                                                  pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                                  //Wait for the container caption label is visible in the page
                                                                  waitForElementVisible ( "//div[2]/div/div/div[1]/div[2]/span", 9000, false, function ( checkContainerCaption ) {
                                                                    if ( checkContainerCaption.value == true ) {
                                                                      pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                                      //Get the caption value in the page
                                                                      getText ( "//div[2]/div/div/div[1]/div[2]/span", function ( captionValues ) {
                                                                        if  ( captionValues.value == excel.D[ excelColumn ] ) {
                                                                        //Write the Excel to FAIL Result and Reason
                                                                        pagesContainerCheck.writeToExcelPass ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5 );
                                                                        }
                                                                        else {
                                                                          //Write the Excel to FAIL Result and Reason
                                                                          this.verify.fail ( chechAddedContainer.value, true, 'Timeout issue or fail due to the saved container is not visible' );
                                                                          pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: "+chechAddedContainer.value+". ExpectedResult: the saved container should be visible" );
                                                                        }
                                                                      } );
                                                                    }
                                                                    else {
                                                                      //Write the Excel to FAIL Result and Reason
                                                                      this.verify.fail ( checkContainerCaption.value, true, 'Timeout issue or fail due to Delete Button is not displayed in the page' );
                                                                      pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "Container Caption is not displayed in the page" );
                                                                    }
                                                                  } );
                                                                }
                                                                else {
                                                                  //Write the Excel to FAIL Result and Reason
                                                                  this.verify.fail ( checkDeleteBtn.value, true, 'Timeout issue or fail due to Delete Button is not displayed in the page' );
                                                                  pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "Delete Button is not displayed in the page" );
                                                                }
                                                                } );
                                                              }
                                                              else { 
                                                                //Write the Excel to FAIL Result and Reason
                                                                this.verify.fail ( checkOtherContainerBtn.value, true, 'Timeout issue or fail due to OtherContainer Button is not displayed in the page' );
                                                                pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "OtherContainer Button is not displayed in the page" );
                                                              }
                                                            } );
                                                          }
                                                          else { 
                                                            //Write the Excel to FAIL Result and Reason
                                                            this.verify.fail ( checkPencilIcon.value, true, 'Timeout issue or fail due to Pencil icon is not displayed in the page' );
                                                            pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "Pencil icon is not displayed in the page" );
                                                          }
                                                        } );                                                        
                                                      }
                                                      else {
                                                        //Write the Excel to FAIL Result and Reason
                                                        this.verify.fail ( chechAddedContainer.value, true, 'Timeout issue or fail due to the saved container is not visible' );
                                                        pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+chechAddedContainer.value+". ExpectedResult: the saved container should be visible' )" );
                                                      }
                                                    } );
                                                  }
                                                  else {
                                                    pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                    //Verify the Cancel button is visible in the container pop-up form
                                                    verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                                    pause ( 4000 ).
                                                    //Click on the Cancel button in the container pop-up form
                                                    click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
                                                    //Write the Excel to FAIL Result and Reason
                                                    this.verify.fail ( checkSaveBtn.value, true, 'Timeout issue or fail due to the Pages Save Button is not visible' );
                                                    pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkSaveBtn.value+". ExpectedResult: the Pages Save button should be visible' )" );
                                                  }
                                                } );
                                              }
                                              else {
                                                pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                                //Verify the Cancel button is visible in the container pop-up form
                                                verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                                pause ( 4000 ).
                                                //Click on the Cancel button in the container pop-up form
                                                click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
                                                //Write the Excel to FAIL Result and Reason
                                                this.verify.fail ( checkoptions.value, true, 'Timeout issue or fail due to the Pages Radio Button is not visible' );
                                                pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkoptions.value+". ExpectedResult: the Pages Radio button should be visible' )" );
                                              }
                                            } );
                                          }
                                          else {
                                            pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                            //Verify the Cancel button is visible in the container pop-up form
                                            verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                            pause ( 4000 ).
                                            //Click on the Cancel button in the container pop-up form
                                            click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
                                            //Write the Excel to FAIL Result and Reason
                                            this.verify.fail ( checkTextInput.value, true, 'Timeout issue or fail due to the Pages Text field is not visible' );
                                            pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkTextInput.value+". ExpectedResult: the Pages Text field should be visible' )" );
                                          }
                                        } );
                                      }
                                      else {
                                        pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                        //Verify the Cancel button is visible in the container pop-up form
                                        verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                        pause ( 4000 ).
                                        //Click on the Cancel button in the container pop-up form
                                        click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
                                        //Write the Excel to FAIL Result and Reason
                                        this.verify.fail ( getCaption.value, true, 'Timeout issue or fail due to the Pages Caption Label is unable to get' );
                                        pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+getCaption.value+". ExpectedResult: the Pages Caption Label should unable to get' )" );
                                      }
                                    } );
                                  }
                                  else {
                                    pagesContainerCheck.useXpath ( ).pause ( 4000 ).
                                    //Verify the Cancel button is visible in the container pop-up form
                                    verify.visible ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ).
                                    pause ( 4000 ).
                                    //Click on the Cancel button in the container pop-up form
                                    click ( "//*[@id='close_modal-new_container_form'][contains(.,'CANCEL')]" ) 
                                    //Write the Excel to FAIL Result and Reason
                                    this.verify.fail ( checkCaption.value, true, 'Timeout issue or fail due to the Pages Caption Label is not visible' );
                                    pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkCaption.value+". ExpectedResult: the Pages Caption Label should be visible' )" );
                                  }
                                } );
                              }
                              else {
                                //Write the Excel to FAIL Result and Reason
                                this.verify.fail ( checkAddPanel.value, true, 'Timeout issue or fail due to the Pages Add Panel is not visible' );
                                pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkAddPanel.value+". ExpectedResult: the Pages Add Panel should be visible' )" );
                              }
                            } );
                          }
                          else {
                            //Write the Excel to FAIL Result and Reason
                            this.verify.fail ( checkAddContainerBtn.value, true, 'Timeout issue or fail due to the Pages Add Container Button is not visible' );
                            pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkAddContainerBtn.value+". ExpectedResult: the Pages Add Container Button should be visible' )" );
                          }
                        } );
                      }                         
                    }                                        
                  }
                  else {
                    //Write the Excel to FAIL Result and Reason
                    this.verify.fail ( checkEditBtn.value, true, 'Timeout issue or fail due to the Pages Edit Button is not visible' );
                    pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkEditBtn.value+". ExpectedResult: the Pages Edit Button should be visible' )" );
                  }
                } );                    
              }
             else {
                //Write the Excel to FAIL Result and Reason
                this.verify.fail ( checkSearchBtn.value, true, 'Timeout issue or fail due to the Pages Search Button is not visible' );
                pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkSearchBtn.value+". ExpectedResult: the Pages Search Button should be visible' )" );
              }
            } );            
          }
          else {       
            //Write the Excel to FAIL Result and Reason    
            this.verify.fail ( checkPagesMenu.value, true, 'Timeout issue or fail due to the Pages Menu is not visible' );
            pagesContainerCheck.writeToExcelFail ( 'pages.xlsx', 'PagesContainerCheck', excelRow, 5, 6, "ActualResult: '"+checkPagesMenu.value+". ExpectedResult: the Pages Menu should be visible' )" );
          }
        } );
      }
    }
  },	
};
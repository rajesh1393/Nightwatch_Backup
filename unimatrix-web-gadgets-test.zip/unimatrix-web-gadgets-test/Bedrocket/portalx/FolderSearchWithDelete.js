//this function is for Folder Search With Delete functionality in the portalx
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'portalx.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['FolderSearchWithDelete'];
var contentTitle = [ ];
var expectedCount, currentCount, actualCount;
var excelData,splitData;
var getData, rowCount = 1;
module.exports = {
  tags: ['folderSearchWithDelete'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  'FolderSearchWithDelete': function ( newFolderDelete ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[1] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[excelData].v );
      }      
    }
    if ( contentTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;
        newFolderDelete.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Folder Menu in Sidebar
        waitForElementVisible ( "//a/span[contains(.,'folders')]", 4000, false, function ( checkFolderMenu ) {
          if ( checkFolderMenu.value == true ) {
            newFolderDelete.pause ( 4000 ).useXpath ( ).
            //Verify the Folder Menu is visible in the sidebar
            verify.visible ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Click on the Folder Menu in sidebar
            click ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Get the Current count in the Content page
            getText ( "//div[@class='index-header-wrapper controls']/span[1]", function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
               currentCount = currentCount.split ('Folders');
              }     
              newFolderDelete.pause ( 4000 ).useXpath ( ).         
              //Wait for search field is visible in the pages index page
              waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
                if ( checkSearchBtn.value == true ) {
                  newFolderDelete.useXpath ( ).pause ( 4000 ).
                  //Click on the search field in the pages index page
                  click ( "//*[@id='search_input']" ).
                  pause ( 2000 ).
                  //Clear the data in the search field in the pages index page
                  clearValue ( "//*[@id='search_input']" ).
                  pause ( 2000 ).
                  //Enter the data in the search field in the pages index page
                  setValue ( "//*[@id='search_input']", contentTitle[ getData ] ).
                  useCss ( ).pause ( 2000 ).
                  //Press return key
                  keys ( newFolderDelete.Keys.ENTER ).
                  useXpath ( ).pause ( 4000 ).
                  //Get the location for the Folder name in the page
                  getLocationInView ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]" ).
                  pause(4000).
                  //Wait for Folder name box is visible in the listing page
                  waitForElementVisible ("//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]",9000,false,function( checkFolderName ) {
                    if (checkFolderName.value == true) {
                      newFolderDelete.pause ( 4000 ).useXpath ( ).
                      //Wait for toggle menu is visible in the listing page
                      waitForElementVisible ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::toggle-menu/span", 9000, false, function ( checkToggleBtn ) {
                        if ( checkToggleBtn.value == true ) {
                          newFolderDelete.pause ( 4000 ).useXpath ( ).
                          //Click on the toggle menu in the listing page
                          click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::toggle-menu/span" ).
                          pause ( 4000 ).
                          //Wait for Rename button is visible in the dropdown list
                          waitForElementVisible ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::div/ul/li[contains(.,'Delete')]", 9000, false, function ( checkRenameBtn ) {
                            if ( checkRenameBtn.value == true ) {
                              newFolderDelete.pause ( 4000 ).useXpath ( ).
                              //Click on the Rename button in the dropdown list
                              click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::div/ul/li[contains(.,'Delete')]" ).
                              pause ( 4000 ).
                              //Wait for cancel button is visible in the page
                              waitForElementVisible("//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::div/div/span[contains(.,'cancel')]", 9000, false, function ( checkCancelBtn ) {
                                if ( checkCancelBtn.value == true ) {
                                  newFolderDelete.pause ( 4000 ).useXpath ( ).
                                  //Wait for the delete button is visible in the page
                                  waitForElementVisible ("//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::div/div/span[contains(.,'delete')]", 9000, false ).
                                  pause ( 4000 ).
                                  //Click on the cancek button in the page
                                  click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::div/div/span[contains(.,'cancel')]" ).
                                  pause ( 4000 ).
                                  //Get the location for the folder name in the page
                                  getLocationInView ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]" ).
                                  pause ( 4000 ).
                                  //Click on the folder title in the page
                                  click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]" ).
                                  pause ( 4000 ).
                                  //Wait for the Togglo button is visible in the page
                                  waitForElementVisible ( "//span/toggle-menu/span", 9000, false, function ( checkBtnToggle ) {
                                    if ( checkBtnToggle.value == true ) {
                                      newFolderDelete.pause ( 4000 ).useXpath ( ).
                                      //Click on the toggle menu in the page
                                      click ("//span/toggle-menu/span").
                                      pause ( 4000 ).
                                      //Wait the Delete button is visible in the page
                                      waitForElementVisible ( "//ng-transclude[contains(.,'Delete')]", 9000, false, function ( checkBtnDelete ) { 
                                        if ( checkBtnDelete.value == true ) {                         
                                          newFolderDelete.pause ( 4000 ).useXpath ( ).
                                          //Click on the Delete button in the page
                                          click ( "//ng-transclude[contains(.,'Delete')]" ).
                                          pause ( 4000 ).
                                          //Wait for Rename field is visible in the listing page
                                          waitForElementVisible ( "//div/div/span[@class='confirm-btn'][contains(.,'delete')]", 9000, false, function ( checkPopUp ) {
                                            if ( checkPopUp.value == true ) {
                                              newFolderDelete.pause ( 4000 ).useXpath ( ).
                                              //Click on the confirm delete button in the page
                                              click ( "//div/div/span[@class='confirm-btn'][contains(.,'delete')]" ).
                                              pause ( 4000 ).
                                              //Verify the Folder Menu is visible in the sidebar
                                              verify.visible ( "//a/span[contains(.,'folders')]" ).
                                              pause ( 4000 ).
                                              //Click on the Folder Menu in sidebar
                                              click ( "//a/span[contains(.,'folders')]" ).
                                              pause ( 4000 ).
                                              //Get the Current count in the Content page
                                              getText ( "//div[@class='index-header-wrapper controls']/span[1]", function ( actualCountResult ) {
                                                //div[@class='index-header-wrapper controls']/span[@ng-if='!categoryItems && !artifactsPage && !loading']
                                                if ( actualCountResult.status != -1 ) {
                                                  actualCount = actualCountResult.value;
                                                  actualCount = actualCount.split ( 'Folders' );                                        
                                                  expectedCount = ( +currentCount[0] - 1 )
                                                  if ( actualCount[0] == expectedCount ) {
                                                    //Write the Excel to PASS Result and Reason
                                                    newFolderDelete.writeToExcelPass ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2 );
                                                  }
                                                  else {
                                                    //Write the Excel to FAIL Result and Reason
                                                    newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "ActualResult: '"+ actualCount +"' in the Total Count After Added New Folder. ExpectedResult: should be'" + expectedCount + "' in the Total Count" );
                                                  }                          
                                                }
                                                else {
                                                  this.verify.fail ( actualCountResult.value, 'true', 'Total Count is not displayed in the Folder listing page' );
                                                  //Write the Excel to FAIL Result and Reason
                                                  newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Total Count is not displayed in the Folder listing page" );
                                                }
                                              } ); 
                                            }
                                            else {
                                              this.verify.fail ( checkPopUp.value, 'true', 'Alert message is not displayed to delete in the Folder page' );
                                              //Write the Excel to FAIL Result and Reason
                                              newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Alert message is not displayed to delete in the Folder page" );
                                            }
                                          } );
                                        }
                                        else {
                                          this.verify.fail ( checkBtnDelete.value, 'true', 'Delete Button is not displayed in the Folder page' );
                                          //Write the Excel to FAIL Result and Reason
                                          newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Delete Button is not displayed in the Folder page" );
                                        }
                                      } );
                                    }
                                    else {
                                      this.verify.fail ( checkBtnToggle.value, 'true', 'Toggle menu is not displayed in the Folder page' );
                                      //Write the Excel to FAIL Result and Reason
                                      newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Toggle menu is not displayed in the Folder page" );
                                    }
                                  } );
                                }
                                else {
                                  this.verify.fail ( checkCancelBtn.value, 'true', 'Cancel Button is displayed in the alert message box' );
                                  //Write the Excel to FAIL Result and Reason
                                  newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Cancel Button is displayed in the alert message box" );
                                }
                              } );                                
                            }
                            else {
                              this.verify.fail ( checkRenameBtn.value, 'true', 'Delete Button is displayed in the Dropdown list' );
                              //Write the Excel to FAIL Result and Reason
                              newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Delete Button is displayed in the Dropdown list" );
                            }
                          } );
                        }
                        else {
                          this.verify.fail ( checkToggleBtn.value, 'true', 'Toggle Button is not displayed in the Folder listing page' );
                          //Write the Excel to FAIL Result and Reason
                          newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Toggle Button is not displayed in the Folder listing page" );
                        }
                      } );
                    }
                    else {
                      this.verify.fail ( checkFolderName.value, 'true', 'Folder Name is not displayed in the Folder listing page' );
                      //Write the Excel to FAIL Result and Reason
                      newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Folder Name is not displayed in the Folder listing page" );
                    }
                  } );
                }
                else {
                  this.verify.fail ( checkSearchBtn.value, 'true', 'Search option is not displayed in Sidebar' );
                  //Write the Excel to FAIL Result and Reason
                  newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Search option is not displayed in Sidebar" );
                }
              } );
            } );
          }
          else {
            this.verify.fail ( checkFolderMenu.value, 'true', 'Folders menu is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            newFolderDelete.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithDelete', rowCount, 2, 3, "Folders menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    newFolderDelete.end ( );
  }
}
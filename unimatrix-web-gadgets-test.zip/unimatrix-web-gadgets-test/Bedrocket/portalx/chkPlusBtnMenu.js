module.exports = {
  tags:  [ 'chkPlusBtnMenu' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkPlusBtnMenu': function ( chkPlusBtnMenuList ) {
    //Setting up the Page object model
    var excel = chkPlusBtnMenuList.globals.excelCol;
    //Manipulating the data from the Excel sheet
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {
    //Exception handling
    try {
      chkPlusBtnMenuList.
      useXpath().
      pause ( 5000 ).
      //Clicking the appropriate pages as described in the Excel sheet
      click ( '//A/span[text()="'+excel.B[ incrementer ]+'"]' ).
      pause ( 8000 ).
      //Waiting till the Add button to be dispalyed in the Application
      waitForElementPresent ( "//div[@tooltip='Add New']", 15000, false, function ( chkVisibilityStatus ) {
        //Checking whether the Add icon is displayed in the Applcation
        if ( chkVisibilityStatus.value != false && chkVisibilityStatus.value.length != null) {
          chkPlusBtnMenuList.
          //Clicking the Add icon in the appropriate pages
          click ( "//div[@tooltip='Add New']" ).
          //Getting the Menu list that is displayed after clicking on the Add icon
          getText ( "//DIV[@class='flyout-menu-large dropdown-menu ng-scope']", function ( getMenuValues ) {
            //Checking whether the Menus in the Excel sheet are matching with the menus displayed in the application
            menuInAddIcon = getMenuValues.value.replace(/\n/g, " ");
            if ( excel.C [ incrementer ] == menuInAddIcon ) {
              chkPlusBtnMenuList.
              //Updating the Pass status in the Excel sheet
              writeToExcelPass ( 'portalx.xlsx', 'chkPlusBtnMenu', ++incrementer, 4 );
            }
            else {
              chkPlusBtnMenuList.
              //Updating the Fail status in Excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'chkPlusBtnMenu', ++incrementer, 4, 5, "Menus displayed are not matching with the Excel sheet" );
            }
          })
        }
        else {
          chkPlusBtnMenuList.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'chkPlusBtnMenu', ++incrementer, 4, 5, "Unable to click the Add button" );
        }
      })
    }
    catch ( e ) {
      chkPlusBtnMenuList.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'chkPlusBtnMenu', ++incrementer, 4, 5, "Script stopped unexpectedly, Need to check locators" );
    }
  }
}
}
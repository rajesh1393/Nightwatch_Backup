module.exports = {
  tags: [ 'chkElipseInTopIndexCategoryPage' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkElipseInTopIndexCategoryPageFun': function ( chkVerticalEllipse ) {
    //Setting up the Page object model
    var excel = chkVerticalEllipse.globals.excelCol;
    for ( let incrementer = 1; incrementer < excel.B.length; incrementer++ ) {
      chkVerticalEllipse.
      useXpath ( ).
      //Navigating to Destination Index page
      click ( "//Span[text()='folders']" ).
      pause ( 3000 ).
      waitForElementPresent ( "//DIV[@class='search-wrapper ng-scope']", 5000, false ).
      //Searching for the Categories folder in side bar
      click ( "//DIV[@class='search-wrapper ng-scope']" ).
      //Clearing the value from the search field
      clearValue ( "//DIV[@class='search-wrapper ng-scope']" ).
      //Entering the Categories in the search name in the Text field
      setValue ( "//DIV[@class='search-wrapper ng-scope']/input","Categories" ).
      //clicking the Categories folder from the Folders 
      pause ( 3000 ).
      //Clicking the vertical ellipse present in the top index page of the Categories page
      click ( "//DIV[@class='sub-menu-option ng-scope']/a/div" ).
      pause ( 15000 ).
      //Waiting for the Destination page to be displayed
      waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='Categories']", 5000, false, function ( chkVisibility ) {
      //Checking whether the Destination is displayed in Index Page
      if ( chkVisibility.value != false ) {
      chkVerticalEllipse.
      //Clicking on the Vertical ellipses of the first Destination
      click ( "//SPAN[@class='folder-options-dropdown-icon']" ).
      pause ( 8000 ).
      //Getting the menu list which is displayed after clicking on the vertical ellipse
      getText ( "(//DIV[@class='flyout-menu-small dropdown-menu ng-scope'])[1]", function ( getMenuDetails ) {
        //Checking whether the Menu displayed in the application is as same as in Excel sheet
        if ( getMenuDetails.value.replace(/\n/g," ") == excel.B [ incrementer ] ) {
          chkVerticalEllipse.
          //Updating the Pass status in Excel sheet
          writeToExcelPass ( 'portalx.xlsx', 'chkElipseInTopIndexCategoryPageFun', ++incrementer, 3 );
        }
        else {
          chkVerticalEllipse.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'chkElipseInTopIndexCategoryPageFun', ++incrementer, 3, 4, "Menus displayed are not matching with the Excel sheet" );
        }
      } );
    }
    else {
      chkVerticalEllipse.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'chkElipseInTopIndexCategoryPageFun', ++incrementer, 3, 4, "Unable to navigate to Destination page" );
    }
  } );
    }
  }
}
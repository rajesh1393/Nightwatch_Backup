//this function is for Folder Search With Rename in the portalx
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'portalx.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['FolderSearchWithRename'];
var contentTitle = [ ];
var renameTitle = [ ];
var excelData;
var getData, rowCount = 1;
module.exports = {
  tags: ['folderSearchWithRename'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  'FolderSearchWithRename': function ( newFolderRename ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[1] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[excelData].v );
      }
      //Read Renamed Title
      if ( excelData.includes ( 'B' ) ) {
        renameTitle.push ( worksheet[excelData].v );
      }
    }
    if ( contentTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;
        newFolderRename.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Folder Menu in Sidebar
        waitForElementVisible ( "//a/span[contains(.,'folders')]", 4000, false, function ( checkFolderMenu ) {
          if ( checkFolderMenu.value == true ) {
            newFolderRename.pause ( 4000 ).useXpath ( ).
            //Verify the Folder Menu is visible in the sidebar
            verify.visible ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Click on the Folder Menu in sidebar
            click ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Wait for search field is visible in the pages index page
            waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
              if ( checkSearchBtn.value == true ) {
                newFolderRename.useXpath ( ).pause ( 4000 ).
                //Click on the search field in the pages index page
                click ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Clear the data in the search field in the pages index page
                clearValue ( "//*[@id='search_input']" ).
                pause ( 2000 ).
                //Enter the data in the search field in the pages index page
                setValue ( "//*[@id='search_input']", contentTitle[ getData ] ).
                useCss ( ).pause ( 2000 ).
                //Press return key
                keys ( newFolderRename.Keys.ENTER ).
                useXpath ( ).pause ( 4000 ).                
                //Wait for Folder name box is visible in the listing page
                waitForElementVisible ("//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]",9000,false,function( checkFolderName ) {
                  if (checkFolderName.value == true) {
                    newFolderRename.pause ( 4000 ).useXpath ( ).
                    //Wait for toggle menu is visible in the listing page
                    waitForElementVisible ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::toggle-menu/span", 9000, false, function ( checkToggleBtn ) {
                      if ( checkToggleBtn.value == true ) {
                        newFolderRename.pause ( 4000 ).useXpath ( ).
                        //Click on the toggle menu in the listing page
                        click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::toggle-menu/span" ).
                        pause ( 4000 ).
                        //Wait for Rename button is visible in the dropdown list
                        waitForElementVisible ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::div/ul/li[contains(.,'Rename')]", 9000, false, function ( checkRenameBtn ) {
                          if ( checkRenameBtn.value == true ) {
                            newFolderRename.pause ( 4000 ).useXpath ( ).
                            //Click on the Rename button in the dropdown list
                            click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]/descendant::div/ul/li[contains(.,'Rename')]" ).
                            pause ( 4000 ).
                            //Clear the value in the Folder name field in the page
                            clearValue ( "//folder-cell/div/span[contains(.,'"+ contentTitle[getData] +"')]//span/input" ).
                            pause ( 4000 ).
                            //Enter the value in the Folder name field in the page
                            setValue ( "//folder-cell/*//span/input[contains(@class,'ng-empty')]", renameTitle[getData] ).
                            pause ( 4000 ).useCss ( ).
                            //Key press on Enter key
                            keys ( newFolderRename.Keys.ENTER ).
                            pause ( 4000 ).useXpath ( ).
                            //Wait for Rename field is visible in the listing page
                            waitForElementVisible ( "//folder-cell/div/span[contains(.,'"+ renameTitle[getData] +"')]", 9000, false, function ( checkRenameFolder ) {
                              if ( checkRenameFolder.value == true ) {
                                //Write the Excel to PASS Result and Reason
                                newFolderRename.writeToExcelPass ( 'portalx.xlsx', 'FolderSearchWithRename', rowCount, 3 );
                              }
                              else {
                                this.verify.fail ( checkRenameFolder.value, 'true', 'Its not Renamed in the Folder listing page' );
                                //Write the Excel to FAIL Result and Reason
                                newFolderRename.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithRename', rowCount, 3, 4, "Its not Renamed in the Folder listing page" );
                              }
                            } );
                          }
                          else {
                            this.verify.fail ( checkRenameBtn.value, 'true', 'Rename Button is displayed in the Dropdown list' );
                            //Write the Excel to FAIL Result and Reason
                            newFolderRename.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithRename', rowCount, 3, 4, "Rename Button is displayed in the Dropdown list" );
                          }
                        } );
                      }
                      else {
                        this.verify.fail ( checkToggleBtn.value, 'true', 'Toggle Button is not displayed in the Folder listing page' );
                        //Write the Excel to FAIL Result and Reason
                        newFolderRename.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithRename', rowCount, 3, 4, "Toggle Button is not displayed in the Folder listing page" );
                      }
                    } );
                  }
                  else {
                    this.verify.fail ( checkFolderName.value, 'true', 'Folder Name is not displayed in the Folder listing page' );
                    //Write the Excel to FAIL Result and Reason
                    newFolderRename.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithRename', rowCount, 3, 4, "Folder Name is not displayed in the Folder listing page" );
                  }
                } );
              }
              else {
                this.verify.fail ( checkSearchBtn.value, 'true', 'Search option is not displayed in Sidebar' );
                //Write the Excel to FAIL Result and Reason
                newFolderRename.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithRename', rowCount, 3, 4, "Search option is not displayed in Sidebar" );
              }
            } );
          }
          else {
            this.verify.fail ( checkFolderMenu.value, 'true', 'Folders menu is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            newFolderRename.writeToExcelFail ( 'portalx.xlsx', 'FolderSearchWithRename', rowCount, 3, 4, "Folders menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    newFolderRename.end ( );
  }
}
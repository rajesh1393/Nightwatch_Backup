var ErrMsg_DestiName;
var actualIndexBeforeAdd = [ ];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkDelDestinationFun' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  //Checking the Delete functionality
  'DeleteDestination': function ( destiDelete ) {
    //Setting up the Page object model
    var excel = destiDelete.globals.excelCol;
    var srchResult = [];
    for ( let incrementer = 1; incrementer < excel.B.length; incrementer++ ) {
      try {
        destiDelete.
        useXpath ( ).
        //Navigating to Index page of the applciation
        click ( "//Span[text()='destinations']" ).
        //Check whether the Search field is displayed
        waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkSearchTxtField ) {
          if ( chkSearchTxtField.value != 0 && chkSearchTxtField.status == 0 ) {
            destiDelete.
            //Clicking the Search icon 
            click ( "//INPUT[@id='search_input']" ).
            //Checking whether Search text field is displayed after clicking on Search icon
            waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkVisibility ) {
              destiDelete.
              //Clicking on the Input search field
              click ( "//INPUT[@id='search_input']" ).
              //Clearing the Value in the Seatch text fiedl
              clearValue ( "//INPUT[@id='search_input']" ).
              //Set value inside the Search field
              setValue ( "//INPUT[@id='search_input']", excel.B[incrementer] );
              try {
                destiDelete.
                pause ( 8000 ).
                //Clicking on the Text field
                keys ( destiDelete.Keys.NULL );
                destiDelete.
                // Hitting the Enter key after entering the text in the search field
                keys ( destiDelete.Keys.ENTER );
                destiDelete.
                //Hold the control for about 5 secs
                pause ( 5000 );
                destiDelete.
                //Checking whether the search results is displayed
                waitForElementPresent ( "//span[@class='destination-name-label ng-binding']", 15000, false, function ( chkVisibility ) {
                  if ( chkVisibility.value != false ) {
                    destiDelete.elements ( 'xpath', "//span[@class='destination-name-label ng-binding']", function ( result ) {
                      for ( let searchDes = 1; searchDes <= result.value.length; searchDes++ ) {
                        destiDelete.
                        useXpath ( );
                        destiDelete.
                        //Get the results from search results
                        getText ( "//destination-cell[" + searchDes + "]/*//span[@class='destination-name-label ng-binding']", function ( getContents ) {
                          //Storing the Regular expression to find whether the Search results are appropriate
                          var RegExp_Search = new RegExp ( excel.B[incrementer], 'gi' );
                          //Checking whether the Search results are macthing with the Regular Expression
                          var search_Result_Parser = getContents.value.match ( RegExp_Search );
                          if ( search_Result_Parser != null ) {
                            //Stroring the Search result values in an array
                            srchResult.push ( getContents.value )
                          }
                        } );
                      }
                      //Checking whether the actual result and expected results are equal 
                      destiDelete.
                      waitForElementPresent ( '//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]', 5000, false, function ( searchDes ) {
                        //Condition to check whether the Array is Empty
                        if ( searchDes.value.length != null ) {
                          //Checking the Search input data with the Search result data
                          if ( srchResult.length == result.value.length ) {
                            destiDelete.
                            //Getting the Location view of the matching element
                            getLocationInView ( '//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]' ).
                            //Getting attribute for the matching element
                            getAttribute ( '//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]/ancestor::destination-cell', "index", function ( searchDesIndex ) {
                              var indexValue = parseInt ( searchDesIndex.value ) + 1;
                              destiDelete.
                              //Checking whether the searched element is displayed
                              waitForElementPresent ( '//destination-cell[' + indexValue + ']/*//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]', 5000, false, function ( selectSearchedDes ) {
                                //Checking whether the Search results array is not null
                                if ( selectSearchedDes.value.length != null ) {
                                  //Checking whether Delete Option is done through List
                                  if ( excel.C[incrementer] == 'List' ) {
                                    destiDelete.
                                    //Clicking on the List icon in the Index page
                                    click ( "//i[contains(@class,'index-header-icon listview-icon')]" );
                                    destiDelete.
                                    pause ( 5000 );
                                    //Clicking the Vertical ellipses
                                    click ( '//destination-cell[' + indexValue + ']/*//span/span[@class="options-container"]/toggle-menu/span' );
                                    destiDelete.
                                    pause ( 5000 );
                                    //Clicking on the Delete option in the Toggle menu
                                    click ( '//destination-cell[' + indexValue + ']/*//span/span[@class="options-container"]//*/ng-transclude' );
                                    destiDelete.
                                    pause ( 5000 );
                                  }
                                  //Checking whether Delete Option is done through Grid view
                                  else if ( excel.C[incrementer] == 'Grid' ) {
                                    destiDelete.
                                    //Clicking on Grid view in the Index page
                                    click ( "//i[contains(@class,'index-header-icon gridview-icon')]" );
                                    destiDelete.
                                    pause ( 5000 );
                                    destiDelete.
                                    //Clicking on the Vertical ellipses in the List  page
                                    click ( '//destination-cell[' + indexValue + ']/*//span[@class="options-container"]/toggle-menu/span' );
                                    destiDelete.
                                    pause ( 5000 );
                                    destiDelete.
                                    //Clicking on the Delete option in the Toggle menu
                                    click ( '//destination-cell[' + indexValue + ']/*//span[@class="options-container"]//*/ng-transclude' );
                                  }
                                  destiDelete.
                                  useXpath ( ).
                                  //Waiting the controller for 5 secs
                                  pause ( 5000 ).
                                  //Checking whether the Confirm Delete popup is displayed
                                  waitForElementVisible ( "(//SPAN[@class='confirm-btn'][text()='delete'])[" + indexValue + "]", 5000, false, function ( deleteBtn ) {
                                    //Checking whether the Delete Button is dispalyed in the Confirm popup
                                    if ( deleteBtn.value == true ) {
                                      destiDelete.
                                      //Clicking the Delete button
                                      click ( "(//SPAN[@class='confirm-btn'][text()='delete'])[" + indexValue + "]" );
                                      destiDelete.
                                      pause ( 5000 );
                                      //Initializing array for storing the Destination count
                                      var actualIndexAfter = [];
                                      try {
                                        destiDelete.
                                        //Navigating to the Destination Index page
                                        click ( "//Span[text()='destinations']" ).
                                        //Checking whether the Element is visible
                                        waitForElementPresent ( "//span[@class = 'folder-count-text ng-binding ng-scope']", 5000, false, function ( chkIndex ) {
                                          destiDelete.
                                          //Getting the Index count from the Index page 
                                          getText ( "//span[@class = 'folder-count-text ng-binding ng-scope']", function ( getIndex ) {
                                            //Manipulating the Indexpage
                                            var parsingIndex = getIndex.value;
                                            if ( parsingIndex.indexOf ( "Destinations" ) >= 0 ) {
                                              actualIndexAfter = parsingIndex.split ( "Destinations" );
                                            } else if ( parsingIndex.indexOf ( "Destination" ) >= 0 ) {
                                              actualIndexAfter = parsingIndex.split ( "Destination" );
                                            }
                                            var parsedIndexs = actualIndexBeforeAdd[0];
                                            var expectedIndexs = parsedIndexs--;
                                            //Condition to check index value is updated after creating the Destination
                                            if ( actualIndexAfter[0] > parseInt(actualIndexAfter[0])-1 ) {
                                              destiDelete.
                                              //Updating the Pass status in Excel sheet
                                              writeToExcelPass ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4 );
                                            } else {
                                              destiDelete.
                                              //Updating the Fail status in Excel sheet
                                              writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "Please try again with some other Destination" );
                                            }
                                          } );
                                        } );
                                      } catch ( e ) {
                                        this.verify.fail ( 'Timeout issue or fail due to the delete option in ' + excel.B[incrementer] + ' view is not present' );
                                        destiDelete.
                                        //Updating the Fail status in Excel sheet
                                        writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "ActualResult: '" + deleteBtn.value + ". ExpectedResult: 'true' ( Timeout issue or fail due to the delete option in " + excel.B[incrementer] + " view is not present )" );
                                      }
                                    } else {
                                      //write the status as Delete button is not visible in the Articles in excel
                                      this.verify.fail ( 'Timeout issue or fail due to the delete option in ' + excel.B[incrementer] + ' view is not present' );
                                      destiDelete.
                                      //Updating the Fail status in the Excel sheet
                                      writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "ActualResult: '" + deleteBtn.value + ". ExpectedResult: 'true' ( Timeout issue or fail due to the delete option in " + excel.B[incrementer] + " view is not present )" );
                                    }
                                  } );
                                } else {
                                  //write to fail status as searched Des is not visible
                                  destiDelete.
                                  //Updating the Fail status in the Excel sheet
                                  writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "Searched Destination is not visible" );
                                  this.verify.fail ( "Search results should be displayed", 'Searched Des is not visible' );
                                }
                              } );
                            } );
                          } else {
                            destiDelete.
                            //Updating the Fail status in the Excel sheet
                            writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "Searched Destination is not present in the list" );
                            //write to fail status as searched Des is not Present
                            this.verify.fail ( "Searched Destination should be present in the list", 'Searched Destination is not present in the list' );
                          }
                        }
                        //If the condition fails then update the Fail status in the Excel
                        else {
                          destiDelete.
                          //Updating the Fail status in the Excel sheet
                          writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "Please try again with the another destination" );
                        }
                      } );
                    } );
                  }
                  else {
                    destiDelete.
                    //Updating the Fail status in the Excel sheet
                    writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "Your searched Destination not found in this list Please update with some other destination" );
                  }
                } );
              } catch ( e ) {
                destiDelete.
                //Updating the Fail status in the Excel sheet
                writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "Please try again with the another destination" );
              }
            } );
          }
        } );
      } catch ( e ) {
        destiDelete.
        //Updating the Fail status in the Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'DeleteDestination', ++incrementer, 4, 5, "Please try again with the another destination" );
      }
    }
  destiDelete.end();
  },
}
//Checking the Title section in Destination Page
module.exports = {
  tags: [ 'chkSecondaryTitleBarInDestination' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkTitleBarInDestinationPage': function ( chkTitleBar ) {
    //Array to store the Result status
    var addResults = [];
    var excel = chkTitleBar.globals.excelCol;
    for ( let inc = 0; inc < 1; inc++ ) {
      try {
        chkTitleBar.
        useXpath ( ).
        //Clicking the Destination link from the side bar
        click ( "//Span[text()='destinations']" ).
        //Checking whether the control is navigated to Destination page and checking whether the Title of the page is displayed
        waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='destinations']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            //Updating the Pass status in Excel sheet
            chkTitleBar.
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 2, 2 );
          }
          else {
            chkTitleBar.
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 2, 2, 3, "Title of the relavant page is not displayed" );
          }
        } );
        chkTitleBar.
         //Checking whether the index count of the Destinations is displayed.
         waitForElementPresent ( "//SPAN[@ng-if='!categoryItems && !artifactsPage && !loading && !stationsTab']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            //Updating the Pass status in Excel sheet
            chkTitleBar.
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 3, 2 );
          }
          else {
            chkTitleBar.
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 3, 2, 3, "Index count of the Destination page is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the index count of the Destinations is displayed.
         waitForElementPresent ( "//SPAN[@class='filtered-text ng-binding']",5000,false,function ( chkVisiblity ) {
          chkTitleBar.
        //Checking the Text displayed is matching the expected one.
        getText ( "//SPAN[@class='filtered-text ng-binding']", function ( getText ) {
          if ( getText.value == "Viewing 100 results" ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 4, 2 );
          }
          else {
            chkTitleBar.
            //Updating the fail status in the Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 4, 2, 3, "Viewing count is not displayed in the Destination Index page" );
          }

        } ) ;
        
      } );
         chkTitleBar.
         //Checking whether the Search icon is displayed in Destinations.
         waitForElementPresent ( "//INPUT[@id='search_input']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 5, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 5, 2, 3, "Search icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the Sortby icon is displayed in Destinations.
         waitForElementPresent ( "//I[@ng-click='toggleElement( $event )']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 6, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 6, 2, 3, "Sortby icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the List icon is displayed in Destinations.
         waitForElementPresent ( "//I[@class='index-header-icon listview-icon current_presentation']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 7, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 7, 2, 3, "List view icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the Grid icon is displayed in Destinations.
         waitForElementPresent ( "//I[@class='index-header-icon gridview-icon']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 8, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 8, 2, 3, "Grid view icon is not displayed" );
          }
        } );
         chkTitleBar.
         useCss ( ).
         //Checking whether the Add icon is displayed in Destinations.
         waitForElementPresent ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 9, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 9, 2, 3, "Add icon is not displayed" );
          }
        } );

       } catch ( e ) {
        chkTitleBar.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInDestinationPage', 3, 4, 5, "Execution of the script terminated due to "+e+" reason");
      }
    }
  }
}
//Checking the Title section in Folders Page
module.exports = {
  tags: [ 'chkSecondaryTitleBarInCategories' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkSecondaryTitleBarInCategoriesPage': function ( chkTitleBar ) {
    //Array to store the Result status
    var addResults = [];
    var excel = chkTitleBar.globals.excelCol;
    for ( let inc = 0; inc < 1; inc++ ) {
      try {
        chkTitleBar.
        useXpath ( ).
        //Clicking the Folders link from the side bar
        click ( "//Span[text()='folders']" ).
        pause ( 3000 ).
        waitForElementPresent ( "//DIV[@class='search-wrapper ng-scope']", 5000, false ).
        //Searching for the Categories folder in side bar
        click ( "//DIV[@class='search-wrapper ng-scope']" ).
        //Clearing the value from the search field
        clearValue ( "//DIV[@class='search-wrapper ng-scope']" ).
        //Entering the Categories in the search name in the Text field
        setValue ( "//DIV[@class='search-wrapper ng-scope']/input","Categories" ).
        //clicking the Categories folder from the Folders 
        pause ( 3000 ).
        //Clicking the vertical ellipse present in the top index page of the Categories page
        click ( "//DIV[@class='sub-menu-option ng-scope']/a/div" ).
        pause ( 15000 ).
        //Checking whether the control is navigated to Folders page and checking whether the Title of the page is displayed
        waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='Categories']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            //Updating the Pass status in Excel sheet
            chkTitleBar.
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 2, 2 );
          }
          else {
            chkTitleBar.
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 2, 2, 3, "Title of the relavant page is not displayed" );
          }
        } );
        chkTitleBar.
         //Checking whether the index count of the Folders is displayed.
         waitForElementPresent ( "//SPAN[@class='artifact-count-text ng-binding']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            //Updating the Pass status in Excel sheet
            chkTitleBar.
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 3, 2 );
          }
          else {
            chkTitleBar.
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 3, 2, 3, "Index count of the Folders page is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the Language filter is displayed.
         waitForElementPresent ( "//DIV[@ng-if='artifactsPage']",5000,false,function ( chkVisiblity ) {
        //Checking the Text displayed is matching the expected one.
        if ( chkVisiblity.value != false ) {
          chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 4, 2 );
          }
          else {
            chkTitleBar.
            //Updating the fail status in the Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 4, 2, 3, "Language filter is not displayed in the Folders Index page" );
          }
        } );
         chkTitleBar.
         //Checking whether the Search icon is displayed in Folders.
         waitForElementPresent ( "//INPUT[@id='search_input']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 5, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 5, 2, 3, "Search icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the Sortby icon is displayed in Folders.
         waitForElementPresent ( "//I[@ng-click='toggleElement( $event )']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 6, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 6, 2, 3, "Sort by Drop down is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the List icon is displayed in Folders.
         waitForElementPresent ( "//I[@class='index-header-icon listview-icon' ]",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 7, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 7, 2, 3, "List view icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the Grid icon is displayed in Folders.
         waitForElementPresent ( "//I[@class='index-header-icon gridview-icon current_presentation']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 8, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 8, 2, 3, "Grid view icon is not displayed" );
          }
        } );
         chkTitleBar.
         useCss ( ).
         //Checking whether the Add icon is displayed in Folders.
         waitForElementPresent ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 9, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 9, 2, 3, "Add icon is not displayed" );
          }
        } );

       } catch ( e ) {
        chkTitleBar.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'chkSecondaryTitleBarInCategoriesPage', 3, 4, 5, "Execution of the script terminated due to "+e+" reason");
      }
    }
  }
}
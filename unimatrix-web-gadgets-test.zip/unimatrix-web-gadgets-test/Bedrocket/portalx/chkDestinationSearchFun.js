var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: ['chkDestinationSearchFun'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'DestinationSearchFun': function ( chkSearch ) {
    //Setting up the Page object model
    var excel = chkSearch.globals.excelCol;
    var srchResult = [];
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {
      try {
        chkSearch.
        /*Navigating to Index page of the applciation*/
        //Clicking the Destination link from the side bar
        useXpath ( ).
        click ( "//Span[text ( )='destinations']" ).
        //Check whether the Search field is displayed
        waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkSearchTxtField ) {
          if ( chkSearchTxtField.value != 0 && chkSearchTxtField.status == 0 ) {
            chkSearch.
            //Clicking the Search icon 
            click ( "//INPUT[@id='search_input']" ).
            //Checking whether Search text field is displayed after clicking on Search icon
            waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkVisibility ) {
              chkSearch.
              //Clicking on the Input search field
              click ( "//INPUT[@id='search_input']" ).
              //Clearing the value in the search feild
              clearValue ( "//INPUT[@id='search_input']" ).
              //Set value inside the Search field
              setValue ( "//INPUT[@id='search_input']", excel.B[incrementer] );
              try {
                chkSearch.
                pause ( 8000 ).
                //Clicking on the Text field
                keys ( chkSearch.Keys.NULL );
                chkSearch.
                // Hitting the Enter key after entering the text in the search field
                keys ( chkSearch.Keys.ENTER );
                chkSearch.
                //Hold the control for about 5 secs
                pause ( 5000 );
                chkSearch.
                //Checking whether the search results is displayed
                waitForElementPresent ( "//span[@class='destination-name-label ng-binding']", 15000, false, function ( chkVisibility ) {
                  if ( chkVisibility.value != false ) {
                    chkSearch.elements ( 'xpath', "//span[@class='destination-name-label ng-binding']", function ( result ) {
                      for ( let searchDes = 1; searchDes <= result.value.length; searchDes++ ) {
                        chkSearch.
                        useXpath ( );
                        chkSearch.
                        //Get the results from search results
                        getText ( "//destination-cell[" + searchDes + "]/*//span[@class='destination-name-label ng-binding']", function ( getContents ) {
                          //Storing the Regular expression to find whether the Search results are appropriate
                          var RegExp_Search = new RegExp ( excel.B[incrementer], 'gi' );
                          //Checking whether the Search results are macthing with the Regular Expression
                          var search_Result_Parser = getContents.value.match ( RegExp_Search );
                          if ( search_Result_Parser != null ) {
                            //Stroring the Search result values in an array
                            srchResult.push ( getContents.value )
                          }
                        } );
                      }
                      //Checking whether the actual result and expected results are equal 
                      chkSearch.
                      waitForElementPresent ( '//span/span[contains(@class,"name-container")]/span[@id="' + excel.B[incrementer] + '"]', 5000, false, function ( searchDes ) {
                        //Condition to check whether the Array is Empty
                        if ( searchDes.value.length != null ) {
                          //Checking the Search input data with the Search result data
                          if ( srchResult.length == result.value.length ) {
                            chkSearch.
                            //Getting the Location view of the matching element
                            getLocationInView ( '//span/span[contains(@class,"name-container")]/span[@id="' + excel.B[incrementer] + '"]' ).
                            //Getting attribute for the matching element
                            getAttribute ( '//span/span[contains(@class,"name-container")]/span[@id="' + excel.B[incrementer] + '"]/ancestor::destination-cell', "index", function ( searchDesIndex ) {
                              var indexValue = parseInt ( searchDesIndex.value ) + 1;
                              chkSearch.waitForElementPresent ( '//destination-cell[' + indexValue + ']/*//span/span[contains(@class,"name-container")]/span[@id="' + excel.B[incrementer] + '"]', 5000, false, function ( selectSearchedDes ) {
                                if ( selectSearchedDes.value.length != null ) {
                                  chkSearch.click ( '//destination-cell[' + indexValue + ']/*//span/span[contains(@class,"name-container")]/span[@id="' + excel.B[incrementer] + '"]' ).
                                  waitForElementVisible ( '//SPAN[@class="title-box ng-binding"]', 5000 ).
                                  //Getting the Title of the Destination
                                  getText ( '//SPAN[@class="title-box ng-binding"]', function ( searchTitle ) {
                                    //Checking whether the Title is equal to result obtained
                                    if ( searchTitle.value == excel.B[incrementer] ) {
                                      chkSearch.
                                      //Updating the Pass status in the Excel sheet
                                      writeToExcelPass ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3 );
                                    } else {
                                      chkSearch.
                                      //Updating the Fail status in the Excel sheet
                                      writeToExcelFail ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3, 4, "Unable to locate the Searched content" );
                                    }
                                  } )
                                } else {
                                  //write to fail status as searched Des is not visible
                                  chkSearch.
                                  //Updating the Fail status in the Excel sheet
                                  writeToExcelFail ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3, 4, "Searched Destination is not visible" );
                                  this.verify.fail ( selectSearchedDes.value.length, 'not equal to null', 'Searched Des is not visible' );
                                }
                              } );
                            } );
                          } else {
                            chkSearch.
                            //Updating the Fail status in the Excel sheet
                            writeToExcelFail ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3, 4, "Searched Destination is not present in the list" );
                            //write to fail status as searched Des is not Present
                            this.verify.fail ( searchDes.value.length, 'not equal to null', 'Searched Destination is not present in the list' );
                          }
                        }
                        //If the condition fails then update the Fail status in the Excel
                        else {
                          chkSearch.
                          //Updating the Fail status in the Excel sheet
                          writeToExcelFail ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3, 4, "Please try again with the another destination" );
                        }
                      } );
                    } );
                  }
                 else {
                chkSearch.
                //Updating the Fail status in Excel sheet
                writeToExcelFail ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3, 4, "Your searched Destination is not in the List page Please try again with some other destination" );
                  }
                } );
              } catch ( e ) {
                chkSearch.
                writeToExcelFail ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3, 4, "Please try again with the another destination" );
              }
            } );
          }
        } );
      } catch ( e ) {
        chkSearch.
        writeToExcelFail ( 'portalx.xlsx', 'DestinationSearchFun', 2, 3, 4, "Please try again with the another destination" );
      }
    }
  },
}
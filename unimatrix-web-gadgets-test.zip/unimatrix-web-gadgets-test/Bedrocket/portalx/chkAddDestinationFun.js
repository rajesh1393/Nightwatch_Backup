var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: ['addDestination'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'AddDestination': function ( addDestination ) {
    //Setting up the Page object model
    var excel = addDestination.globals.excelCol;
    var splitted_Content = [];
    var distroName = [];
    var realmSelection = [];
    var addResults = [];
    var addResultsNavi = [];
    //Manipulating the data from the Excel sheet
    for ( let incExcel = 1; incExcel <= excel.B.length - 1; incExcel++ ) {
      distroName = excel.B[incExcel].split ( ',' );
      realmSelection = excel.C[incExcel].split ( ',' );
    }
    //Exception handling
    for ( let inc = 0; inc < realmSelection.length; inc++ ) {
      try {
        addDestination.
        useXpath ( ).
        // Navigating to Add Dashboard page
        //Clicking the Destination link from the side bar
        click ( "//Span[text()='destinations']" ).
        //Clikcing the Add btn 
        useCss ( ).
        click ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope" ).
        useXpath ( ).
        //Clikcing the New Destination button from the Toggle dropdown
        click ( "//li[contains(.,'New Destination')]" ).
        //Clicking the Destination Name Text field
        click ( "//INPUT[@name='destinationName']" ).
        //Setting the Value in Destination Name field
        setValue ( "//INPUT[@name='destinationName']", distroName[inc]).
        //Clicking the Realm DrpDown field
        click ( "//DIV[@class='no-edit-field']" ).
        //Selecting the Realm from the Dropdown
        getText ( "//DIV[@class='flyout-destination-realm-menu dropdown-menu ng-scope']/ul", function ( getDrpDown ) {
          //Declaring the Dropdown contents in the drpDownContent
          var drpDownContent = getDrpDown.value;
          //Removing /n from the Array
          splitted_Content = drpDownContent;
          //Checking whether the content contains the Expected Realm in it.
          var expectedContent = splitted_Content.trim == realmSelection[inc].trim;
          //Getting the Index number of the Realm
          var index_Location = splitted_Content == realmSelection[inc];
          //Adding one to that index gives us the Position of the location
          var concat_Location = index_Location + 0;
          //Condition Checking whether the Expected content is present
          if ( expectedContent == true ) {
            addDestination.
            useXpath ( ).
            pause ( 5000 ).
            //Clicking the Expected Realm
            click ( "//DIV[@class='flyout-destination-realm-menu dropdown-menu ng-scope']/ul/li["+concat_Location+"]" ).
            pause ( 5000 ).
            //Clicking the Create Button
            click ( "//BUTTON[@class='cta-button'][text()='CREATE']" ).
            useXpath ( ).
            pause ( 3000 ).
            //Checking for the Falsh message to be displyed
            waitForElementVisible ( "//header/ng-include/div/span", 15000, false, function ( getalertss ) {
              addDestination.
              //Checking the content inside the Flash message
              getText ( "//header/ng-include/div/span", function ( getFlashMsg ) {
                if ( getFlashMsg.value == "Destination Created!" ) {
                  //Updating the Pass status in the Add Results array                  
                  addResults.push ( "Pass" );
                } else {
                  //if fails updating the Fail string in the Add results array
                  addResults.push ( "Fail" );
                }
              } );
              addDestination.pause ( 5000 );
              addDestination.
              //Checking whether after the successful Destination creation, the control is navigated to the Destination Index page
              waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='destinations']", 5000, false, function ( getNavigated ) {
                if ( getNavigated.value.length != null ) {
                  addResultsNavi.push ( "Pass" );
                } else {
                  addResultsNavi.push ( "Fail" );
                }
              } );
            } );
          } else if ( realmSelection[inc]== null ) {
            addDestination.
            //Updating the Fail status in the Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'AddDestination', 3, 4, 5, "Please enter realm name in Excel sheet for adding '" + realmSelection[inc]+ "' Destination" );
          } else {
            addDestination.
            //Updating the Fail status in the Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'AddDestination', 3, 4, 5, "Please check the Realm name" );
          }
        } );
      } catch ( e ) {
        addDestination.
        writeToExcelFail ( 'portalx.xlsx', 'AddDestination', 3, 4, 5, e );
      }
    }
    if ( addResults.includes ( "Fail" ) ) {
      addDestination.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'AddDestination', 2, 4, 5, "Flash message is not displayed" );
    } else {
      addDestination.
      //Updating Pass status in the Excel sheet
      writeToExcelPass ( 'portalx.xlsx', 'AddDestination', 2, 4 );
    }
    if ( !addResultsNavi.includes ( "Fail" ) ) {
      addDestination.
      //Updating the Pass status in Excel sheet             
      writeToExcelPass ( 'portalx.xlsx', 'AddDestination', 3, 4 );
    }
    else {
      addDestination.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'AddDestination', 3, 4, 5, "After successful creation of Destination, control is not navigated to Indexpage" );
    }
  }
}
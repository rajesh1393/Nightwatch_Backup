//this function is for check and Add the Contentlist
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'portalx.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'NewFolderEdit' ];
var contentTitle = [ ];
var renameFolder = [ ];
var categoryName = [ ];
var categoryType = [ ];
var language = [ ];
var createCategory = [ ];
var expectedCount, excelData, actualLabel, splitCategory, splitProvider, providerData, categoryData;
var currentCount ;
var actualCount ;
var getData, rowCount = 1;
var dataProvider, dataCategory = 0;
module.exports = {
  tags: [ 'newFolderEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  'NewFolderEdit': function ( newFolderEdit ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[1] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[excelData].v );
      }
      //Read categoryName
      if ( excelData.includes ( 'B' ) ) {
        renameFolder.push ( worksheet[excelData].v );
      }
      //Read categoryName
      if ( excelData.includes ( 'C' ) ) {
        categoryName.push ( worksheet[excelData].v );
      }
      //Read categoryType
      if ( excelData.includes ( 'D' ) ) {
        categoryType.push ( worksheet[excelData].v );
      }
      //Read language Title
      if ( excelData.includes ( 'E' ) ) {
        language.push ( worksheet[excelData].v );
      }
      //Read createCategory
      if ( excelData.includes ( 'F' ) ) {
        createCategory.push ( worksheet[excelData].v );
      }
    }
    if ( contentTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;
        newFolderEdit.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Folder Menu in Sidebar
        waitForElementVisible ( "//a/span[contains(.,'folders')]", 4000, false, function ( checkFolderMenu ) {
          if ( checkFolderMenu.value == true ) {
            newFolderEdit.pause ( 4000 ).useXpath ( ).
            //Verify the Folder Menu is visible in the sidebar
            verify.visible ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Click on the Folder Menu in sidebar
            click ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Get the Current count in the Content page
            getText ( "//div[@class='index-header-wrapper controls']/span[1]", function ( currentCountResult ) {
              //div[@class='index-header-wrapper controls']/span[@ng-if='!categoryItems && !artifactsPage && !loading']
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
               currentCount = currentCount.split ('Folders');
              }
              newFolderEdit.pause ( 4000 ).
               //Get the location for the Folder name in the page
              getLocationInView ( "//folder-cell/div/span[contains(.,'"+ contentTitle[ getData ] +"')]" ).
              pause(4000).
              //Wait for Folder name box is visible in the listing page
              waitForElementVisible ("//folder-cell/div/span[contains(.,'"+ contentTitle[ getData ] +"')]", 9000, false, function ( checkFolderName ) {
                if (checkFolderName.value == true) {
                  newFolderEdit.pause ( 4000 ).useXpath ( ).
                  //Wait for toggle menu is visible in the listing page
                  waitForElementVisible ( "//folder-cell/div/span[contains(.,'"+ contentTitle[ getData ] +"')]/descendant::toggle-menu/span", 9000, false, function ( checkToggleBtn ) {
                    if ( checkToggleBtn.value == true ) {
                      newFolderEdit.pause ( 4000 ).useXpath ( ).
                      //Click on the toggle menu in the listing page
                      click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[ getData ] +"')]/descendant::toggle-menu/span" ).
                      pause ( 4000 ).
                      //Wait for Rename button is visible in the dropdown list
                      waitForElementVisible ( "//folder-cell/div/span[contains(.,'"+ contentTitle[ getData ] +"')]/descendant::div/ul/li[contains(.,'Configure')]", 9000, false, function ( checkConfigureBtn ) {
                        if ( checkConfigureBtn.value == true ) {
                          newFolderEdit.pause ( 4000 ).useXpath ( ).
                          //Click on the Rename button in the dropdown list
                          click ( "//folder-cell/div/span[contains(.,'"+ contentTitle[ getData ] +"')]/descendant::div/ul/li[contains(.,'Configure')]" ).
                          pause ( 4000 ).
                          //Get the location for the save
                          getLocationInView("//div/button[contains(@class,'cta_inactive')]").
                          pause ( 4000 ).
                          //Wait for New Folder button is visible in the dropdown list
                          waitForElementVisible ( "//div/button[contains(@class,'cta_inactive')]", 4000, false, function ( checkInactiveSave ) {
                            if ( checkInactiveSave.value == true ) {
                              newFolderEdit.pause ( 4000 ).  
                              //Get the Location for the label Name         
                              getLocationInView("//div/span[@class='title-box ng-binding']").           
                              //Get the Label text in the Folder Page
                              getText ( "//div/span[@class='title-box ng-binding']", function ( getLabelName ) {
                                actualLabel = getLabelName.value;
                                if ( actualLabel == contentTitle[ getData ] ) {
                                  newFolderEdit.useXpath ( ).pause ( 4000 ).
                                  //Wait for the Folder name is visible in the page
                                  waitForElementVisible ( "//form/input[@name='folderName']", 4000, false ).
                                  pause ( 4000 ).
                                  //Verify the the Folder name is visible in the page
                                  clearValue ( "//form/input[@name='folderName']" ).
                                  pause ( 4000 ).
                                  //Enter the Data in the Folder name field
                                  setValue ( "//form/input[@name='folderName']", renameFolder[ getData ] ).
                                  pause ( 4000 )
                                  if ( categoryName[ getData ] != undefined ) {                            
                                    newFolderEdit.useXpath ( ).
                                    //Wait for the Category field is visible in the page
                                    waitForElementVisible ( "//div/input[@type='text']", 4000, false ).
                                    pause ( 4000 ).
                                    //Enter the Data in the Category field
                                    setValue ( "//div/input[@type='text']", categoryName[ getData ] ).
                                    pause ( 4000 ).
                                    //Wait for the Category present in the field
                                    waitForElementPresent ( "//div[1]/div[@class='suggestion-item']/span[@class='category-name ng-binding']", 4000, false, function ( checkCategoryType ) {
                                      console.log ( "checkCategoryType", checkCategoryType )
                                      if ( checkCategoryType.value == true  ) {
                                        newFolderEdit.useXpath ( ).pause ( 4000 ).
                                        //Verify for the Category is visible in the page                               
                                        verify.visible ( "//div/div[@class='suggestion-item']/span[@class='category-name ng-binding'][text( )[normalize-space(.)='"+ categoryName[ getData ] +"']]" ).
                                        pause ( 4000 ).
                                        //Click on the Categories in the list
                                        click ( "//div/div[@class='suggestion-item']/span[@class='category-name ng-binding'][text( )[normalize-space(.)='"+ categoryName[ getData ] +"']]" )
                                      }
                                      else {
                                        if ( createCategory[ getData ] != undefined ) {
                                          newFolderEdit.pause ( 4000 ).useXpath ( ).
                                          //Wait for the Create category is visible in the dropdown list
                                          waitForElementVisible ( "//div/ul/li/a[text( )[normalize-space(.)='"+ createCategory[ getData ] +"']]", 9000, false ).
                                          pause ( 4000 ).
                                          //Click on the Create category in the dropdown list
                                          click ( "//div/ul/li/a[text( )[normalize-space(.)='"+ createCategory[ getData ] +"']]" ).
                                          pause ( 4000 )
                                        }
                                        else {
                                          newFolderEdit.pause ( 4000 ).useCss ( ).
                                          //Key press on Enter key
                                          keys ( newFolderRename.Keys.ENTER ).                                         
                                          keys ( newFolderRename.Keys.ENTER )
                                        }
                                      }
                                    } );
                                  }
                                  var splitCategory = categoryType[ getData ].split (',');
                                  for ( let categoryData = 0, dataCategory = 0; categoryData < splitCategory.length; categoryData++ ) {
                                    dataCategory++;
                                    newFolderEdit.useXpath ( ).pause ( 4000 ).
                                    //Get the location for Category Type data field
                                    getLocationInView ( "//div/ul/li/div/label[text( )[normalize-space(.)='"+ splitCategory[categoryData] +"']]" ).
                                    pause ( 4000 ).
                                    //Wait for the category Type field is visible in the page
                                    waitForElementVisible ( "//div/ul/li/div/label[text( )[normalize-space(.)='"+ splitCategory[categoryData] +"']]", 9000, false, function ( checkCategoryType ) {
                                      if ( checkCategoryType.value == true ) {
                                        newFolderEdit.useXpath ( ).pause ( 4000 ).
                                        //Click on the category type data in the field
                                        click ( "//div/ul/li/div/label[text( )[normalize-space(.)='"+ splitCategory[categoryData] +"']]" ).
                                        pause ( 4000 )
                                        if ( dataCategory == splitCategory.length ) {
                                          var splitProvider = language[ getData ].split (',');
                                          for ( let providerData = 0, dataProvider = 0; providerData < splitProvider.length; providerData++ ) {
                                            dataProvider++;
                                            newFolderEdit.useXpath ( ).pause ( 4000 ).
                                            //Get the location for Language Type data field
                                            getLocationInView ( "//div/ul/li/div/label[@class='radio-button-label ng-binding'][text( )[normalize-space(.)='"+ splitProvider[providerData] +"']]"  ).
                                            pause ( 4000 ).
                                            //Wait for the Language field is visible in the page
                                            waitForElementVisible ( "//div/ul/li/div/label[@class='radio-button-label ng-binding'][text( )[normalize-space(.)='"+ splitProvider[providerData] +"']]", 9000, false, function ( checkLanguageType ) {
                                              if ( checkLanguageType.value == true ) {
                                                newFolderEdit.useXpath ( ).pause ( 4000 ).
                                                //Click on the Language type data in the field
                                                click ( "//div/ul/li/div/label[@class='radio-button-label ng-binding'][text( )[normalize-space(.)='"+ splitProvider[providerData] +"']]" ).
                                                pause ( 4000 ).
                                                //Get the Cancel button location in the page
                                                getLocationInView ( "//div/button[@class='cancel-button']" ).
                                                pause ( 4000 ).
                                                //Wait for cancel button is visible in the page
                                                waitForElementVisible ( "//div/button[@class='cancel-button']", 4000, false ).
                                                pause ( 4000 ).
                                                //Wait for save button is visible in the page
                                                waitForElementVisible ( "//div/button[@class='cta-button']", 4000, false ).
                                                pause ( 4000 ).
                                                //Click on the Save Button in the page
                                                click ( "//div/button[@class='cta-button']" ).
                                                pause ( 2000 ).useXpath ( ).  
                                                //Get the location of the alert message
                                                getLocationInView ( "//div[@class='flash-message ng-scope']/span" ).
                                                //Wait for the Alert message is visible in the page
                                                waitForElementVisible ( "//div[@class='flash-message ng-scope']/span", 9000, false, function ( checkAlertMsg ) {
                                                	if ( checkAlertMsg.value == true ) {   
                                                		newFolderEdit.useXpath ( ).  
                                                		//Get the Value of the alert message in the page                   
                                               			getText ( "//div[@class='flash-message ng-scope']/span", function ( textGetting ) {
        	                                       			if ( textGetting.value == 'Folder Saved!') {
        	                                       				newFolderEdit.useXpath ( ).pause ( 4000 ).
        	                                        			//Wait for Folder menu is visible in the sidebar
        	                                        			waitForElementVisible ( "//a/span[contains(.,'folders')]", 4000, false ).
        	                                       				pause ( 4000 ).
        				                                        //Click on the Folder menu in sidebar
        				                                        click ( "//a/span[contains(.,'folders')]" ).
        				                                        pause ( 10000 ).useXpath ( ).
        				                                        //Verify the Total count label is visible in the Folder page
        				                                        verify.visible ( "//div/span[@class='folder-count-text ng-binding ng-scope']" ).
        				                                        pause ( 4000 ).
        				                                        //Get Actual Total Count after created in the Content 
        				                                        getText ( "//div/span[@class='folder-count-text ng-binding ng-scope']", function ( actualCountResult ) {
        				                                          if ( actualCountResult.status != -1 ) {
        				                                            actualCount = actualCountResult.value;
        				                                            actualCount = actualCount.split ('Folders');                                        
        				                                            expectedCount = ( +currentCount[0] )
        				                                            if ( actualCount[0] == expectedCount ) {
        				                                              //Write the Excel to PASS Result and Reason
        				                                              newFolderEdit.writeToExcelPass ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7 );
        				                                            }
        				                                            else {
                                                              this.verify.fail ( actualCountResult.value, 'true', 'actual value is not displayed in the page' );
        				                                              //Write the Excel to FAIL Result and Reason
        				                                              newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "ActualResult: '"+ actualCount +"' in the Total Count After Added New Folder. ExpectedResult: should be'" + expectedCount + "' in the Total Count" );
        				                                            }
        	                                          			}
        	                                        			} ); 
        	                                        		}
        			                                        else {
                                                        this.verify.fail ( textGetting.value, 'true', 'Text value is not displayed in the page' );
        			                                        	//Write the Excel to FAIL Result and Reason
                                                				newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "Actual alert message as: '"+ textGetting.value +"',After Created New Folder. ExpectedResult: should be 'New Folder Created!'" );
        			                                        }
        			                                      } ); 
        	                                        }
        	                                        else {
                                                    this.verify.fail ( checkAlertMsg.value, 'true', 'New Folder Created message is not displayed in the page' );
        	                                        	//Write the Excel to FAIL Result and Reason
                                                		newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "New Folder Created message is not displayed in the page" );
        	                                        }
                                                } );                                           
                                              }
                                              else {
                                                this.verify.fail ( checkLanguageType.value, 'true', 'Language Type is not displayed in the New folder page' );
                                                //Write the Excel to FAIL Result and Reason
                                                newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "Language Type is not displayed in the New folder page" );
                                              }
                                            } );
                                          }
                                        }
                                      }
                                      else {
                                        this.verify.fail ( checkCategoryType.value, 'true', 'Category Name is not displayed in the New folder page' );
                                        //Write the Excel to FAIL Result and Reason
                                        newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "Category Name is not displayed in the New folder page" );
                                      }
                                    } );
                                  }
                                }
                                else {
                                  this.verify.fail ( getLabelName.value, 'true', 'Label Name is not displayed in the New folder page' );
                                  //Write the Excel to FAIL Result and Reason
                                  newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "Label Name is not displayed in the New folder page" );
                                }
                              } );
                            }
                            else {
                              this.verify.fail ( checkInactiveSave.value, 'true', 'Rename Button is displayed in the Dropdown list' );
                              //Write the Excel to FAIL Result and Reason
                              newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "Inactive Save button is not displayed in the list" ) 
                            }
                          } );
                        }
                        else {
                          this.verify.fail ( checkConfigureBtn.value, 'true', 'Configure Button is not displayed in the listing page' );
                          //Write the Excel to FAIL Result and Reason
                          newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7,8, "Configure Button is not displayed in the listing page" )
                        }
                      });
                    }
                    else {
                      this.verify.fail ( checkToggleBtn.value, 'true', 'Toggle menu is not displayed in the listing page' );
                      //Write the Excel to FAIL Result and Reason
                      newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7,8, "Toggle menu is not displayed in the listing page" )
                    }
                  });
                }
                else {
                  this.verify.fail ( checkFolderName.value, 'true', 'Folder Name is not displayed in the listing page' );
                  //Write the Excel to FAIL Result and Reason
                  newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7,8, "Folder Name is not displayed in the listing page" )
                }
              } );
            } );
          }
          else {
            this.verify.fail ( checkFolderMenu.value, 'true', 'Folders menu is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            newFolderEdit.writeToExcelFail ( 'portalx.xlsx', 'NewFolderEdit', rowCount, 7, 8, "Folders menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    newFolderEdit.end ( );
  }
}
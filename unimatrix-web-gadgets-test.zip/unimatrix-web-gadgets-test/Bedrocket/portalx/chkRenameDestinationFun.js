var ErrMsg_DestiName;
var actualIndexBeforeAdd = [ ];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkRenameDestinationFun' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'RenameDestination': function ( chkRename ) {
    //Setting up the Page object model
    var excel = chkRename.globals.excelCol;
    for ( let incrementer = 1; incrementer < excel.C.length; incrementer++ ) {
      chkRename.
      useXpath ( ).
      //Navigating to Destination Index page
      click ( "//Span[text()='destinations']" ).
      pause ( 15000 ).
      //Checking whether the Destination is displayed in Index Page
      waitForElementPresent ( " ( //SPAN[@ng-click='buildShowUrl()'] )[1]", 5000, false,function ( chkVisibility ) {
        if ( chkVisibility.value != false ) {
      chkRename.
      //Clicking on the Vertical ellipses of the first Destination
      click ( '//destination-cell[1]/*//span/span[@class="options-container"]/toggle-menu/span' ).
      //Clicking on the Destination Name Text field
      click ( '//destination-cell[1]/*//LI[@ng-click="setFocusInput()"]' ).
      //Setting up the value in the Destination Name Text field
      setValue ( '//SPAN[@id="' + excel.B[incrementer] + '"]/input', excel.C[incrementer] ).
      pause ( 8000 ).
      //Clicking on the Text field
      keys ( chkRename.Keys.ENTER );
      chkRename.
      pause ( 5000 );
      chkRename.
      //Checking whether the label of the Destination is displayed
      waitForElementPresent ( "//SPAN[@id='" + excel.C[incrementer] + "']", 5000, false, function ( chkLabel ) {
        chkRename.
        //Getting the Updated Destination Name
        getText ( "//SPAN[@id='" + excel.C[incrementer] + "'][1]", function ( getDestName ) {
          //Checking whether the Updated destination name is as same as the Excel sheet
          if ( getDestName.value == excel.C[incrementer] ) {
            chkRename.
            //Updating the Pass status in Excel sheet
            writeToExcelPass ( 'portalx.xlsx', 'RenameDestination', ++incrementer, 4 );
          } else {
            chkRename.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'RenameDestination', ++incrementer, 4, 5, 6, "Some thing went wrong, Please try again" );
          }
        } );
      } );
    }
    else {
      chkRename.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'RenameDestination', ++incrementer, 4, 5, 6, "Destination list page is Empty it seems, Please add a Destination and then try again" );
    }
  });
  }
}
}
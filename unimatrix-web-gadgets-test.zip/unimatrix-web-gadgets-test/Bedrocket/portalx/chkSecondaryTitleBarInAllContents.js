//Checking the Title section in AllContent page Page
module.exports = {
  tags: [ 'chkSecondaryTitleBarInAllContent page' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkTitleBarInAllContentsPage': function ( chkTitleBar ) {
    var excel = chkTitleBar.globals.excelCol;
    for ( let inc = 0; inc < 1; inc++ ) {
      try {
        chkTitleBar.
        useXpath ( ).
        //Clicking the AllContent page link from the side bar
        click ( "//Span[text()='all content']" ).
        //Checking whether the control is navigated to AllContent page page and checking whether the Title of the page is displayed
        waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='all content']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            //Updating the Pass status in Excel sheet
            chkTitleBar.
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 2, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in the Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 2, 2, 3, "Title of the relavant page is not displayed" );
          }
        } );
        chkTitleBar.
         //Checking whether the index count of the AllContent page is displayed.
         waitForElementPresent ( "//SPAN[@class='artifact-count-text ng-binding']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            //Updating the Pass status in Excel sheet
            chkTitleBar.
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 3, 2 );
          }
          else {
            chkTitleBar.
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 3, 2, 3, "Index count of the AllContent page page is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the index count of the AllContent page is displayed.
         waitForElementPresent ( "//DIV[@ng-if='artifactsPage']",5000,false,function ( chkVisiblity ) {
          chkTitleBar.
        //Checking the Text displayed is matching the expected one.
        getText ( "//DIV[@ng-if='artifactsPage']", function ( getText ) {
          //manipulatin the obtained string
          var expText = getText.value.replace(/\n/g,' '); 
          //Getting the Substring of the replaced String
          expText = expText.substr(0, expText.indexOf('|')); 
          //Checking the obtained text contains the expected text
          if ( expText.includes ( "Language: All" ) ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 4, 2 );
          }
          else {
            chkTitleBar.
            //Updating the fail status in the Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 4, 2, 3, "Filter by language option is not displayed in the AllContent page Index page" );
          }
        } ) ;
      } );
         chkTitleBar.
         //Checking whether the Search icon is displayed in AllContent page.
         waitForElementPresent ( "//INPUT[@id='search_input']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 5, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 5, 2, 3, "Search icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the Sortby icon is displayed in AllContent page.
         waitForElementPresent ( "//I[@ng-click='toggleElement( $event )']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 6, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 6, 2, 3, "Search icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the List icon is displayed in AllContent page.
         waitForElementPresent ( "//I[@class='index-header-icon listview-icon current_presentation']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 7, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 7, 2, 3, "Search icon is not displayed" );
          }
        } );
         chkTitleBar.
         //Checking whether the Grid icon is displayed in AllContent page.
         waitForElementPresent ( "//I[@class='index-header-icon gridview-icon']",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 8, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 8, 2, 3, "Search icon is not displayed" );
          }
        } );
         chkTitleBar.
         useCss ( ).
         //Checking whether the Add icon is displayed in AllContent page.
         waitForElementPresent ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope",5000,false,function ( chkVisiblity ) {
          if ( chkVisiblity.value != false ) {
            chkTitleBar.
            //Updating the Pass status in Excel sheet
            writeToExcelPass( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 9, 2 );
          }
          else {
            chkTitleBar.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 9, 2, 3, "Search icon is not displayed" );
          }
        } );

       } catch ( e ) {
        chkTitleBar.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'chkTitleBarInAllContentsPage', 3, 4, 5, "Execution of the script terminated due to "+e+" reason");
      }
    }
  }
}
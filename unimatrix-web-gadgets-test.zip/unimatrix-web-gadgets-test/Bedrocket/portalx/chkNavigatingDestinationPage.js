var ErrMsg_DestiName;
var actualIndexBeforeAdd = [ ];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkNavigatingDestinationPage' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'NaviToDestiniPage': function ( Navigating ) {
    //Setting up the Page object for the Destination Page
    try {
      Navigating.
      useXpath ( ).
      //Checking the Destination is displayed in the Sidebar
      waitForElementPresent ( "//Span[text()='destinations']", 15000, false, function ( check_Sidebar_Lnk ) {
        Navigating.
        //Clicking the Destination link from the side bar
        click ( "//Span[text()='destinations']" ).
        useCss ( ).
        //Waiting for the Add Button visibility
        waitForElementPresent ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope", 15000, false ).
        //Clikcing the Add btn 
        click ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope" ).
        //Clikcing the New Destination button from the Toggle dropdown
        useXpath ( ).
        click ( "//li[contains(.,'New Destination')]" ).
        //Checking whether the control is navigated to Add Destination Page
        waitForElementPresent ( "//BUTTON[@class='cancel-button'][text()='CANCEL']", 20000, false, function ( check_Sidebar_Lnk ) {
          //If the condition is true then it is passed
          if ( check_Sidebar_Lnk.value != 0 ) {
            Navigating.
            //Updating the Pass status in the excel sheet
            writeToExcelPass ( 'portalx.xlsx', 'NaviToDestiniPage', 2, 2 );
          } else {
            //Updating the Fail status in the excel sheet
            Navigating.
            writeToExcelFail ( 'portalx.xlsx', 'NaviToDestiniPage', 2, 2, 3, "Unable to navigate to Add Destination page" );
          }
        } );
      } );
    } catch ( e ) {
      Navigating.
      //Updating the fail status in excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'NaviToDestiniPage', 2, 2, 3, "Unable to navigate to Add Destination page" );
    }
  },
}
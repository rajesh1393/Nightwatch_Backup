
module.exports = {
  tags: [ 'chkNoContentPlaceHolderInFolders' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  //Checking the Search functionality in the Side bar of the Application under Folders Tab
  'chkNoContentPlaceHolderInFoldersFun': function ( chkSearch ) {
    var placeholderText;
    var placeholderSubText;
    //Setting up the Page object model
    var excel = chkSearch.globals.excelCol;
    //Exception handling
    for ( let inc = 1; inc <= excel.B.length-1; inc++ ) {
      try {
        chkSearch.
        useXpath ( ).
        //Checking whether the Folders option is displayed in the Side bar
        waitForElementPresent ( "//Span[text()='folders']",5000, false, function ( chkFoldersVisibility ) { 
          if ( chkFoldersVisibility.value != false ) {
            chkSearch.
            //Clicking the Folders menu under the side bar
            click ( "//Span[text()='folders']" ).
            //Checking whether the search field is displayed in the ide bar
            waitForElementPresent ( "//div[@class='search-wrapper ng-scope']/input",5000, false, function ( chkSearchField ) {
              if ( chkSearchField.value != false ) { 
                chkSearch.
                //Clicking the Search field
                click ( "//div[@class='search-wrapper ng-scope']/input" ).
                //Entering the Search text into the Search field.
                setValue ( "//div[@class='search-wrapper ng-scope']/input", excel.B [ inc ] ).
                pause ( 3000 ).
                //Checking whether the Searched results contains appropriate values with respect to searched element
                waitForElementPresent ( "//DIV[contains(text(),'"+excel.B [ inc ]+"')]", 5000, false,function ( chkSrchResult ) {
                  if ( chkSrchResult.value != false ) {
                    chkSearch.
                    //Clicking the appropriate page from the search result
                    click ( "//DIV[contains(text(),'"+excel.B [ inc ]+"')]" ).
                    //Checking whether the No content image place holder is displayed
                    waitForElementPresent ( "//I[@class='no-content-icon']", 5000, false, function ( chkGif ) {
                      if ( chkGif.value != false ) {
                        chkSearch.
                        //Updating the Pass status in Excel sheet
                        writeToExcelPass ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3 );
                      }
                      else {
                        chkSearch.
                        //Updating the Fail status in Excel sheet
                        writeToExcelFail ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3, 4, "Gif image is not displayed/This page contains contents" );
                      }
                    } );
                    chkSearch.
                     //Checking whether the No content image place holder is displayed
                     waitForElementPresent ( "//div[@class='no-content-container ng-scope']/span", 5000, false, function ( chkPlaceholderText ) {
                      if ( chkPlaceholderText.value != false ) {
                        chkSearch.
                      //Getting the Place holder text
                      getText ( "//div[@class='no-content-container ng-scope']/span", function ( getSubText ) {
                        //Storing the place holder text in a variable
                        placeholderText = getSubText.value;
                        chkSearch.
                      //Getting the Place holder sub text
                      getText ( "//div[@class='no-content-container ng-scope']/span[2]", function ( getSubsText ) {
                        //Storing the place holder Sub text in a variable
                        placeholderSubText = getSubsText.value;
                        //Checking whether the Place holder text is displayed
                        if ( placeholderText == "No Content!" && placeholderSubText == "Your content will appear here." ) {
                          chkSearch.
                        //Updating the Pass status in Excel sheet
                        writeToExcelPass ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3 );
                      }
                      else {
                        chkSearch.
                        //Updating the Fail status in Excel sheet
                        writeToExcelFail ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3, 4, "Place holder text is not displayed as expected" );
                      }
                    } );
                    } );  
                    }
                    else {
                      chkSearch.
                      //updating the Fail status in Excel sheet
                      writeToExcelFail ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3, 4, "Place holder text is not displayed" );
                    }
                  } );
                   }
                   else {
                    chkSearch.
                    //Updating the Fail status in Excel sheet
                    writeToExcelFail ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3, 4, "Searched result not found in the Search result" );
                  }
                } );
              }
              else {
                chkSearch.
                //Updating the Fail status in Excel sheet
                writeToExcelFail ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3, 4, "Unable to locate Folders in the search field in the Side bar" );
              }
            } );
}
else { 
  chkSearch.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3, 4, "Unable to locate Folders in the side bar of the Application" );
        }
      } );
} catch ( e ) {
  chkSearch.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'chkNoContentPlaceHolderInFoldersFun',++inc, 3, 4, "Automation script terminated unexpectedly due to "+e+" reason, please try again" );
      }
    }
  }
}
var currRealmName;
module.exports = {
  tags: ['chkSettingsFun'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'ErrMsgInSettingsPage': function ( realmEdit ) {
    try {
      realmEdit.
      useCss ( ).
      pause ( 3000 ).
      //Checking whether the realm name is displayed in the Sidebar of the Application
      waitForElementVisible ( ".current-realm-text.ng-binding", 4000, false ).
      //Getting the current realm name from the Sidebar of the application
      getText ( ".current-realm-text.ng-binding", function ( checkTheme ) {
        //Storing the current realm name in a variable
        currRealmName = checkTheme.value;
      } );
      realmEdit.
      useXpath ( ).
      //CHecking whether the Settings link is displayed
      waitForElementVisible ( "//Span[text()='settings']", 15000, false, function ( getStatus ) {
        if ( getStatus.value == true ) {
          realmEdit.
          //Navigating to the Settings page
          click ( "//Span[text()='settings']" ).
          pause ( 5000 ).
          //Checking whether the Realm name is correctly displayed in the Current realm name field
          waitForElementVisible ( "//INPUT[@disabled='']", 15000, false, function ( getCurrRealmStatus ) {
            if ( getCurrRealmStatus.value == true ) {
              realmEdit.
              //Checking whether the Current realm name displayed in the Settings page is as same as the Sidebar
              getValue ( "//INPUT[@disabled='']", function ( getCurrRealmName ) {
                if ( getCurrRealmName.value == currRealmName ) {
                  realmEdit.
                  //Checking whether the Input field is displayed in the Settings page
                  waitForElementVisible ( "//INPUT[@required='']", 15000, false, function ( chkVisibility ) {
                    if ( chkVisibility.value == true ) {
                      realmEdit.
                      //Clearing the Value in the Input field
                      clearValue ( "//INPUT[@required='']" ).
                      pause ( 5000 ).
                      //Checking whether the Save button is displayed
                      waitForElementVisible ( "//BUTTON[@class='cta-button'][text()='SAVE']",5000,false ).
                      //Clicking the Save button after clearing the Input field
                      click ( "//BUTTON[@class='cta-button'][text()='SAVE']" ).
                      pause ( 2000 ).
                      //Validating the Error message displayed is matching with the Expected one
                      getText ( "//DIV[@class='error-area']", function ( getErrMsg ) {
                        if ( getErrMsg.value == "Please Enter Realm name" ) {
                         realmEdit.
                         //Updating the Pass status in the Excel sheet
                         writeToExcelPass ( 'portalx.xlsx', 'ErrMsgInSettingsPage', 2,2 );
                        } else {
                          realmEdit.
                          //Updating the Fail status in the Excel sheet
                          writeToExcelFail ( 'portalx.xlsx', 'ErrMsgInSettingsPage', 2,2,3, "Error Message is not displayed" );
                        }
                      } );
                    } else {
                      realmEdit.
                      //Updating the Fail status in the excel sheet
                      writeToExcelFail ( 'portalx.xlsx', 'ErrMsgInSettingsPage', 2,2,3, "Unable to update the Realm name" );
                    }
                  } )
                } else {
                  realmEdit.
                  //updating the Fail status in the excel sheet
                  writeToExcelFail ( 'portalx.xlsx', 'ErrMsgInSettingsPage', 2,2,3, "It seems that the Crrent realm name displayed in settings page is not as same as in the Realm sidebar" );
                }
              } )
            } else {
              realmEdit.
              //Updating the fail status in Excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'ErrMsgInSettingsPage', 2,2,3, "Current realm name is not displayed" );
            }
          } );
        } else {
          realmEdit.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'ErrMsgInSettingsPage', 2,2,3, "There is a problem while navigating to the Settings page" );
        }
      } );
    } catch ( e ) {
      realmEdit.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'ErrMsgInSettingsPage', 2,2,3, "Please try again it seems there is problem in execution" );
    }
  }
}
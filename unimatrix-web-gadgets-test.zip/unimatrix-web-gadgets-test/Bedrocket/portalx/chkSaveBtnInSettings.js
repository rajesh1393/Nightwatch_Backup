var currRealmName;
module.exports = {
  tags: ['chkSaveBtnInSettings'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkSaveBtnInSettings': function ( chkSaveBtnFun ) {
    try {
      //Storing the Excel global variables in excel
      var excel = chkSaveBtnFun.globals.excelCol;
      chkSaveBtnFun.
      useCss ( ).
      pause ( 3000 ).
      //Waiting for the element to be displayed
      waitForElementVisible ( ".current-realm-text.ng-binding", 4000, false ).
      //Getting the Realm name from the sidebar
      getText ( ".current-realm-text.ng-binding", function ( checkTheme ) {
        currRealmName = checkTheme.value;
      } );
      chkSaveBtnFun.
      useXpath ( ).
      //Checking whether the Settings link is dispalyed
      waitForElementVisible ( "//Span[text()='settings']", 15000, false, function ( getStatus ) {
        //Checking whether the link is displayed
        if ( getStatus.value == true ) {
          chkSaveBtnFun.
          //Clicking the Settings link
          click ( "//Span[text()='settings']" ).
          pause ( 5000 ).
          //Checking whether the Current realm field is dispalyed
          waitForElementVisible ( "//INPUT[@disabled='']", 15000, false, function ( getCurrRealmStatus ) {
            //Condition whether the Input field is displayed
            if ( getCurrRealmStatus.value == true ) {
              chkSaveBtnFun.
              //Getting the value from the input field
              getValue ( "//INPUT[@disabled='']", function ( getCurrRealmName ) {
                //Checking whether the Current realm name is as same as the current realm name
                if ( getCurrRealmName.value == currRealmName ) {
                  chkSaveBtnFun.
                  //If the conditions true then the Control is executed
                  waitForElementVisible ( "//INPUT[@required='']", 15000, false, function ( chkVisibility ) {
                    if ( chkVisibility.value == true ) {
                      chkSaveBtnFun.
                      //Clicking the Save button directly after entering into the Settings page
                      waitForElementVisible ( "//BUTTON[@class='cta-button cta_inactive'][text()='SAVE']", 15000, false, function ( chkBtnStatus ) {
                        if ( chkBtnStatus.value == true ) {
                          chkSaveBtnFun.
                          //Clicking on the inactive save button
                          click ( "//BUTTON[@class='cta-button cta_inactive'][text()='SAVE']" ).
                          pause ( 2000 ).
                          //Checking whether the Flash success message is displayed
                          waitForElementVisible ( "//header/ng-include/div/span", 15000, false, function ( chkForSuccessMsg ) {
                            if ( chkForSuccessMsg.value == true ) {
                              chkSaveBtnFun.
                              //Updating the Fail status in the excel sheet
                              writeToExcelFail ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2, 3, "Even if save button is inactive, User can able to click on Save button and Success message is displayed" );
                            } else {
                              chkSaveBtnFun.
                              //Updating the Pass status in the Excel sheet
                              writeToExcelPass ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2 );
                            }
                           } );
                        } else {
                          chkSaveBtnFun.
                          //Updating the Fail status in the Excel sheet
                          writeToExcelFail ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2, 3, "Save Button is not in inactive state" );
                        }
                      } );
                    } else {
                      chkSaveBtnFun.
                      //Updating the Fail status in the Excel sheet
                      writeToExcelFail ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2, 3, "Realm Name is not same as from the Side bar and in Settings page" );
                    }
                  } );
                } else {
                  chkSaveBtnFun.
                  //Updating the Fail status in the excel sheet
                  writeToExcelFail ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2, 3, "Realm Name is not same as from the Side bar and in Settings page" );
                }
              } )
            } else {
              chkSaveBtnFun.
              //updating the Fail status in the excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2, 3, "It seems that the Crrent realm name displayed in settings page is not as same as in the Realm sidebar" );
            }
          } )
        } else {
          chkSaveBtnFun.
          //Updating the fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2, 3, "Current realm name is not displayed" );
        }
      } );
    } catch  ( e ) {
      chkSaveBtnFun.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'chkSaveBtnInSettings', 2, 2, 3, "Please try again it seems there is problem in execution" );
    }
  }
}
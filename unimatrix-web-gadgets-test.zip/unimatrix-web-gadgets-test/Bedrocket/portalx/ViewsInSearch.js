//this function is for Views In Search the Portalx
var excelRow, excelColumn = 1;
var splitSourceOrder = [ ];           
var splitDestinationOrder = [ ]; 
var currentSource = [ ];
var actualSource = [ ];
var robot = require("robotjs");
module.exports = {
  tags: ['viewsInSearch'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'ViewsInSearch': function ( viewsInSearch ) {   
    var excel = viewsInSearch.globals.excelCol; 
    if ( excel.A.length > 0 ) {
    	for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        viewsInSearch.pause ( 4000 ).useXpath ( ).
        //Wait for left side menu is visible in the page
        waitForElementVisible ( "//div[1]/div/a/span[contains(.,'"+excel.A[excelColumn]+"')]", 9000, false, function ( leftSideMenu ) {
        	viewsInSearch.pause ( 4000 ).useXpath ( ).
          //Click on the left side menu in the page
        	click ( "//div[1]/div/a/span[contains(.,'"+excel.A[excelColumn]+"')]" ).
        	pause ( 4000 )
        	if ( leftSideMenu.value == true ) {
            if ( excel.A[excelColumn] == "folders") {
          		viewsInSearch.pause ( 4000 ).useXpath ( ).
  		        //Wait for the arrow dropdown is visible in the page
  		        waitForElementVisible ( "//div[3]/div/i", 9000, false, function ( folderDropdown ) {
  		        	if ( folderDropdown.value == true ) {
  		        		viewsInSearch.pause ( 4000 ).useXpath ( ).
  		        		//Click on the arrow dropdown
  		        		click ( "//div[3]/div/i" ).
  		        		pause ( 4000 )
  		        	}
  		        } );
		        }
		        var searchData;		        
            if ( excel.B[excelColumn] == 'list' ) {
              viewsInSearch.pause ( 4000 ).useXpath ( ).
              //Wait for the list view is visible in the page
              waitForElementVisible ( "//ng-view/div/div/div[2]/i[1]", 9000, false, function ( checkListView ) {
                if ( checkListView.value == true ) {
                  viewsInSearch.pause ( 4000 ).useXpath ( ).
                  //Click on the list view in the page
                  click ( "//ng-view/div/div/div[2]/i[1]" ).
                  pause ( 4000 ).
                  //Wait for the list view in page is visible in the page
                  waitForElementVisible ( "//index-collection/ng-transclude[@class='list_display']", 9000, false, function ( checkListViewInPage ) {
                    if ( checkListViewInPage.value == true ) {
                      viewsInSearch.pause ( 4000 ).useXpath ( ).
                      //Wait for the search button is visible in the page
                      waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
                        if ( checkSearchBtn.value == true ) {
                          viewsInSearch.useXpath ( ).pause ( 4000 ).
                          //Click on the search field in the portalx index page
                          click ( "//*[@id='search_input']" ).
                          pause ( 2000 ).
                          //Clear the data in the search field in the portalx index page
                          clearValue ( "//*[@id='search_input']" ).
                          pause ( 2000 ).
                          //Enter the data in the search field in the portalx index page
                          setValue ( "//*[@id='search_input']", excel.C[ excelColumn ] ).
                          useCss ( ).pause ( 2000 ).
                          //Press return key
                          keys ( viewsInSearch.Keys.ENTER ).
                          useXpath ( ).pause ( 2000 )
                          switch ( excel.A[excelColumn] ) {
           								 	case "all content":
           								 	  viewsInSearch.useXpath ( ).pause ( 4000 ).
                              //Wait for the searched Result is visible in the listing page
             									waitForElementVisible ( "//item-cell[1]/div/span/a[1]/span[1]", 9000, false, function ( checkSearchedResult ) {
                            		if ( checkSearchedResult.value == true ) {
                              		viewsInSearch.useXpath ( ).pause ( 4000 ).
                                  //Get the title text in the page
                              		getText ( "//item-cell[1]/div/span/a[1]/span[1]", function ( titleTxtList ) {
                                		if ( titleTxtList.value == excel.C[ excelColumn ] ) {
                                  		//Write the Excel to PASS Result and Reason
                                  		viewsInSearch.writeToExcelPass ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4);
                                		}
                                		else {
                                  		this.verify.fail ( titleTxtList.value, 'true', 'Searched Result is not displayed in the listing page' );
                                  		//Write the Excel to FAIL Result and Reason
                                 		  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Actual Title as " +titleTxtList.value+ " and Expected Title as "+excel.C[ excelColumn ]+" in the List View listing page" );
                                		}
                              		} );
                            		}
                            		else {
                              		this.verify.fail ( checkSearchedResult.value, 'true', 'Searched Result is not displayed in the listing page' );
                              		//Write the Excel to FAIL Result and Reason
                              		viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Searched Result is not displayed in the listing page" );
                            		}
                          		} );              
                            break;
            								case "folders":
              								viewsInSearch.useXpath ( ).pause ( 4000 ).
                              //Wait for the searched result is visible in the page
             									waitForElementVisible ( "(//folder-cell[1]//span/a[1]/span[1])[1]", 9000, false, function ( checkSearchedResult ) {
                            		if ( checkSearchedResult.value == true ) {
                              		viewsInSearch.useXpath ( ).pause ( 4000 ).
                                  //Get the title text in the page
                              		getText ( "(//folder-cell[1]//span/a[1]/span[1])[1]", function ( titleTxtList ) {
                                		if ( titleTxtList.value == excel.C[ excelColumn ] ) {
                                  		//Write the Excel to PASS Result and Reason
                                  		viewsInSearch.writeToExcelPass ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4);
                                		}
                                		else {
                                  		this.verify.fail ( titleTxtList.value, 'true', 'Searched Result is not displayed in the listing page' );
                                  		//Write the Excel to FAIL Result and Reason
                                 		  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Actual Title as " +titleTxtList.value+ " and Expected Title as "+excel.C[ excelColumn ]+" in the List View listing page" );
                                		}
                              		} );
                            		}
                            		else {
                              		this.verify.fail ( checkSearchedResult.value, 'true', 'Searched Result is not displayed in the listing page' );
                              		//Write the Excel to FAIL Result and Reason
                              		viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Searched Result is not displayed in the listing page" );
                            		}
                          		} );
							              break;
            								case "destinations":
            									viewsInSearch.useXpath ( ).pause ( 4000 ).
                              //Wait for the Searched Result is visible in the listing page
             									waitForElementVisible ( "(//destination-cell[1]//span//span[1])[2]", 9000, false, function ( checkSearchedResult ) {
                            		if ( checkSearchedResult.value == true ) {
                              		viewsInSearch.useXpath ( ).pause ( 4000 ).
                                  //Get the title text in the page
                              		getText ( "(//destination-cell[1]//span//span[1])[2]", function ( titleTxtList ) {
                                		if ( titleTxtList.value == excel.C[ excelColumn ] ) {
                                  		//Write the Excel to PASS Result and Reason
                                  		viewsInSearch.writeToExcelPass ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4);
                                		}
                                		else {
                                  		this.verify.fail ( titleTxtList.value, 'true', 'Searched Result is not displayed in the listing page' );
                                  		//Write the Excel to FAIL Result and Reason
                                 		  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Actual Title as " +titleTxtList.value+ " and Expected Title as "+excel.C[ excelColumn ]+" in the List View listing page" );
                                		}
                              		} );
                            		}
                            		else {
                              		this.verify.fail ( checkSearchedResult.value, 'true', 'Searched Result is not displayed in the listing page' );
                              		//Write the Excel to FAIL Result and Reason
                              		viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Searched Result is not displayed in the listing page" );
                            		}
                          		} );
							              break;
							            	default:
							            		console.log("Switch data is not avail",excel.A[excelColumn])
							             	break;
          								}
                         
                        }
                        else {
                          this.verify.fail ( checkSearchBtn.value, 'true', 'List View formation is not displayed in the page' );
                          //Write the Excel to FAIL Result and Reason
                          viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "List View formation is not displayed in the page" );
                        }
                      } ); 
                    }
                    else {
                      this.verify.fail ( checkListViewInPage.value, 'true', 'List View formation is not displayed in the page' );
                      //Write the Excel to FAIL Result and Reason
                      viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "List View formation is not displayed in the page" );
                    }
                  } );
                }
                else {
                  this.verify.fail ( checkListView.value, 'true', 'List View Icon is not displayed in the page' );
                  //Write the Excel to FAIL Result and Reason
                  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "List View Icon is not displayed in the page" );
                }
              } );                  
 
            }
            else if ( excel.B[excelColumn] == 'grid' ) {
              viewsInSearch.pause ( 4000 ).useXpath ( ).
              //Wait for the Grid view is visible in the listing page
              waitForElementVisible ( "//ng-view/div/div/div/i[2]", 9000, false, function ( checkGridView ) {
                if ( checkGridView.value == true ) {
                  viewsInSearch.pause ( 4000 ).useXpath ( ).
                  //Click on the grid view icon in the page
                  click ( "//ng-view/div/div/div/i[2]" ).
                  pause ( 4000 ).
                  //Wait for the grid view in page is visible on the page
                  waitForElementVisible ( "//index-collection/ng-transclude[@class='grid_display']", 9000, false, function ( checkGridViewInPage ) {
                    if ( checkGridViewInPage.value == true ) {
                      viewsInSearch.pause ( 4000 ).useXpath ( ).
                      //Wait for the search button is visible in the page
                      waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
                        if ( checkSearchBtn.value == true ) {
                          viewsInSearch.useXpath ( ).pause ( 4000 ).
                          //Click on the search field in the portalx index page
                          click ( "//*[@id='search_input']" ).
                          pause ( 2000 ).
                          //Clear the data in the search field in the portalx index page
                          clearValue ( "//*[@id='search_input']" ).
                          pause ( 2000 ).
                          //Enter the data in the search field in the portalx index page
                          setValue ( "//*[@id='search_input']", excel.C[ excelColumn ] ).
                          useCss ( ).pause ( 2000 ).
                          //Press return key
                          keys ( viewsInSearch.Keys.ENTER ).
                          useXpath ( ).pause ( 2000 )
                          switch ( excel.A[excelColumn] ) {
           								 	case "all content":
           								 	  viewsInSearch.useXpath ( ).pause ( 4000 ).
                              //Wait for the searched result is visible in te listing page
             									waitForElementVisible ( "//item-cell[1]/div/span/a[1]/span[1]", 9000, false, function ( checkSearchedResult ) {
                            		if ( checkSearchedResult.value == true ) {
                              		viewsInSearch.useXpath ( ).pause ( 4000 ).
                                  //Get the title text from the list page
                              		getText ( "//item-cell[1]/div/span/a[1]/span[1]", function ( titleTxtList ) {
                                		if ( titleTxtList.value == excel.C[ excelColumn ] ) {
                                  		//Write the Excel to PASS Result and Reason
                                  		viewsInSearch.writeToExcelPass ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4);
                                		}
                                		else {
                                  		this.verify.fail ( titleTxtList.value, 'true', 'Searched Result is not displayed in the listing page' );
                                  		//Write the Excel to FAIL Result and Reason
                                 		  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Actual Title as " +titleTxtList.value+ " and Expected Title as "+excel.C[ excelColumn ]+" in the List View listing page" );
                                		}
                              		} );
                            		}
                            		else {
                              		this.verify.fail ( checkSearchedResult.value, 'true', 'Searched Result is not displayed in the listing page' );
                              		//Write the Excel to FAIL Result and Reason
                              		viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Searched Result is not displayed in the listing page" );
                            		}
                          		} );              
                            break;
            								case "folders":
              								viewsInSearch.useXpath ( ).pause ( 4000 ).
                              //Wait for the searched result is visible in the page
             									waitForElementVisible ( "(//folder-cell[1]//span/a[1]/span[1])[1]", 9000, false, function ( checkSearchedResult ) {
                            		if ( checkSearchedResult.value == true ) {
                              		viewsInSearch.useXpath ( ).pause ( 4000 ).
                                  //Get the title text in the page
                              		getText ( "(//folder-cell[1]//span/a[1]/span[1])[1]", function ( titleTxtList ) {
                                		if ( titleTxtList.value == excel.C[ excelColumn ] ) {
                                  		//Write the Excel to PASS Result and Reason
                                  		viewsInSearch.writeToExcelPass ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4);
                                		}
                                		else {
                                  		this.verify.fail ( titleTxtList.value, 'true', 'Searched Result is not displayed in the listing page' );
                                  		//Write the Excel to FAIL Result and Reason
                                 		  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Actual Title as " +titleTxtList.value+ " and Expected Title as "+excel.C[ excelColumn ]+" in the List View listing page" );
                                		}
                              		} );
                            		}
                            		else {
                              		this.verify.fail ( checkSearchedResult.value, 'true', 'Searched Result is not displayed in the listing page' );
                              		//Write the Excel to FAIL Result and Reason
                              		viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Searched Result is not displayed in the listing page" );
                            		}
                          		} );
							              break;
            								case "destinations":
            									viewsInSearch.useXpath ( ).pause ( 4000 ).
                              //Wait for the Searched result is visible in the listing page
             									waitForElementVisible ( "(//destination-cell[1]//span//span[1])[2]", 9000, false, function ( checkSearchedResult ) {
                            		if ( checkSearchedResult.value == true ) {
                              		viewsInSearch.useXpath ( ).pause ( 4000 ).
                                  //Get the title text in the page
                              		getText ( "(//destination-cell[1]//span//span[1])[2]", function ( titleTxtList ) {
                                		if ( titleTxtList.value == excel.C[ excelColumn ] ) {
                                  		//Write the Excel to PASS Result and Reason
                                  		viewsInSearch.writeToExcelPass ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4);
                                		}
                                		else {
                                  		this.verify.fail ( titleTxtList.value, 'true', 'Searched Result is not displayed in the listing page' );
                                  		//Write the Excel to FAIL Result and Reason
                                 		  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Actual Title as " +titleTxtList.value+ " and Expected Title as "+excel.C[ excelColumn ]+" in the List View listing page" );
                                		}
                              		} );
                            		}
                            		else {
                              		this.verify.fail ( checkSearchedResult.value, 'true', 'Searched Result is not displayed in the listing page' );
                              		//Write the Excel to FAIL Result and Reason
                              		viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Searched Result is not displayed in the listing page" );
                            		}
                          		} );
							              break;
							            	default:
							            		console.log("Switch data is not avail",excel.A[excelColumn])
							             	break;
          								}
                        }
                        else {
                          this.verify.fail ( checkSearchBtn.value, 'true', 'Grid View formation is not displayed in the page' );
                          //Write the Excel to FAIL Result and Reason
                          viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Grid View formation is not displayed in the page" );
                        }
                      } ); 
                    }
                    else {
                      this.verify.fail ( checkGridViewInPage.value, 'true', 'Grid View formation is not displayed in the page' );
                      //Write the Excel to FAIL Result and Reason
                      viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Grid View formation is not displayed in the page" );
                    }
                  } );
                }
                else {
                  this.verify.fail ( checkGridView.value, 'true', 'Grid View Icon is not displayed in the page' );
                  //Write the Excel to FAIL Result and Reason
                  viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Grid View Icon is not displayed in the page" );
                }
              } );
            }
            else {
              //Write the Excel to FAIL Result and Reason
              viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Views icon is not displayed in the page" );
            }            
          }
          else {
            this.verify.fail ( leftSideMenu.value, 'true', 'Menu is not displayed in the portalx Leftside bar' );
            //Write the Excel to FAIL Result and Reason
            viewsInSearch.writeToExcelFail ( 'portalx.xlsx', 'ViewsInSearch', excelRow, 4, 5, "Menu is not displayed in the portalx Leftside bar" );
          }
        } );
      }
    }
    //End the Browser
    viewsInSearch.end ( );
  }
}
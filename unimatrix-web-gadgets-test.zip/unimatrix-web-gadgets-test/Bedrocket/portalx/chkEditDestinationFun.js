var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: ['chkEditDestinationFun'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'EditDestination': function ( chkEdit ) {
    //Setting up the Page object model
    var excel = chkEdit.globals.excelCol;
    var srchResult = [];
    for ( let incrementer = 1; incrementer <= excel.B.length - 1; incrementer++ ) {
      try {
        chkEdit.
        useXpath ( ).
        //Navigating to Index page of the applciation
        click ( "//Span[text ( )='destinations']" ).
        //Check whether the Search field is displayed
        waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkSearchTxtField ) {
          if ( chkSearchTxtField.value != 0 && chkSearchTxtField.status == 0 ) {
            chkEdit.
            //Clicking the Search icon 
            click ( "//INPUT[@id='search_input']" ).
            //Checking whether Search text field is displayed after clicking on Search icon
            waitForElementPresent ( "//INPUT[@id='search_input']", 5000, false, function ( chkVisibility ) {
              chkEdit.
              //Clicking on the Input search field
              click ( "//INPUT[@id='search_input']" ).
              //Clearing the Values in the Search field
              clearValue ( "//INPUT[@id='search_input']" ).
              //Set value inside the Search field
              setValue ( "//INPUT[@id='search_input']", excel.B[incrementer] );
              try {
                chkEdit.
                pause ( 8000 ).
                //Clicking on the Text field
                keys ( chkEdit.Keys.NULL );
                chkEdit.
                // Hitting the Enter key after entering the text in the search field
                keys ( chkEdit.Keys.ENTER );
                chkEdit.
                //Hold the control for about 5 secs
                pause ( 5000 );
                chkEdit.
                //Checking whether the search results is displayed
                waitForElementPresent ( "//span[@class='destination-name-label ng-binding']", 15000, false, function ( chkVisibility ) {
                  if ( chkVisibility.value.length != null ) {
                    chkEdit.elements ( 'xpath', "//span[@class='destination-name-label ng-binding']", function ( result ) {
                      for ( let searchDes = 1; searchDes <= result.value.length; searchDes++ ) {
                        chkEdit.
                        useXpath ( );
                        chkEdit.
                        //Get the results from search results
                        getText ( "//destination-cell[" + searchDes + "]/*//span[@class='destination-name-label ng-binding']", function ( getContents ) {
                          //Storing the Regular expression to find whether the Search results are appropriate
                          var RegExp_Search = new RegExp ( excel.B[incrementer], 'gi' );
                          //Checking whether the Search results are macthing with the Regular Expression
                          var search_Result_Parser = getContents.value.match ( RegExp_Search );
                          if ( search_Result_Parser != null ) {
                            //Stroring the Search result values in an array
                            srchResult.push ( getContents.value )
                          }
                        } );
                      }
                      //Checking whether the actual result and expected results are equal 
                      chkEdit.
                      waitForElementPresent ( '//span/span[contains (  @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]', 5000, false, function ( searchDes ) {
                        //Condition to check whether the Array is Empty
                        if ( searchDes.value.length != null ) {
                          //Checking the Search input data with the Search result data
                          if ( srchResult.length == result.value.length ) {
                            chkEdit.
                            //Getting the Location view of the matching element
                            getLocationInView ( '//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]' ).
                            //Getting attribute for the matching element
                            getAttribute ( '//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]/ancestor::destination-cell', "index", function ( searchDesIndex ) {
                              var indexValue = parseInt ( searchDesIndex.value ) + 1;
                              chkEdit.waitForElementPresent ( '//destination-cell[' + indexValue + ']/*//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]', 5000, false, function ( selectSearchedDes ) {
                                if ( selectSearchedDes.value.length != null ) {
                                  chkEdit.
                                  //Clicking the Searched result from the Search result
                                  click ( '//destination-cell[' + indexValue + ']/*//span/span[contains ( @class,"name-container" )]/span[@id="' + excel.B[incrementer] + '"]' ).
                                  waitForElementVisible ( '//SPAN[@class="title-box ng-binding"]', 5000 ).
                                  //Getting the Title of the Destination
                                  getText ( "//SPAN[@class='title-box ng-binding']", function ( searchTitle ) {
                                    //Checking whether the Title is equal to result obtained
                                    if ( searchTitle.value == excel.B[incrementer] ) {
                                      chkEdit.
                                      //Clearing the value in the Title field
                                      clearValue ( "//INPUT[@name='destinationName']" ).
                                      //Entering the updated value in the Destination Name field
                                      setValue ( "//INPUT[@name='destinationName']", excel.C[incrementer] );
                                      //Changing the Realm name 
                                      //Clicking the Realm DrpDown field
                                      chkEdit.pause ( 5000 );
                                      chkEdit.
                                      waitForElementPresent ( "//DIV[@class='untouchable-field']", 5000, false, function ( chkClickable ) {
                                        if ( chkClickable.value.length != null ) {
                                          try {
                                            chkEdit.
                                            click ( "//DIV[@class='untouchable-field']" );
                                            chkEdit.pause ( 5000 );
                                          } catch ( e ) {
                                            chkEdit.
                                            //Updating the Fail status in Excel sheet
                                            writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Unable to change the Realm, through Try catch" );
                                          }
                                        } else {
                                          chkEdit.
                                          //Updating the Fail status in Excel sheet
                                          writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Unable to change the Realm" );
                                        }
                                      } )
                                      chkEdit.
                                      //Checking whether the Save button is displayed
                                      waitForElementPresent ( "//BUTTON[@class='cta-button'][text ( )='SAVE']", 5000, false, function ( chkBtn ) {
                                        chkEdit.
                                        //Clicking on Save button
                                        click ( "//BUTTON[@class='cta-button'][text ( )='SAVE']" ).
                                        //Checking for the Falsh message to be displyed
                                        waitForElementPresent ( "//header/ng-include/div/span", 15000, false, function ( getalert ) {
                                          if ( getalert.value.length != null ) {
                                            //Waiting for the Flash message to be displayed
                                            chkEdit.pause ( 2000 );
                                            chkEdit.
                                            //Checking the content inside the Flash message
                                            getText ( "//header/ng-include/div/span", function ( getFlashMsg ) {
                                              if ( getFlashMsg.value == "Changes Saved" ) {
                                                chkEdit.
                                                //Updating Pass status in the Excel sheet
                                                writeToExcelPass ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5 );
                                              } else {
                                                chkEdit.
                                                //Updating the Fail status in Excel sheet
                                                writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Flash message is not displayed" );
                                              }
                                            } );
                                          } else {
                                            chkEdit.
                                            //Updating the Fail status in Excel sheet
                                            writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Flash message is not displayed" );
                                          }
                                        } );
                                      } );
                                    } else {
                                      chkEdit.
                                      //Updating the Fail status in the Excel sheet
                                      writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Unable to locate the Searched content" );
                                    }
                                  } )
                                } else {
                                  //write to fail status as searched Des is not visible
                                  chkEdit.
                                  //Updating the Fail status in the Excel sheet
                                  writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Searched Destination is not visible" );
                                  this.verify.fail ( selectSearchedDes.value.length, 'not equal to null', 'Searched Des is not visible' );
                                }
                              } );
                            } );
                          } else {
                            chkEdit.
                            //Updating the Fail status in the Excel sheet
                            writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Searched Destination is not present in the list" );
                            //write to fail status as searched Des is not Present
                            this.verify.fail ( searchDes.value.length, 'not equal to null', 'Searched Destination is not present in the list' );
                          }
                        }
                        //If the condition fails then update the Fail status in the Excel
                        else {
                          chkEdit.
                          //Updating the Fail status in the Excel sheet
                          writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Please try again with the another destination" );
                        }
                      } );
                    } );
                  }
                } );
              } catch ( e ) {
                chkEdit.
                writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Please try again with the another destination" );
              }
            } );
          }
        } );
      } catch ( e ) {
        chkEdit.
        writeToExcelFail ( 'portalx.xlsx', 'EditDestination', ++incrementer, 5, 6, "Please try again with the another destination" );
      }
    }
  },
}
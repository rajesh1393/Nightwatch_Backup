var currRealmName;
module.exports = {
  tags: [ 'chkSettingsFun' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'RealmEditFun': function ( realmEdit ) {
    try {
      //Storing the Excel global variables in excel
      var excel = realmEdit.globals.excelCol;
      realmEdit.
      useCss ( ).
      pause ( 3000 ).
      //Waiting for the element to be displayed
      waitForElementVisible ( ".current-realm-text.ng-binding", 4000, false ).
      //Getting the Realm name from the sidebar
      getText ( ".current-realm-text.ng-binding", function ( checkTheme ) {
        currRealmName = checkTheme.value;
      } );
      realmEdit.
      useXpath ( ).
      //Checking whether the Settings link is dispalyed
      waitForElementVisible ( "//Span[text()='settings']", 15000, false, function ( getStatus ) {
        //Checking whether the link is displayed
        if ( getStatus.value == true ) {
          realmEdit.
          //Clicking the Settings link
          click ( "//Span[text()='settings']" ).
          pause ( 5000 ).
          //Checking whether the Current realm field is dispalyed
          waitForElementVisible ( "//INPUT[@disabled='']", 15000, false, function ( getCurrRealmStatus ) {
            //Condition whether the Input field is displayed
            if ( getCurrRealmStatus.value == true ) {
              realmEdit.
              //Getting the value from the input field
              getValue ( "//INPUT[@disabled='']", function ( getCurrRealmName ) {
                //Checking whether the Current realm name is as same as the current realm name
                if ( getCurrRealmName.value == currRealmName ) {
                  realmEdit.
                  //If the conditionis true then the Control is executed
                  waitForElementVisible ( "//INPUT[@required='']", 15000, false, function ( chkVisibility ) {
                    if ( chkVisibility.value == true ) {
                      realmEdit.
                      //Clearing the Input field
                      clearValue ( "//INPUT[@required='']" ).
                      //Setting the input in the input field
                      setValue ( "//INPUT[@required='']", excel.B[1] ).
                      //Clicking on save button
                      click ( "//BUTTON[@class='cta-button'][text()='SAVE']" ).
                      pause ( 2000 ).
                      //Checking whether the Flash success message is displayed
                      getText ( "//header/ng-include/div/span", function ( getFlashMsg ) {
                        //Validating the Flash message displayed is correct
                        if ( getFlashMsg.value == "The realm was successfully updated!" ) {
                          realmEdit.
                          useCss ( ).
                          //Again checking the Current realm name gets changed
                          getText ( ".current-realm-text.ng-binding", function ( checkTheme ) {
                            //Checking whether the Realm name is as same as in excel sheet
                            if ( checkTheme.value == excel.B[1] ) {
                              realmEdit.
                              //Updating the Pass status in the Excel sheet
                              writeToExcelPass ( 'portalx.xlsx', 'RealmEditFun', 2, 3 );
                            } else {
                              realmEdit.
                              //Updating the Fail status in the excel sheet
                              writeToExcelFail ( 'portalx.xlsx', 'RealmEditFun', 2, 3, 4, "Realm name not updated in Realm change menu" );
                            }
                          } );
                        } else {
                          realmEdit.
                          //Updating the Fail status in the Excel sheet
                          writeToExcelFail ( 'portalx.xlsx', 'RealmEditFun', 2, 3, 4, "Flash message is not displayed" );
                        }
                      } );
                    } else {
                      realmEdit.
                      //Updating the Fail status in the excel sheet
                      writeToExcelFail ( 'portalx.xlsx', 'RealmEditFun', 2, 3, 4, "Unable to update the Realm name" );
                    }
                  } );
                } else {
                  realmEdit.
                  //updating the Fail status in the excel sheet
                  writeToExcelFail ( 'portalx.xlsx', 'RealmEditFun', 2, 3, 4, "It seems that the Crrent realm name displayed in settings page is not as same as in the Realm sidebar" );
                }
              } );
            } else {
              realmEdit.
              //Updating the fail status in Excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'RealmEditFun', 2, 3, 4, "Current realm name is not displayed" );
            }
          } );
        } else {
          realmEdit.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'RealmEditFun', 2, 3, 4, "There is a problem while navigating to the Settings page" );
        }
      } );
    } catch ( e ) {
      realmEdit.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'RealmEditFun', 2, 3, 4, "Please try again it seems there is problem in execution" );
    }
  }
}
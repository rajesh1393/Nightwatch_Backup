//this function is for check and Add the Contentlist
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'portalx.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['NewFolderAdd'];
var contentTitle = [ ];
var categoryName = [ ];
var categoryType = [ ];
var language = [ ];
var createCategory = [ ];
var expectedCount, excelData, actualLabel, splitCategory, splitProvider, providerData, categoryData;
var currentCount ;
var actualCount ;
var expectedLabel = "New Folder";
var getData, rowCount = 1;
var dataProvider, dataCategory = 0;
module.exports = {
  tags: ['newFolderAdd'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  'NewFolderAdd': function ( newFolderAdd ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[excelData].v );
      }
      //Read categoryName
      if ( excelData.includes ( 'B' ) ) {
        categoryName.push ( worksheet[excelData].v );
      }
      //Read categoryType
      if ( excelData.includes ( 'C' ) ) {
        categoryType.push ( worksheet[excelData].v );
      }
      //Read language Title
      if ( excelData.includes ( 'D' ) ) {
        language.push ( worksheet[excelData].v );
      }
      //Read createCategory
      if ( excelData.includes ( 'E' ) ) {
        createCategory.push ( worksheet[excelData].v );
      }
    }
    if ( contentTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;
        newFolderAdd.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Folder Menu in Sidebar
        waitForElementVisible ( "//a/span[contains(.,'folders')]", 4000, false, function ( checkFolderMenu ) {
          if ( checkFolderMenu.value == true ) {
            newFolderAdd.pause ( 4000 ).useXpath ( ).
            //Verify the Folder Menu is visible in the sidebar
            verify.visible ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Click on the Folder Menu in sidebar
            click ( "//a/span[contains(.,'folders')]" ).
            pause ( 4000 ).
            //Get the Current count in the Content page
            getText ( "//div[@class='index-header-wrapper controls']/span[1]", function ( currentCountResult ) {
              //div[@class='index-header-wrapper controls']/span[@ng-if='!categoryItems && !artifactsPage && !loading']
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.split ('Folders');
              }
              newFolderAdd.pause ( 4000 ).
              //Wait for the Add New button is visible in the Folder page
              waitForElementVisible ( "//div[@tooltip='Add New']", 4000, false, function ( checkAddNew ) {
                if ( checkAddNew.value == true ) {
                  newFolderAdd.pause ( 4000 ).
                  //Click on the Add New Button
                  click ( "//div[@tooltip='Add New']" ).
                  pause ( 4000 ).
                  //Wait for New Folder button is visible in the dropdown list
                  waitForElementVisible ( "//div/ul/li[text( )[normalize-space(.)='New Folder']]", 4000, false, function ( checkNewFolder ) {
                    if ( checkNewFolder.value == true ) {
                      newFolderAdd.pause ( 4000 ).
                      //Click on the New Folder button in tehe dropdown list
                      click ( "//div/ul/li[text( )[normalize-space(.)='New Folder']]" ).
                      pause ( 4000 ).
                      //Wait for Label text is visible in the Folder page
                      waitForElementVisible ( "//div/span[@class='title-box']", 4000, false ).
                      pause ( 4000 ).
                      //Get the Label text in the Folder Page
                      getText ( "//div/span[@class='title-box']", function ( getLabelName ) {
                        actualLabel = getLabelName.value;
                        if ( actualLabel == expectedLabel ) {
                          newFolderAdd.useXpath ( ).pause ( 4000 ).
                          //Wait for the Folder name is visible in the page
                          waitForElementVisible ( "//form/input[@name='folderName']", 4000, false ).
                          pause ( 4000 ).
                          //Verify the the Folder name is visible in the page
                          verify.visible ( "//form/input[@name='folderName']" ).
                          pause ( 4000 ).
                          //Enter the Data in the Folder name field
                          setValue ( "//form/input[@name='folderName']", contentTitle[ getData ] ).
                          pause ( 4000 )
                          if ( categoryName[ getData ] != undefined ) {                            
                            newFolderAdd.useXpath ( ).
                            //Wait for the Category field is visible in the page
                            waitForElementVisible ( "//div/input[@type='text']", 4000, false ).
                            pause ( 4000 ).
                            //Enter the Data in the Category field
                            setValue ( "//div/input[@type='text']", categoryName[ getData ] ).
                            pause ( 4000 ).
                            //Wait for the Category present in the field
                            waitForElementPresent ( "//div[1]/div[@class='suggestion-item']/span[@class='category-name ng-binding']", 4000, false, function ( checkCategoryType ) {
                              if ( ( checkCategoryType.value == true  ) || ( checkCategoryType.value.length != 0 ) ) {
                                newFolderAdd.useXpath ( ).pause ( 4000 ).
                                //Verify for the Category is visible in the page                               
                                verify.visible ( "//div/div[@class='suggestion-item']/span[@class='category-name ng-binding'][text( )[normalize-space(.)='"+ categoryName[ getData ] +"']]" ).
                                pause ( 4000 ).
                                //Click on the Categories in the list
                                click ( "//div/div[@class='suggestion-item']/span[@class='category-name ng-binding'][text( )[normalize-space(.)='"+ categoryName[ getData ] +"']]" )
                              }
                              else {
                                if ( createCategory[ getData ] != undefined ) {
                                  newFolderEdit.pause ( 4000 ).useXpath ( ).
                                  //Wait for the Create category is visible in the dropdown list
                                  waitForElementVisible ( "//div/ul/li/a[text( )[normalize-space(.)='"+ createCategory[ getData ] +"']]", 9000, false ).
                                  pause ( 4000 ).
                                  //Click on the Create category in the dropdown list
                                  click ( "//div/ul/li/a[text( )[normalize-space(.)='"+ createCategory[ getData ] +"']]" ).
                                  pause ( 4000 )
                                }
                                else {
                                  newFolderEdit.pause ( 4000 ).useCss ( ).
                                  //Key press on Enter key
                                  keys ( newFolderRename.Keys.ENTER ).                                         
                                  keys ( newFolderRename.Keys.ENTER )
                                }
                              }
                            } );
                          }
                          var splitCategory = categoryType[ getData ].split (',');
                          for ( let categoryData = 0, dataCategory = 0; categoryData < splitCategory.length; categoryData++ ) {
                            dataCategory++;
                            newFolderAdd.useXpath ( ).pause ( 4000 ).
                            //Get the location for Category Type data field
                            getLocationInView ( "//div/ul/li/div/label[text( )[normalize-space(.)='"+ splitCategory[categoryData] +"']]" ).
                            pause ( 4000 ).
                            //Wait for the category Type field is visible in the page
                            waitForElementVisible ( "//div/ul/li/div/label[text( )[normalize-space(.)='"+ splitCategory[categoryData] +"']]", 9000, false, function ( checkCategoryType ) {
                              if ( checkCategoryType.value == true ) {
                                newFolderAdd.useXpath ( ).pause ( 4000 ).
                                //Click on the category type data in the field
                                click ( "//div/ul/li/div/label[text( )[normalize-space(.)='"+ splitCategory[categoryData] +"']]" ).
                                pause ( 4000 )
                                if ( dataCategory == splitCategory.length ) {
                                  var splitProvider = language[ getData ].split (',');
                                  for ( let providerData = 0, dataProvider = 0; providerData < splitProvider.length; providerData++ ) {
                                    dataProvider++;
                                    newFolderAdd.useXpath ( ).pause ( 4000 ).
                                    //Get the location for Language Type data field
                                    getLocationInView ( "//div/ul/li/div/label[@class='radio-button-label ng-binding'][text( )[normalize-space(.)='"+ splitProvider[providerData] +"']]"  ).
                                    pause ( 4000 ).
                                    //Wait for the Language field is visible in the page
                                    waitForElementVisible ( "//div/ul/li/div/label[@class='radio-button-label ng-binding'][text( )[normalize-space(.)='"+ splitProvider[providerData] +"']]", 9000, false, function ( checkLanguageType ) {
                                      if ( checkLanguageType.value == true ) {
                                        newFolderAdd.useXpath ( ).pause ( 4000 ).
                                        //Click on the Language type data in the field
                                        click ( "//div/ul/li/div/label[@class='radio-button-label ng-binding'][text( )[normalize-space(.)='"+ splitProvider[providerData] +"']]" ).
                                        pause ( 4000 ).
                                        //Get the Cancel button location in the page
                                        getLocationInView ( "//div/button[@class='cancel-button']" ).
                                        pause ( 4000 ).
                                        //Wait for cancel button is visible in the page
                                        waitForElementVisible ( "//div/button[@class='cancel-button']", 4000, false ).
                                        pause ( 4000 ).
                                        //Wait for save button is visible in the page
                                        waitForElementVisible ( "//div/button[@class='cta-button']", 4000, false ).
                                        pause ( 4000 ).
                                        //Click on the Save Button in the page
                                        click ( "//div/button[@class='cta-button']" ).
                                        pause ( 2000 ).useXpath ( ).                                          
                                        //Wait for the Created folder Title is visible in the page
                                        waitForElementVisible ( "//ng-view/div/ng-include/div/div/span/span[2]", 9000, false, function ( checkCreatedTitle ) {
                                        	if ( checkCreatedTitle.value == true ) {   
                                        		newFolderAdd.useXpath ( ).  
                                        		//Get the Value of the Created folder Title in the page                   
                                       			getText("//ng-view/div/ng-include/div/div/span/span[2]", function ( textGetting ) {
	                                       			if ( textGetting.value == contentTitle[ getData ] ) {
	                                       				newFolderAdd.useXpath ( ).pause ( 4000 ).
	                                        			//Wait for Folder menu is visible in the sidebar
	                                        			waitForElementVisible ( "//a/span[contains(.,'folders')]", 4000, false ).
	                                       				pause ( 4000 ).
				                                        //Click on the Folder menu in sidebar
				                                        click ( "//a/span[contains(.,'folders')]" ).
				                                        pause ( 10000 ).useXpath ( ).
				                                        //Verify the Total count label is visible in the Folder page
				                                        verify.visible ( "//div/span[@class='folder-count-text ng-binding ng-scope']" ).
				                                        pause ( 4000 ).
				                                        //Get Actual Total Count after created in the Content 
				                                        getText ( "//div/span[@class='folder-count-text ng-binding ng-scope']", function ( actualCountResult ) {
				                                          if ( actualCountResult.status != -1 ) {
				                                            actualCount = actualCountResult.value;
				                                            //actualCount = actualCount.substring ( 2, 0 );   
				                                            actualCount = actualCount.split ('Folders');                                        
				                                            expectedCount = ( +currentCount[0] + 1 )
				                                            if ( actualCount[0] == expectedCount ) {
				                                              //Write the Excel to PASS Result and Reason
				                                              newFolderAdd.writeToExcelPass ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6 );
				                                            }
				                                            else {
                                                      this.verify.fail ( actualCountResult.value, 'true', 'actual value is not displayed in the page' );
				                                              //Write the Excel to FAIL Result and Reason
				                                              newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "ActualResult: '"+ actualCount +"' in the Total Count After Added New Folder. ExpectedResult: should be'" + expectedCount + "' in the Total Count" );
				                                            }
	                                          			}
	                                        			} ); 
	                                        		}
			                                        else {
                                                this.verify.fail ( textGetting.value, 'true', 'Text value is not displayed in the page' );
			                                        	//Write the Excel to FAIL Result and Reason
                                        				newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "Actual alert message as: '"+ textGetting.value +"',After Created New Folder. ExpectedResult: should be 'New Folder Created!'" );
			                                        }
			                                      } ) 
	                                        }
	                                        else {
                                            this.verify.fail ( checkCreatedTitle.value, 'true', 'Added New folder is not displayed in the page' );
	                                        	//Write the Excel to FAIL Result and Reason
                                        		newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "New Folder Created Title is not displayed in the page" );
	                                        }
                                        } );                                           
                                      }
                                      else {
                                        this.verify.fail ( checkLanguageType.value, 'true', 'Add New button is not displayed in the page' );
                                        //Write the Excel to FAIL Result and Reason
                                        newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "Language Type is not displayed in the New folder page" );
                                      }
                                    } );
                                  }
                                }
                              }
                              else {
                                this.verify.fail ( checkCategoryType.value, 'true', 'Add New button is not displayed in the page' );
                                //Write the Excel to FAIL Result and Reason
                                newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "Category Type is not displayed in the New folder page" );
                              }
                            } );
                          }
                        }
                        else {
                          this.verify.fail ( getLabelName.value, 'true', 'Add New button is not displayed in the page' );
                          //Write the Excel to FAIL Result and Reason
                          newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "Label Name is not displayed in the New folder page" );
                        }
                      } );
                    }
                    else {
                      this.verify.fail ( checkNewFolder.value, 'true', 'Add New button is not displayed in the page' );
                      //Write the Excel to FAIL Result and Reason
                      newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "New Folder menu button is not displayed in the list" ) 
                    }
                  } );
                }
                else {
                  this.verify.fail ( checkAddNew.value, 'true', 'Add New button is not displayed in the page' );
                  //Write the Excel to FAIL Result and Reason
                  newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "Add New button is not displayed in the page" )
                }
              } );
            } );
          }
          else {
            this.verify.fail ( checkFolderMenu.value, 'true', 'Folders menu is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            newFolderAdd.writeToExcelFail ( 'portalx.xlsx', 'NewFolderAdd', rowCount, 6, 7, "Folders menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    newFolderAdd.end ( );
  }
}
//this function is for add, edit, delete the Artifacts EventId
module.exports = {
  tags: [ 'artifactEventId' ],
  before: function ( portalLogin ) {
    //Login to the Portalx with valid credentials
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //clear the array values
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'EventId': function ( eventId ) {
    //Access the variable globally defined
    var excel = eventId.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1 ; excelColumn < excel.A.length; excelColumn++ ) {
        if ( excel.A[ excelColumn ] == "ADD" ) {
          //Add the new Eventid Artifact using custom commands
          eventId.artifactAdd ( 'Eventid', 14, excelColumn, 'portalx.xlsx', 'EventId', ++excelRow, 18, 19 );
        }
        else if ( excel.A[ excelColumn ] == "EDIT" ) {
          //Edit the Eventid Artifact using custom commands
          eventId.artifactEdit ( 'Eventid', 14, excelColumn, 'portalx.xlsx', 'EventId', ++excelRow, 18, 19 );
        }
        else if ( excel.A[ excelColumn ] == "DELETE" ) {
          //Delete the Eventid Artifact using custom commands
          eventId.artifactDelete ( 'EVENTID', excelColumn, 'portalx.xlsx', 'EventId', ++excelRow, 18, 19 );
        }
        else {
          //Input Error
          console.log ( "No valid input in Excel for the field Artifact functionality" );
        }
      }
    }
    else {
      //write to excel 'fail' if error in the excelsheet name
      console.log ( "No input in Excel or Check the Excel Name for the script 'EventId'" );
    }
  },
};
var currRealmName;
module.exports = {
  tags: [ 'ChkCurrRealmSettingsPage' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'ChkCurrRealmSettingsPage': function ( realmEdit ) {
    try {
      realmEdit.
      useCss ( ).
      pause ( 3000 ).
      //Waiting for the Realm name to be displayed from the side bar
      waitForElementVisible ( ".current-realm-text.ng-binding", 4000, false ).
      //Getting the Realm name 
      getText ( ".current-realm-text.ng-binding", function ( checkTheme ) {
        //Storing the Realm name in a variable for frucher manipulation
        currRealmName = checkTheme.value;
      } );
      realmEdit.
      useXpath ( ).
      /*Navigating to the Settings page*/
      //Checking whether the Settings icon is displayed
      waitForElementVisible ( "//Span[text()='settings']", 15000, false, function ( getStatus ) {
        //Condition to check whether the Settings icon is displayed
        if ( getStatus.value == true ) {
          realmEdit.
          //Clicking the Settings link
          click ( "//Span[text()='settings']" ).
          pause ( 5000 ).
          //Checking whether the Current realm name is displayed
          waitForElementVisible ( "//INPUT[@disabled='']", 15000, false, function ( getCurrRealmStatus ) {
            //If the Current realm name is displayed then 
            if ( getCurrRealmStatus.value == true ) {
              realmEdit.
              //Getting the Current realm name from the Current realm name field in the Settings page
              getValue ( "//INPUT[@disabled='']", function ( getCurrRealmName ) {
                //Checking whether the realm name dispalyed in the Settings page is as same as the Current realm name
                if ( getCurrRealmName.value == currRealmName ) {
                  realmEdit.
                  //If the condition goes true then Updating pass status in the Excel sheet
                  writeToExcelPass ( 'portalx.xlsx', 'ChkCurrRealmSettingsPage', 2, 2 );
                } else {
                  realmEdit.
                  //Updating the Fail status in the Excel sheet
                  writeToExcelFail ( 'portalx.xlsx', 'ChkCurrRealmSettingsPage', 2, 2, 3, "It seems that the Crrent realm name displayed in settings page is not as same as in the Realm sidebar" );
                }
              } )
            } else {
              realmEdit.
               //Updating the Fail status in the Excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'ChkCurrRealmSettingsPage', 2, 2, 3, "Current realm name is not displayed" );
            }
          } );
        } else {
          realmEdit.
          //Updating the Fail status in the Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'ChkCurrRealmSettingsPage', 2, 2, 3, "There is a problem while navigating to the Settings page" );
        }
      } );
    } catch ( e ) {
      realmEdit.
      //Updating the Fail status in the Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'ChkCurrRealmSettingsPage', 2, 2, 3, "Please try again it seems there is problem in execution" );
    }
  }
}
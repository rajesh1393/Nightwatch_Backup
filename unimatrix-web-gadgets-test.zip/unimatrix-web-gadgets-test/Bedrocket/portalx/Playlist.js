//this function is for add, edit, delete the Artifacts Playlist
module.exports = {
  tags: [ 'artifactPlaylist' ],
  before: function ( portalLogin ) {
    //Login to the Portalx with valid credentials
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //clear the array values
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'Playlist': function ( playlist ) {
    //Access the variable globally defined
    var excel = playlist.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1 ; excelColumn < excel.A.length; excelColumn++ ) {
        if ( excel.A[ excelColumn ] == "ADD" ) {
          //Add the new Playlist Artifact using custom commands
          playlist.artifactAdd ( 'Playlist', 14, excelColumn, 'portalx.xlsx', 'Playlist', ++excelRow, 18, 19 );
        }
        else if ( excel.A[ excelColumn ] == "EDIT" ) {
          //Edit the Playlist Artifact using custom commands
          playlist.artifactEdit ( 'Playlist', 14, excelColumn, 'portalx.xlsx', 'Playlist', ++excelRow, 18, 19 );
        }
        else if ( excel.A[ excelColumn ] == "DELETE" ) {
          //Delete the Playlist Artifact using custom commands
          playlist.artifactDelete ( 'PLAYLIST', excelColumn, 'portalx.xlsx', 'Playlist', ++excelRow, 18, 19 );
        }
        else {
          //Input Error
          console.log ( "No valid input in Excel for the field Artifact functionality" );
        }
      }
    }
    else {
      //write to excel 'fail' if error in the excelsheet name
      console.log ( "No input in Excel or Check the Excel Name for the script 'Playlist'" );
    }
  },
};
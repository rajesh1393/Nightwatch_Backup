//this function is for add, edit, delete the Artifacts IspVideo
module.exports = {
  tags: [ 'artifactIspVideo' ],
  before: function ( portalLogin ) {
    //Login to the Portalx with valid credentials
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //clear the array values
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'IspVideo': function ( ispVideo ) {
    //Access the variable globally defined
    var excel = ispVideo.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1 ; excelColumn < excel.A.length; excelColumn++ ) {
        if ( excel.A[ excelColumn ] == "ADD" ) {
          //Add the new Isp Video Artifact using custom commands
          ispVideo.artifactAdd ( 'Isp Video', 24, excelColumn, 'portalx.xlsx', 'IspVideo', ++excelRow, 30, 31 );
        }
        else if ( excel.A[ excelColumn ] == "EDIT" ) {
          //Edit the Isp Video Artifact using custom commands
          ispVideo.artifactEdit ( 'Isp Video', 24, excelColumn, 'portalx.xlsx', 'IspVideo', ++excelRow, 30, 31 );
        }
        else if ( excel.A[ excelColumn ] == "DELETE" ) {
          //Delete the Isp Video Artifact using custom commands
          ispVideo.artifactDelete ( 'ISP VIDEO', excelColumn, 'portalx.xlsx', 'IspVideo', ++excelRow, 30, 31 );
        }
        else {
          //Input Error
          console.log ( "No valid input in Excel for the field Artifact functionality" );
        }
      }
    }
    else {
      //write to excel 'fail' if error in the excelsheet name
      console.log ( "No input in Excel or Check the Excel Name for the script 'IspVideo'" );
    }
  },
};
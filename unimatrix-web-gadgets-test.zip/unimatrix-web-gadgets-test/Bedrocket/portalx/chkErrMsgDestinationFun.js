var ErrMsg_DestiName;
var actualIndexBeforeAdd = [];
var ErrMsg_SelectRealm;
module.exports = {
  tags: ['errMsgDestinationPage'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'ErrMsgDestinationPage': function ( errMsg ) {
    // //Setting up the Page object model
    try {
      errMsg.
      useXpath ( ).
      click ( "//Span[text ( )='destinations']" ).
      useCss ( ).
      //Clikcing the Add btn 
      click ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope" ).
      useXpath ( ).
      //Clikcing the New Destination button from the Toggle dropdown
      click ( "//li[contains(.,'New Destination')]" ).
      //Checking the Destination is displayed in the Sidebar
      waitForElementPresent ( "//BUTTON[@class='cta-button'][text ( )='CREATE']", 15000, false, function ( check_Sidebar_Lnk ) {
        if ( check_Sidebar_Lnk.status == 0 ) {
          errMsg.
          //Checking whether the user is redirected to Add Destination page.
          waitForElementPresent ( "//BUTTON[@class='cta-button'][text ( )='CREATE']", 5000, false ).
          //Checking whether the  Error message is displayed for both the fileds if the User clicks directly on the Create buton
          click ( "//BUTTON[@class='cta-button'][text ( )='CREATE']" ).
          //Checking whether the Error message is displayed
          waitForElementPresent ( "//SPAN[@ng-transclude=''][text ( )='Please give this destination a name.']", 5000, false, function ( chkErrMsg ) {
            if ( chkErrMsg.status == 0 ) {
              errMsg.
              //Getting the Error message
              getText ( "//SPAN[@ng-transclude=''][text ( )='Please give this destination a name.']", function ( getErrMsg_DestiName ) {
                //Storing the error message in a ErrMsg_destiName variable
                ErrMsg_DestiName = getErrMsg_DestiName.value;
                errMsg.
                //Getting the Error message
                getText ( "//SPAN[@ng-transclude=''][text ( )='Please select a destination realm.']", function ( getErrMsg_RealmSelect ) {
                  //Storing the Error message in ErrMsg_SelectRealm variable
                  ErrMsg_SelectRealm = getErrMsg_RealmSelect.value;
                  if ( ErrMsg_DestiName == "Please give this destination a name." && ErrMsg_SelectRealm == "Please select a destination realm." ) {
                    errMsg.
                    //Updating the Pass status in Excel sheet
                    writeToExcelPass ( 'portalx.xlsx', 'ErrMsgDestinationPage', 2, 2 );
                  } else {
                    errMsg.
                    //Updating the Fail status in Excel sheet
                    writeToExcelFail ( 'portalx.xlsx', 'ErrMsgDestinationPage', 2, 2, 3, "Error message displayed is not as same as Please give this destination a name. and Please select a destination realm." );
                  }
                } );
              } );
            } else {
              errMsg.
              //Updating the Fail status in The Excel
              writeToExcelFail ( 'portalx.xlsx', 'ErrMsgDestinationPage', 2, 2, 3, "Error message is not displayed" );
            }
          } );
          errMsg.
          //Clicking on Destination Name field
          click ( "//INPUT[@name='destinationName']" ).
          //Entering Dummy data in the Text field
          setValue ( "//INPUT[@name='destinationName']", "Check" ).
          //Clicking on Create button
          click ( "//BUTTON[@class='cta-button'][text ( )='CREATE']" ).
          //Checking whether the error message is displayed or not
          waitForElementPresent ( "//SPAN[@ng-transclude=''][text ( )='Please select a destination realm.']", 5000, false, function ( chk_ErrMsg ) {
            //Checking whether the Error message is displayed 
            if ( chk_ErrMsg.status == 0 ) {
              errMsg.
              getText ( "//SPAN[@ng-transclude=''][text ( )='Please select a destination realm.']", function ( getErrMsg ) {
                //Checking whether the Error message is displayed appropriately
                if ( getErrMsg.value == "Please select a destination realm." ) {
                  errMsg.
                  //Updating Pass status in Excel sheet
                  writeToExcelPass ( 'portalx.xlsx', 'ErrMsgDestinationPage', 3, 2 );
                } else {
                  errMsg.
                  //Updating Fail status in Excel sheet
                  writeToExcelFail ( 'portalx.xlsx', 'ErrMsgDestinationPage', 3, 2, 3, "Error message is not displayed as Please select a destination realm." );
                }
              } );
            } else {
              errMsg.
              //Updating the Fail status in Excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'ErrMsgDestinationPage', 3, 2, 3, "Error message is not displayed as Please select a destination realm." );
            }
          } );
          errMsg.
          //Navigating to Add dashboard page
          click ( "//Span[text ( )='destinations']" ).
          useCss ( ).
          //Clikcing the Add btn 
          click ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope" ).
          useXpath ( ).
          //Clikcing the New Destination button from the Toggle dropdown
          click ( "//li[contains(.,'New Destination')]" ).
          //Clicking the Realm dropdown field
          click ( "//DIV[@class='no-edit-field']" ).
          //Selecting a realm from the dropdown
          click ( "//DIV[@class='flyout-destination-realm-menu dropdown-menu ng-scope']/ul" ).
          //Clicking the Create button
          click ( "//BUTTON[@class='cta-button'][text ( )='CREATE']" ).
          //Checking whether the Error message is displayed
          waitForElementPresent ( "//SPAN[@ng-transclude=''][text ( )='Please give this destination a name.']", 5000, false, function ( chk_ErrMsg_Realm ) {
            errMsg.
            //Evaluating the Error message displayed with the Expected one
            getText ( "//SPAN[@ng-transclude=''][text ( )='Please give this destination a name.']", function ( getErr_Realm ) {
              //Checking whether the Error message is appropriate
              if ( getErr_Realm.value == "Please give this destination a name." ) {
                errMsg.
                //Updating the Pass status in Excel sheet
                writeToExcelPass ( 'portalx.xlsx', 'ErrMsgDestinationPage', 4, 2 );
              } else {
                errMsg.
                //Updating the Fail status in Excel sheet
                writeToExcelFail ( 'portalx.xlsx', 'ErrMsgDestinationPage', 4, 2, 3, "Error message is not displayed as Please select a destination realm." );
              }
            } );
          } );
        } else {
          errMsg.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'ErrMsgDestinationPage', 4, 2, 3, "Error message is not displayed as Please select a destination realm." );
        }
      } );
    } catch ( e ) {
      errMsg.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'ErrMsgDestinationPage', 4, 2, 3, "Something went wrong" );
    }
  },
}
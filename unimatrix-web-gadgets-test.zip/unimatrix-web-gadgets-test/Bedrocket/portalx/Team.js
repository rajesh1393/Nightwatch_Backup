//this function is for add, edit, delete the Artifacts Team
module.exports = {
  tags: [ 'artifactTeam' ],
  before: function ( portalLogin ) {
    //Login to the Portalx with valid credentials
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //clear the array values
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'Team': function ( team ) {
    //Access the variable globally defined
    var excel = team.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1, excelRow = 1 ; excelColumn < excel.A.length; excelColumn++ ) {
        if ( excel.A[ excelColumn ] == "ADD" ) {
          //Add the new TEAM Artifact using custom commands
          team.artifactAdd ( 'Team', 14, excelColumn, 'portalx.xlsx', 'Team', ++excelRow, 18, 19 );
        }
        else if ( excel.A[ excelColumn ] == "EDIT" ) {
          //Edit the TEAM Artifact using custom commands
          team.artifactEdit ( 'Team', 14, excelColumn, 'portalx.xlsx', 'Team', ++excelRow, 18, 19 );
        }
        else if ( excel.A[ excelColumn ] == "DELETE" ) {
          //Delete the TEAM Artifact using custom commands
          team.artifactDelete ( 'TEAM', excelColumn, 'portalx.xlsx', 'Team', ++excelRow, 18, 19 );
        }
        else {
          //Input Error
          console.log ( "No valid input in Excel for the field Artifact functionality" );
        }
      }
    }
    else {
      //write to excel 'fail' if error in the excelsheet name
      console.log ( "No input in Excel or Check the Excel Name for the script 'Team'" );
    }
  },
};
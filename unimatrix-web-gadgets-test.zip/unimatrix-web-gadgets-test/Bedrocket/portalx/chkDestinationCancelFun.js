var ErrMsg_DestiName;
var actualIndexBeforeAdd = [ ];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkDestinationCancelFun'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'DestinationCancelBtnFun': function ( checkCancelBtn ) {
    try {
      checkCancelBtn.
        useXpath ( ).
      //Navigating to Add dashboard page
       //Clicking the Destination link from the side bar
        click  (  "//Span[text()='destinations']"  ).
        useCss ( ).
        //Clikcing the Add btn 
        click  (  "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope"  ).
        useXpath ( ).
        //Clikcing the New Destination button from the Toggle dropdown
        click  (  "//li[contains(.,'New Destination')]"  ).
      //Check Cancel button is displayed
      waitForElementPresent ( "//BUTTON[@class='cancel-button'][text()='CANCEL']", 5000, false, function ( chkVisibility ) {
        //Contidion to check whether the Cancel button is displayed
        if ( chkVisibility.value != 0 && chkVisibility.status == 0 ) {
          checkCancelBtn.
          //Click on Cancel button
          click ( "//BUTTON[@class='cancel-button'][text()='CANCEL']" ).
          //Check whether the user is navigated to Index page of the application
          waitForElementPresent ( "//span[@class = 'folder-count-text ng-binding ng-scope']", 5000, false, function ( chkNavigation ) {
            //Condtition  to check whether the user is navigated or not
            if ( chkNavigation.value != 0 && chkNavigation.status == 0 ) {
              checkCancelBtn.
              //Updating the Pass status in the Excel sheet
              writeToExcelPass ( 'portalx.xlsx', 'DestinationCancelBtnFun', 2, 2);
            }
            //if the user is not navigated then Failure status will be updated
            else {
              checkCancelBtn.
              //Updating the Fail status in the Excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'DestinationCancelBtnFun', 2, 2, 3, "Control is not navigated to Destination Index page after clicking on Cancel button" );
            }
          } );
        } else {
          checkCancelBtn.
          //Updating the Fail status in the Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'DestinationCancelBtnFun', 2, 2, 3, "Cancel button is not displayed" );
        }
      } );
    } catch ( e ) {
      checkCancelBtn.
      //updating the Fail status in the Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'DestinationCancelBtnFun', 2, 2, 3, "Something went wrong please try again" );
    }
    checkCancelBtn.end ( );
  },
}
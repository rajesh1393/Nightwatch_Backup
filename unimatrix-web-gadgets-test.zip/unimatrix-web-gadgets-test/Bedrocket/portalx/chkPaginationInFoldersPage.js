var totalContent = 0;
var statusCount = [];
module.exports = {
  tags: [ 'chkPaginationInFoldersPage' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkPaginationInFolders': function ( chkPagination ) {
    //Setting up the Page object model
    var excel = chkPagination.globals.excelCol;
    //Exception handling
    for ( let inc = 0; inc < 1; inc++ ) {
      try {
        chkPagination.
        useXpath ( ).
        //Clicking the Destination link from the side bar
        click ( "//Span[text()='folders']" ).
        pause ( 5000 ).
        //Getting the Index value from the destination list page
        getText ( "//SPAN[@ng-if='!categoryItems && !artifactsPage && !loading && !stationsTab']",function ( chkIndexValue ) {
          var indexValue = chkIndexValue.value.replace ( /\D/g,'' );
          var remainder = indexValue%25;
          var quotient = Math.floor ( indexValue/25 );
          chkPagination.
          pause ( 5000 ).
          //Getting the total count of destinations present in the destination list page
          elements ( 'xpath', "(//SPAN[@class='name-container'])", function ( searchCount ) { 
            //Adding the total number of content present in a page with the totalContent variable
            totalContent += searchCount.value.length;
          } );
          //Manipulating the Index value in the list page
          if ( quotient >= 1 ) {
            //Looping and counting the Destinations count from each page
            for ( var clickPagination = 1; clickPagination <= quotient; clickPagination++) {
              chkPagination.
              pause ( 5000 ).
              //Clicking the Next page icon in the pagination menu
              click ( "//SPAN[@class='single-right-arrow']" ).
              pause ( 5000 ).
              //Getting the total count of destinations from each page
              elements ( 'xpath', "(//SPAN[@class='name-container'])", function ( searchCount ) { 
              //Adding the destination count in the totalContent
              totalContent += searchCount.value.length;
            } );
            }
            chkPagination.
            waitForElementPresent ( "//A[@ng-if='currentPage == page']", 5000,false, function ( chkVisibility ) { 
            if ( chkVisibility.value != false )
            for ( var clickPagination = 1; clickPagination <= quotient; clickPagination++) {
              chkPagination.
              //Clicking the previous page menu in Pagination menu
              click ( "//SPAN[@class='single-left-arrow']" ).
              //Checking whether the data's are getting loaded 
              waitForElementPresent ( "//SPAN[@class='name-container']",5000, false, function ( chkPreviousPage ) {
                //Condition to check the contents are displayed after clicking on the Previous page icon
                if ( chkPreviousPage.value != false ) {
                  statusCount.push ( "Pass" );                 
                }
                else {
                  statusCount.push ( "Fail" );
                }
              } );
            }
          } );
          }
          chkPagination.
          //Waiting for the Element to be visible
          waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='folders']", 5000, false, function ( chkTitle ) {
            //Checking the Total contents present in the page is equals to index value count
            if ( totalContent == indexValue ) {
              chkPagination.
              //Updating the Pass status in Excel sheet
              writeToExcelPass ( 'portalx.xlsx', 'chkPaginationInFolders',2 , 2 );
            }
            else { 
              chkPagination.
              //Updating the Fail status in Excel sheet
              writeToExcelFail ( 'portalx.xlsx', 'chkPaginationInFolders',2 , 2, 3, "Total count is mismatcing the index count in List page" );
            }
          } );
                //Condition to check the contents are displayed after clicking on the Previous page icon
                if ( statusCount.includes ( "Fail ") ) {
                  chkPagination.
                  //Updating the Fail status in the Excel sheet
                  writeToExcelFail ( 'portalx.xlsx', 'chkPaginationInFolders',3 , 2, 3, "Contents are not getting displayed while clicking the previosus page icon in Pagination menu" );
                }
                else {
                  chkPagination.
                  //Updating the Pass status in Excel sheet
                  writeToExcelPass ( 'portalx.xlsx', 'chkPaginationInFolders',3 , 2 );    
                }
              } );
      } catch ( e ) {
        chkPagination.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'chkPaginationInFolders',2 , 2, 3, "Automation script terminated unexpectedly due to "+e+" reason, please try again" );
      }
    }
  }
}
//this function is for check and Add the Contentlist
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'portalx.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'FolderFilter' ];
var contentTitle = [ ];
var excelData,actualFolderName;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'folderFilter' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  'FolderFilter': function ( folderFilter ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[ excelData ].v );
      }      
    }
    if ( contentTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;
        folderFilter.pause ( 4000 ).useXpath ( ).
        //Wait for the arrow dropdown is visible in the page
        waitForElementVisible ( "//div/div/div/i[@class='dropdown-arrow sidebar-submenu-toggle ng-scope']", 9000, false, function ( folderDropdown ) {
        	console.log("folderDropdown",folderDropdown)
          if ( folderDropdown.value == true ) {
        		folderFilter.pause ( 4000 ).useXpath ( ).
        		//Click on the arrow dropdown
        		click ( "//div/div/div/i[@class='dropdown-arrow sidebar-submenu-toggle ng-scope']" ).
        		pause ( 4000 )
        	}
        } );
        folderFilter.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Folder Menu in Sidebar
        waitForElementVisible ( "//div[@ng-if='option.subMenu']/div/div/input", 4000, false, function ( checkFilterField ) {
          if ( checkFilterField.value == true ) {
            folderFilter.pause ( 4000 ).useXpath ( ).
            //Verify the Folder Menu is visible in the sidebar
            verify.visible ( "//div[@ng-if='option.subMenu']/div/div/input" ).
            pause ( 4000 ).
            //Click on the Folder Menu in sidebar
            click ( "//div[@ng-if='option.subMenu']/div/div/input" ).
            pause ( 4000 ).
            //Clear the value in the search field
            clearValue ( "//div[@ng-if='option.subMenu']/div/div/input" ).
            pause ( 4000 ).
            //Enter the value in the search field
            setValue ( "//div[@ng-if='option.subMenu']/div/div/input",contentTitle[ getData ] ).
            pause ( 4000 ).
            //Get the location for the Folder name in the page
            getLocationInView ( "//div/div/a/div[contains(.,'"+ contentTitle[ getData ] +"')]" ).
            pause ( 4000 ).
            //Wait for Folder name box is visible in the listing page
            waitForElementVisible ( "//div/div/a/div[contains(.,'"+ contentTitle[ getData ] +"')]", 9000, false, function ( checkFolderName ) {
              if ( checkFolderName.value == true ) {
                folderFilter.pause ( 4000 ).useXpath ( ).
                //Click on the folder name in the listing page
                click ( "//div/div/a/div[contains(.,'"+ contentTitle[ getData ] +"')]" ).
                pause ( 4000 ).
                //Wait for the folder title is viible in the page
                waitForElementVisible ("//div/div/span/span[@class='title ng-binding']", 9000, false, function ( checkFolderTitle ) {
                	if ( checkFolderTitle.value == true ) {
                		folderFilter.pause ( 4000 ).useXpath ( ).
                		//Get the text for folder name in the page
                		getText ( "//div/div/span/span[@class='title ng-binding']", function ( checkTheText ) {
                			actualFolderName = checkTheText.value;
                			if ( actualFolderName == contentTitle[ getData ] ) {
                				//Write the Excel to PASS Result and Reason
                        folderFilter.writeToExcelPass ( 'portalx.xlsx', 'FolderFilter', rowCount, 2 );
                			}
                			else {
                        this.verify.fail ( checkTheText.value, 'true', 'Text value is not displayed correctly in the Folder Page' );
                        //Write the Excel to FAIL Result and Reason
                        folderFilter.writeToExcelFail ( 'portalx.xlsx', 'FolderFilter', rowCount, 2, 3, "Actual Folder Name: '"+ actualFolderName +"' in the Folder Page. Expected Folder Name: as'" + contentTitle[getData] + "' in the Folder Page" );
                      }
                		} );
                	}
                	else {
                    this.verify.fail ( checkFolderTitle.value, 'true', 'Folder Name is not displayed correctly in the Folder Page' );
                    //Write the Excel to FAIL Result and Reason
                    folderFilter.writeToExcelFail ( 'portalx.xlsx', 'FolderFilter', rowCount, 2, 3, "Folder Name is not displayed correctly in the Folder Page" );
                  }
                } );  
              }
              else {
                this.verify.fail ( checkFolderName.value, 'true', 'Folder Name is not displayed in the Sidebar' );
                //Write the Excel to FAIL Result and Reason
                folderFilter.writeToExcelFail ( 'portalx.xlsx', 'FolderFilter', rowCount, 2, 3, "Folder Name is not displayed in the Sidebar" );
              }
            } );       
          }
          else {
            this.verify.fail ( checkFilterField.value, 'true', 'Filter field is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            folderFilter.writeToExcelFail ( 'portalx.xlsx', 'FolderFilter', rowCount, 2, 3, "Filter field is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    folderFilter.end ( );
  }
}
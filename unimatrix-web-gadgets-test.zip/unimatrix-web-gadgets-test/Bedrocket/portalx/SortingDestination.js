//this function is for check and Add the Contentlist
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'portalx.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['SortingDestination'];
var contentTitle = [ ];
var sortListName = [ ];
var sortArrow = [ ]; 
var listedTitle = [ ];
var excelData,arrowValue;
var getData, rowCount = 1;
var invertData, valueSwipe;
module.exports = {
  tags: ['sortingDestination'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  'SortingDestination': function ( sortingDestination ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[1] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[excelData].v );
      }
      //Read Sort List Name
      if ( excelData.includes ( 'B' ) ) {
        sortListName.push ( worksheet[excelData].v );
      }
      //Read Sort Arrow
      if ( excelData.includes ( 'C' ) ) {
        sortArrow.push ( worksheet[excelData].v );
      }
      //Read listed Title
      if ( excelData.includes ( 'D' ) ) {
        listedTitle.push ( worksheet[excelData].v );
      }
    }
    if ( contentTitle.length > 1 ) {
    	
      for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;    
        sortingDestination.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Folder Menu in Sidebar
        waitForElementVisible ( "//a/span[contains(.,'"+contentTitle[getData]+"')]", 4000, false, function ( checkMenuName ) {
        	valueSwipe = sortArrow[getData]
					switch ( valueSwipe ) {
				    case "asc":
				      invertData = "des"
				      break;
				    case "desc":
				      invertData = "asc"
				      break;
				  }
          if ( checkMenuName.value == true ) {
            sortingDestination.pause ( 4000 ).useXpath ( ).
            //Verify the Folder Menu is visible in the sidebar
            verify.visible ( "//a/span[contains(.,'"+contentTitle[getData]+"')]" ).
            pause ( 4000 ).
            //Click on the Folder Menu in sidebar
            click ( "//a/span[contains(.,'"+contentTitle[getData]+"')]" ).
            pause ( 4000 ).
            waitForElementVisible ( "//input[@id='search_input']", 9000, false, function ( checkSearchField ) {
              if ( checkSearchField.value == true ) {
                sortingDestination.pause ( 4000 ).useXpath ( ).
                clearValue ( "//input[@id='search_input']" ).
                pause ( 2000 ).
                setValue ( "//input[@id='search_input']", listedTitle[getData] ).
                useCss ( ).pause ( 2000 ).
                keys ( sortingDestination.Keys.ENTER ).
                pause ( 3000 ).useXpath ( ).
                click ( "//div/ng-view/div/ng-include/div/div/span/span[2]" ).
                pause ( 2000 ).
                waitForElementVisible ( "//index-collection/ng-transclude/destination-cell[1]/div/span/span[1]", 9000, false, function ( checksearchResult ) {
                  if ( checksearchResult.value == true ) {
                    sortingDestination.pause ( 4000 ).useXpath ( ).
                    click ( "//index-collection/ng-transclude/destination-cell[1]/div/span/span[1]" ).
                    pause ( 2000 ).
                    getLocationInView ( "//div/input[@name='destinationName']" ).
                    pause ( 2000 ).
                    waitForElementVisible ( "//div/input[@name='destinationName']", 9000, false, function ( checkNameField ) {
                      if ( checkNameField.value == true ) {
                        sortingDestination.pause ( 4000 ).useXpath ( ).
                        clearValue ( "//div/input[@name='destinationName']" ).
                        pause ( 2000 ).
                        setValue ( "//div/input[@name='destinationName']",listedTitle[ getData ] ).
                        pause ( 2000 ).
                        getLocationInView ( "//button[@class='cta-button']" ).
                        pause ( 2000 ).
                        click ("//button[@class='cta-button']").
                        //Verify the Folder Menu is visible in the sidebar
                        verify.visible ( "//a/span[contains(.,'"+ contentTitle[ getData ] +"')]" ).
                        pause ( 4000 ).
                        //Click on the Folder Menu in sidebar
                        click ( "//a/span[contains(.,'"+ contentTitle[ getData ] +"')]" ).
                        pause ( 4000 )
                      }
                      else {
                        this.verify.fail ( checkNameField.value, 'true', 'Name field is not displayed in Destination page' );
                        //Write the Excel to FAIL Result and Reason
                        sortingDestination.writeToExcelFail ( 'Portalx.xlsx', 'SortingDestination', rowCount, 5, 6, "Name field is not displayed in Destination page" );
                      }
                    } );
                  }
                  else {
                    this.verify.fail ( checksearchResult.value, 'true', 'Searched Result is not displayed in Destination listing page' );
                    //Write the Excel to FAIL Result and Reason
                    sortingDestination.writeToExcelFail ( 'Portalx.xlsx', 'SortingDestination', rowCount, 5, 6, "Searched Result is not displayed in Destination listing page" );
                  }
                } );
              }
              else {
                this.verify.fail ( checkSearchField.value, 'true', 'Search Field is not displayed in Destination listing page' );
                //Write the Excel to FAIL Result and Reason
                sortingDestination.writeToExcelFail ( 'Portalx.xlsx', 'SortingDestination', rowCount, 5, 6, "Search Field is not displayed in Destination listing page" );
              }
            });

           sortingDestination.pause ( 4000 ).useXpath ( ).
            //Get the location for the Folder name in the page
            getLocationInView ( "//sort-menu/i[@class='index-header-icon sort-icon auto-untoggle']" ).
            pause ( 4000 ).
            //Wait for Folder name box is visible in the listing page
            waitForElementVisible ("//sort-menu/i[@class='index-header-icon sort-icon auto-untoggle']", 9000, false, function ( checkSortIcon ) {
              if ( checkSortIcon.value == true ) {
                sortingDestination.pause ( 4000 ).useXpath ( ).
                //Click on the sort icon in the dropdown
                click ("//sort-menu/i[@class='index-header-icon sort-icon auto-untoggle']").
                pause ( 4000 ).
                //Wait for the sort list is viisble in the dropdown option
                waitForElementVisible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+sortListName[getData]+"')]", 9000, false, function ( checkSortLst ) {
                	if ( checkSortLst.value == true ) {
                		if ( sortListName[ getData ] == 'Name' ) {
                			sortingDestination.pause ( 4000 ).useXpath ( ).
                      //Verify the sort list is visible in the dropdown option
                			verify.visible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+sortListName[getData]+"')]" ).
                			pause ( 4000 ).
                      //Click on the sort listed name in the dropdown option
                			click ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+sortListName[getData]+"')]" ).
                			pause ( 4000 ).
                      //Wait for the arrow button in the dropdown option
                			waitForElementVisible ( "//div/ul/li/i[2]", 9000, false, function ( checkArrow ) {
                				if ( checkArrow.value == true ) {
                					sortingDestination.pause ( 4000 ).useXpath ( ).
                          //Get the attribute as click in the arrow button
                					getAttribute ( "//div/ul/li/i[2]","ng-click",function ( valueNgClick ) {
                						var clickedValue = valueNgClick.value;
                						//clickedValue = clickedValue.split("desc")
                						clickedValue = clickedValue.substring ( 22, 25 );                			
											      if ( clickedValue == invertData ) {
                							sortingDestination.pause ( 4000 ).useXpath ( ).
                              //Get the text for title in the listing page
                							getText ( "//destination-cell[1]/*//span[@class='destination-name-label ng-binding']", function ( checkFirstTitle ) {
                								var actualTitleNM = checkFirstTitle.value
                								if ( actualTitleNM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingDestination.writeToExcelPass ( 'portalx.xlsx', 'SortingDestination', rowCount, 5 );
                								}
                								else {
                                  this.verify.fail ( actualTitleNM, 'true', 'Fail to display the first title in the listing page' );
                									//Write the Excel to FAIL Result and Reason
                									sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Actual Title as:'"+ actualTitleNM +"'in the Destination listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                						else {
                							sortingDestination.pause ( 4000 ).useXpath ( ).
                              //Click on the arrow button in the dropdown
                							click("//div/ul/li/i[2]").
                							pause(4000).
                              //Get the text for title in the listing page
                							getText ( "//destination-cell[1]/*//span[@class='destination-name-label ng-binding']", function ( checkFirstTitle ) {
                								var actualTitleNM = checkFirstTitle.value
                								if ( actualTitleNM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingDestination.writeToExcelPass ( 'portalx.xlsx', 'SortingDestination', rowCount, 5 );
                								}
                								else {
                                  this.verify.fail ( actualTitleNM, 'true', 'Fail to display the first title in the listing page' );
                									//Write the Excel to FAIL Result and Reason
                									sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Actual Title as:'"+ actualTitleNM +"'in the Destination listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                					} );                					
                				}
                			} );
                		}
                		else if ( sortListName[ getData ] == 'Date Added' ) {
                			sortingDestination.pause ( 4000 ).useXpath ( ).
                      //Verify the sort list option is visible in the dropdown option
                			verify.visible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Click on the sort list option in the dropdown option
                			click ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Wait for the  arrow button is visible in the dropdown list
                			waitForElementVisible ( "//div/ul/li/i[2]", 9000, false, function ( checkArrow ) {
                				if ( checkArrow.value == true ) {
                					sortingDestination.pause ( 4000 ).useXpath ( ).
                          //Get the attribute as click in the arrow button
                					getAttribute ( "//div/ul/li/i[2]","ng-click",function ( valueNgClick ) {
                						var clickedValue = valueNgClick.value;
                						clickedValue = clickedValue.substring ( 22, 25 );
											      if ( clickedValue == invertData ) {
                							sortingDestination.pause ( 4000 ).useXpath ( ).
                              //Get the text for title in the listing page
                							getText ( "//destination-cell[1]/*//span[@class='destination-name-label ng-binding']", function ( checkFirstTitle ) {
                								var actualTitleDA = checkFirstTitle.value
                								if ( actualTitleDA == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingDestination.writeToExcelPass ( 'portalx.xlsx', 'SortingDestination', rowCount, 5 );
                								}
                								else {
                                  this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                									//Write the Excel to FAIL Result and Reason
                									sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Actual Title as:'"+ actualTitleDA +"'in the Destination listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                						else {
                							sortingDestination.pause ( 4000 ).useXpath ( ).
                              //Click on the arrow buuton in dropdown option
                							click("//div/ul/li/i[2]").
                							pause(4000).
                              //Get the text for title in the listing page
                							getText ( "//destination-cell[1]/*//span[@class='destination-name-label ng-binding']", function ( checkFirstTitle ) {
                								var actualTitleDA = checkFirstTitle.value
                								if ( actualTitleDA == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingDestination.writeToExcelPass ( 'portalx.xlsx', 'SortingDestination', rowCount, 5 );
                								}
                								else {
                                  this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                									//Write the Excel to FAIL Result and Reason
                									sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Actual Title as:'"+ actualTitleDA +"'in the Destination listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                					} );                					
                				}
                			} );
                		}
                		else if ( sortListName[ getData ] == 'Last Modified' ) {
                			sortingDestination.pause ( 4000 ).useXpath ( ).
                      //Verify the sort list option is visible in the dropdown option
                			verify.visible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Click on the sort list option in the dropdown option
                			click ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Wait for the arrow button is visible in the dropdown option
                			waitForElementVisible ( "//div/ul/li/i[2]", 9000, false, function ( checkArrow ) {
                				if ( checkArrow.value == true ) {
                					sortingDestination.pause ( 4000 ).useXpath ( ).
                          //Get the attribute as click in the arrow button
                					getAttribute ( "//div/ul/li/i[2]","ng-click",function ( valueNgClick ) {
                						var clickedValue = valueNgClick.value;
                						clickedValue = clickedValue.substring ( 22, 25 );
											      if ( clickedValue == invertData ) {
                							sortingDestination.pause ( 4000 ).useXpath ( ).
                              //Get the text for title in the listing page
                							getText ( "//destination-cell[1]/*//span[@class='destination-name-label ng-binding']", function ( checkFirstTitle ) {
                								var actualTitleLM = checkFirstTitle.value
                								if ( actualTitleLM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingDestination.writeToExcelPass ( 'portalx.xlsx', 'SortingDestination', rowCount, 5);
                								}
                								else {
                                  this.verify.fail ( actualTitleLM, 'true', 'Fail to display the first title in the listing page' );
                									//Write the Excel to FAIL Result and Reason
                									sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Actual Title as:'"+ actualTitleLM +"'in the Destination listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                						else {
                							sortingDestination.pause ( 4000 ).useXpath ( ).
                              //Click on the arrow button in the dropdown
                							click("//div/ul/li/i[2]").
                							pause(4000).
                              //Get the text for title in the listing page
                							getText ( "//destination-cell[1]/*//span[@class='destination-name-label ng-binding']", function ( checkFirstTitle ) {
                								var actualTitleLM = checkFirstTitle.value 
                								if ( actualTitleLM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingDestination.writeToExcelPass ( 'portalx.xlsx', 'SortingDestination', rowCount, 5 );
                								}
                								else {
                                  this.verify.fail ( actualTitleLM, 'true', 'Fail to display the first title in the listing page' );
                									//Write the Excel to FAIL Result and Reason
                									sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Actual Title as:'"+ actualTitleLM +"'in the Destination listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                					} );                					
                				}
                			} );
                		}
                		else {
                      this.verify.fail ( checkSortLst.value, 'true', 'Sort Element is not avail in the list' );
                			//Write the Excel to FAIL Result and Reason
                			sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Sort Element is not avail in the list" );

                		}
                	}
                } );            
              }
              else {
                this.verify.fail ( checkSortIcon.value, 'true', 'Sort Icon is not displayed in the listing page' );
                //Write the Excel to FAIL Result and Reason
                sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5,6, "Sort Icon is not displayed in the listing page" );
              }
            } );
          }
          else {
            this.verify.fail ( checkMenuName.value, 'true', 'Folders menu is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            sortingDestination.writeToExcelFail ( 'portalx.xlsx', 'SortingDestination', rowCount, 5, 6, "Folders menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    sortingDestination.end ( );
  }
}
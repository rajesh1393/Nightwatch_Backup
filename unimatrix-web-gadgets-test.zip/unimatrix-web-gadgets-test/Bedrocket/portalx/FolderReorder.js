//this function is for Folder Reorder in the Portalx
var excelRow, excelColumn = 1;
var splitSourceOrder = [ ];           
var splitDestinationOrder = [ ]; 
var currentSource = [ ];
var actualSource = [ ];
var robot = require("robotjs");
module.exports = {
  tags: ['folderReorder'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'FolderReorder': function ( folderReorder ) {   
    var excel = folderReorder.globals.excelCol; 
    if ( excel.A.length > 0 ) {
    	for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        folderReorder.pause ( 4000 ).useXpath ( ).
        //Wait for the folder menu is visible in the page
        waitForElementVisible ( "//div[1]/div[3]/a/span[contains(.,'folders')]", 9000, false, function ( folderMenu ) {
        	if ( folderMenu.value == true ) {
        		folderReorder.pause ( 4000 ).useXpath ( ).
		        //Wait for the arrow dropdown is visible in the page
		        waitForElementVisible ( "//div[3]/div/i", 9000, false, function ( folderDropdown ) {
		        	if ( folderDropdown.value == true ) {
		        		folderReorder.pause ( 4000 ).useXpath ( ).
		        		//Click on the arrow dropdown
		        		click ( "//div[3]/div/i" ).
		        		pause ( 4000 )
		        	}
		        } );
		        folderReorder.pause ( 4000 ).useXpath ( ).
		        //Wait and Verify the Folder Edit in Sidebar
		        waitForElementVisible ( "//ng-include[3]//div[1]/div[3]//div/span", 4000, false, function ( checkFilterEditBtn ) {
		          if ( checkFilterEditBtn.value == true ) {
		          	folderReorder.pause ( 4000 ).useXpath ( ).
                //Click on the filter edit button in the page
		          	click ( "//ng-include[3]//div[1]/div[3]//div/span" ).
		          	pause ( 4000 ).
                //Wait for the caption text is visible in the page
		          	waitForElementVisible ( "//div[2]/span", 9000, false, function ( checkCaptionTxt ) {
		          		if ( checkCaptionTxt.value == true ) {
		          			folderReorder.pause ( 4000 ).useXpath ( ).
                    //Get the  caption text in the page
		          			getText ( "//div[2]/span", function ( captionTxt ) {
		          				if ( captionTxt.value == "Drag folders to edit order." ) {
		          					splitSourceOrder = excel.A[ excelColumn ].split(':')
                        splitDestinationOrder = excel.B[ excelColumn ].split(':')
                        //loop the 'n' number of splitted input
                        for ( let getOrder = 0; getOrder<splitSourceOrder.length; getOrder++ ) {
                          if ( ( excel.C[ excelColumn ] != "FAIL" ) && ( excel.D[ excelColumn ] == undefined ) ) {
                            folderReorder.useXpath ( ).pause ( 4000 ).
                            //Wait for the Save as Inactive in the page
                            waitForElementVisible ( "//button[@class='cta-button cta_inactive']", 9000, false, function ( checkSaveInactive ) {
                              if ( checkSaveInactive.value == true ) {                           
                                folderReorder.useXpath ( ).pause ( 4000 ).
                                //Get the text for current source order in the page
                                getText ( "//span[@class='folder-name-label ng-binding'][contains(.,'"+splitSourceOrder[ getOrder ]+"')]//..//..//../span[2]/div", function ( currentSourceOrder ) {
                                    if ( currentSourceOrder.status != -1 ) {
                                      currentSource = currentSourceOrder.value;   
                                      folderReorder.useXpath ( ).pause ( 4000 ). 
                                      //Get the location view for destination in the page                                    
                                      getLocationInView( "//span[@class='folder-name-label ng-binding'][contains(.,'"+splitDestinationOrder[ getOrder ]+"')]//..//..//../span[2]/div", function( checkLocation ) {
                                        folderReorder.pause ( 5000 ).useXpath ( ).
                                        //Get the text for destination loctaion x and y coordinates in the page
                                        getText ( "//span[@class='folder-name-label ng-binding'][contains(.,'"+splitDestinationOrder[ getOrder ]+"')]//..//..//../span[2]/div", function ( currentDestinationOrder ) {
                                          console.log("currentDestinationOrder",currentDestinationOrder)
                                          if ( currentDestinationOrder.status != -1 ) {
                                            destinationOrder = currentDestinationOrder.value
                                            if ( currentSource < destinationOrder ) {
                                              folderReorder.pause ( 2000 ).
                                              //Execute the mouse delay in the page
                                              execute ( robot.setMouseDelay ( 2 ) ).
                                              //Execute the mouse move as provided x and y coordinates
                                              execute ( robot.moveMouse ( ( ( checkLocation.value.x )+5 ), ( ( checkLocation.value.y )+120 ) ) );
                                            }
                                            else {
                                              folderReorder.pause ( 2000 ).
                                              //Execute the mouse delay in the page
                                              execute ( robot.setMouseDelay ( 2 ) ).
                                              //Execute the mouse move as provided x and y coordinates
                                              execute ( robot.moveMouse ( ( ( checkLocation.value.x )+5 ), ( ( checkLocation.value.y )+120 ) ) );
                                            }
                                            folderReorder.pause ( 5000 ).useXpath ( ).
                                            //Move to element for the source order in the reorder page
                                            moveToElement ( "//span[@class='folder-name-label ng-binding'][contains(.,'"+splitSourceOrder[ getOrder ]+"')]",10,10 ).
                                            //Hold the left mouse button in the page
                                            mouseButtonDown ( 0 ).
                                            //Move to element for the destination order in the reorder page
                                            moveToElement ( "//span[@class='folder-name-label ng-binding'][contains(.,'"+splitDestinationOrder[ getOrder ]+"')]",20,0 ).
                                            pause ( 5000 ).useCss ( ).
                                            //Release the left mouse button in the page
                                            mouseButtonUp ( 0 ).
                                            pause ( 3000 ).useXpath ( ). 
                                            //Wait for the Save as Active in the page                           
                                            waitForElementVisible ( "//button[@class='cta-button']", 9000, false, function ( checkSaveActive ) {
                                              if ( checkSaveActive.value == true ) {
                                                folderReorder.pause ( 5000 ).useXpath ( ).
                                                //Click on the save button in the reorder page
                                                click ( "//button[@class='cta-button']" ).
                                                pause ( 4000 ).                                                
                                                //Get the actual source ordered in the reorder page
                                                getText ( "//span[@class='folder-name-label ng-binding'][contains(.,'"+splitSourceOrder[ getOrder ]+"')]//..//..//../span[2]/div", function ( actualSourceOrder ) {
                                                  if ( actualSourceOrder.status != -1 ) {
                                                    actualSource = actualSourceOrder.value;
                                                    if ( (actualSource != currentSource) && ( destinationOrder == actualSource ) ) {
                                                      //Write the Excel to PASS Result and Reason
                                                      folderReorder.writeToExcelPass ( 'portalx.xlsx', 'FolderReorder', excelRow, 3 );
                                                    }
                                                    else {
                                                      //Write the Excel to FAIL Result and Reason
                                                      this.verify.fail ( actualSource, 'true', 'actual value is not displayed in the page' );                                                      
                                                      folderReorder.writeToExcelFail ( 'portalx.xlsx', 'FolderReorder', excelRow, 3, 4, "ActualResult: '"+ actualSource +"' position in Reorder containers pages. ExpectedResult: should be'" + currentSource + "' in the Total Count" );
                                                    }
                                                  }
                                                  else {
                                                    //Write the Excel to FAIL Result and Reason
                                                    this.verify.fail ( actualSourceOrder.value, 'true', 'Order Container is not displayed in the page' );                                                      
                                                    folderReorder.writeToExcelFail ( 'portalx.xlsx','FolderReorder', excelRow, 3, 4, "Order Container is not displayed in the page" );
                                                  }
                                                } );
                                              }
                                              else {
                                                //Write the Excel to FAIL Result and Reason
                                                this.verify.fail ( checkSaveActive.value, 'true', 'Save button is not enabled in the page' );                                                      
                                                folderReorder.writeToExcelFail ( 'portalx.xlsx','FolderReorder', excelRow, 3, 4, "Save button is not enabled in the page" );
                                              }
                                            } ); 
                                          }
                                          else {
                                      			//Write the Excel to FAIL Result and Reason
                                            this.verify.fail ( currentDestinationOrder.value, 'true', 'Destination value is not displayed in the page' );                                                      
                                            folderReorder.writeToExcelFail ( 'portalx.xlsx','FolderReorder', excelRow, 3, 4, "Destination value is not displayed in the page" );
                                    			}
                                        } ); 
                                      } );
                                    }
                                    else {
                                      //Write the Excel to FAIL Result and Reason
                                      this.verify.fail ( currentSourceOrder.value, 'true', 'Source value is not displayed in the page' );                                                      
                                      folderReorder.writeToExcelFail ( 'portalx.xlsx','FolderReorder', excelRow, 3, 4, "Source value is not displayed in the page" );
                                    }
                                } );                        
                              }
                              else {
                                //Write the Excel to FAIL Result and Reason
                                this.verify.fail ( checkSaveInactive.value, 'true', 'Save Inactive is not shown in the page' );                                                      
                                folderReorder.writeToExcelFail ( 'portalx.xlsx','FolderReorder', excelRow, 3, 4, "Save Inactive is not shown in the page" );
                              }
                            } );
                          }                          
                        }
		          				}
		          				else {
                        this.verify.fail ( captionTxt.value, 'true', 'Folder Name is not displayed in the Sidebar' );
                        //Write the Excel to FAIL Result and Reason
                        folderReorder.writeToExcelFail ( 'portalx.xlsx', 'FolderReorder', excelRow, 3, 4, "Caption label Text is not readable in the Sidebar" );
		          				}
		          			} );
		          		}
		          		else {
                    this.verify.fail ( checkCaptionTxt.value, 'true', 'Folder Name is not displayed in the Sidebar' );
                    //Write the Excel to FAIL Result and Reason
                    folderReorder.writeToExcelFail ( 'portalx.xlsx', 'FolderReorder', excelRow, 3, 4, "Caption Label is not displayed in the Sidebar" );
		          		}
		          	} );            
              }
              else {
                this.verify.fail ( checkFilterEditBtn.value, 'true', 'Folder Name is not displayed in the Sidebar' );
                //Write the Excel to FAIL Result and Reason
                folderReorder.writeToExcelFail ( 'portalx.xlsx', 'FolderReorder', excelRow, 3, 4, "Folder Name is not displayed in the Sidebar" );
              }
            } );       
          }
          else {
            this.verify.fail ( folderMenu.value, 'true', 'Filter field is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            folderReorder.writeToExcelFail ( 'portalx.xlsx', 'FolderReorder', excelRow, 3, 4, "Filter field is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    folderReorder.end ( );
  }
}
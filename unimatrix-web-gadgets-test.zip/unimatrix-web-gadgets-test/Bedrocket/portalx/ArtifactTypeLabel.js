//this function is for Artifact Type Label the PAGES
var excelRow, excelColumn = 1;
var splitSourceOrder = [ ];           
var splitDestinationOrder = [ ]; 
var currentSource = [ ];
var actualSource = [ ];
var robot = require("robotjs");
module.exports = {
  tags: ['viewsInSearch'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
    	//Clear data in excelinput
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'ArtifactTypeLabel': function ( artifactType ) {   
    var excel = artifactType.globals.excelCol; 
    if ( excel.A.length > 0 ) {
    	for ( let excelColumn = 1, excelRow = 1; excelColumn < excel.A.length; excelColumn++ ) {
        excelRow++;
        artifactType.pause ( 4000 ).useXpath ( ).
        //Wait for the left side menu is visible in the page
        waitForElementVisible ( "//div[1]/div/a/span[contains(.,'"+excel.A[excelColumn]+"')]", 9000, false, function ( leftSideMenu ) {
        	artifactType.pause ( 4000 ).useXpath ( ).
          //Click on left side menu in the page
        	click ( "//div[1]/div/a/span[contains(.,'"+excel.A[excelColumn]+"')]" ).
        	pause ( 4000 )   	
          if ( excel.B[excelColumn] == 'list' ) {
            artifactType.pause ( 4000 ).useXpath ( ).
            //Wait for the list view icon is visible in the page
            waitForElementVisible ( "//ng-view/div/div/div[2]/i[1]", 9000, false, function ( checkListView ) {
              if ( checkListView.value == true ) {
                artifactType.pause ( 4000 ).useXpath ( ).
                //Click on the list view icon in the page
                click ( "//ng-view/div/div/div[2]/i[1]" ).
                pause ( 4000 ).
                //Wat for the list view in page is visible in the page
                waitForElementVisible ( "//index-collection/ng-transclude[@class='list_display']", 9000, false, function ( checkListViewInPage ) {
                  if ( checkListViewInPage.value == true ) {
                    artifactType.pause ( 4000 ).useXpath ( ).
                    //Wait for the search button is visible in the page
                    waitForElementVisible ( "//*[@id='search_input']", 4000, false, function ( checkSearchBtn ) {
                      if ( checkSearchBtn.value == true ) {
                        artifactType.useXpath ( ).pause ( 4000 ).
                        //Click on the search field in the portalx index page
                        click ( "//*[@id='search_input']" ).
                        pause ( 2000 ).
                        //Clear the data in the search field in the portalx index page
                        clearValue ( "//*[@id='search_input']" ).
                        pause ( 2000 ).
                        //Enter the data in the search field in the portalx index page
                        setValue ( "//*[@id='search_input']", excel.C[ excelColumn ] ).
                        useCss ( ).pause ( 2000 ).
                        //Press return key
                        keys ( artifactType.Keys.ENTER ).
                        useXpath ( ).pause ( 2000 ).   
                        //Wait for the searched result is visible in the listing page           
       									waitForElementVisible ( "//item-cell[1]/div/span/a[1]/span[1]", 9000, false, function ( checkSearchedResult ) {
                      		if ( checkSearchedResult.value == true ) {
                        		artifactType.useXpath ( ).pause ( 4000 ).
                            //Get the title text in the listing page
                        		getText ( "//item-cell[1]/div/span/a[1]/span[1]", function ( titleTxtList ) {
                          		if ( titleTxtList.value == excel.C[ excelColumn ] ) {
                          			artifactType.useXpath ( ).pause ( 4000 ).
                                //Wait for the Artifact type is visible in the page
                          			waitForElementVisible ( "(//item-cell/div/span/a[1]/span[2])[1]", 9000, false, function ( checkArtifactType ) {
                          				if ( checkArtifactType.value == true ) {
                          					artifactType.useXpath ( ).pause ( 4000 ).
                                    //Get Value of the Artifact type in the page
                          					getText ( "(//item-cell/div/span/a[1]/span[2])[1]", function ( valueOfArtifactType ) {
                          						if ( valueOfArtifactType.value == excel.D[ excelColumn ] ) {
                          							artifactType.useXpath ( ).pause ( 4000 ).
                                        //Wait for the language type is visible in the page
                          							waitForElementVisible ( "//item-cell[1]/div/span/a[1]/span[3]", 9000, false, function ( checkLanguageType ) {
                          								if ( checkLanguageType.value == true ) {
                          									artifactType.useXpath ( ).pause ( 4000 ).
                                            //Get the value of the language type in the page
                          									getText ( "//item-cell[1]/div/span/a[1]/span[3]", function ( valueOfLanguageType ) {
                          										if ( valueOfLanguageType.value == excel.E[ excelColumn ] ) {
																								//Write the Excel to PASS Result and Reason
                            										artifactType.writeToExcelPass ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6 );
                          										}
                          										else {
                          											this.verify.fail ( valueOfLanguageType.value, 'true', 'value Of Language Type is not displayed in the listing page' );
							                              		//Write the Excel to FAIL Result and Reason
							                             		  artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "Actual value Of Language Type as " +valueOfLanguageType.value+ " and Expected value Of Language Type as "+excel.E[ excelColumn ]+" in the List View listing page" );
                          										}
                          									} );
                          								}
                          								else {
                          									this.verify.fail ( checkLanguageType.value, 'true', 'Language Type is not displayed in the listing page' );
                            								//Write the Excel to FAIL Result and Reason
                           		 							artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "Actual Language Type as " +checkLanguageType.value+ " and Expected Language Type as "+excel.E[ excelColumn ]+" in the List View listing page" );
                           								}
                          							} );
                          						}
                          						else {
                          							this.verify.fail ( valueOfArtifactType.value, 'true', 'Value Of Artifact Type is not displayed in the listing page' );
                            						//Write the Excel to FAIL Result and Reason
                           		  				artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "Actual value Of Artifact Type Label as " +valueOfArtifactType.value+ " and Expected value Of Artifact Type as "+excel.D[ excelColumn ]+" in the List View listing page" );
                           						}
                          					} );
                          				}
                          				else {
                          					this.verify.fail ( checkArtifactType.value, 'true', 'Artifact Type label is not displayed in the listing page' );
                            				//Write the Excel to FAIL Result and Reason
                           		 			artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "Actual Artifact Type label as " +checkArtifactType.value+ " and Artifact Type as "+excel.D[ excelColumn ]+" in the List View listing page" );
                          				}
                          			} );
                          		}
                          		else {
                            		this.verify.fail ( titleTxtList.value, 'true', 'Searched Result is not displayed in the listing page' );
                            		//Write the Excel to FAIL Result and Reason
                           		  artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "Actual Title as " +titleTxtList.value+ " and Expected Title as "+excel.C[ excelColumn ]+" in the List View listing page" );
                          		}
                        		} );
                      		}
                      		else {
                        		this.verify.fail ( checkSearchedResult.value, 'true', 'Searched Result is not displayed in the listing page' );
                        		//Write the Excel to FAIL Result and Reason
                        		artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "Searched Result is not displayed in the listing page" );
                      		}
                    		} );              
                      }
                      else {
                        this.verify.fail ( checkSearchBtn.value, 'true', 'List View formation is not displayed in the page' );
                        //Write the Excel to FAIL Result and Reason
                        artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "List View formation is not displayed in the page" );
                      }
                    } ); 
                  }
                  else {
                    this.verify.fail ( checkListViewInPage.value, 'true', 'List View formation is not displayed in the page' );
                    //Write the Excel to FAIL Result and Reason
                    artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "List View formation is not displayed in the page" );
                  }
                } );
              }
              else {
                this.verify.fail ( checkListView.value, 'true', 'List View Icon is not displayed in the page' );
                //Write the Excel to FAIL Result and Reason
                artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "List View Icon is not displayed in the page" );
              }
            } );                                        
          }
          else {
            this.verify.fail ( leftSideMenu.value, 'true', 'Menu is not displayed in the portalx Leftside bar' );
            //Write the Excel to FAIL Result and Reason
            artifactType.writeToExcelFail ( 'portalx.xlsx', 'ArtifactTypeLabel', excelRow, 6, 7, "Menu is not displayed in the portalx Leftside bar" );
          }
        } );
      }
    }
    //End the Browser
    artifactType.end ( );
  }
}
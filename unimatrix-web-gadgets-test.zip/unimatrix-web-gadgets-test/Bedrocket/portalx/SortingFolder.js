//this function is for check and Add the Contentlist
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'portalx.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['SortingFolder'];
var contentTitle = [ ];
var sortListName = [ ];
var sortArrow = [ ]; 
var listedTitle = [ ];
var excelData,arrowValue;
var getData, rowCount = 1;
var invertData, valueSwipe;
module.exports = {
  tags: ['sortingFolder'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  'SortingFolder': function ( sortingFolder ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[1] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[excelData].v );
      }
      //Read Sort List Name
      if ( excelData.includes ( 'B' ) ) {
        sortListName.push ( worksheet[excelData].v );
      }
      //Read Sort Arrow
      if ( excelData.includes ( 'C' ) ) {
        sortArrow.push ( worksheet[excelData].v );
      }
      //Read listed Title
      if ( excelData.includes ( 'D' ) ) {
        listedTitle.push ( worksheet[excelData].v );
      }
    }
    if ( contentTitle.length > 1 ) {
    	
      for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;
        sortingFolder.pause ( 4000 ).useXpath ( ).
        //Wait and Verify the Folder Menu in Sidebar
        waitForElementVisible ( "//a/span[contains(.,'"+contentTitle[getData]+"')]", 4000, false, function ( checkMenuName ) {
        	valueSwipe = sortArrow[getData]
					switch ( valueSwipe ) {
				    case "asc":
				      invertData = "des"
				      break;
				    case "desc":
				      invertData = "asc"
				      break;
				  }
          if ( checkMenuName.value == true ) {
            sortingFolder.pause ( 4000 ).useXpath ( ).
            //Verify the Folder Menu is visible in the sidebar
            verify.visible ( "//a/span[contains(.,'"+contentTitle[ getData ]+"')]" ).
            pause ( 4000 ).
            //Click on the Folder Menu in sidebar
            click ( "//a/span[contains(.,'"+contentTitle[ getData ]+"')]" ).
            pause ( 4000 ).
            //Get the location for the Folder name in the page
            getLocationInView ( "//sort-menu/i[@class='index-header-icon sort-icon auto-untoggle']" ).
            pause ( 4000 ).
            //Wait for Folder name box is visible in the listing page
            waitForElementVisible ("//sort-menu/i[@class='index-header-icon sort-icon auto-untoggle']", 9000, false, function ( checkSortIcon ) {
              if ( checkSortIcon.value == true ) {
                sortingFolder.pause ( 4000 ).useXpath ( ).
                //Click on the sort list option is visible in the dropdown option
                click ("//sort-menu/i[@class='index-header-icon sort-icon auto-untoggle']").
                pause ( 4000 ).
                //Wait for the sort list option in the dropdown list
                waitForElementVisible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+sortListName[getData]+"')]", 9000, false, function ( checkSortLst ) {
                	if ( checkSortLst.value == true ) {
                		if ( sortListName[ getData ] == 'Name' ) {
                			sortingFolder.pause ( 4000 ).useXpath ( ).
                      //Verify the sort list option is visible in the dropdown option
                			verify.visible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+sortListName[getData]+"')]" ).
                			pause ( 4000 ).
                      //Click on the sort list option in the dropdown option
                			click ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+sortListName[getData]+"')]" ).
                			pause ( 4000 ).
                      //Wait for the arrow button is visible in the dropdown option
                			waitForElementVisible ( "//div/ul/li/i[2]", 9000, false, function ( checkArrow ) {
                				if ( checkArrow.value == true ) {
                					sortingFolder.pause ( 4000 ).useXpath ( ).
                          //Get the attribute value for arrow button in the dropdown option
                					getAttribute ( "//div/ul/li/i[2]","ng-click",function ( valueNgClick ) {
                						var clickedValue = valueNgClick.value;                						
                						clickedValue = clickedValue.substring ( 22, 25 );                						         						
											      if ( clickedValue == invertData ) {
                							sortingFolder.pause ( 4000 ).useXpath ( ).
                              //Get the Text for the title in the listing page
                							getText ( "//div/index-collection/ng-transclude/folder-cell[1]/div/span/span[1]/a/span", function ( checkFirstTitle ) {
                                var actualTitleNM = checkFirstTitle.value
                								if ( actualTitleNM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingFolder.writeToExcelPass ( 'portalx.xlsx', 'SortingFolder', rowCount, 5 );
                								}
                								else {
                									this.verify.fail ( actualTitleNM, 'true', 'Fail to display the first title in the listing page' );
                                  //Write the Excel to FAIL Result and Reason
                                  sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Actual Title as:'"+ actualTitleNM +"'in the Folder listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                						else {
                							sortingFolder.pause ( 4000 ).useXpath ( ).
                              //Click on the arrow button
                							click("//div/ul/li/i[2]").
                							pause(4000).
                              //Get the Text for the title in the listing page
                							getText ( "//div/index-collection/ng-transclude/folder-cell[1]/div/span/span[1]/a/span", function ( checkFirstTitle ) {
                                var actualTitleNM = checkFirstTitle.value
                								if ( actualTitleNM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingFolder.writeToExcelPass ( 'portalx.xlsx', 'SortingFolder', rowCount, 5 );
                								}
                								else {
                									this.verify.fail ( actualTitleNM, 'true', 'Fail to display the first title in the listing page' );
                                  //Write the Excel to FAIL Result and Reason
                                  sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Actual Title as:'"+ actualTitleNM +"'in the Folder listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                					} );                					
                				}
                			} );
                		}
                		else if ( sortListName[ getData ] == 'Date Added' ) {
                			sortingFolder.pause ( 4000 ).useXpath ( ).
                      //Verify the sort list option is visible in the dropdown option
                			verify.visible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Click on the sort list in the dropdown option
                			click ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Wait for the arrow button is visible in the dropdown option
                			waitForElementVisible ( "//div/ul/li/i[2]", 9000, false, function ( checkArrow ) {
                				if ( checkArrow.value == true ) {
                					sortingFolder.pause ( 4000 ).useXpath ( ).
                          //Get the attribute value for arrow button in the dropdown option
                					getAttribute ( "//div/ul/li/i[2]","ng-click",function ( valueNgClick ) {
                						var clickedValue = valueNgClick.value;
                						clickedValue = clickedValue.substring ( 22, 25 );
											      if ( clickedValue == invertData ) {
                							sortingFolder.pause ( 4000 ).useXpath ( ).
                              //Get the Text for the title in the listing page
                							getText ( "//div/index-collection/ng-transclude/folder-cell[1]/div/span/span[1]/a/span", function ( checkFirstTitle ) {
                                var actualTitleDA = checkFirstTitle.value
                								if ( actualTitleDA == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingFolder.writeToExcelPass ( 'portalx.xlsx', 'SortingFolder', rowCount, 5 );
                								}
                								else {
                									this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                                  //Write the Excel to FAIL Result and Reason
                                  sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Actual Title as:'"+ actualTitleDA +"'in the Folder listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                						else {
                							sortingFolder.pause ( 4000 ).useXpath ( ).
                              //Click on the arrow button
                							click("//div/ul/li/i[2]").
                							pause(4000).
                              //Get the Text for the title in the listing page
                							getText ( "//div/index-collection/ng-transclude/folder-cell[1]/div/span/span[1]/a/span", function ( checkFirstTitle ) {
                                var actualTitleDA = checkFirstTitle.value
                								if ( actualTitleDA == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingFolder.writeToExcelPass ( 'portalx.xlsx', 'SortingFolder', rowCount, 5 );
                								}
                								else {
                									this.verify.fail ( actualTitleDA, 'true', 'Fail to display the first title in the listing page' );
                                  //Write the Excel to FAIL Result and Reason
                                  sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Actual Title as:'"+ actualTitleDA +"'in the Folder listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                					} );                					
                				}
                			} );
                		}
                		else if ( sortListName[ getData ] == 'Last Modified' ) {
                			sortingFolder.pause ( 4000 ).useXpath ( ).
                      //Verify the sort list option is visible in the dropdown option
                			verify.visible ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Click on the sort list option in the dropdown
                			click ( "//div/ul/li[@class='auto-untoggle sort-li'][contains(.,'"+ sortListName[getData] +"')]" ).
                			pause ( 4000 ).
                      //Wait for the arrow button is visible in the dropdown list
                			waitForElementVisible ( "//div/ul/li/i[2]", 9000, false, function ( checkArrow ) {
                				if ( checkArrow.value == true ) {
                					sortingFolder.pause ( 4000 ).useXpath ( ).
                          //Get the attribute value for arrow button in the dropdown option
                					getAttribute ( "//div/ul/li/i[2]","ng-click",function ( valueNgClick ) {
                						var clickedValue = valueNgClick.value;
                						clickedValue = clickedValue.substring ( 22, 25 );
											      if ( clickedValue == invertData ) {
                							sortingFolder.pause ( 4000 ).useXpath ( ).
                              //Get the Text for the title in the listing page
                							getText ( "//div/index-collection/ng-transclude/folder-cell[1]/div/span/span[1]/a/span", function ( checkFirstTitle ) {
                								var actualTitleLM = checkFirstTitle.value
                                if ( actualTitleLM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingFolder.writeToExcelPass ( 'portalx.xlsx', 'SortingFolder', rowCount, 5 );
                								}
                								else {
                									this.verify.fail ( actualTitleLM, 'true', 'Fail to display the first title in the listing page' );
                                  //Write the Excel to FAIL Result and Reason
                                  sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Actual Title as:'"+ actualTitleLM +"'in the Folder listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                						else {
                							sortingFolder.pause ( 4000 ).useXpath ( ).
                              //Click on the arrow button
                							click("//div/ul/li/i[2]").
                							pause(4000).
                              //Get the Text for the title in the listing page
                							getText ( "//div/index-collection/ng-transclude/folder-cell[1]/div/span/span[1]/a/span", function ( checkFirstTitle ) {
                                var actualTitleLM = checkFirstTitle.value
                								if ( actualTitleLM == listedTitle[ getData ] ) {
                									//Write the Excel to PASS Result and Reason
                           				sortingFolder.writeToExcelPass ( 'portalx.xlsx', 'SortingFolder', rowCount, 5 );
                								}
                								else {
                									this.verify.fail ( actualTitleLM, 'true', 'Fail to display the first title in the listing page' );
                                  //Write the Excel to FAIL Result and Reason
                                  sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Actual Title as:'"+ actualTitleLM +"'in the Folder listing page. Expected Title is:'"+ listedTitle[ getData ] +"' in the Destination listing page" );
                								}
                							} );
                						}
                					} );                					
                				}
                			} );
                		}
                		else {
                			this.verify.fail ( checkSortLst.value, 'true', 'Sort Element is not avail in the list' );
                      //Write the Excel to FAIL Result and Reason
                			sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Sort Element is not avail in the list" );
                		}
                	}
                } );            
              }
              else {
              	this.verify.fail ( checkSortIcon.value, 'true', 'Sort Icon is not displayed in the listing page' );
                //Write the Excel to FAIL Result and Reason
                sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Sort Icon is not displayed in the listing page" );
              }
            } );
          }
          else {
          	this.verify.fail ( checkMenuName.value, 'true', 'Folders menu is not displayed in Sidebar' );
            //Write the Excel to FAIL Result and Reason
            sortingFolder.writeToExcelFail ( 'portalx.xlsx', 'SortingFolder', rowCount, 5,6, "Folders menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    sortingFolder.end ( );
  }
}
var ErrMsg_DestiName;
var actualIndexBeforeAdd = [ ];
var ErrMsg_SelectRealm;
module.exports = {
  tags: [ 'chkFieldDestinationFun' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'DestinationBtnVisibilityFun': function ( checkFields ) {
    //Checking whether all the fields and buttons are getting displayed in Add destination page
    try {
      checkFields.
      useXpath ( ).
      click ( "//Span[text()='destinations']" ).
      useCss ( ).
      //Clikcing the Add btn 
      click ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope" ).
      useXpath ( ).
      //Clikcing the New Destination button from the Toggle dropdown
      click ( "//li[contains(.,'New Destination')]" ).
      //Checking whether the Cancel button is displayed
      waitForElementPresent ( "//BUTTON[@class='cancel-button'][text()='CANCEL']", 15000, false, function ( chk_CancelBtn ) {
        if ( chk_CancelBtn.value.length != 0 ) {
          checkFields.
          //Updating the Pass status in the Excel sheet
          writeToExcelPass ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 2, 2 );
        } else {
          //Updating the Fail status in the Excel sheet
          checkFields.
          writeToExcelFail ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 2, 2, 3, "Cancel button is not displayed (or) there may be a timeout issue" );
        }
      } );
      checkFields.
      //Checking whether the Create button is Displayed
      waitForElementPresent ( "//BUTTON[@class='cta-button'][text()='CREATE']", 15000, false, function ( createBtns ) {
        if ( createBtns.value.length != 0 ) {
          checkFields.
          //Updating the Pass status in the Excel sheet
          writeToExcelPass ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 3, 2 );
        } else {
          checkFields.
          //Updating the Fail status in the Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 3, 2, 3, "Create button is not displayed (or) there may be a timeout issue" );
        }
      } );
      checkFields.
      useCss ( ).
      //Checking whether the Add Button is displayed
      waitForElementNotPresent ( "ng-view > div > ng-include > div > div > toggle-menu > div.big-green-add-button.ng-isolate-scope", 15000, false, function ( addBtn ) {
        if ( addBtn.status == 0 ) {
          checkFields.
          //Updating the Pass status in Excel sheet
          writeToExcelPass ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 4, 2 );
        } else {
          checkFields.
          //Updating the Fail status in the Excel sheet         
          writeToExcelFail ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 4, 2, 3, "Add button is displayed  ( or ) there may be a timeout issue" );
        }
      } );
      checkFields.
      useXpath ( ).
      //Checking whether the Destination Name  field is dispalyed
      waitForElementPresent ( "//INPUT[@name='destinationName']", 15000, false, function ( DestName_Txtfield ) {
        if ( DestName_Txtfield.value.length != 0 ) {
          checkFields.
          //Updating the Pass status in Excel sheet
          writeToExcelPass ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 5, 2 )
        } else {
          checkFields.
          //Updating the Fail status in the Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 5, 2, 3, "Destination Name Text field is not displayed  ( or ) there may be a timeout issue" );
        }
      } );
      checkFields.
      //Checking whether the Realm Drop down is displyed
      waitForElementPresent ( "//DIV[@class='no-edit-field']", 15000, false, function ( Realm_DrpDown ) {
        if ( Realm_DrpDown.value.length != 0 ) {
          checkFields.
          //Updating the Pass status in Excel sheet
          writeToExcelPass ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 6, 2 );
        } else {
          checkFields.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 6, 2, 3, "Realm Drop down is not displayed  ( or ) there may be a timeout issue" );
        }
      } );
    } catch ( e ) {
      checkFields.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'DestinationBtnVisibilityFun', 6, 2, 3, "Realm Drop down is not displayed  ( or ) there may be a timeout issue" );
    }
  checkFields.end ( );
  },
}
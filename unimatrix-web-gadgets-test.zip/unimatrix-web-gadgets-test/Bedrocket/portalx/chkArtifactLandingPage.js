//Checking the Title section in AllContent page Page
module.exports = {
  tags: [ 'chkArtifactLandingPage' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkArtifactLandingPageFun': function ( chkLandingPage ) {
    var excel = chkLandingPage.globals.excelCol;
    for ( let inc = 1; inc < excel.B.length; inc++ ) {
      try {
        chkLandingPage.
        useXpath ( ).
        //Clicking the AllContent page link from the side bar
        click ( "//Span[text()='all content']" ).
        //Checking whether the control is navigated to All contents page.
        waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='all content']", 5000, false, function ( chkTitle ) {
          if ( chkTitle.value != false ) {
            chkLandingPage.
            //Checking whether the Search field is present in All contents page
            waitForElementPresent ( "//form[@name='searchInput']", 5000, false, function ( chkSrchField ) {
              if ( chkSrchField.value != false ) { 
                chkLandingPage.
                //Clicking the Search field
                click ( "//form[@name='searchInput']" ).
                //Entering the Artifact name from excel sheet to the Search field
                setValue ( "//form[@name='searchInput']/input",excel.B [ inc ] );
                //Hitting the Enter button
                chkLandingPage.
                keys ( chkLandingPage.Keys.ENTER );
                chkLandingPage.
                pause ( 5000 ).
                //Checking whether appropriate results are displayed in Search result
                waitForElementPresent ( "(//A[@ng-click='goToItem()'])[2]", 5000, false, function ( chkSrchResult ) {
                  chkLandingPage.
                  //Checking whether the search result are as same as the excel input
                  getText ( "(//A[@ng-click='goToItem()'])[2]", function ( getArtifactname ) {
                    if ( getArtifactname.value.includes ( excel.B [ inc ] ) ) {
                      chkLandingPage.
                      //Clicking on the Artifact from the search result
                      click ( "//span[@id='"+excel.B [ inc ]+"']" ).
                      pause ( 5000 ).
                      //Checking whether the control is navigated to Artifact detail page
                      waitForElementPresent ( "//SPAN[@class='title-box ng-binding'][text()='"+excel.B [ inc ]+"']", 5000, false, function ( chkDeatilPage ) {
                        if ( chkDeatilPage.value != false ) {
                          chkLandingPage.
                          //Checking whether the Artifact is landed in Properties detail page
                          waitForElementPresent ( "//DIV[@ng-class='{ active: tabs.properties, tab_half: !showMedia && !showContent }'][text()='properties']", 5000, false, function ( chkPropertiesTab ) {
                            if ( chkPropertiesTab.value != false ) {
                              chkLandingPage.
                              //Updating the Pass status in the Excel sheet
                              writeToExcelPass ( 'portalx.xlsx', 'chkArtifactLandingPageFun', ++inc, 3 );
                            }
                            else {
                              chkLandingPage.
                              //Updating the fail status in the Excel sheet
                              writeToExcelFail ( 'portalx.xlsx', 'chkArtifactLandingPageFun', ++inc, 3, 4 ,"After clicking on the Artifacts in All contents page the Page is not redirected to Properties tab" );
                            }
                          } );
                        }
                        else {
                          chkLandingPage.
                          //Updating the Fail status in the Excel sheet
                          writeToExcelFail ( 'portalx.xlsx', 'chkArtifactLandingPageFun', ++inc, 3, 4 ,"Unable to locate the title of the Artifact page" )
                        }
                      } );
                    }
                    else {
                      chkLandingPage.
                      //Updating the Fail status in Excel sheet
                      writeToExcelFail ( 'portalx.xlsx', 'chkArtifactLandingPageFun', ++inc, 3, 4 ,"Artifact you are searching is not avail in All contents page" )
                    }
                  } );
                } );
              }
              else {
                chkLandingPage.
                //Updating the fail status in Excel sheet
                writeToExcelFail ( 'portalx.xlsx', 'chkArtifactLandingPageFun', ++inc, 3, 4 ,"Search field is not displayed in the All contents page" );
              }
            } );
          }
          else {
            chkLandingPage.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkArtifactLandingPageFun', ++inc, 3, 4 ,"Control is not navigated to All contents page" );
          }
        } );
       } catch ( e ) {
        chkLandingPage.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'chkArtifactLandingPageFun', ++inc, 4, 5, "Execution of the script terminated due to "+e+" reason");
      }
    }
  }
}
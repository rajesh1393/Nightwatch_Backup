module.exports = {
  tags: ['chkElipseFolderPageFun'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profilex;
    portalLogin.loginx ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  //Assigning the Excel values to global excel variables
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'portalx.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  //Clearing the Global excel values after each function
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'chkElipseInFolderPageFun': function ( chkVerticalEllipse ) {
    //Setting up the Page object model
    var excel = chkVerticalEllipse.globals.excelCol;
    for ( let incrementer = 1; incrementer < excel.B.length; incrementer++ ) {
      chkVerticalEllipse.
      useXpath ( ).
      //Navigating to Destination Index page
      click ( "//Span[text()='folders']" ).
      pause ( 15000 );
      if ( excel.B [ incrementer ] == "List" ) {
        chkVerticalEllipse.
      //Checking whether the grid change icon is displayed in the Destiations page
      waitForElementPresent ( '//I[@class="index-header-icon listview-icon current_presentation"]', 15000, false, function ( chkListViewIcon ) {
        //Checking whether the List view icon is displayed in Destination page
        if ( chkListViewIcon.value != false ) {
          chkVerticalEllipse.
        //Clicking the list view icon
        click ( '//I[@class="index-header-icon listview-icon current_presentation"]' ).
        pause ( 5000 );
      }
      else {
        chkVerticalEllipse.
        //Updating the Fail status in Excel sheet
        writeToExcelFail ( 'portalx.xlsx', 'chkVerticalEllipseDestFunInView', ++incrementer, 4, 5, "Some thing went wrong, Please try again" );
      }
    } );
    }
    else {
      chkVerticalEllipse.
        //Waiting for the Grid view icon to be displayed
        waitForElementPresent ( '//I[@class="index-header-icon gridview-icon"]', 15000, false, function ( chkGridViewIcon ) {
          //Checking whether the Grid view icon is displayed in the Destination page
          if ( chkGridViewIcon.value != false ) {
            chkVerticalEllipse.
            //Clicking the Grid view icon from the destination page
            click ( '//I[@class="index-header-icon gridview-icon"]' ).
            pause ( 5000 );
          }
          else {
            chkVerticalEllipse.
            //Updating the Fail status in Excel sheet
            writeToExcelFail ( 'portalx.xlsx', 'chkVerticalEllipseDestFunInView', ++incrementer, 4, 5, "Some thing went wrong, Please try again" );
          }
        } );
      }
      chkVerticalEllipse.
      //Waiting for the Destination page to be displayed
      waitForElementPresent ( "//SPAN[@class='title ng-binding'][text()='folders']", 5000, false, function ( chkVisibility ) {
      //Checking whether the Destination is displayed in Index Page
      if ( chkVisibility.value != false ) {
        chkVerticalEllipse.
      //Clicking on the Vertical ellipses of the first Destination
      click ( "(//SPAN[@class='cell-options-dropdown'])[1]" ).
      pause ( 8000 ).
      //Getting the menu list which is displayed after clicking on the vertical ellipse
      getText ( '//div[@class="flyout-menu-small dropdown-menu ng-scope"]', function ( getMenuDetails ) {
        //Checking whether the Menu displayed in the application is as same as in Excel sheet
        console.log(getMenuDetails.value.replace(/\n/g, " "))
        if ( getMenuDetails.value.replace(/\n/g," ") == excel.C [ incrementer ]) {
          chkVerticalEllipse.
          //Updating the Pass status in Excel sheet
          writeToExcelPass ( 'portalx.xlsx', 'chkElipseInFolderPageFun', ++incrementer, 4 );
        }
        else {
          chkVerticalEllipse.
          //Updating the Fail status in Excel sheet
          writeToExcelFail ( 'portalx.xlsx', 'chkElipseInFolderPageFun', ++incrementer, 4, 5, "Menus displayed are not matching with the Excel sheet" );
        }
      } );
    }
    else {
      chkVerticalEllipse.
      //Updating the Fail status in Excel sheet
      writeToExcelFail ( 'portalx.xlsx', 'chkElipseInFolderPageFun', ++incrementer, 4, 5, "Unable to navigate to Destination page" );
    }
  } );
    }
  }
}
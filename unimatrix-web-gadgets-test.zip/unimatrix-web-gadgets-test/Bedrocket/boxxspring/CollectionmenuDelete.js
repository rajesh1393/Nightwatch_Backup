//this function is for check and Delete the Collections Menu 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CollectionmenuDelete' ];
var searchCollection = [ ];
var collectionTitle = [ ];
var expectedCount, currentCount, actualCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'collectionmenuDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;    
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CollectionmenuDelete': function ( collectionsDeletemenu ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Search Collection Title
      if ( excelData.includes ( 'A' ) ) {
        searchCollection.push ( worksheet[ excelData ].v );
      }
      //Read Collection Title
      if ( excelData.includes ( 'B' ) ) {
        collectionTitle.push ( worksheet[ excelData ].v );
      }
    }
    if ( searchCollection.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < searchCollection.length; getData++ ) {
        rowCount++;
        collectionsDeletemenu.pause ( 4000 ).useXpath ( ).
        //Check and Wait for the ALL button in the collections is visible
        waitForElementVisible ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false, function ( checkALLMenu ) {
          if ( checkALLMenu.value == true ) {
            collectionsDeletemenu.pause ( 4000 ).useXpath ( ).
            //Click on the All button in the collections
            click ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]" ).
            pause ( 4000 ).useCss ( ).
            //Get the Current Total Count in the Collections listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }
              collectionsDeletemenu.pause ( 4000 ).
              keys ( collectionsDeletemenu.Keys.ENTER ).
              keys ( collectionsDeletemenu.Keys.ENTER ).useXpath ( ).
              //Check and Wait for the Search input field in the collections is visible
              waitForElementVisible ( "//h2[contains (.,'"+ searchCollection[ getData ] +"')]", 4000, false, function ( checkSearchedLst ) { 
                if ( checkSearchedLst.value == true ) {
                  collectionsDeletemenu.pause ( 4000 ).useXpath ( ).
                  //Click on the Search collections in the collections page
                  click ( "//h2[contains (.,'"+ searchCollection[ getData ] +"')]" ).
                  useCss ( ).pause ( 4000 ).
                  //Check and Wait for the Headline field in the collections is visible
                  waitForElementVisible ( ".text-input-headline", 4000, false ).
                  pause ( 4000 ).
                  //Clear the Headline data in the field
                  clearValue ( ".text-input-headline" ).
                  pause ( 4000 ).
                  //Enter the Headline data in the field
                  setValue ( ".text-input-headline", collectionTitle[ getData ] ).
                  pause ( 4000 ).
                  //Verify the Headline field in the collections is visible
                  verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                  pause ( 4000 ).
                  //Click on the Delete button in the page
                  click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                  pause ( 4000 ).
                  //Check the existance of delete confirmation dialog
                  verify.visible ( "dialog[ name=deleteVerification ]" ).
                  pause ( 4000 ).
                  //Verify Cancel Button is visible in Delete Dialog
                  verify.visible ( ".link-secondary" ).
                  pause ( 4000 ).
                  //click on the cancel button
                  click ( ".link-secondary" ).
                  pause ( 4000 ).
                  //Verify the Delete in the Properties Tab
                  verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                  //Click the Delete in the Properties Tab
                  click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                  pause ( 4000 ).
                  //Check the existance of delete confirmation to delete
                  verify.visible ( "dialog[ name=deleteVerification ]" ).
                  pause ( 4000 ).
                  //Verify the delete button is visible in the page
                  verify.visible ( "button.btn:nth-child( 2 )" ).
                  pause ( 4000 ).
                  //Click on the Delete button
                  click ( "button.btn:nth-child( 2 )" ).
                  pause ( 4000 ).useXpath ( ).
                  //Check and Wait for the ALL button in the collections is visible
                  waitForElementVisible ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]", 5000, false ).
                  pause ( 4000 ).
                  //Click on the All button in the collections
                  click ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]" ).
                  pause ( 4000 ).useCss ( ).
                  //Get the Actual Total Count in the Collections listing page
                  getText ( '.content-count > strong', function ( actualCountResult ) {
                    if ( actualCountResult.status != -1 ) {
                      actualCount = actualCountResult.value;
                      actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                      expectedCount = ( ( + currentCount ) - 1 );
                      if ( actualCount == expectedCount ) {
                        //Write the Excel:PASS Result
                        collectionsDeletemenu.writeToExcelPass ( 'boxxspring.xlsx', 'CollectionmenuDelete', rowCount, 4 );
                      }
                      else {
                        //Write the Excel:FAIL Result and Reason
                        collectionsDeletemenu.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Collections Menu. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
                      }
                    }
                  } );                 
                }
                else { 
                  //Write the Excel:FAIL Result and Reason
                  collectionsDeletemenu.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuDelete', rowCount, 4, 5, "Searched Data is not listed in the Collections listing page" );   
                }
              } );                
            } );
          }
          else {
            //Write the Excel:FAIL Result and Reason
            collectionsDeletemenu.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuDelete', rowCount, 4, 5, "ALL Menu is not displayed under the Collections main menu in the Sidebar" );
          }
        } );
      }
    }
    //End the browser
    collectionsDeletemenu.end ( );
  }
}
//this function is for check and Edit the Boxxspring Destintaion in DISTRIBUTION
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' )  xlsx= require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'DestinationBoxxspringEdit' ];
var socialSearch = [ ];
var destinationTitle = [ ];
var currentCount, expectedCount, actualCount, excelData, searchCount;
var rowCount, getData = 1;
module.exports = {
  tags: [ 'DestinationBoxxspringEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DestinationBoxxspringEdit': function ( boxxspringDestinationEdit ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Search Boxxspring Title
      if ( excelData.includes ( 'A' ) ) {
        socialSearch.push ( worksheet[ excelData ].v );
      }
      //Read Destination Title
      if ( excelData.includes ( 'B' ) ) {
        destinationTitle.push ( worksheet[ excelData ].v );
      }      
    }
    if ( socialSearch.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < destinationTitle.length; getData++ ) {
        rowCount++;
        boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
        waitForElementPresent ( "//div/a[@class='content-header-link content'][text()[normalize-space(.)='Distribution']]", 4000, false, function ( checkDistributionMenu ) {
          if ( checkDistributionMenu.value.length != 0 ) {
            boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
            waitForElementVisible ( "//i[@ng-if='!collapse.distribution']", 4000, false, function ( checkArrow ) {
              if ( checkArrow.value == true ) {
                boxxspringDestinationEdit.pause ( 4000 ).useCss ( ).
                verify.visible ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 ).
                //Click on the Distribution menu in the side bar
                click ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 );
              }
            } );
            boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
            waitForElementVisible ( "//a[text ( ) = 'Destinations']",4000, false, function ( checkDestinationMenu ) {
              if ( checkDestinationMenu.value == true ) {
                boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).           
                //Verify the Destination menu in DISTRIBUTION is visible
                verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
                pause ( 4000 ).
                //Click on the Destination menu in DISTRIBUTION
                click ( "//a[ text ( ) = 'Destinations']" ).
                useCss ( ).pause ( 4000 ).
                //Get the Current Total count in the Destination listing page
                getText ( '.content-count > strong', function ( currentCountResult ) {
                  if ( currentCountResult.status != -1 ) {
                    currentCount = currentCountResult.value;
                  }                
                  boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
                  //Wait for the Search Field is visible
                  waitForElementVisible ( "//div[@class='suggestion-dropdown-wrap']/input", 4000, false ).
                  pause ( 4000 ).
                  //Verify the Search Field is visible
                  verify.visible ( "//div[@class='suggestion-dropdown-wrap']/input" ).
                  pause ( 4000 ).
                  //Clear avail data in the Search Field
                  clearValue ( "//div[@class='suggestion-dropdown-wrap']/input" ).
                  pause ( 4000 ).
                  //Enter data in the Search Field input
                  setValue ( "//div[@class='suggestion-dropdown-wrap']/input", destinationTitle[ getData ] ).useCss ( ).
                  pause ( 4000 ).  
                  //Wait for Total Count label is visible
                  waitForElementVisible ( ".content-count>strong", 4000, false ).
                  //Verify the Total Count label is visible
                  verify.visible ( ".content-count>strong" )
                  //Check the Searched Video Count
                  boxxspringDestinationEdit.getText ( '.content-count > strong', function ( searchCountResult ) {                
                    if ( searchCountResult.status != -1 ) {
                      searchCount = searchCountResult.value;
                      searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                    }
                    //Check IF Searched Video Count is greater than zero,it will continue in the statement or it will be move else part
                    if ( searchCount > 0 ) {
                      boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
                      //Wait for the Searched destination to visible
                      waitForElementVisible ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ destinationTitle[ getData ] +"']]", 4000, false, function ( checkSearchedLst ) {
                        if ( checkSearchedLst.value == true ) {
                          boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
                          //Verify the Searched destination is visible
                          verify.visible ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ destinationTitle[ getData ] +"']]" ).
                          pause ( 4000 ).
                          //Click on the Searched destination
                          click ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ destinationTitle[ getData ] +"']]" ).
                          pause ( 4000 ).useCss ( ).
                          waitForElementVisible ( ".typeName-label", 4000, false ).
                          pause ( 4000 ).
                          getText ( ".typeName-label",function ( getCaptionText ) {
                            if ( getCaptionText.value == "DESTINATION" ) {
                              //Verify the Contains text in the provider field is visible
                              boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
                              waitForElementVisible ( "//div[@class='input-like']", 4000, false ).
                              pause ( 4000 ).
                              getText ( "//div[@class='input-like']",function ( getProviderText ) {
                                if ( getProviderText.value == "Boxxspring" ) {
                                  boxxspringDestinationEdit.pause ( 4000 ).useCss ( ).
                                  //Verify the Headline text field is visible
                                  verify.visible ( ".text-input-headline" ).
                                  pause ( 4000 ).
                                  //Clear the data in the Headline text field
                                  clearValue ( ".text-input-headline" ).
                                  pause ( 4000 ).
                                  //Enter the data in the Headline text field
                                  setValue ( ".text-input-headline", destinationTitle[ getData ] ).
                                  pause ( 4000 ).useXpath ( ).                              
                                  //Check and wait for Save button should active is visible in the page
                                  waitForElementVisible ( "//a[@class='btn btn-icon btn-active']", 4000, false, function ( checkActiveSaveBTN ) {
                                    if ( checkActiveSaveBTN.value == true ) {
                                      boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
                                      //Click on the Save button
                                      click ( "//a[@class='btn btn-icon btn-active']" ).
                                      pause ( 4000 ).
                                      //Check and wait for Save button should not active is visible in the page 
                                      waitForElementNotPresent ( "//a[@class='btn btn-icon btn-active']", 4000, false, function ( checkInActiveSaveBTN ) {
                                       if ( checkInActiveSaveBTN.value.length == 0 ) {
                                          boxxspringDestinationEdit.pause ( 4000 ).useXpath ( ).
                                          //Verify the Destination menu in DISTRIBUTION is visible
                                          verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
                                          pause ( 4000 ).
                                          //Click on the Destination menu in DISTRIBUTION
                                          click ( "//a[ text ( ) = 'Destinations']" ).
                                          useCss ( ).pause ( 4000 ).                                      
                                          waitForElementVisible ( ".content-count > strong", 4000, false ).
                                          pause ( 4000 ).
                                          //Get the Actual Total count  after searched in the Destination listing page
                                          getText ( '.content-count > strong', function ( actualCountResult ) {
                                            if ( actualCountResult.status != -1 ) {
                                              actualCount = actualCountResult.value;
                                              if ( actualCount == currentCount ) {                            
                                                //Write in the spreadsheet: Pass Result and Reason
                                                boxxspringDestinationEdit.writeToExcelPass ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4 );
                                              }
                                              else {
                                                //Write in the spreadsheet: Fail Result and Reason
                                                boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Added New story. ExpectedResult: should be 1 in the Total Count " );
                                              }
                                            }
                                          } );
                                        }
                                        else {
                                          //Write in the spreadsheet: Fail Result and Reason
                                          boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, " Save Button is till ACTIVE after Saved the artifacts in the page" );
                                        }
                                      } );
                                    }
                                    else {
                                      //Write in the spreadsheet: Fail Result and Reason
                                      boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "Save Button is not ACTIVE in the page" );                                   
                                    }
                                  } );
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "Expected Provider as Boxxspring and Actual Provider as '"+getProviderText.value+"'" );
                                }
                              } );
                            }
                            else {
                              //Write in the spreadsheet: Fail Result and Reason
                              boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "Caption Label is not displayed as expected,its shown as '"+getCaptionText.value+"'" );
                            }
                          } );
                        }
                        else {
                          //Write in the spreadsheet: Fail Result and Reason
                          boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "Searched Data is not displayed in the listing page" );
                        }
                      } );
                    }
                    else {
                      //Write the Excel data for Search FAIL Result and Reason
                      boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "0<-->No Results" )                    
                    }
                  } );        
                } );
              }
              else {
                //Write the Excel data for Search FAIL Result and Reason
                boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "Destinations Menu is not displayed in the Sidebar" )      
              }
            } );
          }
          else {
            //Write the Excel data for Search FAIL Result and Reason
            boxxspringDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringEdit', rowCount, 4, 5, "Distribution Menu is not displayed in the Sidebar" )    
          }
        } );
      }
    }
    //End the Browser
    boxxspringDestinationEdit.end ( );
  }
}
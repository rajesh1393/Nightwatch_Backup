//this function is for check and add 360 videos
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ '360VideosAdd' ];
var dragUrl = [ ];
var videoTitle = [ ];
var shortTitle = [ ];
var shortDesc = [ ];
var author = [ ];
var attribution = [ ];
var categoryName = [ ];
var shortNote = [ ];
var dragImg = [ ];
var currentCount, actualCount;
var expectedCount,excelData,uploadErrorMsg;
var getData,rowCount = 1;
module.exports = {
  tags: [ '360VideosAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  '360VideosAdd': function ( videoThreeSixty ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read video URL
      if ( excelData.includes ( 'A' ) ) {
        dragUrl.push ( worksheet[ excelData ].v );
      }
      //Read Video Title
      if ( excelData.includes ( 'B' ) ) {
        videoTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        shortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        shortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Author Name
      if ( excelData.includes ( 'E' ) ) {
        author.push ( worksheet[ excelData ].v );
      }
      //Read Attribution Name
      if ( excelData.includes ( 'F' ) ) {
        attribution.push ( worksheet[ excelData ].v );
      }
      //Read Category Name
      if ( excelData.includes ( 'G' ) ) {
        categoryName.push ( worksheet[ excelData ].v );
      }
      //Read Short Notes
      if ( excelData.includes ( 'H' ) ) {
        shortNote.push ( worksheet[ excelData ].v );
      }
      if ( excelData.includes ( 'I' ) ) {
        dragImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( dragUrl.length > 1 ) {
      var checkResult = videoThreeSixty.globals.excelCol.resultCustomData; 
      for ( let getData = 1,rowCount = 1; getData < dragUrl.length; getData++ ) {
        rowCount++;
        videoThreeSixty.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text( ) = '360videos' ]",4000,false,function ( check360VideoMenu ) {
          if ( check360VideoMenu.value == true ) {
            videoThreeSixty.pause ( 4000 ).useXpath ( ).
            //Verify the 360videos in CONTENT menu is visible
            verify.containsText ( "//ul/li/a[ text( ) = '360videos' ]", "360videos" ).
            pause ( 4000 ).
            //Click on the 360videos in the CONTNET menu
            click ( "//ul/li/a[ text( ) = '360videos' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get the Current Total count in the 360videos listing page before adding the story
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }             
              videoThreeSixty.pause ( 4000 ).
              //Wait for the Add 360videos button is visible
              waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false,function ( checkAddbtn ) {
                console.log("checkAddbtn",checkAddbtn)
                if ( checkAddbtn.value.length == 0 ) {
                  videoThreeSixty.pause ( 4000 ).
                  //Verify the Add 360videos button is visible
                  verify.visible ( ".btn.btn-primary.btn-add" ).
                  pause ( 4000 ).
                  //Click on the Add 360videos button in the listing page
                  click ( ".btn.btn-primary.btn-add" ).
                  pause ( 4000 ).
                  //Set the 360video path and upload in the field
                  setValue ( '.hidden-input > input:nth-child(1) ', require ( 'path' ).resolve ( dragUrl[ getData ] ) ).
                  pause ( 100000 ).useXpath().
                  waitForElementVisible("//video-artifact-player/div[1]/div/div[@class='unimatrix-video-controls']",4000,false ).
                  pause ( 4000 ).
                  //Get the text for Error meassage for upload url
                  getText ( "//video-artifact-player/div[1]/div/div[@class='unimatrix-video-controls']", function ( uploaderror ) {            
                    console.log("uploaderror",uploaderror)
                    uploadErrorMsg = uploaderror.status;
                    if ( uploaderror.status == -1 ) {
                      var uploadCount = uploaderror.value;
                      console.log("uploadCount", uploadCount);
                    }            
                    //Check the Given input condition should be match with in the expected conditions
                    if ( ( uploadErrorMsg != -1 ) && ( ( dragUrl[ getData ].match ( /mpeg\b/g ) ) || ( dragUrl[ getData ].match ( /mp4\b/g ) ) || ( dragUrl[ getData ].match ( /wmv\b/g ) ) || ( dragUrl[ getData ].match ( /mts\b/g ) ) || ( dragUrl[ getData ].match ( /m2ts\b/g ) ) || ( dragUrl[ getData ].match ( /mov\b/g ) ) ) ) {
                      videoThreeSixty.pause ( 4000 ).useCss().
                      //Check Video Preview
                      verify.visible ( "a.preview-btn.ng-scope" ).
                      //Check Video Title
                      verify.visible ( ".wmd-input" ).
                      pause ( 4000 ).
                      //Verify the Delete Button
                      verify.visible ( ".btn-delete" ).
                      pause ( 4000 ).useCss().
                      waitForElementVisible ( '.container-head > text-field > input' , 4000 , false ).
                      pause ( 4000 ).
                      //Verify the Video title field is visbile
                      verify.visible ( ".container-head > text-field > input" ).
                      pause ( 4000 ).
                      //Clear the Video title data in field
                      clearValue ( '.container-head > text-field > input' ).
                      pause ( 4000 ).
                      //Enter the Video title data in field
                      setValue ( '.container-head > text-field > input', videoTitle[ getData ] ).
                      pause ( 4000 ).
                      video_properties ( shortTitle[ getData ], shortDesc[ getData ], categoryName[ getData ], shortNote[ getData ], dragImg[ getData ] ).
                      pause ( 4000 ).useCss ( ).
                      waitForElementVisible ( ".video-tabs > a[ href='#properties']",4000,false,function ( checkProperties ) {
                        if ( checkProperties.value == true ) {
                          if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                            videoThreeSixty.writeToExcelFail ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11, 12, "Thumbnail is not displayed in the properties tab" );
                            checkResult.length = 0;
                          }
                          else if ( checkResult.length == 0 ) {
                          }
                          else {
                            checkResult.length = 0;
                            //Check and click save button
                            videoThreeSixty.verify.visible ( "a.btn-active" ).
                            //click on the save button
                            click ( "a.btn-active" ).
                            pause ( 4000 ).useXpath ( ).
                            //Verify the videos menu in the sidebar
                            verify.containsText ( "//ul/li/a[ text( ) = '360videos']", "360videos" ).
                            pause ( 4000 ).
                            //click on the videos menu in CONTENT
                            click ( "//ul/li/a[ text( ) = '360videos']" ).
                            useCss ( ).pause ( 4000 ) 
                            //Check the Actual Count after each video added
                            videoThreeSixty.useCss().pause( 4000 ).
                            getText ( '.content-count > strong', function ( actualCountResult ) {
                              if ( actualCountResult.status != -1 ) {
                                actualCount = actualCountResult.value;
                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                expectedCount = ( ( +currentCount ) + ( 1 ) );
                                if ( actualCount == expectedCount ) {
                                  //Write in the spreadsheet: Pass Result and Reason
                                  videoThreeSixty.writeToExcelPass ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11 );
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  videoThreeSixty.writeToExcelFail ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11, 12, "ActualResult:'"+ actualCount +"'in the Total Count After Added New 360Videos. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                                }
                              }
                            } );
                          }
                          if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                            checkResult.length = 0;
                          }
                        }
                        else {
                        }
                      } );           
                    }
                    else {
                      //Check the Error message for Invalid url
                      videoThreeSixty.waitForElementVisible ( '.field-error > span:nth-child(1) > span:nth-child(2) > span:nth-child(1)', 5000, false ).
                      //Get the Url Error message
                      getText ( '.field-error > span:nth-child(1) > span:nth-child(2) > span:nth-child(1)', function ( urlErrorMsg ) {
                      	var errmsg = urlErrorMsg.value;
                        var expectedmsg = "Invalid file type";
                        if ( urlErrorMsg.status !== -1 ) {                  
                          if ( expectedmsg == errmsg ) {                    
                            videoThreeSixty.writeToExcelPass ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11 );
                          }
                          else {
                            //Write the Excel:FAIL Result and Reason
                            videoThreeSixty.writeToExcelFail ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11, 12, "ActualResult:'"+ errmsg +"'in the 360videos page. ExpectedResult: should be'"+ expectedmsg +"' in the 360videos page" );
                          }
                        }
                        else {
                          //Write the Excel:FAIL Result and Reason
                          videoThreeSixty.writeToExcelFail ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11, 12, "Unsupported files or uploading timeout in the 360videos Add page" );
                        }
                      } );
                    }                
                  } );  
                }
                else {
                  //Write the Excel:FAIL Result and Reason
                  videoThreeSixty.writeToExcelFail ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11, 12, "Add button is not functioning in 360videos listing page" );
                }
              } );
            } );
          }
          else {
            //Write the Excel:FAIL Result and Reason
            videoThreeSixty.writeToExcelFail ( 'boxxspring.xlsx', '360VideosAdd', rowCount, 11, 12, "360videos menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    videoThreeSixty.end ( );
  }
}
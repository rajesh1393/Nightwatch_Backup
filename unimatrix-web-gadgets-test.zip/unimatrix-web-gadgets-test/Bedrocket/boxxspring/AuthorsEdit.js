//this function is for check and Edit the Authors
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['AuthorsEdit'];
var authorTitle = [ ];
var authorDescription = [ ];
var authorShortTitle = [ ];
var authorShortDesc = [ ];
var authorCategoryName = [ ];
var authorNote = [ ];
var authorImg = [ ];
var currentCount, actualCount, expectedCount, excelData, searchCount;
var authorSearch = [ ];
var getData,rowCount = 1;
module.exports = {
  tags: [ 'authorsEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AuthorsEdit': function ( authorsEdit ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        authorTitle.push ( worksheet[ excelData ].v );
      }
      //Read authors Description
      if ( excelData.includes ( 'B' ) ) {
        authorDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        authorShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        authorShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read authors category Name
      if ( excelData.includes ( 'E' ) ) {
        authorCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read authors Note
      if ( excelData.includes ( 'F' ) ) {
        authorNote.push ( worksheet[ excelData ].v );
      }
      //Read authors Image
      if ( excelData.includes ( 'G' ) ) {
        authorImg.push ( worksheet[ excelData ].v );
      }
      //Read authors Search
      if ( excelData.includes ( 'H' ) ) {
        authorSearch.push ( worksheet[ excelData ].v );
      }      
    }
    if ( authorTitle.length > 1 ) {
    	var checkResult = authorsEdit.globals.excelCol.resultCustomData; 
    	for ( let getData = 1,rowCount = 1; getData < authorTitle.length; getData++ ) {
    		rowCount++;
    		authorsEdit.pause ( 4000 ).useXpath ( ).
    		//Check and Wiat for Authors menu is visible in the sidebar
    		waitForElementVisible ("//ul/li/a[ text( ) = 'Authors' ]",4000,false,function ( checkAuthorMenu ) {
    			if ( checkAuthorMenu.value == true ) {
			      authorsEdit.pause ( 4000 ).useXpath ( ).
			      //Verify the Authors menu in the CONTENT
			      verify.containsText ( "//ul/li/a[ text( ) = 'Authors' ]", "Authors" ).
			      pause ( 4000 ).
			      //Click on the Authors menu in the CONTENT
			      click ( "//ul/li/a[ text( ) = 'Authors' ] " ).
			      useCss ( ).pause ( 4000 ).
			      //Get the Authors Total Count in the authors listing page
			      getText ( '.content-count > strong', function ( currentCountResult ) {
			        if ( currentCountResult.status != -1 ) {
			          currentCount = currentCountResult.value;
			          currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
			        }
			        //Wait for the search field is visible in the listing page
		          authorsEdit.pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
		          pause ( 4000 ).
		          //Verify the search field is visible in the listing page
		          verify.visible ( ".search-field-input" ).
		          pause ( 4000 ).
		          //Clear the data in search field
		          clearValue ( ".search-field-input" ).
		          pause ( 4000 ).
		          //Enter the serach data in the field
		          setValue ( ".search-field-input", authorSearch[ getData ] ).
		          pause ( 4000 ).
		          //Press Enter key to search
		          keys ( authorsEdit.Keys.ENTER ).
		          click ( ".search-field-input" ).
		          // release the control
		          keys ( authorsEdit.Keys.NULL ). 
		          pause ( 4000 ).
		          //Wait for label count is visible in the listing page
		          waitForElementVisible ( ".content-count>strong", 4000, false ).
		          pause ( 4000 ).
		          //erify the label count is visible in the listing page
		          verify.visible ( ".content-count>strong" ).
				   		pause ( 4000 ).
		          //Get the Authors Total Count in the authors listing page after Search data
		          getText ( '.content-count > strong', function ( searchCountResult ) {		            
		            if ( searchCountResult.status != -1 ) {
		              searchCount = searchCountResult.value;
		              searchCount = searchCount.substring ( 1, searchCount.length - 1 );
		            }
		            if ( searchCount > 0 ) {
		              authorsEdit.pause ( 4000 ).useXpath ( ).
		              //Wait for searched Authors is visible in the listing page
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ authorSearch[ getData ] +"']]", 4000, false,function ( checkattributionLst ) {
                  	if ( checkattributionLst.value == true ) {
				              authorsEdit.pause ( 4000 ).useXpath ( ).
				              //Verify the searched Authors is visible in the listing page
				              verify.visible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ authorSearch[ getData ] +"']]" ).
				              pause ( 4000 ).
				              //Click on the Edit Author button
				              click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ authorSearch[ getData ] +"']]" ).
				              useCss ( ).pause ( 4000 ).
				              verify.visible ( ".video-tabs > a[ href='#content' ] " ).
				              pause ( 4000 ).
				              click ( ".video-tabs > a[ href='#content' ] " ).
				              pause ( 4000 ).
				              //Check the Authors Title filed visible
				              waitForElementVisible ( ".text-input-headline", 4000, false ).
				              //Clear the Authors Title in the field
				              clearValue ( ".text-input-headline" ).
				              pause ( 4000 ).
				              //Enter the Authors Title in the Field
				              setValue ( ".text-input-headline", authorTitle[ getData ] ).
				              pause ( 4000 ).
				              //Check and Enter Authors Text Description
				              waitForElementVisible ( ".wmd-input", 4000, false ).
				              //Clear the Author Description
				              clearValue ( ".wmd-input" ).
				              //Enter the Authors Description
				              setValue ( ".wmd-input", authorDescription[ getData ] ).
				              pause ( 4000 ).
				              //Check and click Save button
				              waitForElementVisible ( '.btn-active', 4000, false ).
				              pause ( 4000 ).
				              //VErify the Save button is visible in the page
				              verify.visible ( ".btn-active" ).
				              pause ( 4000 ).
				              //Click on the Save Button
				              click ( ".btn-active" ).
				              pause ( 4000 ).
				              video_properties ( authorShortTitle[ getData ], authorShortDesc[ getData ], authorCategoryName[ getData ], authorNote[ getData ], authorImg[ getData ] ).
				              pause ( 4000 ).useCss ( ).
				              //Check and Wait for the Properties tab is visible in the page
				              waitForElementVisible ( ".video-tabs > a[ href='#properties']",4000,false,function ( checkProperties ) {
		                    if ( checkProperties.value == true ) {
		                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
		                      	//Write in the spreadsheet: Fail Result and Reason
		                        authorsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsEdit', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
		                        checkResult.length = 0;
		                      }
		                      else if ( checkResult.length == 0 ) {
		                      }
		                      else {
		                        checkResult.length = 0;
		                        //Check and click save button
		                        authorsEdit.verify.visible ( "a.btn-active" ).
		                        //click on the save button
		                        click ( "a.btn-active" ).
		                        pause ( 4000 ).
		                        //Check and Wait for the Save button active is not visible in the page
		                        waitForElementNotPresent ( "a.btn-active",4000,false,function ( checkSaveBtn ) {
		                          if ( checkSaveBtn.value.length == 0 ) {
		                            authorsEdit.pause ( 4000 ).useXpath ( ).
		                            //Verify the videos menu in the sidebar
		                            verify.containsText ( "//ul/li/a[ text( ) = 'Authors']", "Authors" ).
		                            pause ( 4000 ).
		                            //click on the videos menu in CONTENT
		                            click ( "//ul/li/a[ text( ) = 'Authors']" ).
		                            useCss ( ).pause ( 4000 ) 
		                            //Check the Actual Count after each video added
		                            authorsEdit.useCss().pause( 4000 ).
		                            getText ( '.content-count > strong', function ( actualCountResult ) {
		                              if ( actualCountResult.status != -1 ) {
		                                actualCount = actualCountResult.value;
		                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
		                                if ( actualCount == currentCount ) {
		                                  //Write in the spreadsheet: Pass Result and Reason
		                                  authorsEdit.writeToExcelPass ( 'boxxspring.xlsx', 'AuthorsEdit', rowCount, 10 );
		                                }
		                                else {
		                                  //Write in the spreadsheet: Fail Result and Reason
		                                  authorsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsEdit', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Edit Authors. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
		                                }
		                              }
		                            } );
		                          }
		                          else {
		                            //Write in the spreadsheet: Fail Result and Reason
		                            authorsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsEdit', rowCount, 10, 11, " Save button is not functioning as expected" );
		                          }
		                        } );		                        
		                      }
		                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
		                        checkResult.length = 0;
		                      }
		                    }		                    
		                  } );        
					          }
					          else {
					            //Write in the Excel for Search Fail Result and Reason
					            authorsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsEdit', rowCount, 10, 11, "Searched Result Count,'"+ searchCount +"'" );
					          }
		         			} );
				        }
			        	else {
			        	//Write in the Excel for Search Fail Result and Reason
			          authorsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsEdit', rowCount, 10, 11, "Searched Data is not availed in the listing page" );
				        }
				      } );
		      	} );
					}
					else {
						//Write in the Excel for Search Fail Result and Reason
						authorsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsEdit', rowCount, 10, 11, "Authors Menu is not displayed in Sidebar" );		            
					}
				} );
			}
		}
    //End the Browser
    authorsEdit.end ( );
  }
};
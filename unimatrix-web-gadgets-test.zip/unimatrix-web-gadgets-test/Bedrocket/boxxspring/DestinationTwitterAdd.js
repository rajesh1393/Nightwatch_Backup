//this function is for Add Twitter Destinations 
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'boxxspring.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'DestinationTwitterAdd' ];
var playlistTitle = [ ];
var username = [ ];
var password = [ ];
var currentCount;
var actualCount, expectedCount;
module.exports = {
  tags: [ 'destinationTwitterAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DestinationTwitterAdd': function ( DestinationTwitter ) {
    try {
      for ( z in worksheet ) {
        if ( z[ 1 ] === '!' ) continue;
        //Read playlistTitle from excel
        if ( z.includes ( 'A' ) ) {
          playlistTitle.push ( worksheet[ z ].v );
        }
        //Read username from excel
        if ( z.includes ( 'B' ) ) {
          username.push ( worksheet[ z ].v );
        }
        //Read password from excel
        if ( z.includes ( 'C' ) ) {
          password.push ( worksheet[ z ].v );
        }
      }
    }
    catch ( err ) {
      console.log ( "Please check File name" );
    }
    if ( playlistTitle.length > 0 ) {
      for ( let excelColumn = 1; excelColumn < playlistTitle.length; excelColumn++ ) {
        var excelRow = 1;
        //Verify the Distribution Menu in side bar is visible
        DestinationTwitter.pause ( 3000 ).
        waitForElementVisible ( "div.content-header:nth-child ( 7 )", 5000, false, function ( ) { } ).
        //Click on the Distribution menu in the side bar
        click ( "div.content-header:nth-child(7)" ).
        useXpath ( ).
        //verify the Destination menu in DISTRIBUTION is visible
        waitForElementVisible ( "//a[text()= 'Destinations']", 5000, false, function ( ) { } ).
        //Click on the Destination menu in DISTRIBUTION
        click ( "//a[text()= 'Destinations']" ).
        useCss ( ).pause ( 10000 ).
        getText ( '.content-count > strong', function ( currentCountResult ) {
          currentCount = currentCountResult.value;
          DestinationTwitter.useCss ( ).
          //Wait for the Add destination button is visible
          waitForElementVisible ( "a.btn-primary", 3000, false, function ( ) { } ).
          //Click on Add destination button in destination page
          click ( "a.btn-primary" ).
          useXpath ( ).
          //Wait for the Twitter button is visible in add destination
          waitForElementVisible ( "//li/a/div/span[contains( .,'twitter')]", 3000, false ).
          //Click on Twitter Social button in add destination page
          click ( "//li/a/div/span[contains(.,'twitter')]" ).
          useCss ( ).
          //switch to the new secondary browser window
          switchToSecondaryWindow ( 'twitter' ).
          pause ( 5000 ).
          waitForElementNotVisible ( ".current-user > a", 5000, false, function ( currentUser ) {
            if ( currentUser.value == true ) {
              DestinationTwitter.click ( ".current-user > a" ).
              pause ( 5000 ).
              click ( ".textual.link" ).
              closeWindow ( ).switchToSecondaryWindow ( 'twitter' );
            }
          } )
          //sign in with the twitter account
          DestinationTwitter.waitForElementVisible ( "#username_or_email", 3000, false ).
          //sign in with the Username
          setValue ( "#username_or_email", username[ excelColumn ] ).
          //Enter the valid password
          setValue ( "#password", password[ excelColumn ] ).
          //Click submit button
          click ( "#allow" ).
          windowHandles ( function ( window ) {
            if ( window.value.length != 2 ) {
              DestinationTwitter.switchToPrimaryWindow ( 'boxxspring' ).
              pause ( 3000 ).
              //Wait for the DESTINATION caption is visible in the add destination page
              waitForElementVisible ( ".typeName-label", 3000, false, function ( ) { } ).
              pause ( 3000 ).
              //Clear the Headline data in the field            
              useXpath ( ).waitForElementVisible ( "//div[@class='input-like'][contains(.,'Twitter')]", 5000, false, function ( provider ) {
                if ( provider.value == true ) {
                  DestinationTwitter.getText ( "//div[@class='input-like ng-binding']", function ( headline ) {
                    DestinationTwitter.getText ( "//div[@class='input-like ng-binding']", function ( user ) {
                      if ( user.value == headline.value ) {
                        DestinationTwitter.pause ( 9000 ).useCss ( ).
                        clearValue ( ".text-input-headline" ).
                        pause ( 3000 ).
                        //Enter the Headline title in the field
                        setValue ( ".text-input-headline", playlistTitle[ excelColumn ] ).
                        useXpath ( ).
                        //Wait for the Save button in the destiantion page is visible
                        waitForElementVisible ( "//form[1]/div/a[@ng-click='save( )']", 3000, false ).
                        //Click on the Save button in the destination page
                        click ( "//form[1]/div/a[@ng-click='save( )']" ).
                        pause ( 7000 ).
                        //Click on the Destination menu in DISTRIBUTION 
                        click ( "//a[ text( ) = 'Destinations']" ).
                        useCss ( ).
                        pause ( 20000 ).
                        //Get the Actual Total count in the Destination listing page
                        getText ( '.content-count > strong', function ( actualCountResult ) {
                          if ( actualCountResult.status !== -1 ) {
                            console.log ( "currentCount", currentCount );
                            expectedCount = parseInt ( currentCount ) + 1;
                            if ( actualCountResult.value == expectedCount ) {
                              //Write in the spreadsheet: Pass Result and Reason
                              DestinationTwitter.writeToExcelPass ( 'boxxspring.xlsx', 'DestinationTwitterAdd', ++excelRow, 5 );
                            }
                            else {
                              //Write in the spreadsheet: Fail Result and Reason
                              DestinationTwitter.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationTwitterAdd', ++excelRow, 5, 6, "ActualResult: '" + actualCount + "' in the Total Count After Addded Youtube Destination. ExpectedResult: should be'" + expectedCount + "' in the Total Count" );
                            }
                          }
                        } );
                      }
                      else {
                        //Write in the spreadsheet: Fail Result and Reason
                        DestinationTwitter.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationTwitterAdd', ++excelRow, 5, 6, "ActualResult: '" + user.value + "'. ExpectedResult: '" + headline.value + "' ( User field mismatch with the headline field while Adding Destination )" );
                      }
                    } );
                  } );
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
                  DestinationTwitter.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationTwitterAdd', ++excelRow, 5, 6, "ActualResult: '" + provider.value + "'. ExpectedResult: 'True' (Error in provider data which is not as Twitter )" );
                }
              } );
            }
            else {
              //Write in the spreadsheet: Login error and the message
              DestinationTwitter.waitForElementVisible ( ".message", 9000, false, function ( loginError ) {
                if ( loginError.value == true ) {
                  //return the error message for the invalid credentials
                  DestinationTwitter.getText ( ".message", function ( twitterLoginError ) {
                    this.verify.fail ( "Error in Twitter login", "To login in Twitter", twitterLoginError.value );
                    DestinationTwitter.closeWindow ( ).
                    switchToPrimaryWindow ( 'boxxspring' );
                    DestinationTwitter.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationTwitterAdd', ++excelRow, 5, 6, "ActualResult: '" + twitterLoginError.value + "' . ExpectedResult: 'Valid Credentials'" );
                  } );
                }
              } );
            }
          } );
        } );
      }
    }
    //End the Browser
    DestinationTwitter.end ( );
  }
};
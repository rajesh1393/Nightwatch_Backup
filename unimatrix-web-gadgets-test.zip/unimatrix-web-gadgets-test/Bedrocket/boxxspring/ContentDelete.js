//this function is for check and Delete in the Contentlist
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'ContentDelete' ];
var searchContent = [ ];
var contentTitle = [ ];
var expectedCount, actualCount, currentCount, excelData, actualLabel;
var getData,rowCount = 1;
var expectedLabel = "CONTENT";
module.exports = {
  tags: [ 'contentDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;    
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'ContentDelete': function ( contentsDelete ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Search Collection Title
      if ( excelData.includes ( 'A' ) ) {
        searchContent.push ( worksheet[ excelData ].v );
      }
      //Read Collection Title
      if ( excelData.includes ( 'B' ) ) {
        contentTitle.push ( worksheet[ excelData ].v );
      }
    }
    if ( contentTitle.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < contentTitle.length; getData++ ) {
        rowCount++;
        contentsDelete.pause ( 4000 ).useXpath ( ).
        //Wait for the ALL Menu in CONTENT is visible
        waitForElementVisible ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false, function ( checkContentMenu ) {
          if ( checkContentMenu.value == true ) {
            contentsDelete.pause ( 4000 ).useXpath ( ).
            //Click on the ALL menu in CONTENT
            click ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]" ).
            pause ( 4000 ).useCss ( ).
            //Get the Current total count in the Content listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              contentsDelete.pause ( 4000 ).
              keys ( contentsDelete.Keys.END ).keys ( contentsDelete.Keys.END ).useXpath ( ).
              //Wait for the Search content is visible in the listing page
              waitForElementVisible ( "//h2[contains ( .,'"+ searchContent[ getData ] +"' )]", 4000, false, function ( checkContentMenuLst ) {
                if ( checkContentMenuLst.value == true ) {
                  contentsDelete.pause ( 4000 ).useXpath ( ).
                  verify.visible ( "//h2[contains ( .,'"+ searchContent[ getData ] +"' )]" ).
                  pause ( 4000 ).
                  //Click on the Searched Content in the listing page
                  click ( "//h2[contains ( .,'"+ searchContent[ getData ] +"' )]" ).
                  pause ( 4000 ).
                  getText ( "//div/header/div/div[@class='typeName-label']", function ( getLabelName ) {
                    console.log ( "getLabelName",getLabelName )
                    actualLabel = getLabelName.value;
                    if ( actualLabel == expectedLabel ) {
                      contentsDelete.useCss ( ).pause ( 4000 ).
                      //Wait for the Headline field is visible in the edit page
                      waitForElementVisible ( ".text-input-headline", 4000, false ).
                      pause ( 4000 ).
                      //Verify the Headline field is visible in the edit page
                      verify.visible ( ".text-input-headline" ).
                      pause ( 4000 ).
                      //Clear the data in Headline field.
                      clearValue ( ".text-input-headline" ).
                      pause ( 4000 ).
                      //Enter the data in Headline field.
                      setValue ( ".text-input-headline", contentTitle[ getData ] ).
                      pause ( 4000 ).
                      //Verify the Delete button is visible in the edit content page
                      verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      //Click on the Delete button
                      click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Check the existance of delete confirmation dialog
                      verify.visible ( "dialog[ name=deleteVerification ]" ).
                      pause ( 4000 ).
                      //Verify the Cancel Button in Delete Dialog is visible
                      verify.visible ( ".link-secondary" ).
                      //Click Cancel Button in Delete Dialog
                      click ( ".link-secondary" ).
                      pause ( 4000 ).
                      //Verify the Delete button is visible in the edit page
                      verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      //Click on the Delete button in the edit content page
                      click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Check the existance of delete confirmation to delete
                      verify.visible ( "dialog[ name=deleteVerification ]" ).
                      //Verify the Delete Button in Delete Dialog is visible
                      verify.visible ( "button.btn:nth-child( 2 )" ).
                      pause ( 4000 ).
                      //Click Delete Button in Delete Dialog
                      click ( "button.btn:nth-child( 2 )" ).
                      pause ( 4000 ).useXpath ( ).
                      //Wait for the ALL Menu in CONTENT is visible
                      waitForElementVisible ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false ).
                      pause ( 4000 ).
                      //Click on the ALL Menu in CONTENT
                      click ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]" ).
                      pause ( 4000 ).useCss ( ).
                      //Get the Actual total count in the Content listing page
                      getText ( '.content-count > strong', function ( actualCountResult ) {
                        if ( actualCountResult.status != -1 ) {
                          actualCount = actualCountResult.value;
                          actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                          expectedCount = ( ( +currentCount ) - 1 );
                          if ( actualCount == expectedCount ) {
                            //Write in the Excel file:PASS Result
                            contentsDelete.writeToExcelPass ( 'boxxspring.xlsx', 'ContentDelete', rowCount, 4 );
                          }
                          else {
                            //Write in the Excel file:FAIL Result and Reason
                            contentsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'ContentDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Content. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                          }
                        }
                      } );   
                    }
                    else {
                      //Write in the Excel file:FAIL Result and Reason
                      contentsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'ContentDelete', rowCount, 4, 5, "Caption Name is not related to the page, which has expected as '"+ expectedLabel +"' and got actual as '"+ actualLabel +"'" );             
                    }
                  } );             
                }
                else {
                  //Write in the Excel file:FAIL Result and Reason
                  contentsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'ContentDelete', rowCount, 4, 5, "Searched Content artifact is not displayed is the listing page" );             
                }
              } );
            } );
          }
          else {
            //Write in the Excel file:FAIL Result and Reason
            contentsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'ContentDelete', rowCount, 4, 5, "Content Menu is not displayed in the Sidebar" );         
          }
        } );
      }
    }
    //End the Browser
    contentsDelete.end ( );
  }
}
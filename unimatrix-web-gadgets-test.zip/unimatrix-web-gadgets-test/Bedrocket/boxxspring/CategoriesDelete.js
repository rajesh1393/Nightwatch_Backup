//this function is for check and Delete the categories 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CategoriesDelete' ];
var storyTitle = [ ];
var storyEditTitle = [ ];
var storyShortDesc = [ ];
var currentCount, actualCount, expectedCount, searchCount, excelData;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'categoriesDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;    
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CategoriesDelete': function ( categoriesDelete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;      
      //Read story title
      if ( excelData.includes ( 'A' ) ) {
        storyTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Edit Title
      if ( excelData.includes ( 'B' ) ) {
        storyEditTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'C' ) ) {
        storyShortDesc.push ( worksheet[ excelData ].v );
      }
    }
    if ( storyTitle.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < storyTitle.length; getData++ ) {
        rowCount++;
        categoriesDelete.pause ( 4000 ).useXpath ( ).
        //Check and wait for Categories menu is visible in the CONTENT sidebar
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Categories' ]",4000,false,function ( checkCategoriesMenu ) {
          if ( checkCategoriesMenu.value == true ) {
            categoriesDelete.pause ( 4000 ).useXpath ( ).
            //Verify the Categories menu in CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Categories' ]", "Categories" ).
            pause ( 4000 ).
            //Click on the Categories
            click ( "//ul/li/a[ text( ) = 'Categories' ]" ).
            useCss ( ).pause ( 4000 ).
            //Wait for count label is visible in the categories listing page
            waitForElementVisible ( ".content-count>strong", 4000, false ).
            pause ( 4000 ).
            //Verify the count value is visible
            verify.visible ( ".content-count>strong" ).
            //Get the Current Total Count in the Categories List
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              categoriesDelete.pause ( 4000 ).useCss ( ).              
              //Wait for the Search input field is visible
              waitForElementVisible ( ".search-field-input", 4000, false ).
              pause ( 4000 ).
              //Verify the Search input field is visible
              verify.visible ( ".search-field-input" ).
              //Enter the data in the Search input field
              setValue ( ".search-field-input", storyTitle[ getData ] ).
              //hold the control
              keys ( categoriesDelete.Keys.ENTER ). 
              click ( ".search-field-input" ).
              //release the control
              keys ( categoriesDelete.Keys.NULL ). 
              pause ( 4000 ).
              //Wait for count label is visible in the categories listing page
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              pause ( 4000 ).
              //Verify the count label is visible in the categories listing page
              verify.visible ( ".content-count>strong" ).
              //Get the Total Searched Count in the Categories List
              getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                }
                if ( searchCount > 0 ) {
                  categoriesDelete.useXpath().
                  //Wait for searched data is visible in the categories listing page
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ storyTitle[ getData ] +"']]", 4000, false, function ( checkSearchedLst ) {
                    if ( checkSearchedLst.value == true ) {
                      categoriesDelete.pause ( 4000 ).
                      //Click on the searched categories in the listing page
                      click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ storyTitle[ getData ] +"']]" ).
                      useCss().pause ( 4000 ).
                      //Wait for the Properties Tab is visible
                      waitForElementVisible ( ".video-tabs > a[href='#properties' ]", 4000, false ).
                      pause ( 4000 ).
                      //Check the Properties Tab is visible
                      verify.visible ( ".video-tabs > a[href='#properties' ]" ).
                      pause ( 4000 ).
                      //Click on the Properties Tab
                      click ( ".video-tabs > a[href='#properties' ]" ).
                      pause ( 4000 ).
                      //Verify the Headline field is visible
                      verify.visible ( ".text-input-headline" ).
                      //Clear the Headline data in the field
                      clearValue ( ".text-input-headline" ).
                      pause ( 4000 ).
                      //Enter the Headline data in the field
                      setValue ( ".text-input-headline", storyEditTitle[ getData ] ).
                      pause ( 4000 ).    
                      //Wait for delete button is visible in the categories page 
                      waitForElementVisible ( ".btn-delete > span[ng-click='showDeleteVerification();']",4000, false, function ( checkDeleteBtn ) {
                        if ( checkDeleteBtn.value == true ) {                 
                          //Check and Click Delete Button.
                          categoriesDelete.verify.visible ( ".btn-delete > span[ng-click='showDeleteVerification();']" ).
                          pause ( 4000 ). 
                          //Click on the Delete button in the Portal
                          click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                          pause ( 4000 ).
                          //Check the existance of delete confirmation dialog
                          verify.visible ( "dialog[name=deleteVerification ]" ).
                          pause ( 4000 ).
                          //Click Cancel Button in Delete Dialog
                          verify.visible ( ".link-secondary" ).
                          pause ( 4000 ).
                          //Click on the Cancel button in the pop-up window
                          click ( ".link-secondary" ).
                          pause ( 4000 ).
                          verify.visible ( ".btn-delete > span[ng-click='showDeleteVerification();']" ).
                          pause ( 4000 ). 
                          //Click Cancel Button in Delete Dialog
                          click ( ".btn-delete > span[ng-click='showDeleteVerification();']" ).
                          pause ( 4000 ).
                          //Check the existance of delete confirmation to delete
                          verify.visible ( "dialog[name=deleteVerification]" ).
                          pause ( 4000 ). 
                          //Verify the delete button in the popup window in the categories page
                          verify.visible ( "button.btn:nth-child(2)" ).
                          pause ( 4000 ).
                          //Click on the delete button in pop-up window
                          click ( "button.btn:nth-child(2)" ).
                          pause ( 4000 ).useXpath ( ).
                          //Verify the Categories menu in CONTENT
                          verify.containsText ( "//ul/li/a[text( ) = 'Categories']", "Categories" ).
                          pause ( 4000 ).
                          //Click on the Categories Menu in CONTENT
                          click ( "//ul/li/a[ text( ) = 'Categories']" ).
                          useCss ( ).pause ( 4000 ).
                          //Wait for count label is visible in the categories listing page
                          waitForElementVisible ( ".content-count>strong", 4000, false ).
                          pause ( 4000 ).
                          //Verify count label is visible in the categories listing page
                          verify.visible ( ".content-count>strong" ).
                          //Get the Total Count in the Categories list
                          getText ( '.content-count > strong', function ( actualCountResult ) {
                            if ( actualCountResult.status != -1 ) {
                              actualCount = actualCountResult.value;
                              actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
                              expectedCount = ( ( + currentCount ) - ( 1 ) );
                              if ( actualCount == expectedCount ) {
                                //Write in the Excel for Pass Result and Reason
                                categoriesDelete.writeToExcelPass ( 'boxxspring.xlsx', 'CategoriesDelete', rowCount, 5 );
                              }
                              else {
                                //Write in the Excel for Fail Result and Reason
                                categoriesDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesDelete', rowCount, 5, 6, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Categories. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
                              }
                            }
                          } );
                        }
                        else {
                          //Write in the Excel for Fail Result and Reason
                          categoriesDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesDelete', rowCount, 5, 6, "Delete button is not visible in the page" )                    
                        }
                      } );
                    }
                    else {
                      //Write in the Excel for Fail Result and Reason
                       categoriesDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesDelete', rowCount, 5, 6, "Searched Data is not avail in the Listing page" )
                    }
                  } );
                }
                else {
                  //Write in the Excel for Fail-Search Result and Reason
                  categoriesDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesDelete', rowCount, 5, 6,  "Searched Result Count,'"+ searchCount +"'" );
                }              
              } );                  
            } );
          }
          else {
            //Write in the Excel for Fail-Search Result and Reason
            categoriesDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesDelete', rowCount, 5, 6,  "Categories Menu is not displayed in Sidebar" );                        
          }
        } );
      }
    }
    else {
      //Write in the Excel for Fail-Search Result and Reason
      categoriesDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesDelete', rowCount, 5, 6, "No such data avail in the excel file" );                        
    }
    //End the Browser
    categoriesDelete.end ( );
  }
};
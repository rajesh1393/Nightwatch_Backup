'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if  ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'FeedsAdd' ];
var feedTitle = [ ];
var provider = [ ];
var videoFiles = [ ];
var videoPlayer = [ ];
var content = [ ];
var permaLink = [ ];
var categoryType = [ ];
var categories = [ ];
var currentCount, actualCount, expectedCount, permaLinkUpper, excelData, permaLinkUpper;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'feedsAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'FeedsAdd': function ( feedAdd ) {
    for  ( excelData in worksheet ) {
      if  ( excelData[ 1 ] == '!' ) continue;
      //Read Provider Title
      if  ( excelData.includes ( 'A' ) ) {
        provider.push ( worksheet[ excelData ].v );
      }
      //Read Feed Title 
      if  ( excelData.includes ( 'B' ) ) {
        feedTitle.push ( worksheet[ excelData ].v );
      }
      //Read Video Files Title
      if  ( excelData.includes ( 'C' ) ) {
        videoFiles.push ( worksheet[ excelData ].v );
      }      
      //Read Video Player 
      if  ( excelData.includes ( 'D' ) ) {
        videoPlayer.push ( worksheet[ excelData ].v );
      }
      //Read Permanent Link 
      if  ( excelData.includes ( 'E' ) ) {
        permaLink.push ( worksheet[ excelData ].v );
      }
      //Read Content 
      if  ( excelData.includes ( 'F' ) ) {
        content.push ( worksheet[ excelData ].v );
      }
      //Read Category Type
      if  ( excelData.includes ( 'G' ) ) {
        categoryType.push ( worksheet[ excelData ].v );
      }
      //Read Categories
      if  ( excelData.includes ( 'H' ) ) {
        categories.push ( worksheet[ excelData ].v );
      }
    }
    if  ( provider.length > 0 ) {
      for ( let getData = 1, rowCount = 1; getData < provider.length; getData++ ) {
        rowCount++;
      	feedAdd.pause ( 4000 ).useXpath().
      	// Check and wait for the Distribution sub menu is visible in the side bar
      	waitForElementVisible ( "//i[@ng-if='!collapse.distribution']", 4000, false, function ( checkArrow ) {
	        if ( checkArrow.value == true ) {
	          feedAdd.pause ( 4000 ).useCss ( ).
	          //Verify the Distribution sub menu is visible in the side bar
	          verify.visible ( "div.content-header:nth-child( 7 )" ).
	          pause ( 4000 ).
	          //Click on the Distribution menu in the side bar
	          click ( "div.content-header:nth-child( 7 )" ).
	          pause ( 4000 )
	        }
	      } );
	    	feedAdd.pause ( 4000 ).useXpath ( ).
	    	//Check and Wait for Feeds menu is visible in the DISTRIBUTION
	    	waitForElementVisible ( "//a[text ( ) = 'Feeds']", 4000, false, function ( checkFeedMenu ) {
	        if ( checkFeedMenu.value == true ) {
		          feedAdd.pause ( 4000 ).useXpath ( ).
		          //Verify the Feeds menu is visible in the DISTRIBUTION
				      verify.containsText ( "//a[text( ) = 'Feeds']", "Feeds" ).
				      pause ( 4000 ).
				      //Click on the Feeds menu is visible in the DISTRIBUTION
				      click ( "//a[ text( ) = 'Feeds']" ).
				      useCss ( ).pause ( 4000 ).
				      //Get the text value for label count in the listing page
				      getText ( '.content-count > strong', function ( currentCountResult ) {
			        if  ( currentCountResult.status != -1 ) {
			          currentCount = currentCountResult.value;
			        }	
			        feedAdd.pause ( 4000 ).useCss().	          
		          //Wait for the Add videos button is visible in the Videos listing page	            
	            waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false, function( checkAddbtn ) {
                if ( checkAddbtn.value.length == 0 ) {
              		feedAdd.pause ( 4000 ).useXpath ( ).
              		//Wait for the Add button is visible in the Listing page
				          waitForElementVisible ( "//a[@class='btn btn-primary long ng-scope']", 4000, false ).
				          pause ( 4000 ).
				          //Verify the Add button is visible in the Listing page
				          verify.visible ( "//a[@class='btn btn-primary long ng-scope']" ).
				          pause ( 4000 ).
				          //Click on Add button in the Listing page
				          click("//a[@class='btn btn-primary long ng-scope']").
				          pause ( 4000 ).useXpath ( ).
				          //Wait for the provider is visible in the Feeds page
			            waitForElementVisible ( "//li/a/div[contains (.,'"+ provider[ getData ] +"')]", 4000, false ).
			            pause ( 4000 ).
			            //Verify the provider is visible in the Feeds page
			            verify.visible ( "//li/a/div[contains (.,'"+ provider[ getData ] +"')]" ).
			            pause ( 4000 ).
			            //Click on the Provider in the Feeds page
			            click ( "//li/a/div[contains (.,'"+ provider[ getData ] +"')]" ).
			            pause ( 4000 ).
			            //Get the text value in the label
			            getText ( "//div[@class='typeName-label']",function ( labelValue ) {
			              if (labelValue.value == "FEED" ){
					            feedAdd.pause ( 4000 ).
					            //Wait for the Text field is visible in the Feeds page
					            waitForElementVisible("//div/text-field[@class='ng-scope field-input ng-empty ng-valid']/input",4000,false ).
					            pause ( 4000 ).
					            //Clear the value on Text field in the Feeds page
					            clearValue("//div/text-field[@class='ng-scope field-input ng-empty ng-valid']/input" ).
					            pause ( 4000 ).
					            //Enter the value on Text field in the Feeds page
					            setValue ( "//div/text-field[@class='ng-scope field-input ng-empty ng-valid']/input", feedTitle[ getData ] ).
					            pause ( 4000 ).
					            //Wait for the provider field is visible in the feeds page
					            waitForElementVisible ( "//div[@class='input-like ng-binding']", 4000, false ).
					            pause ( 4000 ).useCss ( ).
					            //Click on the save button in the Feeds page
					            click ( ".btn-active" ). 
					            useXpath ( ).pause ( 4000 ). 
					            //Verify the provider field is visible in the feeds page    				
					            verify.containsText ( "//div[@class='input-like ng-binding'][contains(.,'"+ provider[ getData ] +"')]", provider[ getData ] ).
					            pause ( 4000 ).
					            //Wait for the input field is visible in the feeds page
					            waitForElementVisible ( "//div[@class='field-input slug-field ng-scope']/input[@placeholder]",4000,false ).
					            pause ( 4000 ).
					            //Get the attribute for field input in the Feeds page
					            getAttribute ( "//div[@class='field-input slug-field ng-scope']/input", "placeholder", function ( urlSlugValue ) {
					            	var requireText = "saving this feed";
					            	if  ( new RegExp ( requireText ).test ( urlSlugValue.value ) == true ) {
					            		feedAdd.useXpath ( ).
					            		//Wait for dropdown list field for Video files is visible in the Feeds page
					            		waitForElementVisible ( "//div/div[1]/div[3]/div/ul/li[1]/a", 4000, false ).
					            		pause ( 4000 ).
					            		//Click on the dropdown list field for Video files button in the Feeds page
					            		click ( "//div/div[1]/div[3]/div/ul/li[1]/a").
					            		pause ( 4000 ). 
					            		//Wait for the video file field is visible in the Feeds page
					            		waitForElementVisible ( "//ul/li/a[@class='ellipsis ng-binding'][text()='"+ videoFiles[ getData ]+"']", 4000, false ).
					            		pause ( 4000 ).
					            		//Click on the videofile listed in the Feeds page
					            		click ( "//ul/li/a[@class='ellipsis ng-binding'][text()='"+ videoFiles[ getData ] +"']" ).
					            		pause ( 4000 ).useCss ( ).
					            		//Wait for dropdown list field for Videoplayer is visible in the Feeds page
					            		waitForElementVisible ( "div.field-input:nth-child(4) > div > ul:nth-child(1) > li:nth-child(1) > a:nth-child(1)", 4000, false ).
					            		pause ( 4000 ).
					            		//Click on the dropdown list field for Videoplayer button in the Feeds page
					            		click ( "div.field-input:nth-child(4) > div > ul:nth-child(1) > li:nth-child(1) > a:nth-child(1)" ).
					            		pause ( 4000 ).useXpath ( ).
					            		//Wait for Videoplayer value is visible in dropdown list
					            		waitForElementVisible ( "//ul/li/a[@class='ellipsis'][text()='"+ videoPlayer[ getData ] +"']", 4000, false ).
					            		pause ( 4000 ).
					            		//Click on the Videoplayer in the dropdown list
					            		click ( "//ul/li/a[@class='ellipsis'][text()='"+ videoPlayer[ getData ] +"']" ).
					            		pause ( 4000 ).
					            		//Wait for permalink is visible in the Feeds page
					            		waitForElementVisible ( "//ul/li/div/label[@class='select'][@for='permalink']", 4000, false ).       		           		
					            		pause ( 4000 ).
					            		//Get attribute for permalink in the feeds page
					            		getAttribute ( "//ul/li/div/input","checked",function ( permaLinkCheck ) {    			
					                  permaLinkUpper = permaLinkCheck.value;
					                  if ( permaLinkUpper != null ) {
						                  permaLinkUpper = permaLinkUpper.toUpperCase();
					                    if ( permaLinkUpper != permaLink[ getData ] ) {
					            				  feedAdd.useXpath ( ).pause ( 4000 ).
					            				  //click("//ul/li/div/label[@class='select']").
					            				  click ( "//ul/li/div/input[@id='permalink']" ).
					            				  pause ( 4000 )
					            		    }					            		   
					            		  }
					            		  else {
					            		  	if ( permaLinkUpper == permaLink[ getData ] ) {
					            		    }
					            		    else {
					            		    	feedAdd.useXpath ( ).pause ( 4000 ).
					            		    	//Click on the permalink button
					            				  click ( "//ul/li/div/input[@id='permalink']" ).
					            				  click ( "//ul/li/div/label[@class='select']" ).
					            				  pause ( 4000 )
					            		    }
						            		}
						            		feedAdd.keys ( feedAdd.Keys.END ).
						            		pause ( 5000 ).useXpath ( ).
						            		//Wait for the content list button is visible in the Feeds page
						            		waitForElementVisible ( "//div/div[1]/div/div/div/a", 4000, false ).
						            		pause ( 4000 ).
						            		//Click on content list button in the Feeds page
						            		click ( "//div/div[1]/div/div/div/a" ).
						            		pause ( 4000 ).
						            		//Wait for the content list field is visible in the Feeds page
						            		waitForElementVisible ( "//ul/li/a[text()[normalize-space(.)='"+ content[ getData ] +"']]", 4000, false ).
						            		pause ( 4000 ).
						            		//Click on the content list in the Feeds page
						            		click ( "//ul/li/a[text()[normalize-space(.)='"+ content[ getData ] +"']]" ).
						            		pause ( 4000 )
							            } );
							            //Wait for the add button is visible in the Feeds page
				                  feedAdd.waitForElementVisible ( "//div[@class='field-input']/a[@class='btn btn-primary centered']", 4000, false ).
				            		  pause ( 4000 ).
				            		  //Click on the button in the Feeds page
				            		  click ( "//div[@class='field-input']/a[@class='btn btn-primary centered']" ).
				            		  pause ( 4000 ).
				            		  //Check and Wait for the Filter condition field is visible in the Feeds page
				            		  waitForElementVisible ( "//div[@class='field-input filter-conditions ng-scope']", 4000, false, function ( conditionVisible ) {
					            			if ( conditionVisible.value == true ) {
					            				feedAdd.useXpath ( ).pause ( 4000 ).
					            				//Verify category field is visible in the Feeds page
					            				verify.visible ( "//div/a[@class='ng-binding'][text()[normalize-space(.)='Category']]" ).
					            				pause ( 4000 ).
					            				//Wait for the filter field is visible in the Feeds page
					            				waitForElementVisible ( "//filter/div/div[2]/div[2]/section/div/div/div/a", 4000, false ).
					            				pause ( 4000 ).
					            				//Click on the filter in the Feeds page
					            				click ( "//filter/div/div[2]/div[2]/section/div/div/div/a" ).
					            				pause ( 4000 ).
					            				//Wait for the Category type is visible in the Feeds page
					            				waitForElementVisible ( "//ul/li/a[text()[normalize-space(.)='"+ categoryType[ getData ] +"']]", 4000, false ).
					            				pause ( 4000 ).
					            				//Click on the Category Type in the Feeds page
					            				click ( "//ul/li/a[text()[normalize-space(.)='"+ categoryType[ getData ] +"']]" ).
					            				pause ( 4000 ).
					            				//Wait for the filter categories is visible in the Feeds page
					            				waitForElementVisible ( "//filter/div/div[2]/div[3]/div/div/div/input", 4000, false ).
					            				pause ( 4000 ).
					            				//Enter the categories in the Feeds page
					            				setValue ( "//filter/div/div[2]/div[3]/div/div/div/input",categories[ getData ] ).
					            				pause ( 4000 ).
					            				//Wait for the suggestion item in the Feeds page
			                        waitForElementVisible ( "//div/div[@class='suggestion-item']/span[text()[normalize-space(.)='"+ categories[ getData ] +"']]", 4000, false ).
			                        pause ( 4000 ).
			                        //Click on the Suggestion item in the Feeds page
			                        click ( "//div/div[@class='suggestion-item']/span[text()[normalize-space(.)='"+ categories[ getData ] +"']]" ).
			                        pause ( 4000 ).     
			                        //Wait for save button is visible in the Feeds page               
					            				waitForElementVisible ( "//ul/li/a/span[text()[normalize-space(.)='Save']]", 4000, false ).
					            			  pause ( 4000 ).
					            			  //Click on the save button in the Feeds page 
					            				click ( "//ul/li/a/span[text()[normalize-space(.)='Save']]" )  
					            				feedAdd.pause ( 4000 ).useXpath ( ).
					            				//Verify the Feeds menu is visible in the DISTRIBUTION
									            verify.containsText ( "//a[text( ) = 'Feeds']", "Feeds" ).
									            pause ( 4000 ).
									            //Click on Feeds menu is visible in the DISTRIBUTION
									            click ( "//a[ text( ) = 'Feeds']" ).
									            useCss ( ).pause ( 4000 ).
									            //Wait for label count is visible in the Feeds listing page
									            waitForElementVisible ( ".content-count>strong", 4000, false ).
									            pause ( 4000 ).
									            //Verify label count is visible in the Feeds listing page
									            verify.visible ( ".content-count>strong" ).
									            pause ( 4000 ).
									            //Get the text value in the label count in the listing page
									            getText ( '.content-count > strong', function ( actualCountResult ) {
									              if  ( actualCountResult.status != -1 ) {
									                actualCount = actualCountResult.value;
									                expectedCount =  ( ( + currentCount ) +  ( 1 ) );
									                if  ( actualCount == expectedCount ) {
									                  //Write in the spreadsheet: Pass Result and Reason
									                  feedAdd.writeToExcelPass ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10 );
									                }
									                else {
									                  //Write in the spreadsheet: Fail Result and Reason
									                  feedAdd.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10, 11, "ActualResult: '"+ actualCount +"' in the Total Count After Added Feeds. ExpectedResult: should be'"+ expectedCount +"' in the Total Count "  );
									                }
									              }
									            } );    				
					            			}
					            			else {
					            				//Write in the spreadsheet: Fail Result and Reason
					            				feedAdd.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10, 12, "Filter Condition is not working in the Feeds page" );
					            			}
					            		});     		
					              }
					            	else {
					              	feedAdd.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10, 12, "Not getting permalinks attributes" );
					            	}
					          	});  
			          	  }
			              else{
			              	//Write in the spreadsheet: Fail Result and Reason
			                feedAdd.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10, 12, "Feed caption is not displayed" );
			              }
			            }); 
			          }
			          else {
			          	//Write in the spreadsheet: Fail Result and Reason
			    				feedAdd.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10, 11, "Feeds Add is not functioning in the list page" );
			          }
			      	}); 
			     	});
		      } 
		      else {
		      	//Write in the spreadsheet: Fail Result and Reason
			    	feedAdd.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10, 11, "Feeds menu is not displayed in the sidebar" );
	      	}
				});	      
    	}
		}
    //End the Browser
    feedAdd.end ( );
  }
};









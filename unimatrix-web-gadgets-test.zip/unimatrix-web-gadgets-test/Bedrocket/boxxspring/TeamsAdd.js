//this function is for check and add the Teams
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'TeamsAdd' ];
var teamTitle = [ ];
var teamDescription = [ ];
var teamshortTitle = [ ];
var teamshortDesc = [ ];
var teamCategoryName = [ ];
var teamNote = [ ];
var teamImg = [ ];
var currentCount, actualCount, expectedCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'teamsAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'TeamsAdd': function ( teamsAdd ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Teams Title
      if ( excelData.includes ( 'A' ) ) {
        teamTitle.push ( worksheet[ excelData ].v );
      }
      //Read Teams Description
      if ( excelData.includes ( 'B' ) ) {
        teamDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        teamshortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        teamshortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Teams category Name
      if ( excelData.includes ( 'E' ) ) {
        teamCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read Teams Note
      if ( excelData.includes ( 'F' ) ) {
        teamNote.push ( worksheet[ excelData ].v );
      }
      //Read Teams Image
      if ( excelData.includes ( 'G' ) ) {
        teamImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( teamTitle.length > 1 ) {
      var checkResult = teamsAdd.globals.excelCol.resultCustomData; 
      for ( let getData = 1,rowCount = 1; getData < teamTitle.length; getData++ ) {
        rowCount++;
        teamsAdd.pause ( 9000 ).useXpath ( ).
        //Wait for the Team menu is visible in the sidebar
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Teams' ]", 9000, false, function ( checkTeamMenu ) {
          if ( checkTeamMenu.value == true ) {
            teamsAdd.pause ( 9000 ).useXpath ( ).
            //Verify the Teams Menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Teams' ]", "Teams" ).
            pause ( 9000 ).
            //Click on the Teams Menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Teams' ]" ).
            useCss ( ).pause ( 9000 ).
            //Get the Total Teams count in the Teams listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length  - 1 ) );
              }
              teamsAdd.useCss ( ).
              //Wait for the Add button is visible in the listing page
              waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false, function ( checkAddbtn ) {
                if ( checkAddbtn.value.length == 0 ) {
                  teamsAdd.pause ( 9000 ).
                  //Click on the Add button to create an author
                  click ( ".btn-add" ).
                  pause ( 9000 ).
                  //Get the caption label value in the Teams page
                  getText ( ".typeName-label.ng-binding", function ( labelName ) {
                    if ( labelName.value == "TEAM") {
                      teamsAdd.pause ( 9000 ).
                      //Verify the Content Tab in the Teams page
                      verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                      //Click on the Content Tab
                      click ( ".video-tabs > a[ href='#content' ]" ).
                      pause ( 9000 ).
                      //Check and Enter Teams Title
                      waitForElementVisible ( ".text-input-headline", 9000, false ).
                      //Enter the Teams Title in the Headline
                      setValue ( ".text-input-headline", teamTitle[ getData ] ).
                      pause ( 9000 ).
                      //Check and Enter Teams Text Description
                      waitForElementVisible ( ".wmd-input", 9000, false ).
                      pause ( 7000 ).
                      //Clear the data in the field
                      clearValue ( ".wmd-input" ).
                      pause ( 7000 ).
                      //Enter the Data in the field
                      setValue ( ".wmd-input", teamDescription[ getData ] ).
                      pause ( 9000 ).
                      //Check and click Save button
                      waitForElementVisible ( '.btn-active', 9000, false ).
                      pause ( 9000 ).
                      //Click on the Save button
                      click ( ".btn-active" ).
                      pause ( 6000 ).
                      //Check and Enter the valid input in the Properties Tab
                      all_properties ( teamshortTitle[ getData ], teamshortDesc[ getData ], teamCategoryName[ getData ], teamNote[ getData ], teamImg[ getData ] ).
                      pause ( 4000 ).useCss ( ).
                      //Wait for the Content tab is visible in the Teams page
                      waitForElementVisible ( ".video-tabs > a[ href='#properties']", 9000, false, function ( checkProperties ) {
                        if ( checkProperties.value == true ) {
                          if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                            //Write in the spreadsheet: Fail Result and Reason
                            teamsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsAdd', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                            checkResult.length = 0;
                          }
                          else if ( checkResult.length == 0 ) {
                          }
                          else {
                            checkResult.length = 0;
                            //Check and click save button
                            teamsAdd.verify.visible ( "a.btn-active" ).
                            //click on the save button
                            click ( "a.btn-active" ).
                            pause ( 7000 ).
                            //Wait for the save active should not present in Teams Page
                            waitForElementNotPresent ( "a.btn-active", 9000, false, function ( checkSaveInactive ) {
                              if ( checkSaveInactive.value.length == 0 ) {
                                teamsAdd.pause ( 4000 ).useXpath ( ).
                                //Verify the videos menu in the sidebar
                                verify.containsText ( "//ul/li/a[ text( ) = 'Teams']", "Teams" ).
                                pause ( 9000 ).
                                //click on the videos menu in CONTENT
                                click ( "//ul/li/a[ text( ) = 'Teams']" )
                                //Check the Actual Count after each video added
                                teamsAdd.useCss ( ).pause( 9000 ).
                                //Wait for Totla count label is visible in the listing page
                                waitForElementVisible ('.content-count > strong', 9000, false ).
                                pause ( 7000 ).
                                //Get the text from the label in the listing page
                                getText ( '.content-count > strong', function ( actualCountResult ) {
                                  if ( actualCountResult.status != -1 ) {
                                    actualCount = actualCountResult.value;
                                    actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                    expectedCount = ( ( + currentCount ) + ( 1 ) );
                                    if ( actualCount == expectedCount ) {
                                      //Write in the spreadsheet: Pass Result and Reason
                                      teamsAdd.writeToExcelPass ( 'boxxspring.xlsx', 'TeamsAdd', rowCount, 9 );
                                    }
                                    else {
                                      //Write in the spreadsheet: Fail Result and Reason
                                      teamsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsAdd', rowCount, 9, 10, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Teams. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                    }
                                  }
                                } );
                              }
                              else {
                                //Write in the spreadsheet: Fail Result and Reason
                                teamsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsAdd', rowCount, 9, 10, "Save functionality is not working as expected" );
                              }
                            } );
                          }
                          if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                            checkResult.length = 0;
                          }
                        }                       
                      } );
                    }
                    else {
                      //Write in the spreadsheet: Fail Result and Reason
                      teamsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsAdd', rowCount, 9, 10, "Lable Name as Expected 'TEAM' but Actual as '"+ labelName.value +"'" );                         
                    }
                  } );
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
                  teamsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsAdd', rowCount, 9, 10, "Add button is not working in the Teams Listing page" );                    
                }
              } );
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            teamsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsAdd', rowCount, 9, 10, "Teams menu is not displayed in Sidebar" ); 
          }
        } );
      }
    }
    //End the browser
    teamsAdd.end ( );
  }
};
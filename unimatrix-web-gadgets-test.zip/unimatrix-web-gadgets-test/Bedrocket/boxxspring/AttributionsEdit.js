//this function is for check and Edit the Attributions 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'AttributionsEdit' ];
var attributionTitle = [ ];
var attributionSearch = [ ];
var attributionDescription = [ ];
var attributionShortTitle = [ ];
var attributionShortDesc = [ ];
var attributionCategoryName = [ ];
var attributionNote = [ ];
var attributionImg = [ ];
var currentCount, actualCount, excelData, searchCount;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'attributionsEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AttributionsEdit': function ( editAttribution ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        attributionTitle.push ( worksheet[ excelData ].v );
      }
      //Read attributions Description
      if ( excelData.includes ( 'B' ) ) {
        attributionSearch.push ( worksheet[ excelData ].v );
      }
      if ( excelData.includes ( 'C' ) ) {
        attributionDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'D' ) ) {
        attributionShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'E' ) ) {
        attributionShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read attributions category Name
      if ( excelData.includes ( 'F' ) ) {
        attributionCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read attributions Note
      if ( excelData.includes ( 'G' ) ) {
        attributionNote.push ( worksheet[ excelData ].v );
      }
      //Read attributions Image
      if ( excelData.includes ( 'H' ) ) {
        attributionImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( attributionTitle.length > 1 ) {  
      var checkResult = editAttribution.globals.excelCol.resultCustomData;  
      for ( let getData = 1,rowCount = 1; getData < attributionTitle.length; getData++ ) {
        rowCount++;   
        editAttribution.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text ( ) = 'Attributions' ]", 4000, false, function ( checkAttributeMenu ) {
          if ( checkAttributeMenu.value == true ) {
            editAttribution.pause ( 4000 ).useXpath ( ).
            //Verify the Attribution Menu in CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Attributions' ] ", "Attributions" ).
            pause ( 4000 ).
            //Click on the Attribution Menu in CONTENT
            click ( "//ul/li/a[ text( ) = 'Attributions' ] " ).
            useCss ( ).pause ( 4000 ).
            //Get the Actual Total count in the Attibutions After Edit
            getText ( '.content-count > strong', function ( actualCountResult ) {
              if ( actualCountResult.status !== -1 ) {
                currentCount = actualCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              editAttribution.pause ( 4000 ).
              //Wait for the Search input field is visible
              waitForElementVisible ( ".search-field-input", 4000,false ).
              //Verify the Search input field is visible
              verify.visible ( ".search-field-input" ).
              setValue ( ".search-field-input", attributionSearch[ getData ] ).
              //hold the control
              keys ( editAttribution.Keys.ENTER ). 
              click ( ".search-field-input" ).
              //release the control
              keys ( editAttribution.Keys.NULL ). 
              pause ( 4000 ).  
              //Wait for the Count value is visible        
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              pause ( 4000 ).
              verify.visible ( ".content-count>strong" ).
              pause ( 4000 ).
              //Get the count after searched in the Attribution listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {                      
                if ( searchCountResult.status !== -1 ) {
                  searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                }
                //Check the Searched Count as greater than Zero
                if ( searchCount > 0 ) {
                  editAttribution.pause ( 4000 ).useXpath().
                  //Wait for the Edit pullout button is visible
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ attributionSearch[ getData ] +"']]", 4000, false,function ( checkattributionLst ) {
                  	if ( checkattributionLst.value == true ) {
		                  editAttribution.pause ( 4000 ).
		                  verify.visible ("//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ attributionSearch[ getData ] +"']]").
		                  pause ( 5000 ).
		                  //Click on the Edit pullout button
		                  click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ attributionSearch[ getData ] +"']]" ).
		                  useCss().pause ( 4000 ).
		                  //Verify the Content Tab is visibel
		                  verify.visible ( ".video-tabs > a[ href='#content'] " ).
		                  pause ( 4000 ).
		                  //Click on the Content Tab
		                  click ( ".video-tabs > a[ href='#content'] " ).
		                  pause ( 4000 ).
		                  //Check and Enter Categories Title
		                  waitForElementVisible ( ".text-input-headline", 4000, false ).
		                  //Clear the Headline data in the field
		                  clearValue ( ".text-input-headline" ).
		                  //Enter the Headline data in the field
		                  setValue ( ".text-input-headline", attributionTitle[ getData ] ).
		                  pause ( 4000 ).
		                  //Check and Enter Categories Text Description
		                  waitForElementVisible ( ".wmd-input", 4000, false ).
		                  //Clear the Short description data in the field
		                  clearValue ( ".wmd-input" ).
		                  //Enter the Short description data in the field
		                  setValue ( ".wmd-input", attributionDescription[ getData ] ).
		                  pause ( 4000 ).
		                  //Check and click Save button
		                  waitForElementVisible ( '.btn-active', 4000, false ).
		                  pause ( 4000 ).
		                  //Verify the SAve button is visible
		                  verify.visible ( ".btn-active" ).
		                  pause ( 4000 ).
		                  //Click on the Save button
		                  click ( ".btn-active" ).
		                  pause ( 4000 ).
		                  //Set the details in the Attributions Properties Tab
		                  video_properties ( attributionShortTitle[ getData ], attributionShortDesc[ getData ], attributionCategoryName[ getData ], attributionNote[ getData ], attributionImg[ getData ] ).
		                  pause ( 4000 ).useCss ( ).
		                  waitForElementVisible ( ".video-tabs > a[ href='#properties']",4000,false,function ( checkProperties ) {
		                    if ( checkProperties.value == true ) {
		                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
		                        editAttribution.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsEdit', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
		                        checkResult.length = 0;
		                      }
		                      else if ( checkResult.length == 0 ) {
		                      }
		                      else {
		                        checkResult.length = 0;
		                        //Check and click save button
		                        editAttribution.verify.visible ( "a.btn-active" ).
		                        //click on the save button
		                        click ( "a.btn-active" ).
		                        pause ( 4000 ).
		                        waitForElementNotPresent ( "a.btn-active",4000,false,function ( checkSaveBtn ) {
		                          if ( checkSaveBtn.value.length == 0 ) {
		                            editAttribution.pause ( 4000 ).useXpath ( ).
		                            //Verify the videos menu in the sidebar
		                            verify.containsText ( "//ul/li/a[ text( ) = 'Attributions']", "Attributions" ).
		                            pause ( 4000 ).
		                            //click on the videos menu in CONTENT
		                            click ( "//ul/li/a[ text( ) = 'Attributions']" ).
		                            useCss ( ).pause ( 4000 ) 
		                            //Check the Actual Count after each video added
		                            editAttribution.useCss().pause( 4000 ).
		                            getText ( '.content-count > strong', function ( actualCountResult ) {
		                              if ( actualCountResult.status !== -1 ) {
		                                actualCount = actualCountResult.value;
		                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
		                                if ( actualCount == currentCount ) {
		                                  //Write in the spreadsheet: Pass Result and Reason
		                                  editAttribution.writeToExcelPass ( 'boxxspring.xlsx', 'AttributionsEdit', rowCount, 10 );
		                                }
		                                else {
		                                  //Write in the spreadsheet: Fail Result and Reason
		                                  editAttribution.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsEdit', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Videos(URL). ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
		                                }
		                              }
		                            } );
		                          }
		                          else {
		                            //Write in the spreadsheet: Fail Result and Reason
		                            editAttribution.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsEdit', rowCount, 10, 11, " Save button is not functioning as expected" );
		                          }
		                        } );		                        
		                      }
		                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
		                        checkResult.length = 0;
		                      }
		                    }
		                    else {
		                    }
		                  } );  
                 		}
                  	else {
                  	//Writ in the Excel for Search Fail Result and Reason
                  	editAttribution.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsEdit', rowCount, 10, 11, "There is no Searched Data in the listing page" );
                  	}
                  } );               
                }
                else {
                  //Writ in the Excel for Search Fail Result and Reason
                  editAttribution.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsEdit', rowCount, 10, 11, "Searched Result Count,'"+ searchCount +"'" );
                }
              } );           
            } );
          }
          else {
            //Writ in the Excel for Search Fail Result and Reason
            editAttribution.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsEdit', rowCount, 10, 11, "Attribution menu is not displayed in sidebar" );
          }
        } );
      }
    }
    //End the Browser
    editAttribution.end ( );
  }
};
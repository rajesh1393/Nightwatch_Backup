//this function is for check and add the Bulk edit collections
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['BulkeditCollections'];
var collectionTitle = [ ];
var splitCategories = [ ];
var resultStatus = [ ];
var resultStatusFirst = [ ];
var categoryTitle = [ ];
var searchcategoryTitle = [ ];
var expectedCount, actualCount, currentCount, excelData, splitCategoriesName;
var getData, rowCount = 1;
var dataCatagory, categoryData, countCategory, categoryCount = 0;
module.exports = {
  tags: ['bulkeditCollections'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'BulkeditCollections': function ( bulkeditCollection ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[1] == '!' ) continue;
      //Read Search Collection Title
      if ( excelData.includes ( 'A' ) ) {
        collectionTitle.push ( worksheet[excelData].v );
      }
      //Read Collection Title
      if ( excelData.includes ( 'B' ) ) {
        categoryTitle.push ( worksheet[excelData].v );
      }
      //Read Search categories Title
      if ( excelData.includes ( 'C' ) ) {
        searchcategoryTitle.push ( worksheet[excelData].v );
      }
    }
    if ( collectionTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < collectionTitle.length; getData++ ) {
        rowCount++;
        bulkeditCollection.pause ( 4000 ).useXpath ( ).
        //Verify the Collection title is visible
        waitForElementVisible ( "//ul/li/a[ text()[normalize-space(.)= '" + collectionTitle[ getData ] + "']]", 4000, false, function ( checkCollectionMenu ) {
          if ( checkCollectionMenu.value == true ) {
            bulkeditCollection.pause ( 4000 ).useXpath ( ).
            //Click on the Collection title
            click ( "//ul/li/a[ text()[normalize-space(.)= '" + collectionTitle[ getData ] + "']]" ).
            pause ( 4000 ).useCss ( ).
            //Get the Current Total count in the Collection listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              if ( currentCount > 0 ) {
                bulkeditCollection.pause ( 4000 ).useCss ( ).
                //Wait for the Bulk Edit button is visible
                waitForElementVisible ( "a.btn:nth-child( 2 )", 4000, false, function ( checkBulkeditBtn ) {
                  if ( checkBulkeditBtn.value == true ) {
                    bulkeditCollection.pause ( 4000 ).
                    //Click on the Bulk Edit button
                    click ( "a.btn:nth-child( 2 )" ).
                    pause ( 4000 ).
                    //Wait for the Bulk Edit dialog box is visible
                    waitForElementVisible ( ".dialog-large", 4000, false, function ( checkDialogbox ) {
                      if ( checkDialogbox.value == true ) {
                        bulkeditCollection.pause ( 4000 ).useCss ( ).
                        //Verify the Bulk Edit dialog box is visible
                        verify.visible ( ".dialog-large" ).
                        pause ( 4000 ).useXpath ( ).
                        //Verify the Bulk Edit dialog box close button is visible
                        verify.visible ( "//*/div/section/h1/i" )
                        splitCategories = categoryTitle[getData].split(',');                        
                        bulkeditCollection.pause ( 4000 ).useXpath ( ).
                        waitForElementVisible ( "//*//div/div/div/input", 4000, false, function ( getCategories ) {
                          if ( getCategories.value == true ) {
                            for ( let countCategory = 0, dataCatagory = 0; countCategory < splitCategories.length; countCategory++ ) {
                              dataCatagory++;
                              bulkeditCollection.pause ( 4000 ).useXpath ( ).
                              waitForElementVisible ( "//*//section/section/section/a", 4000, false, function ( checkCancelBtn ) {
                              	if ( checkCancelBtn.value == true ) {
		                              var splitCategoriesName = splitCategories[countCategory].split(';');
		                              bulkeditCollection.pause ( 4000 ).useXpath ( ).
		                              verify.visible ( "//*//div/div/div/input" ).
		                              pause ( 4000 ).
		                              setValue ( "//*//div/div/div/input", splitCategoriesName[0] ).
		                              pause ( 4000 ).
		                              //Click on the Bulk Edit dialog box Search field
		                              waitForElementVisible ( "//div/div/span[contains(.,'"+splitCategoriesName[0]+"')]//ancestor::div/div/span[contains(.,'"+splitCategoriesName[1]+"')]", 4000, false, function ( checkDropList ) {
		                                if ( checkDropList.value == true ) {
		                                  bulkeditCollection.pause ( 4000 ).useXpath ( ).
		                                  verify.visible ( "//div/div/span[contains(.,'"+splitCategoriesName[0]+"')]//ancestor::div/div/span[contains(.,'"+splitCategoriesName[1]+"')]" ).
		                                  pause ( 4000 ).
		                                  click ( "//div/div/span[contains(.,'"+splitCategoriesName[0]+"')]//ancestor::div/div/span[contains(.,'"+splitCategoriesName[1]+"')]" ).
		                                  pause ( 4000 )
		                                }
		                                else {
		                                	bulkeditCollection.pause ( 4000 ).useCss ( ).
		                                  keys ( bulkeditCollection.Keys.ENTER ).
		                                  keys ( bulkeditCollection.Keys.ENTER )
		                                }
		                                if ( dataCatagory == splitCategories.length ) {
		                                  bulkeditCollection.pause ( 4000 ).useCss ( ).
		                                  waitForElementVisible ( "button.ng-scope", 4000, false ).
		                                  pause ( 4000 ).
		                                  //Click on the Save Button
		                                  click ( "button.ng-scope" )
		                                  for ( let categoryCount = 0, categoryData = 0; categoryCount < splitCategories.length; categoryCount++ ) {
		                                    categoryData++;
		                                    bulkeditCollection.pause ( 4000 ).useXpath ( ).
		                                    //Verify the Categories Menu in CONTENT is visible
		                                    verify.containsText ( "//ul/li/a[ text()[normalize-space(.)= 'Categories']]", "Categories" ).
		                                    pause ( 4000 ).
		                                    //Click on the Categories Menu in CONTENT is visible
		                                    click ( "//ul/li/a[ text()[normalize-space(.)='Categories']]" ).
		                                    useCss ( ).pause ( 4000 ).
		                                    //Wait for the Search input field in categories is visible
		                                    waitForElementVisible ( ".search-field-input", 4000, false, function ( checkSearchField ) {
		                                    	if ( checkSearchField.value == true ) {
		                                    		if ( ( !( resultStatusFirst.indexOf ('NO') >= 0 ) ) || resultStatusFirst.length == 0 ) {
		                                    			bulkeditCollection.pause ( 4000 ).useCss ( ).
					                                    //Verify the Search input field in categories is visible
					                                    verify.visible ( ".search-field-input" ).
					                                    //Enter the Search input field in categories is visible
					                                    setValue ( ".search-field-input", splitCategoriesName[0] ).
					                                    keys ( bulkeditCollection.Keys.ENTER ). // hold the control
					                                    click ( ".search-field-input" ).
					                                    pause ( 4000 ).useCss ( ).
					                                    waitForElementVisible ( ".grid", 4000, false, function ( checkGridBtn ) {
					                                      if ( checkGridBtn.value == true ) {
					                                        bulkeditCollection.pause ( 4000 ).useCss ( ).
					                                        click ( ".grid" ).
					                                        pause ( 4000 ).useXpath ( ).
					                                        //Wait for the searched data listed is visible in the listing page
					                                        waitForElementVisible ( "//h2[text()[normalize-space(.)='" + splitCategoriesName[0] + "')]]//ancestor::section/div/a[2]", 4000, false, function ( checkSearchedLst ) {
					                                          if ( checkSearchedLst.value == true ) {
					                                            bulkeditCollection.pause ( 4000 ).useXpath ( ).
					                                            click ( "//h2[text()[normalize-space(.)='" + splitCategoriesName[0] + "' )]]//ancestor::section/div/a[2]" ).
					                                            pause ( 4000 ).
					                                            waitForElementPresent ( "//div[@class='content-title'][text()[normalize-space(.)='" + searchcategoryTitle[getData] + "' )]]", 4000, false, function ( checkContentTitle ) {
					                                              if ( checkContentTitle.value.length != 0 ) {
					                                                resultStatus.push ( 'PASS' )
					                                              }
					                                              else {
					                                                resultStatus.push ( 'FAIL' )
					                                              }
					                                              if ( categoryData == splitCategories.length ) {
					                                                if ( resultStatus.indexOf ( 'FAIL' ) >= 0 ) {
					                                                  //Write in the Excel:FAIL Result and Reason
					                                                  bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Content Title is not displayed in the categories view items page" );
					                                                }
					                                                else {
					                                                  //Write in the Excel:PASS Result
					                                                  bulkeditCollection.writeToExcelPass ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5 );
					                                                }
					                                                if ( resultStatus.indexOf ( 'FAIL' ) || resultStatus.indexOf ( 'PASS' ) >= 0 ) {
					                                                  resultStatus.length = 0;
					                                                }
					                                              }
					                                            } );
					                                            resultStatusFirst.push ("YES");
					                                          }
					                                          else {
					                                          	resultStatusFirst.push ("NO");
					                                          }
					                                        } );
					                                      }
					                                      else {
					                                        //Write in the Excel:FAIL Result and Reason
					                                        bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Grid button is not displayed in the categories listing page" );
					                                      }
					                                    } );
					                                  }
					                                  else {
					                                  	//Write in the Excel:FAIL Result and Reason
					                                    bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Content Title '" + splitCategories[categoryCount] + "'is not displayed in the categories listing page" );
					                                  }
				                                  }
				                                  else {
				                                  	//Write in the Excel:FAIL Result and Reason
				                                    bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Search field is not displayed in the categories listing page" );
				                                  }
						                            } );
				                              } 
				                            }
				                          } );
																}
																else {
																	//Write in the Excel:FAIL Result and Reason
																	bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Cancel button is not displayed in the dialog box" );                               
																}
			  											} );  
                            } 
                          }
                          else {
                            //Write in the Excel:FAIL Result and Reason
                            bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Categories Input field is not displayed in the Dialog box" );
                          }
                        } );
                      }
                      else {
                        //Write in the Excel:FAIL Result and Reason
                        bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Dialog-large box is not displayed in the collections page" );
                      }
                    } );
                  }
                  else {
                    //Write in the Excel:FAIL Result and Reason
                    bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Bulk Edit Button is not displayed in the collections page" );
                  }
                } );
              }
            } );
          }
          else {
          	//Write in the Excel:FAIL Result and Reason
            bulkeditCollection.writeToExcelFail ( 'boxxspring.xlsx', 'BulkeditCollections', rowCount, 5, 6, "Collections menu '"+collectionTitle[getData]+"' is not displayed in the Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    bulkeditCollection.end ( );
  }
}
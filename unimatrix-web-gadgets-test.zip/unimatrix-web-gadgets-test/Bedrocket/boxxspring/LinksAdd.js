//this function is for check and add the Links
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'LinksAdd' ];
var linkTitle = [ ];
var linkUrl = [ ];
var linkDescription = [ ];
var linkShortTitle = [ ];
var linkShortDesc = [ ];
var linkCategoryName = [ ];
var linkNote = [ ];
var linkImg = [ ];
var currentCount, actualCount, excelData, expectedCount;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'linksAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'LinksAdd': function ( linksAdd ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read links Title
      if ( excelData.includes ( 'A' ) ) {
        linkTitle.push ( worksheet[ excelData ].v );
      }
      //Read links Description
      if ( excelData.includes ( 'B' ) ) {
        linkUrl.push ( worksheet[ excelData ].v );
      }
      if ( excelData.includes ( 'C' ) ) {
        linkDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'D' ) ) {
        linkShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'E' ) ) {
        linkShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read links category Name
      if ( excelData.includes ( 'F' ) ) {
        linkCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read links Note
      if ( excelData.includes ( 'G' ) ) {
        linkNote.push ( worksheet[ excelData ].v );
      }
      //Read links Image
      if ( excelData.includes ( 'H' ) ) {
        linkImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( linkTitle.length > 1 ) {
      var checkResult = linksAdd.globals.excelCol.resultCustomData; 
      for ( let getData = 1, rowCount = 1; getData < linkTitle.length; getData++ ) {
        rowCount++;
        linksAdd.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text ( ) = 'Links']", 4000, false, function ( checkLinksMenu ) {
          if ( checkLinksMenu.value == true ) {
            linksAdd.pause ( 4000 ).useXpath ( ).
            //Verify the Links menu is visible in the CONTENT 
            verify.containsText ( "//ul/li/a[ text ( ) = 'Links']", "Links" ).
            pause ( 4000 ).
            //Click on the Links menu in the CONTENT 
            click ( "//ul/li/a[ text ( ) = 'Links']" ).
            useCss ( ).pause ( 4000 ).
            //Get the current total count in the links listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }              
              //Wait for the Save button is visible
              linksAdd.waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false, function ( checkAddBtn ) {
                if ( checkAddBtn.value.length == 0 ) {
                  linksAdd.pause ( 4000 ).
                  verify.visible ( ".btn-add" ).
                  pause ( 4000 ).
                  //Click on the Save button
                  click ( ".btn-add" ).
                  pause ( 4000 ).
                  //Verify the Content tab is visible
                  verify.visible ( ".video-tabs > a[href='#content']" ).
                  pause ( 4000 ).
                  //Click on the content tab in the links add page 
                  click ( ".video-tabs > a[href='#content']" ).
                  pause ( 4000 ).
                  //Check and Enter link Title
                  waitForElementVisible ( ".text-input-headline", 4000, false ).
                  setValue ( ".text-input-headline", linkTitle[ getData ] ).
                  pause ( 4000 ).
                  //Wait fpr the links Text Description
                  waitForElementVisible ( ".wmd-input", 4000, false ).
                  //Clear the data in the Text description field
                  clearValue ( ".wmd-input" ).
                  pause ( 4000 ).
                  //Enter the data in the Text description field
                  setValue ( ".wmd-input", linkDescription[ getData ] ).
                  pause ( 4000 )
                  if ( linkUrl[ getData] != undefined ) {
                    //Check and Enter link URL
                    linksAdd.useXpath ( ).waitForElementVisible ( "//div[@class = 'link-well']/input", 4000, false ).
                    pause ( 4000 ).
                    setValue ( "//div[@class = 'link-well']/input", linkUrl[ getData ] ).
                    pause ( 4000 )
                  }
                  //Wait for the Save button is visible
                  linksAdd.useCss( ).waitForElementVisible ( '.btn-active', 4000, false ).
                  pause ( 4000 ). 
                  //Verify the SAve button is visible
                  verify.visible ( ".btn-active" ).
                  pause ( 4000 ).
                  //Click on the Save button
                  click ( ".btn-active" ).
                  pause ( 4000 ).
                  //Check and fill the data in the Properties Tab is visible
                  all_properties ( linkShortTitle[ getData ], linkShortDesc[ getData ], linkCategoryName[ getData ], linkNote[ getData ], linkImg[ getData ] ).
                  pause ( 4000 ).useCss ( ).
                  waitForElementVisible ( ".video-tabs > a[ href='#properties']",4000, false, function ( checkProperties ) {
                    if ( checkProperties.value == true ) {
                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                        linksAdd.writeToExcelFail ( 'boxxspring.xlsx', 'LinksAdd', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                        checkResult.length = 0;
                      }
                      else if ( checkResult.length == 0 ) {
                      }
                      else {
                        checkResult.length = 0;
                        //Check and click save button
                        linksAdd.verify.visible ( "a.btn-active" ).
                        //click on the save button
                        click ( "a.btn-active" ).
                        pause ( 4000 ).
                        //Wait and check the Save button is active in the Attribution page
                        waitForElementNotPresent ( "a.btn-active", 4000, false, function ( checkSaveInactive ) {
                          if ( checkSaveInactive.value.length == 0 ) {
                            linksAdd.pause ( 4000 ).useXpath ( ).
                            //Verify the videos menu in the sidebar
                            verify.containsText ( "//ul/li/a[ text( ) = 'Links']", "Links" ).
                            pause ( 4000 ).
                            //click on the videos menu in CONTENT
                            click ( "//ul/li/a[ text( ) = 'Links']" )
                            //Check the Actual Count after each video added
                            linksAdd.useCss ( ).pause( 4000 ).
                            //Wait for label count in the listing page
                            waitForElementVisible ('.content-count > strong', 4000, false ).
                            pause ( 4000 ).
                            getText ( '.content-count > strong', function ( actualCountResult ) {
                              if ( actualCountResult.status != -1 ) {
                                actualCount = actualCountResult.value;
                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                expectedCount = ( ( + currentCount ) + ( 1 ) );
                                if ( actualCount == expectedCount ) {
                                  //Write in the spreadsheet: Pass Result and Reason
                                  linksAdd.writeToExcelPass ( 'boxxspring.xlsx', 'LinksAdd', rowCount, 10 );
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  linksAdd.writeToExcelFail ( 'boxxspring.xlsx', 'LinksAdd', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Attributions. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                }
                              }
                            } );
                          }
                          else {
                            //Write in the spreadsheet: Fail Result and Reason
                            linksAdd.writeToExcelFail ( 'boxxspring.xlsx', 'LinksAdd', rowCount, 10, 11, "Save functionality is not working as expected" );
                          }
                        } );
                      }
                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                        checkResult.length = 0;
                      }
                    }                   
                  } );
                }
                else {
                  //Write in the Excel details as FAIL Results and Reason
                  linksAdd.writeToExcelFail ( 'boxxspring.xlsx', 'LinksAdd', rowCount, 10, 11, "Add button is not avail/working in the listing page" );   
                }
              } );            
            } );
          }
          else {
            //Write in the Excel details as FAIL Results and Reason
            linksAdd.writeToExcelFail ( 'boxxspring.xlsx', 'LinksAdd', rowCount, 10, 11, "Links Menu is not displayed in the Sidebar" );                    
          }
        } );
			}			
    }
    else {
      //Write in the Excel details as FAIL Results and Reason
      linksAdd.writeToExcelFail ( 'boxxspring.xlsx', 'LinksAdd', rowCount, 10, 11, "There is no Data avail in Excel sheet" );               
    }
    //End the Browsser
    linksAdd.end ( );
  }
};
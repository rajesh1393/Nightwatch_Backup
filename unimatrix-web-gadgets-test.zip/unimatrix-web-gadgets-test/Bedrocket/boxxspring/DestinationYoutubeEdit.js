//this function is for check and Edit the Youtube Destinations 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'DestinationYoutubeEdit' ];
var socialSearch = [ ];
var playlistTitle = [ ];
var destinationTitle = [ ];
var editTitle = [ ];
var currentCount, expectedCount, actualCount, excelData, searchCount;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'destinationYoutubeEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DestinationYoutubeEdit': function ( youtubeDestinationEdit ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        socialSearch.push ( worksheet[ excelData ].v );
      }
      //Read Category Description
      if ( excelData.includes ( 'B' ) ) {
        playlistTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        destinationTitle.push ( worksheet[ excelData ].v );
      }
      //Read Edit Title
      if ( excelData.includes ( 'D' ) ) {
        editTitle.push ( worksheet[ excelData ].v );
      }
    }
    if ( socialSearch.length > 1 ) {
    	for ( let getData = 1, rowCount = 1; getData < destinationTitle.length; getData++ ) {
    		rowCount++;
      	youtubeDestinationEdit.pause ( 4000 ).useXpath ( ).
     		waitForElementPresent( "//div/a[@class='content-header-link content'][text()[normalize-space(.)='Distribution']]", 4000, false, function ( checkDistributionMenu ) {
          if ( checkDistributionMenu.value.length != 0 ) {
            youtubeDestinationEdit.pause ( 4000 ).useXpath ( ).
            waitForElementVisible ( "//i[@ng-if='!collapse.distribution']", 4000, false, function ( checkArrow ) {
              if ( checkArrow.value == true ) {
                youtubeDestinationEdit.pause ( 4000 ).useCss ( ).
                verify.visible ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 ).
                //Click on the Distribution menu in the side bar
                click ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 );
              }
            } );
			      youtubeDestinationEdit.useXpath ( ).pause ( 4000 ).
			      waitForElementVisible ( "//a[text ( ) = 'Destinations']",4000, false, function ( checkDistributionMenu ) {
			      	if ( checkDistributionMenu.value == true ) {
			      		youtubeDestinationEdit.useXpath ( ).pause ( 4000 ).
					      //Verify the Destination menu in DISTRIBUTION is visible
					      verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
					      pause ( 4000 ).
					      //Click on the Destination menu in DISTRIBUTION
					      click ( "//a[ text ( ) = 'Destinations']" ).
					      useCss ( ).pause ( 4000 ).
					      //Get the Current Total count in the Destination listing page
					      getText ( '.content-count > strong', function ( currentCountResult ) {
					        if ( currentCountResult.status != -1 ) {
					          currentCount = currentCountResult.value;
					        }
				          youtubeDestinationEdit.pause ( 4000 ).useXpath ( ).
				          //Wait for the Search Field is visible
				          waitForElementVisible ( "//div[@class='suggestion-dropdown-wrap']/input", 4000, false ).
				          pause ( 4000 ).
				          //Verify the Search Field is visible
				          verify.visible ( "//div[@class='suggestion-dropdown-wrap']/input" ).
				          pause ( 4000 ).
				          //Clear avail data in the Search Field
				          clearValue ( "//div[@class='suggestion-dropdown-wrap']/input" ).
				          pause ( 4000 ).
				          //Enter data in the Search Field input
				          setValue ( "//div[@class='suggestion-dropdown-wrap']/input", destinationTitle[ getData ] ).useCss ( )
				          youtubeDestinationEdit.pause ( 4000 ).         
				          //Wait for Total Count label is visible
				          waitForElementVisible ( ".content-count>strong", 4000, false ).
				          //Verify the Total Count label is visible
				          verify.visible ( ".content-count>strong" )
				          //Check the Searched Video Count
				          youtubeDestinationEdit.getText ( '.content-count > strong', function ( currentCountResult ) {
				            if ( currentCountResult.status != -1 ) {
				              searchCount = currentCountResult.value;
				            }
				            //Check IF Searched Video Count is greater than zero,it will continue in the statement or it will be move else part
				            if ( searchCount > 0 ) {
				              youtubeDestinationEdit.pause ( 4000 ).useXpath ( ).
				              //Wait for the Searched destination to visible
				              waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ destinationTitle[ getData ] +"']]", 4000, false, function ( checkSearchedLst ) {
				              	if ( checkSearchedLst.value == true ) {
						              youtubeDestinationEdit.pause ( 4000 ).useXpath ( ).
						              //Verify the Searched destination is visible
						              verify.visible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ destinationTitle[ getData ] +"']]" ).
						              pause ( 4000 ).
						              //Click on the Searched destination
						              click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ destinationTitle[ getData ] +"']]" ).
						              pause ( 4000 ).
						              //Verify the Contains text in the provider field is visible
						              verify.containsText ( "//div[@class='input-like'][contains ( .,'Youtube' )]", "Youtube" ).
						              pause ( 4000 ).useCss ( ).
						              //Verify the Headline text field is visible
						              verify.visible ( ".text-input-headline" ).
						              pause ( 4000 ).
						              //Clear the data in the Headline text field
						              clearValue ( ".text-input-headline" ).
						              pause ( 4000 ).
						              //Enter the data in the Headline text field
						              setValue ( ".text-input-headline", editTitle[ getData ] ).
						              pause ( 4000 ).useXpath ( ).
						              //Verify the Provider field is visible
						              verify.visible ( "//div[@class='input-like'][contains ( .,'"+ socialSearch[ getData ] +"' )]" ).
						              pause ( 4000 ).
						              //Verify the Contains text in the provider field is visible
						              verify.containsText ( "//div[@class='input-like'][contains ( .,'"+ socialSearch[ getData ] +"' )]", socialSearch[ getData ] ).
						              pause ( 4000 ).
						              //Verify the Contains text in the Channel field is visible
						              verify.visible ( "//div[@class='input-like ng-binding']" ).
						              pause ( 4000 )
						              var playlistTemp = playlistTitle[ getData ];
						              //Split the data from excel input and stored in variable
						              var playlistTemp_array = playlistTemp.split ( ',' );
						              for ( let playlistCount = 0; playlistCount < playlistTemp_array.length; playlistCount++ ) {
						                playlistTemp_array[ playlistCount ] = playlistTemp_array[ playlistCount ].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
						                youtubeDestinationEdit.useXpath ( ).pause ( 4000 ).
						                //Verify the Playlist field is visible
						                verify.containsText ( "//label[ contains ( .,'"+ playlistTemp_array[ playlistCount ] +"' )]", playlistTemp_array[ playlistCount ] ).
						                pause ( 4000 ).
						                //Click on the Playlist field
						                click ( "//label[ contains ( .,'"+ playlistTemp_array[ playlistCount ] +"' )]" ).
						                pause ( 4000 )
						              }
						              youtubeDestinationEdit.useXpath ( ).
						              //Verify the Save button is visible
						              waitForElementVisible ( "//a[@class='btn btn-icon btn-active']", 4000, false ).
						              pause ( 4000 ).
						              //Click on the Save button
						              click ( "//a[@class='btn btn-icon btn-active']" ).
						              pause ( 4000 ).
						              //Verify the Destination menu in DISTRIBUTION is visible
						              verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
						              pause ( 4000 ).
						              //Click on the Destination menu in DISTRIBUTION
						              click ( "//a[ text ( ) = 'Destinations']" ).
						              useCss ( ).pause ( 4000 ).
						              //Wait for the Search Field is visible
						              waitForElementVisible ( ".ng-pristine[placeholder='Search']", 4000, false ).
						              pause ( 4000 ).
						              //Verify the Search Field is visible
						              verify.visible ( ".ng-pristine[placeholder='Search']" ).
						              pause ( 4000 ).
						              //Clear the Search Field input
						              clearValue ( ".ng-pristine[placeholder='Search']" ).
						              pause ( 4000 ).
						              //Enter the Search Field input
						              setValue ( ".ng-pristine[placeholder='Search']", editTitle[ getData ] ).
						              pause ( 4000 ).
						              //Get the Actual Total count  after searched in the Destination listing page
						              getText ( '.content-count > strong', function ( actualCountResult ) {
						                if ( actualCountResult.status != -1 ) {
						                  actualCount = actualCountResult.value;
						                  if ( actualCount > 0 ) {
						                    //Write in the spreadsheet: Pass Result and Reason
						                    youtubeDestinationEdit.writeToExcelPass ( 'boxxspring.xlsx', 'DestinationYoutubeEdit', rowCount, 6 );
						                  }
						                  else {
						                    //Write in the spreadsheet: Fail Result and Reason
						                    youtubeDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeEdit', rowCount, 6, 7, "ActualResult: '"+ actualCount +"' in the Total Count After Youtube Destination Edit. ExpectedResult: should be 1 in the Total Count" );
						                  }
						                }
						              } );	             
						            }
						            else {
						            	//Write the Excel data for Search FAIL Result and Reason
						              youtubeDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeEdit', rowCount, 6, 7, "Searched Data is not listed in the Destination listing page" )
						            }
				          		} );
					          }
					          else {
					            //Write the Excel data for Search FAIL Result and Reason
					            youtubeDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeEdit', rowCount, 6, 7, "0<-->No Results" )
					            
					          }
					        } );	        
							  } );
							}
							else {
								//Write the Excel data for Search FAIL Result and Reason
					  		youtubeDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeEdit', rowCount, 6, 7, "DESTINATION Menu is not displayed in the Sidebar" )
							}
						} );
					}
					else {
						//Write the Excel data for Search FAIL Result and Reason
					  youtubeDestinationEdit.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeEdit', rowCount, 6, 7, "DISTRIBUTION Menu is not displayed in the Sidebar" )
					}
				} );
			}
    }
    //End the Browser
    youtubeDestinationEdit.end ( );
  }
}
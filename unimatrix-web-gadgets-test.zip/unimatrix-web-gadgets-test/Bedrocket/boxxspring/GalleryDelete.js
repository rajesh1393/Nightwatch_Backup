//this function is for delete the existing Gallery
module.exports = {
  tags: [ 'galleryDelete' ],
  before: function ( portalLogin ) {
    //login the portal and check the theme
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name from the function name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'boxxspring.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //clear the input array allocated in the global
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'GalleryDelete': function ( galleryDelete ) {
    //Access the variable globally defined
    var excel = galleryDelete.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
        var excelRow = 1;
        galleryDelete.pause ( 5000 ).
        useXpath ( ).
        //check the visibility of gallery button 
        waitForElementVisible ( "//ul/li/a[text()='Galleries']", 3000, function ( searchGallery ) {
          if ( searchGallery.value == true ) {
            galleryDelete.acceptAlert ( ).
            click ( "//ul/li/a[text()='Galleries']" ).useCss ( ).
            pause ( 5000 ).
            getAttribute ( '.presentation-toggle.clearfix > div.active', "class", function ( getGridView ) {
              //Checking the Active Grid/list type
              if ( getGridView.value == "grid active" ) {
                galleryDelete.click ( ".list" );
              }
            } );
            galleryDelete.useXpath ( ).
            //check the visibility of the search textbox
            waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 5000, false, function ( searchFieldInput ) {
              if ( searchFieldInput.value == true ) {
                galleryDelete.clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", excel.A[ excelColumn ] ).
                keys ( galleryDelete.Keys.ENTER ).
                //get the gallery count before delete the existing gallery
                getText ( "//strong[@class='ng-binding']", function ( getDefaultCount ) {
                  //check the search text box present in the gallery and click the search result
                  galleryDelete.waitForElementPresent ( "//h2[@class='ng-binding'][text()[normalize-space(.)='" + excel.A[ excelColumn ] + "']]", 5000, false, function ( searchResult ) {
                    if ( searchResult.status == 0 ) {
                      galleryDelete.pause ( 9000 ).
                      click ( "//h2[@class='ng-binding'][text()[normalize-space(.)='" + excel.A[ excelColumn ] + "']]" ).
                      waitForElementPresent ( "//div[@class='container-head edit']/div[1]", 10000, false, function ( galleryhead ) {
                        if ( galleryhead.status == 0 ) {
                          //check the visibility of the title after clicking the edit gallery button 
                          galleryDelete.getText ( "//div[@class='container-head edit']/div[1]", function ( galleryPageTitle ) {
                            if ( galleryPageTitle.value == "GALLERY" ) {
                              //check the visibility of the heading after clicking the edit gallery button 
                              galleryDelete.waitForElementVisible ( "//div/text-field/input", 5000, false, function ( galleryHeadline ) {
                                if ( galleryHeadline.value == true ) {
                                  //get the gallery headline value
                                  galleryDelete.getValue ( "//div/text-field/input", function ( getHeadline ) {
                                    if ( getHeadline.value == excel.A[ excelColumn ] ) {
                                      galleryDelete.waitForElementPresent ( '//li/ul/li[@class="gallery-cell"]', 5000, false, function ( removeGallery ) {
                                        if ( removeGallery.status == 0 ) {
                                          var remveGalleryCount = removeGallery.value.length;
                                          //remove the 'n' number of media gallery
                                          for ( let editGalleryCount = 2; editGalleryCount < remveGalleryCount + 2; editGalleryCount++ ) {
                                            galleryDelete.pause ( 5000 ).
                                            click ( '//li["' + editGalleryCount + '"]/ul/li[@class="gallery-cell"]' );
                                          }
                                          galleryDelete.pause ( 5000 ).
                                          click ( '//ul/li[1]/a[@class="btn btn-icon btn-active"]' );
                                        }
                                      } );
                                      galleryDelete.waitForElementNotPresent ( '//li/ul/li[@class="gallery-cell"]', 5000, false, function ( rmveGallery ) {
                                        if ( rmveGallery.status == 0 ) {
                                          galleryDelete.
                                          //check the visibility of the delete button
                                          waitForElementPresent ( '//div/ng-include/ul/li/a[@class="btn btn-icon btn-delete"]', 5000, false, function ( deleteGallery ) {
                                            if ( deleteGallery.status == 0 ) {
                                              galleryDelete.pause ( 9000 ).
                                              click ( '//div/ng-include/ul/li/a[@class="btn btn-icon btn-delete"]' ).
                                              pause ( 5000 ).
                                              click ( "//section/button[contains(.,'Delete' )]" ).
                                              acceptAlert ( ).pause ( 5000 ).
                                              click ( "//ul/li/a[text()='Galleries']" ).
                                              waitForElementVisible ( "//div[@class = 'suggestion-dropdown-wrap']/input", 9000, false ).
                                              pause ( 3000 ).
                                              clearValue ( "//div[@class = 'suggestion-dropdown-wrap']/input" ).
                                              setValue ( "//div[@class = 'suggestion-dropdown-wrap']/input", excel.A[ excelColumn ] ).
                                              keys ( galleryDelete.Keys.ENTER ).
                                              //get the count after deleting the gallery
                                              waitForElementVisible ( "//strong[@class='ng-binding']", 9000, false ).
                                              getText ( "//strong[@class='ng-binding']", function ( getDeleteCount ) {
                                                var getFinalCount = parseInt ( getDeleteCount.value.substring ( 1, ( getDeleteCount.value.length - 1 ) ) ) + 1;
                                                var getDefltCount = getDefaultCount.value.substring ( 1, ( getDefaultCount.value.length - 1 ) );
                                                //compare the before & after delete gallery count
                                                if ( getFinalCount == getDefltCount ) {
                                                  //write to excel as "pass" if the gallery deleted successfully
                                                  galleryDelete.writeToExcelPass ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2 );
                                                }
                                                else {
                                                  //write to excel as "fail" if unable to delete the gallery
                                                  this.verify.fail ( getFinalCount, getDefltCount, 'Fail to delete the existing Gallery' );
                                                  galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + getFinalCount + ". ExpectedResult: '" + getDefltCount + "' ( Unable to delete the existing gallery )" );
                                                }
                                              } );
                                            }
                                            else {
                                              //write to excel as 'fail if the Delete button is not working properly
                                              this.verify.fail ( deleteGallery.value, true, 'Delete button is not working properly' );
                                              galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + deleteGallery.value + ". ExpectedResult: 'true' ( Delete button is not working properly )" );
                                            }
                                          } );
                                        }
                                        else {
                                          //write to excel as 'fail' as unable to delete/remove the existing media gallery
                                          this.verify.fail ( undefined, undefined, 'Fail to delete/remove the existing media gallery' );
                                          galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "Fail to delete/remove the existing media gallery" );
                                        }
                                      } );
                                    }
                                    else {
                                      //write to excel as 'fail' if the Title of the gallery mismatch after clicking Edit button
                                      this.verify.fail ( getHeadline.value, excel.A[ excelColumn ], 'Title of the Gallery mismatch after clicking Edit button' );
                                      galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + getHeadline + ". ExpectedResult: '" + excel.A[ excelColumn ] + "' ( Title of the Gallery mismatch after clicking Edit button )" );
                                    }
                                  } );
                                }
                                else {
                                  this.verify.fail ( galleryHeadline.value, 'true', 'Timeout loading issue while redirect to the edit page of Gallery' );
                                  galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + galleryHeadline.value + ". ExpectedResult: 'true' ( Timeout loading issue while redirect to the edit page of Gallery )" );
                                }
                              } );
                            }
                            else {
                              //write to excel as 'fail' while error in the gallery page title
                              this.verify.fail ( galleryPageTitle.value, "GALLERY", 'Error in the displayed title in the Gallery Page' );
                              galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + galleryPageTitle.value + ". ExpectedResult: 'GALLERY'. ( Error in the displayed title in the Gallery Page )" );
                            }
                          } );
                        }
                        else {
                          //write to excel as 'fail' if the Timeout issue in the visibility of Gallery Title
                          this.verify.fail ( galleryhead.value, true, 'Timeout issue in the visibility of Gallery Title' );
                          galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + galleryhead.value + ". ExpectedResult: 'true' ( Timeout issue in the visibility of Gallery Title )" );
                        }
                      } );
                    }
                    else {
                      //write to excel as 'fail' while Unable to delete due to no result found in search
                      galleryDelete.getText ( "//strong[@class='ng-binding']", function ( emptyResult ) {
                        if ( emptyResult.value == '(0)' ) {
                          this.verify.fail ( undefined, undefined, 'Unable to delete due to no result found while search in Gallery' );
                          galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "Unable to delete due to no result found while search in Gallery" );
                        }
                        else {
                          //write to excel as 'fail' while error in the search functionality
                          this.verify.fail ( emptyResult.value, '(0)', 'Error in the search functionality as it fail to list the relevant data' );
                          galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + emptyResult.value + ". ExpectedResult: '(0)' ( Error in the search functionality as it fail to list the relevant data )" );
                        }
                      } );
                    }
                  } );
                } );
              }
              else {
                //write to excel as 'fail' while error in the Search text box field
                this.verify.fail ( searchFieldInput.value, true, 'Error in the Search text box field' );
                galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + searchFieldInput.value + ". ExpectedResult: 'true' ( Error in the Search text box field )" );
              }
            } );
          }
          else {
            //write to excel as 'fail' due to timeout issue in the visibility of gallery button
            this.verify.fail ( searchGallery.value, true, "Timeout issue in the visibility of 'Gallery' in Content" );
            galleryDelete.writeToExcelFail ( 'boxxspring.xlsx', 'GalleryDelete', ++excelRow, 2, 3, "ActualResult: '" + searchGallery.value + ". ExpectedResult: 'true' ( Timeout issue in the visibility of 'Gallery' in Content )" );
          }
        } );
      }
    }
    else {
      //write to excel 'fail' if error in the excelsheet name
      console.log ( "No input in Excel or Check the Excel Name for the script 'GalleryDelete'" );
    }
  }
};
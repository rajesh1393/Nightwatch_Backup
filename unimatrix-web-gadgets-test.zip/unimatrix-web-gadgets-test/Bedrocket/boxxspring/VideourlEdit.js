//this function is for check and Edit the Videos URL
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'VideourlEdit' ];
var videoTitle = [ ];
var shortTitle = [ ];
var shortDesc = [ ];
var author = [ ];
var attribution = [ ];
var categoryName = [ ];
var categoryType = [ ];
var shortNote = [ ];
var description = [ ];
var dragImg = [ ];
var rowCount, getData = 1;
var actualCount, searchCount, excelData;
var currentCount;
module.exports = {
  tags: [ 'videourlEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'VideourlEdit': function ( videoEdit ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Video Title
      if ( excelData.includes ( 'A' ) ) {
        videoTitle.push ( worksheet[excelData].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'B' ) ) {
        shortTitle.push ( worksheet[excelData].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'C' ) ) {
        shortDesc.push ( worksheet[excelData].v );
      }
      //Read Author Name
      if ( excelData.includes ( 'D' ) ) {
        author.push ( worksheet[excelData].v );
      }
      //Read Attribution Name
      if ( excelData.includes ( 'E' ) ) {
        attribution.push ( worksheet[excelData].v );
      }
      //Read Category Name
      if ( excelData.includes ( 'F' ) ) {
        categoryName.push ( worksheet[excelData].v );
      }
      //Read Short Notes
      if ( excelData.includes ( 'G' ) ) {
        shortNote.push ( worksheet[excelData].v );
      }
      //Read Thumbnail Image
      if ( excelData.includes ( 'H' ) ) {
        dragImg.push ( worksheet[excelData].v );
      }
    }
    if ( videoTitle.length > 1 ) {
      var checkResult = videoEdit.globals.excelCol.resultCustomData; 
      for ( let getData = 1, rowCount = 1; getData < videoTitle.length; getData++ ) {
        rowCount++;
        videoEdit.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text ( ) = 'Videos']", 4000, false, function ( checkVideoMenu ) {
          if ( checkVideoMenu.value == true ) {
            videoEdit.pause ( 4000 ).useXpath ( ).
            //Verify the videos menu in content is visible
            verify.containsText ( "//ul/li/a[ text ( ) = 'Videos']", "Videos" ).
            pause ( 4000 ).
            //Click on videos menu in content
            click ( "//ul/li/a[ text ( ) = 'Videos']" ).
            useCss ( ).pause (4000 ).
            //Get the Current Total Count  in videos listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }
              //Wait for the Saerch input field is visible
              videoEdit.pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
              //Verify the Search input field is visible
              verify.visible ( ".search-field-input" ).
              //Enter the Data in search input field
              setValue ( ".search-field-input", videoTitle[ getData ] )
              videoEdit.keys ( videoEdit.Keys.ENTER ). // hold the control
              //Click on the Search field input
              click ( ".search-field-input" ).
              keys ( videoEdit.Keys.NULL ). // release the control
              pause ( 4000 ).
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              //Get the searched data Total Count  in videos listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, ( searchCount.length - 1 ) );
                }
                //Check IF Searched Video Count is greater than zero,it will continue in the statement or it will be move else part
                if ( searchCount > 0 ) {
                  videoEdit.pause ( 4000 ).
                  //Wait for the List visbile
                  waitForElementVisible ( ".list", 4000, false ).
                  pause ( 4000 ).
                  //Click on the List option in the Video listing page
                  click ( ".list" ).
                  pause ( 4000 ).useXpath ( ).
                  //Wait for the Edit pullout button in the video listing page
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ videoTitle[ getData ] +"']]", 4000, false ).
                  pause ( 4000 ).
                  //Click on the Edit pullout button in the video listing page
                  click ( " ( //h2[@class='ng-binding'] )[text( )[normalize-space(.)='"+ videoTitle[ getData ] +"']]" ).
                  pause ( 12000 ).useCss ( ).
                  //Verify the Content tab is visible
                  verify.visible ( ".video-tabs > a[ href='#content']" ).
                  //Click on the Content Tab in Videos page
                  click ( ".video-tabs > a[ href='#content']" ).
                  pause ( 4000 ).useXpath ( ).
                  waitForElementVisible ( "//div/ng-include/header/div/text-field/input", 4000, false ).
                  pause ( 4000 ).
                  clearValue ( "//div/ng-include/header/div/text-field/input" ).
                  pause ( 4000 ).
                  setValue ( "//div/ng-include/header/div/text-field/input", videoTitle[ getData ] ).
                  //Check and Enter Valid input in the Properties Tab
                  video_properties ( shortTitle[ getData ], shortDesc[ getData ], categoryName[ getData ], shortNote[ getData ], dragImg[ getData ] ).
                  pause ( 4000 ).
                  propertiesEdit ( author[ getData ], attribution[ getData ] ).
                  pause ( 4000 ).useCss ( ).
                  waitForElementVisible ( ".video-tabs > a[ href='#properties']", 4000, false, function ( checkProperties ) {
                    if ( checkProperties.value == true ) {
                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                        videoEdit.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlEdit', rowCount, 10, 11, "Properties artifact is failed" );
                        checkResult.length = 0;
                      }
                      else if ( checkResult.length == 0 ) {
                      }
                      else {
                        checkResult.length = 0;
                        //Check and click save button
                        videoEdit.verify.visible ( "a.btn-active" ).
                        //click on the save button
                        click ( "a.btn-active" ).
                        pause ( 4000 ).useXpath ( ).
                        //Verify the videos menu in the sidebar
                        verify.containsText ( "//ul/li/a[ text ( ) = 'Videos']", "Videos" ).
                        pause ( 4000 ).
                        //click on the videos menu in CONTENT
                        click ( "//ul/li/a[ text ( ) = 'Videos']" ).
                        useCss ( ).
                        pause ( 4000 ).
                        //Get Actual count in the total Videos count after edited
                        getText ( '.content-count > strong', function ( actualCountResult ) {
                          if ( actualCountResult.status != -1 ) {
                            actualCount = actualCountResult.value;
                            actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
                            if ( actualCount == currentCount ) {
                              //Write in the spreadsheet: PASS Result and Reason
                              videoEdit.writeToExcelPass ( 'boxxspring.xlsx', 'VideourlEdit', rowCount, 10 );
                            }
                            else {
                              //Write in the spreadsheet: FAIL Result and Reason
                              videoEdit.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlEdit', rowCount, 10, 11, "ActualResult:'"+ actualCount +"' in the Total Count After Videos URL Edit. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                            }
                          }
                        } );
                      }
                    }
                    else {
                    	//Write in the spreadsheet: FAIL Result and Reason
                      videoEdit.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlEdit', rowCount, 10, 11, "Properties tab is not displayed" );
                    }
                  } );
                }
                else {
                  //Write in the spreadsheet: FAIL Result and Reason
                  videoEdit.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlEdit', rowCount, 10, 11, "Searched Result Count,'"+ searchCount +"'" );
                }
              } );
            } );
          }
          else {
            //Write in the spreadsheet: FAIL Result and Reason
            videoEdit.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlEdit', rowCount, 10, 11, "Videos menu is not displayed in sidebar" );
          }
        } );
      }
    }
    //End the Browser
    videoEdit.end ( );
  }
}
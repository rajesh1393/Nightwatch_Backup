//this function is for Check and Edit the Contentlist
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'boxxspring.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'ContentEdit' ];
var contentTitle = [ ];
var categoryType = [ ];
var contentType = [ ];
var providerTitle = [ ];
var alignment = [ ];
var contentTypeResult = [ ];
var providerTypeResult = [ ];
module.exports = {
  tags: ['contentEdit'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'Content Edit': function ( editContent ) {
    //Read values from excel
    for ( z in worksheet ) {
      if ( z[ 1 ] === '!' ) continue;
      //Read Content Title
      if ( z.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[ z ].v );
      }
      //Read Category Type
      if ( z.includes ( 'B' ) ) {
        categoryType.push ( worksheet[ z ].v);
      }
      //Read Content Type Title
      if ( z.includes ( 'C' ) ) {
        contentType.push ( worksheet[ z ].v);
      }
      //Read Provider Title
      if ( z.includes ( 'D' ) ) {
        providerTitle.push ( worksheet[ z ].v);
      }
      //Read alignment
      if ( z.includes ( 'E' ) ) {
        alignment.push ( worksheet[ z ].v);
      }
    }
    if ( contentTitle.length > 1 ) {
      //loop the 'n' number of excel input
      for ( let excelColumn = 1; excelColumn != contentTitle.length; excelColumn++ ) {
        var excelRow = 1;
        editContent.useXpath ( ).
        //Wait and click the ALL option in CONTENT
        waitForElementVisible ( "//div[2]/ul/li/a[contains(.,'All')]", 3000, false, function ( contentAll ) {
          if(contentAll.value == true ) {
            //Click on the ALL option in CONTENT
            editContent.click ( "//div[2]/ul/li/a[contains(.,'All')]" ).
            pause ( 3000 ).
            waitForElementVisible ( "//h2[text()[normalize-space(.)='" + contentTitle[ excelColumn ] + "']]", 3000, false, function ( searchTitle ) {
              if ( searchTitle.value == true) {
                editContent.click ( "//h2[text()[normalize-space(.)='" + contentTitle[ excelColumn  ] + "']]" ).
                pause ( 10000 );
                //Verify the content type title checkbox selected 
                contentTypeTitle = contentType[ excelColumn ].split("," );
                console.log ( "contentType", contentTypeTitle );
                providerType = providerTitle[ excelColumn ].split ( "," );
                console.log ( "providerType", providerType );
                for ( let selectType = 0; selectType < contentTypeTitle.length; selectType++ ) {
                  editContent.getAttribute ( "//div[label[text()='Select Content Type']]//*/div/input[@id='" + contentTypeTitle[ selectType ] + "']", "checked", function ( isChecked ) {
                    contentTypeResult.push ( isChecked.value );                  
                    //Verify the provider type title checkbox selected
                    if ( selectType == contentTypeTitle.length - 1 ) {
                      console.log ( "contentTypeResult", contentTypeResult );
                      if ( contentTypeResult.indexOf ( null ) == -1 ) {
                        for ( let chooseProvider = 0; chooseProvider < providerType.length; chooseProvider++ ) {
                          editContent.pause ( 3000 ).
                          //get the selected checkbox in the provider type
                          getAttribute ( "//div[label[text()='Choose Providers']]//*/div/input[@id='" + providerType[ chooseProvider ] + "']", "checked", function ( providerIsChecked ) {
                            providerTypeResult.push ( providerIsChecked.value );
                            if ( chooseProvider == providerType.length - 1 ) {
                              console.log ( "providerTypeResult", providerTypeResult );
                              if ( providerTypeResult.indexOf ( null ) == -1 ) {
                                editContent.useCss ( ).
                                //Verify the alignment selected as per the input
                                getText ( ".presentation > div.active > div", function ( defaultAlignment ) {
                                  if ( defaultAlignment.value == alignment[ excelColumn ] ) {
                                    //write to excel as "Pass" such that edit data equal to the input provided
                                    editContent.writeToExcelPass ( 'boxxspring.xlsx', 'ContentEdit', ++excelRow, 7 );
                                  }
                                  else {
                                    //write to fail status as the issue in the alignment
                                    this.verify.fail ( defaultAlignment.value, alignment[excelColumn], "ActualResult: '" + defaultAlignment.value +
                                      "'. ExpectedResult: '" + alignment[ excelColumn ] + "'  ( Default alignment is not selected as '" +
                                      alignment[ excelColumn ] + "' as per the input  )" );
                                    editContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentEdit', ++excelRow, 7, 8, "ActualResult: '" +
                                      defaultAlignment.value + "'. ExpectedResult: '" + alignment[ excelColumn ] +
                                      "'  ( Default alignment is not selected as '" + alignment[ excelColumn ] + "'' as per the input  )" );
                                  }
                                } );
                              }
                              else {
                                //write to fail status as the issue in the provider type
                                this.verify.fail ( undefined, undefined, "Checkbox not selected while adding in Provider type" );
                                editContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentEdit', ++excelRow, 7, 8,
                                  "while adding Provider type Checkbox not selected as per the input data" );
                              }
                            }
                          } );
                          providerTypeResult.length = 0;
                        }
                      }
                      else {
                        //write to fail status as the issue in the contenttype type
                        this.verify.fail ( undefined, undefined, "Checkbox not selected while adding in ContentType" );
                        editContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentEdit', ++excelRow, 7, 8,
                          "while adding content type Checkbox not selected as per the input data" );
                      }
                    }
                  } );
                  contentTypeResult.length = 0;
                }
              }
              else {
                //write to fail status as no results found while search the content title
                this.verify.fail ( searchTitle.value, true, 'No result found while search in Content' );
                editContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentEdit', ++excelRow, 7, 8, "ActualResult: '" + searchTitle.value +
                  ". ExpectedResult: 'true' ( No result found while search in Content" );
              }
            } );
          }
          else {
            //write to fail status as timeout issue while clicking All option
            this.verify.fail ( contentAll.value, true, 'Timeout loading issue while clicking "All" option in Content' );
            editContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentEdit', ++excelRow, 7, 8, "ActualResult: '" + contentAll.value +
              ". ExpectedResult: 'true' ( Timeout loading issue while clicking 'All' option in Content" );
          }
        } );
      }
    }
    //End the Browser
    editContent.end ( );
  }
}
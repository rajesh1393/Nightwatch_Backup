//this function is for check and add the Authors
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'AuthorsAdd' ];
var authorTitle = [ ];
var authorDescription = [ ];
var authorShortTitle = [ ];
var authorShortDesc = [ ];
var authorCategoryName = [ ];
var authorNote = [ ];
var authorImg = [ ];
var currentCount, actualCount, expectedCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'authorsAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AuthorsAdd': function ( authorsAdd ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read authors Title
      if ( excelData.includes ( 'A' ) ) {
        authorTitle.push ( worksheet[ excelData ].v );
      }
      //Read authors Description
      if ( excelData.includes ( 'B' ) ) {
        authorDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        authorShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        authorShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read authors category Name
      if ( excelData.includes ( 'E' ) ) {
        authorCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read authors Note
      if ( excelData.includes ( 'F' ) ) {
        authorNote.push ( worksheet[ excelData ].v );
      }
      //Read authors Image
      if ( excelData.includes ( 'G' ) ) {
        authorImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( authorTitle.length > 1 ) {
      var checkResult = authorsAdd.globals.excelCol.resultCustomData; 
      for ( let getData = 1,rowCount = 1; getData < authorTitle.length; getData++ ) {
        rowCount++;
        authorsAdd.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Authors' ]",4000,false,function ( checkAuthorMenu ) {
          if ( checkAuthorMenu.value == true ) {
            authorsAdd.pause ( 4000 ).useXpath ( ).
            //Verify the Authors Menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Authors' ]", "Authors" ).
            pause ( 4000 ).
            //Click on the Authors Menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Authors' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get the Total Authors count in the Authors listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length  - 1 ) );
              }
              authorsAdd.useCss ( ).pause ( 4000 ).
              waitForElementVisible ( ".btn-add", 4000, false,function ( checkAuthorAdd ) {
                if ( checkAuthorAdd.value == true ) {
                  authorsAdd.pause ( 4000 ).
                  //Click on the Add button to create an author
                  click ( ".btn-add" ).
                  pause ( 4000 ).
                  //Verify the Content Tab in the Author page
                  verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                  //Click on the Content Tab
                  click ( ".video-tabs > a[ href='#content' ]" ).
                  pause ( 4000 ).
                  //Check and Enter authors Title
                  waitForElementVisible ( ".text-input-headline", 4000, false ).
                  //Enter the Author Title in the Headline
                  setValue ( ".text-input-headline", authorTitle[ getData ] ).
                  pause ( 4000 ).
                  //Check and Enter authors Text Description
                  waitForElementVisible ( ".wmd-input", 4000, false ).
                  clearValue ( ".wmd-input" ).
                  setValue ( ".wmd-input", authorDescription[ getData ] ).
                  pause ( 4000 ).
                  //Check and click Save button
                  waitForElementVisible ( '.btn-active', 4000, false ).
                  verify.visible ( ".btn-active" ).
                  pause ( 4000 ).
                  //Click on the Save button
                  click ( ".btn-active" ).
                  pause ( 6000 ).
                  //Check and Enter the valid input in the Properties Tab
                  all_properties ( authorShortTitle[ getData ], authorShortDesc[ getData ], authorCategoryName[ getData ], authorNote[ getData ], authorImg[ getData ] ).
                  pause ( 4000 ).useCss ( ).
                  waitForElementVisible ( ".video-tabs > a[ href='#properties']",4000,false,function ( checkProperties ) {
                    if ( checkProperties.value == true ) {
                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                        authorsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsAdd', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                        checkResult.length = 0;
                      }
                      else if ( checkResult.length == 0 ) {
                      }
                      else {
                        checkResult.length = 0;
                        //Check and click save button
                        authorsAdd.verify.visible ( "a.btn-active" ).
                        //click on the save button
                        click ( "a.btn-active" ).
                        pause ( 7000 ).
                        waitForElementNotPresent ( "a.btn-active",4000,false,function ( checkSaveInactive ) {
                          if ( checkSaveInactive.value.length == 0 ) {
                            authorsAdd.pause ( 4000 ).useXpath ( ).
                            //Verify the videos menu in the sidebar
                            verify.containsText ( "//ul/li/a[ text( ) = 'Authors']", "Authors" ).
                            pause ( 4000 ).
                            //click on the videos menu in CONTENT
                            click ( "//ul/li/a[ text( ) = 'Authors']" )
                            //Check the Actual Count after each video added
                            authorsAdd.useCss().pause( 4000 ).
                            waitForElementVisible ('.content-count > strong',4000,false ).
                            pause ( 7000 ).
                            getText ( '.content-count > strong', function ( actualCountResult ) {
                              if ( actualCountResult.status !== -1 ) {
                                actualCount = actualCountResult.value;
                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                expectedCount = ( ( + currentCount ) + ( 1 ) );
                                if ( actualCount == expectedCount ) {
                                  //Write in the spreadsheet: Pass Result and Reason
                                  authorsAdd.writeToExcelPass ( 'boxxspring.xlsx', 'AuthorsAdd', rowCount, 9 );
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  authorsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsAdd', rowCount, 9,10, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Authors. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                }
                              }
                            } );
                          }
                          else {
                            //Write in the spreadsheet: Fail Result and Reason
                            authorsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsAdd', rowCount, 9, 10, "Save functionality is not working as expected" );
                          }
                        } );
                      }
                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                        checkResult.length = 0;
                      }
                    }                    
                  } );
                }
              } );
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            authorsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsAdd', rowCount, 9, 10, "Authors menu is not displayed in Sidebar" );
                
          }
        } );
      }
    }
    //End the browser
    authorsAdd.end( );
  }
};
//This function is using for Authors Distribution in the portal
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'DistributionAuthors' ];
var categoryTitle = [ ];
var categoryHeadline = [ ];
var distribSearch = [ ];
var resultStatus = [ ];
var currentCount;
var actualCount;
var expectedCount;
var getData, convertData,rowCount = 1;
module.exports = {
  tags: [ 'distributionAuthors' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'Distribution Authors': function ( AuthorsDistribution ) {
    for ( z in worksheet ) {
      if ( z[ 1 ] === '!' ) continue;
      //Read Authors Title
      if ( z.includes ( 'A' ) ) {
        categoryTitle.push ( worksheet[ z ].v );
      }
      //Read Authors Description
      if ( z.includes ( 'B' ) ) {
        categoryHeadline.push ( worksheet[ z ].v );
      }
      //Read Destination Search Type
      if ( z.includes ( 'C' ) ) {
        distribSearch.push ( worksheet[ z ].v );
      }
    }
    if ( categoryTitle.length > 1 ) {
      AuthorsDistribution.pause ( 4000 ).useXpath ( ).
      //Verify the Authors menu in the CONTENT is visible
      verify.containsText ( "//ul/li/a[ text ( ) = 'Authors']", "Authors" ).
      pause ( 3000 ).
      //Click on the Authors menu in the CONTENT
      click ( "//ul/li/a[ text ( ) = 'Authors']" ).
      useCss ( ).pause ( 4000 ).
      //Get the Current Total count in the Authors listing page
      getText ( '.content-count > strong', function ( currentCountResult ) {
        if ( currentCountResult.status !== -1 ) {
          currentCount = currentCountResult.value;
          currentCount = currentCount.substring ( 1, currentCount.length - 1 );
        }
        for ( var getData = 1, rowCount = 1; getData < categoryTitle.length; getData++ ) {
          var resultStatus = [ ];
          AuthorsDistribution.pause ( 4000 ).
          //Wait for the List view option is visible in the Authors listing page
          waitForElementVisible ( ".list", 4000, false ).
          pause ( 4000 ).
          //Click on the List view option in the Authors listing page
          click ( ".list" ).
          //Wait for the Search Input Field is visible
          pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
          //Verfiy the Search Input Field is visible
          verify.visible ( ".search-field-input" ).
          //Clear the data in Search Input field 
          clearValue ( ".search-field-input" ).
          //Enter the data in Search Input field 
          setValue ( ".search-field-input", categoryTitle[ getData ] ).
          //Press Enter key
          keys ( AuthorsDistribution.Keys.ENTER ).
          click ( ".search-field-input" ).
          //Release Enter Key
          keys ( AuthorsDistribution.Keys.NULL ).
          pause ( 4000 ).
          //Wait for the Search Count label is visible
          waitForElementVisible ( ".content-count>strong", 5000,false ).
          //Verfiy the Search Count label is visible
          verify.visible ( ".content-count>strong" ).
          //Get the Searched data count in the Authors listing page
          getText ( '.content-count > strong', function ( searchCountResult ) {
            if ( searchCountResult.status !== -1 ) {
              searchCount = searchCountResult.value;
              searchCount = searchCount.substring ( 1, searchCount.length - 1 );
            }
            if ( getData >= categoryTitle.length ) {
              var convertData = getData - ( categoryTitle.length - 1 );
              getData++;
            }
            AuthorsDistribution.pause ( 4000 ).useXpath ( ).
            //Wait for the Searched data is visible in the Authors listing page
            waitForElementVisible ( " ( //h2[@class='ng-binding'])[1]", 4000, false ).
            pause ( 4000 ).
            //Verify the Searched data is visible in the Authors listing page
            verify.visible ( " ( //h2[@class='ng-binding'])[1]" ).
            pause ( 4000 ).
            //Click on the Searched data in the Authors listing page
            click ( " ( //h2[@class='ng-binding'])[1]" ).
            useCss ( ).pause ( 4000 )
            AuthorsDistribution.pause ( 4000 ).
            //Verify the Content Tab is visible in the Authors page
            verify.visible ( ".video-tabs > a[ href='#content']" ).
            //Click on the Content Tab in the Authors page
            click ( ".video-tabs > a[ href='#content']" ).
            pause ( 4000 ).
            //Wait for the Headline field is visible in the Authors page
            waitForElementVisible ( ".text-input-headline", 4000, false ).
            //Clear the data in the Headline field in the Authors page
            clearValue ( ".text-input-headline" ).
            //Enter the data in the Headline field in the Authors page
            setValue ( ".text-input-headline", categoryHeadline[ convertData ] ).
            pause ( 4000 ).
            //Verify the Save button is visible
            verify.visible ( ".btn-active" ).
            pause ( 4000 ).
            //Click on the Save button
            click ( ".btn-active" ).
            pause ( 4000 ).
            //Verify the Properties Tab is visible in the Authors page
            verify.visible ( ".video-tabs a[ href='#distribution']" ).
            pause ( 4000 ).
            //Click on the Properties Tab in the Authors Page
            click ( ".video-tabs a[ href='#distribution']" ).
            pause ( 4000 ).
            //Wait for the Add Distribution button is visible in Distribution Tab page
            waitForElementVisible ( ".distro-button", 4000, false ).
            pause ( 4000 ).
            //Click on the Add Distribution button in Distribution Tab page
            click ( ".distro-button" ).
            pause ( 4000 ).
            //Wait for the Toggle filter dropdown is visible
            waitForElementVisible ( "a.ng-binding[ng-click='toggleFilterDropdown();']", 4000, false ).
            pause ( 4000 ).
            //Verify the Toggle filter dropdown is visible
            verify.visible ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
            pause ( 4000 ).
            //Click on the Toggle filter dropdown option
            click ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
            pause ( 4000 ).useXpath ( ).
            //Wait for the options in the list should be visible
            waitForElementVisible ( "//ul/li/a[contains (.,'boxxspring')]", 4000, false ).
            pause ( 4000 ).
            //Verify the options in the listing is visible
            verify.visible ( "//ul/li/a[contains (.,'boxxspring')]" ).
            pause ( 4000 ).
            //Click on the options in the dropdown list
            click ( "//ul/li/a[contains (.,'boxxspring')]" )
            var categoryTemp = distribSearch[ convertData ];
            var categoryTemp_array = categoryTemp.split ( ',' );
            for ( var categoryCount = 0; categoryCount < categoryTemp_array.length; categoryCount++ ) {
              //Split the Category data and store in the Temp variable
              categoryTemp_array[ categoryCount ] = categoryTemp_array[ categoryCount ].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
              AuthorsDistribution.useCss ( ).pause ( 7000 ).
              //Wait for the Saerch -Input Field is visible
              waitForElementVisible ( ".full-width-search-field-input", 4000, false ).
              pause ( 4000 ).
              //Verify the Saerch -Input Field is visible
              verify.visible ( ".full-width-search-field-input" ).
              pause ( 4000 ).
              //Clear the data in the Saerch -Input Field
              clearValue ( ".full-width-search-field-input" ).
              pause ( 4000 ).
              //Enter the data in the Saerch -Input Field
              setValue ( ".full-width-search-field-input", categoryTemp_array[ categoryCount ] ).
              pause ( 4000 ).useXpath ( ).
              //Wait for the searched data in listing down is visible
              waitForElementVisible ( "//label[@class='label-left ng-binding'][contains (.,'"+ categoryTemp_array[ categoryCount ] +"')]", 4000, false ).
              pause ( 4000 ).
              //Click on the Searched data in the distribution page
              click ( "//label[@class='label-left ng-binding'][ contains (.,'"+ categoryTemp_array[ categoryCount ] +"')]" ).
              useCss ( ).pause ( 5000 )
            }
            AuthorsDistribution.pause ( 5000 ).
            //Wait for the Next button is visible
            waitForElementVisible ( ".btn-next", 4000, false ).
            //Click on the Next Button in the Distribution button
            click ( ".btn-next" ).
            //Get the Text for Selected Destination count in the Distribution page
            getText ( "h3.distributions-title.ng-binding", function ( test ) {
              var rest = test.value;
              var rest1 = "Selected Destinations "+ categoryTemp_array.length;
              //Compare the Actual and Expected data in the Distribution page
              if ( rest === rest1 ) {
                AuthorsDistribution.pause ( 4000 ).useCss ( ).
                //Verify the Cancel button in the Distribution page
                verify.visible ( ".cancel-distribution" ).
                pause ( 4000 ).
                //Verify the All Post button is visible in the Distribution page
                verify.visible ( "a.btn-next:nth-child( 2 )" ).
                pause ( 4000 ).
                //Click on the All Post button in the Distribution page
                click ( "a.btn-next:nth-child( 2 )" ).
                pause ( 4000 )
                for ( var getData = 3; getData < categoryTemp_array.length + 3; getData++ ) {
                  //Get the Value for Destination posted in the Distribution page
                  AuthorsDistribution.pause ( 4000 ).getValue ( "ul.post-list li>.ng-scope", function ( allPost ) {
                    if ( allPost.status === 0 ) {
                      if ( getData >= categoryTemp_array.length + 3 ) {
                        convertData = getData - ( categoryTemp_array.length );
                        getData++;
                        AuthorsDistribution.pause ( 4000 ).useCss ( ).
                        //Wait for the Distributed post is visible in the distribution page
                        waitForElementVisible ( "li.completed:nth-child("+ convertData +")>span>ng-include>div.description>a", 4000, false, function ( result1 ) {
                          if ( result1.value === true ) {
                            AuthorsDistribution.pause ( 4000 ).
                            //Get the Distributed post url in the distribution page
                            getText ( "li.completed:nth-child("+ convertData +")>span>ng-include>div.description>a", function ( urlResult ) {
                              if ( urlResult.status == 0 ) {                                
                                AuthorsDistribution.pause ( 4000 );
                                //Push result in the resultstatus array as PASS Results
                                resultStatus.push ( "PASS" );
                              }
                              else {                                
                                AuthorsDistribution.pause ( 4000 );
                                //Push result in the resultstatus array as FAIL Results
                                resultStatus.push ( "FAIL" );                            
                              }
                            } );
                          }
                          else {
                            //Write in the Excel as FAIL Results and Reason
                            AuthorsDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionAuthors', ++rowCount, 5, 6, "Completed Post is not displayed" );
                          }
                        } );
                      }
                    }
                    else {
                      //Write in the Excel as FAIL Results and Reason
                      AuthorsDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionAuthors', ++rowCount, 5, 6, "Post List is not visible" );
                    }
                  } );
                }
                AuthorsDistribution.pause ( 4000 ).getValue ( "ul.post-list li>.ng-scope", function ( allPostResult ) {
                  if ( resultStatus.indexOf ( 'FAIL' ) >= 0 ) {
                    //Write in the Excel as FAIL Results and Reason
                    AuthorsDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionAuthors', ++rowCount, 5, 6, "Completed Post URL is not displayed" );
                  }
                  else if ( resultStatus.length == 0 ) {
                  }
                  else {
                    //Write in the Excel as PASS Results
                    AuthorsDistribution.writeToExcelPass ( 'boxxspring.xlsx', 'DistributionAuthors', ++rowCount, 5 );
                  }
                  if ( resultStatus.indexOf ( 'FAIL' ) || resultStatus.indexOf ( 'PASS' ) >= 0 ) {
                    resultStatus.length = 0;
                  }
                } );
              }
            } );
            AuthorsDistribution.pause ( 4000 ).useXpath ( ).
            //Verify the Authors menu in the CONTENT is visible
            verify.containsText ( "//ul/li/a[ text ( ) = 'Authors']", "Authors" ).
            pause ( 4000 ).
            //Click on the Authors menu in the CONTENT
            click ( "//ul/li/a[ text ( ) = 'Authors']" ).
            useCss ( )
          } );
        }
      } );
    }
    //End the Browser
    AuthorsDistribution.end ( );
  }
};
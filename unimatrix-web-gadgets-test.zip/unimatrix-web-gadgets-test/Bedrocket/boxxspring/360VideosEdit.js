'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
var workbook1 = new Excel.Workbook ( );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ '360VideosEdit' ];
var videoTitle = [ ];
var shortTitle = [ ];
var shortDesc = [ ];
var author = [ ];
var attribution = [ ];
var categoryName = [ ];
var categoryType = [ ];
var shortNote = [ ];
var description = [ ];
var dragImg = [ ];
var rowCount, getData = 1;
var currentCount, searchCount, actualCount, excelData;
module.exports = {
  tags: [ '360VideosEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  '360VideosEdit': function ( video360Edit ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Video Title
      if ( excelData.includes ( 'A' ) ) {
        videoTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'B' ) ) {
        shortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'C' ) ) {
        shortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Author Name
      if ( excelData.includes ( 'D' ) ) {
        author.push ( worksheet[ excelData ].v );
      }
      //Read Attribution Name
      if ( excelData.includes ( 'E' ) ) {
        attribution.push ( worksheet[ excelData ].v );
      }
      //Read Category Name
      if ( excelData.includes ( 'F' ) ) {
        categoryName.push ( worksheet[ excelData ].v );
      }
      //Read Short Notes
      if ( excelData.includes ( 'G' ) ) {
        shortNote.push ( worksheet[ excelData ].v );
      }
      //Read Thumbnail Image
      if ( excelData.includes ( 'H' ) ) {
        dragImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( videoTitle.length > 1 ) {
      var checkResult = video360Edit.globals.excelCol.resultCustomData; 
      for ( let getData = 1, rowCount = 1; getData < videoTitle.length; getData++ ) {
        rowCount++;
        video360Edit.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text( ) = '360videos' ]",9000,false,function ( check360VideoMenu ) {
          if ( check360VideoMenu.value == true ) {
            //Search for videos content menu
            video360Edit.pause ( 4000 ).useXpath ( ).
            //Verify the 360videos menu is visible in the CONTENT
            verify.containsText ( "//ul/li/a[ text ( ) = '360videos']", "360videos" ).
            pause ( 4000 ).
            //Click on the 360videos menu in the CONTENT
            click ( "//ul/li/a[ text ( ) = '360videos']" ).
            useCss ( ).pause ( 4000 ).
            //Check the Total Video Count before edited
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }              
              //Check the Search field is visible in the 360videos listing page
              video360Edit.pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
              verify.visible ( ".search-field-input" ).
              setValue ( ".search-field-input", videoTitle[ getData ] ).
              // hold the control
              keys ( video360Edit.Keys.ENTER ). 
              click ( ".search-field-input" ).
              // release the control
              keys ( video360Edit.Keys.NULL ). 
              pause ( 4000 ).
              //Check the Total count label is visible in the 360videos listing page
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              pause ( 4000 ).
              //Verify the Total count label is visible in the 360videos listing page
              verify.visible ( ".content-count>strong" )
              //Check the Searched Video Count
              video360Edit.getText ( '.content-count > strong', function ( currentCountResult ) {                
                if ( currentCountResult.status !== -1 ) {
                  var searchCount = currentCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                }
                //Check IF Searched Video Count is greater than zero,it will continue in the statement or it will be move else part
                if ( searchCount > 0 ) {
                  video360Edit.pause ( 4000 ).
                  //Check the list view option is visible in the 360videos listing page
                  waitForElementVisible ( ".list", 4000, false ).
                  pause ( 4000 ).
                  click ( ".list" ).
                  useXpath ( ).
                  //Wait for the Searched data is visible in the Videos listing page
                  waitForElementVisible ( "(//h2[@class='ng-binding'] )[text( )[normalize-space(.)='"+ videoTitle[ getData ] +"']]", 4000, false ).
                  pause ( 4000 ).
                  //Verify the Searched data is visible in the Videos listing page
                  verify.visible ( "( //h2[@class='ng-binding'] )[text( )[normalize-space(.)='"+ videoTitle[ getData ] +"']]" ).
                  pause ( 4000 ).
                  //Click on the Searched data in the Videos listing page
                  click ( "(//h2[@class='ng-binding'] )[text( )[normalize-space(.)='"+ videoTitle[ getData ] +"']]" ).
                  useCss ( ).pause ( 4000 ).
                  //Verify the Content tab is visible
                  verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                  //Click on the Content Tab
                  click ( ".video-tabs > a[ href='#content' ]" ).
                  pause ( 5000 ).useCss().
                  waitForElementVisible ( '.container-head > text-field > input', 4000, false ).
                  pause ( 5000 ).
                  //Verify the Video title field is visbile
                  verify.visible ( ".container-head > text-field > input" ).
                  pause ( 4000 ).
                  //Clear the Video title data in field
                  clearValue ( '.container-head > text-field > input' ).
                  pause ( 4000 ).
                  //Enter the Video title data in field
                  setValue ( '.container-head > text-field > input', videoTitle[ getData ] ).
                  pause ( 5000 ).
                  video_properties ( shortTitle[ getData ], shortDesc[ getData ], categoryName[ getData ], shortNote[ getData ], dragImg[ getData ] ).
                  pause ( 4000 ).useCss ( ).
                  waitForElementVisible ( ".video-tabs > a[ href='#properties']",9000,false,function ( checkProperties ) {
                    if ( checkProperties.value == true ) {
                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                        video360Edit.writeToExcelFail ( 'boxxspring.xlsx', '360VideosEdit', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                        checkResult.length = 0;
                      }
                      else if ( checkResult.length == 0 ) {
                      }
                      else {
                        checkResult.length = 0;
                        //Check and click save button
                        video360Edit.verify.visible ( "a.btn-active" ).
                        //click on the save button
                        click ( "a.btn-active" ).
                        pause ( 4000 ).useXpath ( ).
                        //Verify the videos menu in the sidebar
                        verify.containsText ( "//ul/li/a[ text( ) = '360videos']", "360videos" ).
                        pause ( 4000 ).
                        //click on the videos menu in CONTENT
                        click ( "//ul/li/a[ text( ) = '360videos']" ).
                        useCss ( ).pause ( 4000 ) 
                        //Check the Actual Count after each video added
                        video360Edit.useCss().pause( 4000 ).
                        getText ( '.content-count > strong', function ( actualCountResult ) {
                          if ( actualCountResult.status !== -1 ) {
                            actualCount = actualCountResult.value;
                            actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                            if ( actualCount == currentCount ) {
                              //Write in the spreadsheet: Pass Result and Reason
                              video360Edit.writeToExcelPass ( 'boxxspring.xlsx', '360VideosEdit', rowCount, 10 );
                            }
                            else {
                              //Write in the spreadsheet: Fail Result and Reason
                              video360Edit.writeToExcelFail ( 'boxxspring.xlsx', '360VideosEdit', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Videos(URL). ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                            }
                          }
                        } );
                      }
                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                        checkResult.length = 0;
                      }
                    }
                    else {
                    }
                  } );                     
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
                  video360Edit.writeToExcelFail ( 'boxxspring.xlsx', '360VideosEdit', rowCount, 10, 11, "Searched Result Count,'"+ searchCount +"'" );
                }
              } );              
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            video360Edit.writeToExcelFail ( 'boxxspring.xlsx', '360VideosEdit', rowCount, 10, 11, "360Videos Menu is not displayed in sidebar" ); 
          }
        } );
      }
    }
    else {
    }
    //End the Browser      
    video360Edit.end ( );
  }
}
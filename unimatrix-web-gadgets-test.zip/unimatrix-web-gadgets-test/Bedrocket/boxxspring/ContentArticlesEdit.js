//This Function is check and Distribute the Articles from Boxxspring Destination
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'ContentArticlesEdit' ];
var articlesTitle = [ ];
var categoryTitle = [ ];
var articleShortTitle = [ ];
var articleShortDesc = [ ];
var articleCategoryName = [ ];
var articleNote = [ ];
var authors = [ ];
var thumbnail = [ ];
var currentCount, actualCount, excelData;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'contentArticlesEdit' ],
  // Login the Portal Boxxspring
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'ContentArticlesEdit': function ( contentArticles ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Articles Title
      if ( excelData.includes ( 'A' ) ) {
        articlesTitle.push ( worksheet[ excelData ].v );
      }
      //Read Articles Edit Title
      if ( excelData.includes ( 'B' ) ) {
        categoryTitle.push ( worksheet[ excelData ].v );
      }
      //Read Articles Short Title
      if ( excelData.includes ( 'C' ) ) {
        articleShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Articles Short Description
      if ( excelData.includes ( 'D' ) ) {
        articleShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Articles Categories Name
      if ( excelData.includes ( 'E' ) ) {
        articleCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read Articles Note
      if ( excelData.includes ( 'F' ) ) {
        articleNote.push ( worksheet[ excelData ].v );
      }
      //Read Articles Thumbnail
      if ( excelData.includes ( 'G' ) ) {
        thumbnail.push ( worksheet[ excelData ].v );
      }
      //Read Authors
      if ( excelData.includes ( 'H' ) ) {
        authors.push ( worksheet[ excelData ].v );
      }
    }
    if ( articlesTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < articlesTitle.length; getData++ ) {
        rowCount++;
        contentArticles.pause ( 4000 ).timeoutsImplicitWait ( 4000 ).useXpath ( ).
        //Check and wait for Articles menu is visible in the CONTENT
        waitForElementVisible ( "//ul/li/a[ text() = 'Articles']", 4000, false, function ( articlesMenuCheck ) {
          console.log ( "articlesMenuCheck", articlesMenuCheck )
          if ( articlesMenuCheck.value == true ) {
            contentArticles.pause ( 4000 ).useXpath ( ).
            //Verify the Articles Menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text() = 'Articles']", "Articles" ).
            pause ( 4000 ).
            //Click on the Articles Menu in the CONTENT
            click ( "//ul/li/a[ text() = 'Articles']" ).
            useCss ( ).pause ( 4000 ).
            //Get the Current Totla Count in the Articles listing Page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }            
              contentArticles.pause ( 4000 ).useCss ( ).
              //Verify the searched field is visible in the pictures listing page
              verify.visible ( ".search-field-input" ).
              pause ( 4000 ).
              //Clear the data in the Searched field
              clearValue ( ".search-field-input" ).
              pause ( 4000 ).
              //Enter the data in the Searched field
              setValue ( ".search-field-input", articlesTitle[ getData ] ).
              pause ( 4000 ).
              //Hold the control
              keys ( contentArticles.Keys.ENTER ).
              click ( ".search-field-input" ).
              //Release the control
              keys ( contentArticles.Keys.NULL ).
              pause ( 6000 ).
              //Wait for the total count label is visible in the pictures page
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              //Verify the total count label is visible in the pictures page
              verify.visible ( ".content-count>strong" ).
              pause ( 4000 ).
              //Get the searched count in the pictures listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status !== -1 ) {
                  var searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                  if ( searchCount > 0 ) {
                    contentArticles.pause ( 4000 ).useXpath ( ).
                    //Wait for the Searched data us visible in the pictures listing page
                    waitForElementVisible ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ articlesTitle[ getData ] +"']]", 4000, false ).
                    pause ( 4000 ).
                    //Click on the Searched data in the pictures listing page
                    click ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ articlesTitle[ getData ] +"']]" ).
                    useCss ( ).pause ( 4000 ).
                    //Verify the Content tab is visible in the pictures page
                    verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                    pause ( 4000 ).
                    //Click on the Content tab in the pictures page
                    click ( ".video-tabs > a[ href='#content' ]" ).
                    pause ( 4000 ).useXpath ( ).
                    //Wait and Check for Caption field is visible in the Articles page
                    waitForElementVisible ( "//*/header/div/div[@class='typeName-label ng-binding']", 4000, false, function ( captionCheck ) {
                      if ( captionCheck.value == true ) {
                        //Get the text as "Article" in the label
                        contentArticles.getText ( "//*/header/div/div[@class='typeName-label ng-binding']", function ( labelName ) {
                          if ( labelName.value == 'ARTICLE' ) {
                            contentArticles.pause ( 4000 ).useXpath ( ).
                            //Wait for text field is visible in the Articles page
                            waitForElementVisible ( "//*/header/div/text-field/input", 4000, false ).
                            pause ( 4000 ).
                            //Clear the data on the text field in Articles page
                            clearValue ( "//*/header/div/text-field/input" ).
                            pause ( 4000 ).
                            //Enter the data on the text field in Articles page
                            setValue ( "//*/header/div/text-field/input", categoryTitle[ getData ] ).
                            pause ( 4000 ).
                            //Check and wait for Save button is visible in the Articles page
                            waitForElementVisible ( "//a[@class='btn btn-icon btn-active']", 4000, false, function ( checkSaveBtn ) {
                              if ( checkSaveBtn.value == true ) {
                                contentArticles.pause ( 4000 ).useXpath ( ).
                                //Verify the save button is visible in the Articles page
                                verify.visible ( "//a[@class='btn btn-icon btn-active']" ).
                                pause ( 4000 ).
                                //Click on the Save button in the Articles page
                                click ( "//a[@class='btn btn-icon btn-active']" ).
                                pause ( 4000 ).
                                //Wait for text field is visible in the Articles page
                                waitForElementVisible ( "//section[1]/text-field[1]/textarea", 4000, false ).
                                pause ( 4000 ).
                                //Clear the data on the text field in Articles page
                                clearValue ( "//section[1]/text-field[1]/textarea" ).
                                pause ( 4000 ).
                                //Enter the data on the text field in Articles page
                                setValue ( "//section[1]/text-field[1]/textarea", articlesTitle[ getData ] ).
                                pause ( 4000 ).useCss ( ).
                                //Check and add details on properties tab in the Articles page
                                allproperties ( articleShortTitle[ getData ], articleShortDesc[ getData ], articleCategoryName[ getData ], articleNote[ getData ], thumbnail[ getData ] )
                                contentArticles.pause ( 4000 ).useXpath ( ).
                                //Wait for Authors field is visible in the properties tab
                                waitForElementVisible ( "//div/a[@ng-click='showAddAuthor()']",9000,false ).
                                pause ( 4000 ).
                                //Click on the Authors name in the dropdown list
                                click ( "//div/a[@ng-click='showAddAuthor()']" ).
                                //Wait for Search Authors in the dropdown option is visible
                                waitForElementVisible ( '//input[@placeholder ="Search authors"]', 9000, false ).
                                pause ( 3000 ).
                                //Verify the Search Authors in the dropdown is visible
                                verify.visible ( '//input[@placeholder ="Search authors"]' ).
                                pause ( 3000 ).
                                //Enter the author name in the search field
                                setValue ( '//input[@placeholder ="Search authors"]', authors[ getData ] ).
                                pause ( 3000 ).
                                //Wait for Authors listing in the dropdown is visible
                                waitForElementPresent ( "//ul/li/a/span[ text ( ) = '"+ authors[ getData ] +"']", 9000, false, function ( authorCheck ) {
                                  console.log ( "authorCheck", authorCheck )
                                  if ( authorCheck.value != false ) {
                                    contentArticles.pause ( 3000 ).useXpath ( ).
                                    //Click on the Authors dropdown option
                                    click ( "//ul/li/a/span[ text ( ) = '"+ authors[ getData ] +"']" ).
                                    pause(3000).
                                    //Verify the Articles Menu in the CONTENT
                                    verify.containsText ( "//ul/li/a[ text() = 'Articles']", "Articles" ).
                                    pause ( 4000 ).
                                    //Click on the Articles Menu in the CONTENT
                                    click ( "//ul/li/a[ text() = 'Articles']" ).
                                    useCss ( ).pause ( 4000 ).
                                    //Wait for Total count label is visible in the listing page
                                    waitForElementVisible ( ".content-count > strong", 4000, false ).
                                    pause ( 4000 ).
                                    //Get the Text value for Total count in the listing page
                                    getText ( '.content-count > strong', function ( actualCountResult ) {
                                      if ( actualCountResult.status !== -1 ) {
                                        var actualCount = actualCountResult.value;
                                        actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                        if ( actualCount == currentCount ) {
                                          //Write in the spreadsheet: Pass Result and Reason
                                          contentArticles.writeToExcelPass ( 'boxxspring.xlsx', 'ContentArticlesEdit', rowCount, 9 );
                                        }
                                        else {
                                          //Write in the spreadsheet: Fail Result and Reason
                                          contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesEdit', rowCount, 9, 10, "ActualResult:'"+ actualCount +"'in the Total Count Existing Authors. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                        }
                                      }
                                    } );
                                  }
                                  else {
                                    contentArticles.pause ( 7000 ).useXpath ( ).
                                    //Wait for close button is visible in the Authors popup
                                    waitForElementVisible ( "//div/div/dialog-include[2]/dialog/section/h1/i",9000,false ).
                                    pause ( 7000 ).
                                    //Click on the close button in the Authors popup
                                    click ( "//div/div/dialog-include[2]/dialog/section/h1/i" )
                                    //Write in the spreadsheet: Fail Result and Reason
                                    contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesEdit', rowCount, 9, 10, "Author is not displayed in the Articles page" );                                   
                                  }
                                } );
                              }
                              else {
                                //Write in the spreadsheet: Fail Result and Reason
                                contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesEdit', rowCount, 9, 10, "Save button is not enabled in the page" );
                              }
                            } );
                          } 
                          else {
                          	//Write in the spreadsheet: Fail Result and Reason
                          	contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesEdit', rowCount, 9, 10, "Article Label is not displayed in the page" );
                          }
                        } ); 
                      } 
                      else {
                      	//Write in the spreadsheet: Fail Result and Reason
                      	contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesEdit', rowCount, 9, 10, "Caption field is not available in the page" );
                      } 
                    } ); 
                  }
                }
              } );                       
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesEdit', rowCount, 9, 10, "Articles Menu is not displayed in the Sidebar" );
          }
        } );
      }
    }
    //Close the browser
    contentArticles.end ( );
  }
}
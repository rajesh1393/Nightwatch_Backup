//this function is for check and Edit the Teams
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['TeamsEdit'];
var teamTitle = [ ];
var teamDescription = [ ];
var teamShortTitle = [ ];
var teamShortDesc = [ ];
var teamCategoryName = [ ];
var teamNote = [ ];
var teamImg = [ ];
var currentCount, actualCount, expectedCount, excelData, searchCount;
var teamSearch = [ ];
var getData,rowCount = 1;
module.exports = {
  tags: [ 'teamsEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'teamsEdit': function ( teamsEdit ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        teamTitle.push ( worksheet[ excelData ].v );
      }
      //Read teams Description
      if ( excelData.includes ( 'B' ) ) {
        teamDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        teamShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        teamShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read teams category Name
      if ( excelData.includes ( 'E' ) ) {
        teamCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read teams Note
      if ( excelData.includes ( 'F' ) ) {
        teamNote.push ( worksheet[ excelData ].v );
      }
      //Read teams Image
      if ( excelData.includes ( 'G' ) ) {
        teamImg.push ( worksheet[ excelData ].v );
      }
      //Read teams Search
      if ( excelData.includes ( 'H' ) ) {
        teamSearch.push ( worksheet[ excelData ].v );
      }      
    }
    if ( teamTitle.length > 1 ) {
    	var checkResult = teamsEdit.globals.excelCol.resultCustomData; 
    	for ( let getData = 1,rowCount = 1; getData < teamTitle.length; getData++ ) {
    		rowCount++;
    		teamsEdit.pause ( 4000 ).useXpath ( ).
    		waitForElementVisible ("//ul/li/a[ text( ) = 'Teams' ]", 9000, false, function ( checkteamMenu ) {
    			console.log("checkteamMenu",checkteamMenu)
    			if ( checkteamMenu.value == true ) {
			      teamsEdit.pause ( 4000 ).useXpath ( ).
			      //Verify the Teams menu in the CONTENT
			      verify.containsText ( "//ul/li/a[ text( ) = 'Teams' ]", "Teams" ).
			      pause ( 4000 ).
			      //Click on the Teams menu in the CONTENT
			      click ( "//ul/li/a[ text( ) = 'Teams' ] " ).
			      useCss ( ).pause ( 4000 ).
			      //Get the Teams Total Count in the Teams listing page
			      getText ( '.content-count > strong', function ( currentCountResult ) {
			        if ( currentCountResult.status != -1 ) {
			          currentCount = currentCountResult.value;
			          currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
			        }
		          teamsEdit.pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
		          pause ( 4000 ).
		          verify.visible ( ".search-field-input" ).
		          pause ( 4000 ).
		          //Clear the data in search field
		          clearValue ( ".search-field-input" ).
		          pause ( 4000 ).
		          //Enter the serach data in the field
		          setValue ( ".search-field-input", teamSearch[ getData ] ).
		          pause ( 4000 ).
		          //Press Enter key to search
		          keys ( teamsEdit.Keys.ENTER ).
		          // release the control
		          keys ( teamsEdit.Keys.NULL ). 
		          pause ( 4000 ).
		          //Wait for the count label is visible in the listing page
		          waitForElementVisible ( ".content-count>strong", 4000, false ).
							pause ( 4000 ).
		          //Get the Teams Total Count in the Teams listing page after Search data
		          getText ( '.content-count > strong', function ( searchCountResult ) {		            
		            if ( searchCountResult.status !== -1 ) {
		              searchCount = searchCountResult.value;
		              searchCount = searchCount.substring ( 1, searchCount.length - 1 );
		            }
		            if ( searchCount > 0 ) {
		              teamsEdit.pause ( 4000 ).useXpath ( ).
		              //Wait for the searched data listed is visible in the listing page
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ teamSearch[ getData ] +"']]", 9000, false, function ( checkattributionLst ) {
                  	if ( checkattributionLst.value == true ) {
				              teamsEdit.pause ( 4000 ).useXpath ( ).
				              //Verify the searched data listed is visible in the listing page
				              verify.visible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ teamSearch[ getData ] +"']]" ).
				              pause ( 4000 ).
				              //Click on the Edit team button
				              click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ teamSearch[ getData ] +"']]" ).
				              pause ( 7000 ).useCss ( ).
				              //Get the caption lable text in the Teams page
				              getText ( ".typeName-label.ng-binding",function ( labelName ) {
				              	console.log ( "labelName",labelName )
				              	if ( labelName.value == "TEAM") {
						              teamsEdit.useCss ( ).pause ( 4000 ).
						              //Verify the Content tab is visible in the Teams page
						              verify.visible ( ".video-tabs > a[ href='#content' ]" ).
						              pause ( 4000 ).
						              //Click on the content tab in the Teams page
						              click ( ".video-tabs > a[ href='#content' ]" ).
						              pause ( 4000 ).
						              //Check the Teams Title filed visible
						              waitForElementVisible ( ".text-input-headline", 4000, false ).
						              //Clear the Teams Title in the field
						              clearValue ( ".text-input-headline" ).
						              pause ( 4000 ).
						              //Enter the Teams Title in the Field
						              setValue ( ".text-input-headline", teamTitle[ getData ] ).
						              pause ( 4000 ).
						              //Check and Enter Teams Text Description
						              waitForElementVisible ( ".wmd-input", 4000, false ).
						              //Clear the team Description
						              clearValue ( ".wmd-input" ).
						              //Enter the Teams Description
						              setValue ( ".wmd-input", teamDescription[ getData ] ).
						              pause ( 4000 ).
						              //Check and click Save button
						              waitForElementVisible ( '.btn-active', 4000, false ).
						              pause ( 4000 ).
						              //Click on the Save Button
						              click ( ".btn-active" ).
						              pause ( 4000 ).
						              video_properties ( teamShortTitle[ getData ], teamShortDesc[ getData ], teamCategoryName[ getData ], teamNote[ getData ], teamImg[ getData ] ).
						              pause ( 4000 ).useCss ( ).
						              //Wait for the Properites tab is visible in the Teams page
						              waitForElementVisible ( ".video-tabs > a[ href='#properties']", 9000, false, function ( checkProperties ) {
				                    if ( checkProperties.value == true ) {
				                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
				                      	//Write in the Excel for Search Fail Result and Reason
				                        teamsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
				                        checkResult.length = 0;
				                      }
				                      else if ( checkResult.length == 0 ) {
				                      }
				                      else {
				                        checkResult.length = 0;
				                        //Check and click save button
				                        teamsEdit.verify.visible ( "a.btn-active" ).
				                        //click on the save button
				                        click ( "a.btn-active" ).
				                        pause ( 7000 ).
				                        //Wait for the Save active status should not present in the Teams Page
				                        waitForElementNotPresent ( "a.btn-active",9000,false,function( checkSaveBtn ) {
				                          if ( checkSaveBtn.value.length == 0 ) {
				                            teamsEdit.pause ( 4000 ).useXpath ( ).
				                            //Verify the videos menu in the sidebar
				                            verify.containsText ( "//ul/li/a[ text( ) = 'Teams']", "Teams" ).
				                            pause ( 9000 ).
				                            //click on the videos menu in CONTENT
				                            click ( "//ul/li/a[ text( ) = 'Teams']" ).
				                            useCss ( ).pause ( 9000 ).
				                            //Check the Actual Count after each video added
				                            getText ( '.content-count > strong', function ( actualCountResult ) {
				                              if ( actualCountResult.status !== -1 ) {
				                                actualCount = actualCountResult.value;
				                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
				                                if ( actualCount == currentCount ) {
				                                  //Write in the spreadsheet: Pass Result and Reason
				                                  teamsEdit.writeToExcelPass ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10 );
				                                }
				                                else {
				                                  //Write in the spreadsheet: Fail Result and Reason
				                                  teamsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Edit Teams. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
				                                }
				                              }
				                            } );
				                          }
				                          else {
				                            //Write in the spreadsheet: Fail Result and Reason
				                            teamsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10, 11, " Save button is not functioning as expected" );
				                          }
				                        } );		                        
				                      }				                      
				                    }				                    
				                  } );  
			                  }
			                  else {
			                  	//Write in the Excel for Search Fail Result and Reason
					            		teamsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10, 11, "Lable Name as Expected 'TEAM' but Actual as '"+labelName.value+"'" );
					              }
		                  } );      
					          }
					          else {
					            //Write in the Excel for Search Fail Result and Reason
					            teamsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10, 11, "Searched Data is not availed in the listing page" );
					          }
		         			} );
				        }
			        	else {
			        	//Write in the Excel for Search Fail Result and Reason
			          teamsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10, 11, "Searched Result Count,'"+ searchCount +"'" );
				        }
				      } );
		      	} );
					}
					else {
						//Write in the Excel for Search Fail Result and Reason
						teamsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsEdit', rowCount, 10, 11, "Teams Menu is not displayed in Sidebar" );		            
					}
				} );
			}
		}
    //End the Browser
    teamsEdit.end ( );
  }
};
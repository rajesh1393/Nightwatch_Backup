//this function is for check and Add the Collections list 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CollectionslistAdd' ];
var collectionTitle = [ ];
var contentTitle = [ ];
var collectionMenu = [ ];
var resultStatus = [ ];
var currentCount, expectedCount, excelData, actualCount, splitCollection,splitArtifactName, finalCount;
var getData,getFirstData,rowCount = 1;
var dataCategory = 0;
module.exports = {
  tags: [ 'collectionsListAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;   
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CollectionsListAdd': function ( collectionsListAdd ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Search Collection Title
      if ( excelData.includes ( 'A' ) ) {
        collectionTitle.push ( worksheet[ excelData ].v );
      }
      //Read Content Title
      if ( excelData.includes ( 'B' ) ) {
        contentTitle.push ( worksheet[ excelData ].v );
      }
       //Read Content Title
      if ( excelData.includes ( 'C' ) ) {
        collectionMenu.push ( worksheet[ excelData ].v );
      }
      
    }
    if ( collectionTitle.length > 1 ) {
    	for ( let getData = 1, rowCount = 1; getData < collectionTitle.length; getData++ ) {
	      rowCount++;      
	      collectionsListAdd.pause ( 4000 ).useXpath ( ).
	      //Wait for the collection title is visible in the sidebar
	      waitForElementVisible ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']", 4000, false, function ( checkCollectionsTitle ) {
	      	if ( checkCollectionsTitle.value == true ) {
	      		collectionsListAdd.pause ( 4000 ).useXpath ( ).
			      //Verify the Collection Title in the menu is visible
			      verify.containsText ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']", collectionTitle[ getData ] ).
			      pause ( 4000 ).
			      //Click on the Collections Title in the menu
			      click ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']" ).
			      pause ( 4000 ).useCss ( )      
		        //Get the Current Total count in the Collections listing page
		        collectionsListAdd.getText ( '.content-count > strong', function ( currentCountResult ) {
		          if ( currentCountResult.status != -1 ) {
		            currentCount = currentCountResult.value;
		            currentCount = currentCount.substring ( 1, currentCount.length - 1 );
		          }         
		          collectionsListAdd.pause ( 4000 ).useXpath ( ).
		          //Wait for the Content menu is visible in the sidebar
		          waitForElementVisible ( "//ul/li/a[ text( ) = '"+ contentTitle[ getData ] +"']", 4000, false, function ( checkContentMenu ) {
		          	if ( checkContentMenu.value == true ) {
		          		collectionsListAdd.pause ( 4000 ).useXpath ( ).
				          //Verify the Collection Title is visible
				          verify.containsText ( "//ul/li/a[ text( ) = '"+ contentTitle[ getData ] +"']", contentTitle[ getData ] ).
				          pause ( 4000 ).
				          //Click on the Collection Title
				          click ( "//ul/li/a[ text( ) = '"+ contentTitle[ getData ] +"']" ).
				          pause ( 4000 ).useCss ( )				          
				          splitArtifactName = collectionMenu[ getData ].split(',');								          
		              for ( let collectionData = 0, dataCategory = 0; collectionData <splitArtifactName.length; collectionData++ ) {   
			              dataCategory++;
			              collectionsListAdd.pause ( 4000 ).useCss ( ).
					          //Wait for Search input field is visible
					          waitForElementVisible ( ".search-field-input", 4000, false ).
					          //Verify the Search input field is visible
					          verify.visible ( ".search-field-input" ).
					          pause ( 4000 ).
					          //Clear the data in the field
					          clearValue ( ".search-field-input" ).
					          pause ( 4000 ).
					          //Enter the search data in the field
					          setValue ( ".search-field-input", splitArtifactName[ collectionData ] ).
					          pause ( 4000 ).
					          //Hold the control
					          keys ( collectionsListAdd.Keys.ENTER ). 
					          pause ( 4000 ).useXpath ( ).
					          //Wait for collections list is visible
				          	waitForElementVisible ( "//div/*/a/div/h2[contains(.,'"+ splitArtifactName[ collectionData ] +"')] | following::ul/li[2]",4000, false, function ( checkCollectionBtn ) {
					          	if ( checkCollectionBtn.value == true ) {
							          collectionsListAdd.pause ( 4000 ).useCss ( ).
							          //Verify the collections list is visible
							          verify.visible ( "ul.content-menu > li:nth-child( 2 )" ).
							          pause ( 4000 ).
							          //Click on the Collections list
							          click ( "ul.content-menu > li:nth-child( 2 )" ).
							          pause ( 4000 ).
							          //Wait for dialog box collections list is visible
							          waitForElementVisible ( "dialog.dialog-small:nth-child( 1 )", 4000, false, function ( checkDialogBox ) {
							          	if ( checkDialogBox.value == true ) {
									          collectionsListAdd.pause ( 4000 ).useCss ( ).
									          //Verify the dialog box collections list is visible
									          verify.visible ( "dialog.dialog-small:nth-child( 1 )" ).
									          pause ( 4000 )		              				
			            					collectionsListAdd.pause ( 4000 ).useXpath ( ).
			            					//Wait for the Collection label is visible in the collections page
			            					waitForElementVisible ( "//label[text ( )='"+ collectionTitle[ getData ] +"']", 4000, false, function ( checkCollectionsLstMenu ) {
			            						if ( checkCollectionsLstMenu.value == true ) {
							          				collectionsListAdd.pause ( 4000 ).useXpath ( ).
							          				//Verify the collections Title field is visible
											          verify.containsText ( "//label[text ( )='"+ collectionTitle[ getData ] +"']", collectionTitle[ getData ] ).
											          pause ( 4000 ).
											          //Click on the Collections Title
											          click ( "//label[text ( )='"+ collectionTitle[ getData ] +"']" ).
											          pause ( 4000 ).useCss ( ).
											          //Wait for the Primary button is visible
											          waitForElementVisible ( "button.btn-primary:nth-child( 2 )", 4000, false, function ( checkSaveBtn ) {
											          	if ( checkSaveBtn.value == true ) {
													          collectionsListAdd.pause ( 4000 ).useCss ( ).
													          //Click on the Primary button
													          click ( "button.btn-primary:nth-child( 2 )" ).
													          pause ( 4000 )
													          if ( dataCategory == splitArtifactName.length ) {
														          collectionsListAdd.pause ( 4000 ).useXpath ( ).
														          //Wait for the collections menu is visible in the sidebar
														          waitForElementVisible ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']", 4000, false, function ( checkCollectionsMenu ) {
														          	if ( checkCollectionsMenu.value == true ) {
																          collectionsListAdd.pause ( 4000 ).useXpath ( ).
																          //Verify the collections Title is visible
																          verify.containsText ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']", collectionTitle[ getData ] ).
																          pause ( 4000 ).
																          //Click on the collections Title is visible
																          click ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']" )
																          for ( let listData = 0; listData < splitArtifactName.length; listData++ ) {
																	          collectionsListAdd.pause ( 5000 ).useXpath ( ).
																	          //Wait for the searched data is visible in the collections page
																	          waitForElementVisible ( "//div[@class='content-title']/h2[@class='ng-binding'][text()[normalize-space(.)='"+ splitArtifactName[ listData ] +"']]", 4000, false, function ( contentCheck ) {
																	            if ( contentCheck.value == true ) {
																	              resultStatus.push ( "PASS" );
																	            }
																	            else {
																	            	resultStatus.push ( "FAIL" );
																	            }
																	          } );	
																	        }
		      																collectionsListAdd.useCss ( ). pause ( 4000 ).
		      																//Get the count value in the listing page
		      																getText ( '.content-count > strong', function ( finalCountResult ) {
		      																	if ( finalCountResult.status != -1 ) {
		          																finalCount = finalCountResult.value;
		          																finalCount = finalCount.substring ( 1, finalCount.length - 1 );
		          																expectedCount = ( ( + currentCount ) + ( + splitArtifactName.length ) );
		          															}
		          															if ( finalCount == expectedCount ) {				                 
																							if ( resultStatus.indexOf ( 'FAIL' ) >= 0 ) {
																								//Write in the Excel:FAIL Result and Reason
																								collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Collection list is not Found in the listing page" );
																							}
																							else if ( resultStatus.length == 0 ) {
		                        									}
		                        									else {
		                        										//Write in the Excel:PASS Result
		                        										collectionsListAdd.writeToExcelPass ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5 );
		                       									  }
		                    											if ( resultStatus.indexOf ( 'FAIL' ) || resultStatus.indexOf ( 'PASS' ) >= 0 ) {
		                      											resultStatus.length = 0;
		                        									}
		                        								}
		                        								else {
		                        									//Write in the Excel:FAIL Result and Reason
																							collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Actual Count has been'"+ finalCount +"' and Expected Count is '"+ expectedCount +"'" );
		                        								}
		                        							} );
																        }
																        else {
																        	//Write in the Excel:FAIL Result and Reason
																          collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Collections menu '"+ checkCollectionsMenu +"' is not displayed in the Side Menu" );
																        }
																      } );
														        }
													        }
													        else {
													        	//Write in the Excel:FAIL Result and Reason
													          collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Save button in the dialog box is not displayed" );
													        }
													      } );														    
														  }										    
							        				else {			
							        					//Write in the Excel:FAIL Result and Reason					        																				    	
							        					collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "No '"+ collectionMenu[ getData ] +"' Found in the collections list" );
									        		}
									      		} );				        		
								        	}
								        	else {
								        		//Write in the Excel:FAIL Result and Reason
								          	collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Dialog box is not displayed in the collection list page" );
								        	}
									      } );      
							        }
							        else {
							        	//Write in the Excel:FAIL Result and Reason
						          	collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Collection Button is not displayed in the searched listing page" );
							        }
							      } );
									}
			          }
			          else {
			          	//Write in the Excel:FAIL Result and Reason
			          	collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Content Menu '"+contentTitle[ getData ] +"' is not displayed in the Sidebar" );
			          } 
		          } );    
		        } );
		      }
		      else {
		      	//Write in the Excel:FAIL Result and Reason
		        collectionsListAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionslistAdd', rowCount, 5, 6, "Collection Title '"+collectionTitle[ getData ] +"' is not displayed in the Side Menu" );
		      }
		    } );
      }
    }
    //End the Browser
    collectionsListAdd.end ( );
  }
}
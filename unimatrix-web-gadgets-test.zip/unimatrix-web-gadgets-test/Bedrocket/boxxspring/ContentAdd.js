//this function is for check and Add the Contentlist
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'ContentAdd' ];
var contentTitle = [ ];
var categoryName = [ ];
var categoryType = [ ];
var providerType = [ ];
var alignment = [ ];
var expectedCount, currentCount, actualCount, excelData, actualLabel;
var expectedLabel = "CONTENT";
var getData, rowCount = 1;
module.exports = {
  tags: [ 'contentAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'ContentAdd': function ( addContent ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Content Title
      if ( excelData.includes ( 'A' ) ) {
        contentTitle.push ( worksheet[ excelData ].v );
      }
      //Read Content Type
      if ( excelData.includes ( 'B' ) ) {
        categoryName.push ( worksheet[ excelData ].v );
      }
      //Read Content Type
      if ( excelData.includes ( 'C' ) ) {
        categoryType.push ( worksheet[ excelData ].v );
      }
      //Read Provider Title
      if ( excelData.includes ( 'D' ) ) {
        providerType.push ( worksheet[ excelData ].v );
      }
      //Read alignment
      if ( excelData.includes ( 'E' ) ) {
        alignment.push ( worksheet[ excelData ].v );
      }
    }
    if ( contentTitle.length > 1 ) {
    	for ( let getData = 1, rowCount = 1; getData < contentTitle.length; getData++ ) {
    		rowCount++;
      	addContent.pause ( 4000 ).useXpath ( ).
    		//Wait and Verify the ALL Menu in CONTENT
	      waitForElementVisible ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false, function ( checkContentAllMenu ) {
	      	if ( checkContentAllMenu.value == true ) {
	    			addContent.pause ( 4000 ).useXpath ( ).
	    			verify.visible ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]" ).
	    			pause ( 4000 ).
			      //Click on the ALL Menu in CONTENT
			      click ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]" ).
			      pause ( 4000 ).useCss ( ).
			      //Get the Current count in the Content page
			      getText ( '.content-count > strong', function ( currentCountResult ) {
			        if ( currentCountResult.status != -1 ) {
			          currentCount = currentCountResult.value;
			          currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
			        }
		          addContent.pause ( 4000 ).
		          //Wait for the Content Menu Visible
		          waitForElementVisible ( "div.content:nth-child( 1 ) > a:nth-child( 2 )", 4000, false ).
		          pause ( 4000 ).
		          //Verify the Content Menu Visible
		          verify.containsText ( "div.content:nth-child( 1 ) > a:nth-child( 2 )", "CONTENT" ).
		          pause ( 4000 ).
		          //Wait for the Content Add Button
		          waitForElementVisible ( "div.content:nth-child( 1 ) > span:nth-child( 3 ) > a:nth-child( 1 ) > img:nth-child( 1 )", 4000, false ).
		          //Verify for the Content Add Button
		          verify.visible ( "div.content:nth-child( 1 ) > span:nth-child( 3 ) > a:nth-child( 1 ) > img:nth-child( 1 )" ).
		          pause ( 4000 ).
		          //Click on the Content Add Button
		          click ( "div.content:nth-child( 1 ) > span:nth-child( 3 ) > a:nth-child( 1 ) > img:nth-child( 1 )" ).
		          pause ( 4000 ).useXpath ( ).
		          waitForElementVisible ( "//div/header/div/div[@class='typeName-label']", 4000, false ).
		          pause ( 4000 ).
		          getText ( "//div/header/div/div[@class='typeName-label']", function ( getLabelName ) {
                actualLabel = getLabelName.value;
                if ( actualLabel == expectedLabel ) {
                  addContent.useCss ( ).pause ( 4000 ).
				          //Wait for the Headline visible
				          waitForElementVisible ( ".text-input-headline", 4000, false ).
				          pause ( 4000 ).
				          //Verify the Headline visible
				          verify.visible ( ".text-input-headline" ).
				          pause ( 4000 ).
				          //Enter the Headline in the Field
				          setValue ( ".text-input-headline", contentTitle[ getData ] )
				          if ( categoryName[ getData] != undefined ) {
		                //Check and Enter category
		                addContent.useXpath().waitForElementVisible ( "//*/div[2]/form/div[1]/div/div/div/input", 4000, false ).
		                pause ( 4000 ).
		                setValue ( "//*/div[2]/form/div[1]/div/div/div/input", categoryName[ getData ] ).
		                pause ( 4000 ).
		                waitForElementPresent ( "//div/div[2]/form/div[1]/div/div/div[2]/div", 4000, false, function ( checkCategoryType ) {
		                	if ( checkCategoryType.value != false ) {
		                		 addContent.useXpath().pause ( 4000 ).
		                		 waitForElementPresent ( "//*/div/span[text()='"+ categoryName[ getData ] +"']",4000, false, function ( checkCategoryLst ) {
		                			if ( checkCategoryLst.value != false ) {
		                				 addContent.useXpath().pause ( 4000 ).
		                				 verify.visible ( "//*/div/span[text()='"+ categoryName[ getData ] +"']" ).
		                				pause ( 4000 ).
		                				click ( "//*/div/span[text()='"+ categoryName[ getData ] +"']" )
		                			}		                			
		              			} );
					            }
					            else {
					            	addContent.pause ( 4000 ).useCss ( )
					            	addContent.keys ( addContent.Keys.ENTER )
					            	addContent.keys ( addContent.Keys.ENTER )
					            }
		          			} );
		              }		             
				          addContent.useXpath ( ).pause ( 4000 ).
				          //Verify the Contains in the Category Type
				          verify.containsText ( "//label[ text( ) ='"+ categoryType[ getData ].trim( ) +"']", categoryType[ getData ].trim( ) ).
				          pause ( 4000 ).
				          //Click on the Contains in the Category Type
				          click ( "//label[ text( ) ='"+ categoryType[ getData ].trim( ) +"']" ).
				          pause ( 4000 ).
				          //Verify the Contains in the Provider Type
				          verify.containsText ( "//label[ text( ) ='"+ providerType[ getData ].trim( ) +"']", providerType[ getData ].trim( ) ).
				          pause ( 4000 ).
				          //Click on the Contains in the Provider Type
				          click ( "//label[ text( ) ='"+ providerType[ getData ].trim( ) +"']" ).
				          useCss ( ).
				          //Wait for the alignment visible
				          waitForElementVisible ( ".presentation", 4000, false ).
				          pause ( 4000 )
				          if ( ( alignment[ getData ] == "Grid" ) || ( alignment[ getData ] == "List" ) ) {
					          //Check the condition for Grid in the alignment
					          if ( alignment[ getData ] == "Grid" ) {
					            addContent.waitForElementVisible ( ".grid", 4000, false ).
					            pause ( 4000 ).
					            click ( ".grid" ).
					            pause ( 4000 )
					          }
					          //Check the condition for List in the alignment
					          else if ( alignment[ getData ] == "List" ) {
					            addContent.waitForElementVisible ( ".list", 4000, false ).
					            pause ( 4000 ).
					            click ( ".list" ).
					            pause ( 4000 )
					          }
					          else {
					          }
					          //Wait for Save button visible
					          addContent.waitForElementVisible ( ".btn-active", 4000, false ).
					          pause ( 4000 ).
					          //Click on the Save Button
					          click ( ".btn-active" ).
					          pause ( 4000 ).useXpath ( ). 
					          getText ( "//div/div[2]/form/div[1]/div/div/div/ul/li[1]",function ( checkCategoryAvail ) {
					          	if ( ( checkCategoryAvail.value.length != 0 ) || ( categoryName[ getData] == undefined ) )  {
					          		addContent.useCss( ).
					          		waitForElementNotPresent ( ".btn-active",4000,false, function ( checkSaveEnable ) {
					          			if ( checkSaveEnable.value.length == 0 ) {
									          //Wait for ALL button is Visible
									          addContent.useXpath( ).
									          waitForElementVisible ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false ).
									          pause ( 4000 ).
									          //Click on the ALL Button in CONTENT
									          click ( "//div[2]/ul/li/a[text()[normalize-space(.)='All']]" ).
									          pause ( 10000 ).useCss ( ).
									          //Verify the Total count label is visible in the Content All page
									          verify.visible ( ".content-count > strong" ).
									          pause ( 4000 ).
									          //Get Actual Total Count after created in the Content 
									          getText ( '.content-count > strong', function ( actualCountResult ) {
									            if ( actualCountResult.status != -1 ) {
									              actualCount = actualCountResult.value;
									              actualCount = actualCount.substring ( 1, actualCount.length - 1 );
									              expectedCount = ( ( +currentCount ) + ( 1 ) );
									              if ( actualCount == expectedCount ) {
									                //Write the Excel to PASS Result and Reason
									                addContent.writeToExcelPass ( 'boxxspring.xlsx', 'ContentAdd', rowCount, 7 );
									              }
									              else {
									                //Write the Excel to FAIL Result and Reason
									                addContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentAdd', rowCount, 7, 8, "ActualResult: '"+ actualCount +"' in the Total Count After Added New Content. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
									              }
									            }
									          } );
									        }
									        else {
									        	//Write the Excel to FAIL Result and Reason
									          addContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentAdd', rowCount, 7, 8, "Save button is ACTIVE after saved the Content in the page" );
									        }
									      } );
						          }
						          else {
						          	//Write the Excel to FAIL Result and Reason
						            addContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentAdd', rowCount, 7, 8, "Added Categories is not saved in the Content" );
						          }
						        } );		
				          }  
				          else {
				          	//Write the Excel to FAIL Result and Reason
					          addContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentAdd', rowCount, 7, 8, "The alignment data '"+ alignment[ getData ] +"' is not in the list" );			              
				          }     
			          }
			          else {
			          	//Write the Excel to FAIL Result and Reason
				          addContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentAdd', rowCount, 7, 8, "Caption Name is not related to the page, which has expected as '"+ expectedLabel +"' and got actual as '"+ actualLabel +"'" );			              
			          } 
		          } ); 
		        } );
					}
					else {
						//Write the Excel to FAIL Result and Reason
			      addContent.writeToExcelFail ( 'boxxspring.xlsx', 'ContentAdd', rowCount, 7, 8, "Content All menu is not displayed in the Sidebar" );             
		  		}
				} );
			}
    }
    //End the Browser
    addContent.end ( );
  }
}
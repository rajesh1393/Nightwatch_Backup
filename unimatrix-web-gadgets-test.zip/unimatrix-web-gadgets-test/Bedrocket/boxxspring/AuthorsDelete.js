//this function is for check and Delete the Authors
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'AuthorsDelete' ];
var authorType = [ ];
var authorTitle = [ ];
var authorEditTitle = [ ];
var storyShortDesc = [ ];
var currentCount, expectedCount, actualCount;
var addedCount, searchCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'authorsDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AuthorsDelete': function ( authorDelete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read story title
      if ( excelData.includes ( 'A' ) ) {
        authorTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Edit Title
      if ( excelData.includes ( 'B' ) ) {
        authorEditTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'C' ) ) {
        storyShortDesc.push ( worksheet[ excelData ].v );
      }
    }
    if ( authorTitle.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < authorTitle.length; getData++ ) {
        rowCount++;
        authorDelete.pause ( 4000 ).useXpath ( ).
        //Check and wait for Authors Menu is visible in the CONTENT
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Authors' ]", 4000, false, function ( checkAuthorsMenu ) {
          if ( checkAuthorsMenu.value == true ) {
            authorDelete.pause ( 4000 ).useXpath ( ).
            //Verify the Authors menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Authors' ]", "Authors" ).
            pause ( 4000 ).
            //Click the Authors menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Authors' ]" ).
            useCss ( ).pause ( 4000 ).
            waitForElementVisible ( ".content-count>strong", 4000, false ).
            pause ( 4000 ).
            verify.visible ( ".content-count>strong" ).
            //Get current total count in the authors listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }            
              authorDelete.useCss ( ).pause ( 4000 ).                          
              //Wait for the search field visible
              waitForElementVisible ( ".search-field-input", 4000, false ).
              verify.visible ( ".search-field-input" ).
              //Enter the search data in the field
              setValue ( ".search-field-input", authorTitle[ getData ] ).
              keys ( authorDelete.Keys.ENTER ). // hold the control
              //click on the search field
              click ( ".search-field-input" ).
              keys ( authorDelete.Keys.NULL ). // release the control
              pause ( 4000 ).
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              verify.visible ( ".content-count>strong" ).
              //Get Actual total count in the authors listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                }
                if ( searchCount > 0 ) {
                  authorDelete.useXpath ( ).pause ( 4000 ).
                  waitForElementVisible ("//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ authorTitle[ getData ] +"']]", 4000, false, function ( checkSearchedData ) {
                    if ( checkSearchedData.value == true ) {
                      authorDelete.useXpath ( ).pause ( 4000 ).
                      //Click on the Searched data in the listing page
                      click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ authorTitle[ getData ] +"']]" ).
                      useCss().pause ( 4000 ).
                      //Check and Enter Category Title
                      waitForElementVisible ( ".video-tabs > a[ href='#properties' ]", 4000, false ).
                      verify.visible ( ".video-tabs > a[ href='#properties' ]" ).
                      pause ( 4000 ).
                      //Click on the Properties Tab
                      click ( ".video-tabs > a[ href='#properties' ]" ).
                      pause ( 4000 ).
                      //Verify the Headline is visible
                      verify.visible ( ".text-input-headline" ).
                      //Clear the Author Title data in the field
                      clearValue ( ".text-input-headline" ).
                      pause ( 4000 ).
                      //Enter the Author Title data in the field
                      setValue ( ".text-input-headline", authorEditTitle[ getData ] ).
                      pause ( 4000 ).
                      //Check the Save button
                      waitForElementVisible ( '.btn-active', 4000, false ).
                      //Verify the Save button is visible
                      verify.visible ( ".btn-active" ).
                      pause ( 4000 ).
                      //Click on the Save button
                      click ( ".btn-active" ).
                      pause ( 4000 ).
                      //Check the Delete Button.
                      verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Click on the Delete button in the Properties Tab
                      click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Check the existance of delete confirmation dialog
                      verify.visible ( "dialog[ name=deleteVerification ]" ).
                      pause ( 4000 ).
                      //Verify the Cancel Button in Delete Dialog is visible
                      verify.visible ( ".link-secondary" ).
                      //Click Cancel Button in Delete Dialog
                      click ( ".link-secondary" ).
                      pause ( 4000 ).
                      //Verify the Delete Button in the Properties Tab is visible
                      verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Click on the Delete button in the Properties Tab
                      click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Check the existance of delete confirmation to delete
                      verify.visible ( "dialog[ name=deleteVerification ]" ).
                      pause ( 4000 ).
                      verify.visible ( "button.btn:nth-child( 2 )" ).
                      pause ( 4000 ).
                      //Click on the Delete Button in Delete Dialog box
                      click ( "button.btn:nth-child( 2 )" ).
                      pause ( 4000 ).useXpath ( ).
                      //Verify the Authors menu in the CONTENT
                      verify.containsText ( "//ul/li/a[ text( ) = 'Authors' ]", "Authors" ).
                      pause ( 4000 ).
                      //Click on the Authors menu in the CONTENT
                      click ( "//ul/li/a[ text( ) = 'Authors' ]" ).
                      useCss ( ).pause ( 4000 ).
                      waitForElementVisible ( ".content-count>strong", 4000,false ).
                      verify.visible ( ".content-count>strong" ).
                      //Get Authors total count in the authors listing page
                      getText ( '.content-count > strong', function ( actualCountResult ) {
                        if ( actualCountResult.status !== -1 ) {
                          actualCount = actualCountResult.value;
                          actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
                          expectedCount = ( ( + currentCount ) - ( 1 ) );
                          if ( actualCount == expectedCount ) {
                            //Write in the Excel for Pass Result and Reason
                            authorDelete.writeToExcelPass ( 'boxxspring.xlsx', 'AuthorsDelete', rowCount, 5 );
                          }
                          else {
                            //Write in the Excel for Fail Result and Reason
                            authorDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsDelete', rowCount, 5, 6, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Authors. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                          }
                        }
                      } );
                    }
                    else {
                      //Write in the Excel for Fail Result and Reason
                      authorDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsDelete', rowCount, 5, 6, " Searched Data is not avail in the Listing page" );                      
                    }
                  })
                }
                else {
                  //Write in the Excel for Search Fail Result and Reason
                  authorDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsDelete', rowCount, 5, 6, "Searched Result Count,'"+ searchCount +"'" );
                }
              } );
            } );
          }
          else { 
            //Write in the Excel for Search Fail Result and Reason
            authorDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsDelete', rowCount, 5, 6, "Authors menu is not displayed in Sidebar" );                
          }
        } );
      }
    }
    else {
      //Write in the Excel for Search Fail Result and Reason
      authorDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AuthorsDelete', rowCount, 5, 6, "Data is not avail in the Excel" );    
    }
    //End the Browser
    authorDelete.end ( );
  }
};
	module.exports = {
		before: function ( browser ) {
			var profile = browser.globals.profile;
			browser.windowMaximize ( ) . 
			login ( profile.portalUri, profile.username, profile.password ); 
		},
		'Checking for appropriate Error messages in Add Contents page': function ( addContentsPage ) {
		 var content = addContentsPage.page.ContentsPage ( ); 
		 content.
	    //Checking whether the Add button is displayed
	    waitForElementPresent ( '@contentAdd', 15000, false ). 
	    //Clicking the Add button
	    click ( '@contentAdd' ). 
	    //Waiting untill the Title field is present in the Contents add page
	    waitForElementPresent ( '@titleField', 15000, false ). 
	    //Waiting for the save button to be visible
	    waitForElementPresent ( '@saveBtn', 15000, false ). 
	    //Entering some samples in Title field
	    setValue ( '@titleField', "This is a Sample Text" ). 
	    //Clearing the value in the Title field
	    clearValue ( '@titleField' ). 
	    //Checking whether the Save button is enabled
	    waitForElementPresent ( '@activeSaveBtn', 15000, false ). 
	    //Clicking the Save button
	    click ( '@activeSaveBtn' ). 
	    //Checking whether the Appropriate Error message is displayed.
	    checkUI ( '@errorMsg1', 'SmokeTesting.xlsx', 'UI', 2, 5, 6, "Unable to find the Specified element" ); 
	    content.
	    //Checking whether the Appropriate Error message is displayed.
	    checkUI ( '@errorMsg2', 'SmokeTesting.xlsx', 'UI', 3, 5, 6, "Unable to find the Specified element" ); 
	    content.
	    //Checking whether the Appropriate Error message is displayed.
	    checkUI ( '@errorMsg3', 'SmokeTesting.xlsx', 'UI', 4, 5, 6, "Unable to find the Specified element" ); 
	    content.
	    //Checking whether the Save button is visible
	    checkUI ( '@activeSaveBtn', 'SmokeTesting.xlsx', 'UI', 5, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking UI in Contents All Page': function ( listPage ) {
	  	var contentsAll = listPage.page.ContentsPage ( ); 
	  	contentsAll.
	    //Navigating to Contents all page
	    waitForElementPresent ( '@contentAll', 5000, false ). 
	    click ( '@contentAll' ). 
	    checkUI ( '@editOrder', 'SmokeTesting.xlsx', 'UI', 6, 5, 6, "Unable to find the Specified element" ); 
	    contentsAll.
	    checkUI ( '@itemsCount', 'SmokeTesting.xlsx', 'UI', 7, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in add videos page': function ( addVideosPage ) {
	  	var content = addVideosPage.page.ContentsPage ( ); 
	  	content.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@videos_addIcn", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@videos_addIcn" ). 
	    //Checking whether the Title of the videos page is displayed
	    checkUI ( '@videosAddPage_Titlelbl', 'SmokeTesting.xlsx', 'Contents', 2, 5, 6, "Unable to find the Specified element" ); 
	    content.
	    //Checking whether the URL field is displayed
	    checkUI ( '@videosAddPage_URLTxt', 'SmokeTesting.xlsx', 'Contents', 3, 5, 6, "Unable to find the Specified element" ); 
	    content.
	    //Checking whether the Drag and Drop section is displayed.
	    checkUI ( '@videosAddPage_DragnDrp', 'SmokeTesting.xlsx', 'Contents', 4, 5, 6, "Unable to find the Specified element" ); 
	    content.
	    //Entering the invalid URL in the URL field.
	    setValue ( '@videosAddPage_URLTxt', 'this is not a valid URL' ).
	    //Checking whether the appropriate Error message is displayed
	    checkUI ( '@videosAddPage_ErrMsg', 'SmokeTesting.xlsx', 'Contents', 5, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in add Articles page': function ( addArticlesPage ) {
	  	var content_Articles = addArticlesPage.page.ContentsPage ( ); 
	  	content_Articles.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@articles_addIcn", 15000, false ). 
	    //Clicking the Add Articles icon from the side bar
	    click ( "@articles_addIcn" ). 
	    //Checking whether the All the Template Types are displayed
	    checkUI ( '@artAddPage_DescTemp', 'SmokeTesting.xlsx', 'Contents', 6, 5, 6, "Unable to find the Specified element" ); 
	    content_Articles.
	    //Checking whether the All the Template Types are displayed
	    checkUI ( '@artAddPage_AscTemp', 'SmokeTesting.xlsx', 'Contents', 7, 5, 6, "Unable to find the Specified element" ); 
	    content_Articles.
	    //Checking whether the All the Template Types are displayed
	    checkUI ( '@artAddPage_DefaultTemp', 'SmokeTesting.xlsx', 'Contents', 8, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in Articles List page': function ( addArticlesPage ) {
	  	var content_Articles = addArticlesPage.page.ContentsPage ( ); 
	  	content_Articles.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@articles_LnkSideBar", 15000, false ). 
	    //Clicking the Add Articles icon from the side bar
	    click ( "@articles_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@articles_AddBtn', 'SmokeTesting.xlsx', 'Contents', 9, 5, 6, "Unable to find the Specified element" ); 
	    content_Articles.
	    //Checking whether the Search field is dipslayed in Articles list page
	    checkUI ( '@articles_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 10, 5, 6, "Unable to find the Specified element" ); 
	    content_Articles.
	    //Checking whether the Sort DropDown is dipslayed in Articles list page
	    checkUI ( '@articles_sortbyDrpDown', 'SmokeTesting.xlsx', 'Contents', 11, 5, 6, "Unable to find the Specified element" ); 
	    content_Articles.
	    //Checking whether the Title page label is dipslayed in Articles list page
	    checkUI ( '@articles_Title', 'SmokeTesting.xlsx', 'Contents', 12, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking UI in 360-videos list page ': function ( vid360ListPage ) {
	  	var vid360ListPge = vid360ListPage.page.ContentsPage ( ); 
	  	vid360ListPge.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@video360_LnkSideBar", 15000, false ). 
	    //Clicking the Add Articles icon from the side bar
	    click ( "@video360_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@articles_AddBtn', 'SmokeTesting.xlsx', 'Contents', 13, 5, 6, "Unable to find the Specified element" ); 
	    vid360ListPge.
	    //Checking whether the Search field is dipslayed in Articles list page
	    checkUI ( '@articles_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 14, 5, 6, "Unable to find the Specified element" ); 
	    vid360ListPge.
	    //Checking whether the Sort DropDown is dipslayed in Articles list page
	    checkUI ( '@articles_sortbyDrpDown', 'SmokeTesting.xlsx', 'Contents', 15, 5, 6, "Unable to find the Specified element" ); 
	    vid360ListPge.
	    //Checking whether the Title page label is dipslayed in Articles list page
	    checkUI ( '@video360_Title', 'SmokeTesting.xlsx', 'Contents', 16, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in add 360-videos page': function ( add360VidPage ) {
	  	var content_360Vid = add360VidPage.page.ContentsPage ( ); 
	  	content_360Vid.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@video360_AddIcn", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@video360_AddIcn" ). 
	    //Checking whether the Title of the videos page is displayed
	    checkUI ( '@videosAddPage_Titlelbl', 'SmokeTesting.xlsx', 'Contents', 17, 5, 6, "Unable to find the Specified element" ); 
	    content_360Vid.
	    //Checking whether the URL field is displayed
	    checkUI ( '@videosAddPage_URLTxt', 'SmokeTesting.xlsx', 'Contents', 18, 5, 6, "Unable to find the Specified element" ); 
	    content_360Vid.
	    //Checking whether the Drag and Drop section is displayed.
	    checkUI ( '@videosAddPage_DragnDrp', 'SmokeTesting.xlsx', 'Contents', 19, 5, 6, "Unable to find the Specified element" ); 
	    content_360Vid.
	    //Entering the invalid URL in the URL field.
	    setValue ( '@videosAddPage_URLTxt', 'this is not a valid URL' ). 
	    //Checking whether the appropriate Error message is displayed
	    checkUI ( '@videosAddPage_ErrMsg', 'SmokeTesting.xlsx', 'Contents', 20, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking UI in videos list page ': function ( vidListPage ) {
	  	var videoListPge = vidListPage.page.ContentsPage ( ); 
	  	videoListPge.
	    //Waiting for Videos list page link to be present in Sidebar
	    waitForElementVisible ( "@videosListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add Video link from the side bar
	    click ( "@videosListPage_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@videosListPage_AddBtn', 'SmokeTesting.xlsx', 'Contents', 21, 5, 6, "Unable to find the Specified element" ); 
	    videoListPge.
	    //Checking whether the Search field is dipslayed in Video list page
	    checkUI ( '@videosListPage_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 22, 5, 6, "Unable to find the Specified element" ); 
	    videoListPge.
	    //Checking whether the Sort DropDown is dipslayed in Video list page
	    checkUI ( '@videosListPage_sortbyDrpDown', 'SmokeTesting.xlsx', 'Contents', 23, 5, 6, "Unable to find the Specified element" ); 
	    videoListPge.
	    //Checking whether the Title page label is dipslayed in Video list page
	    checkUI ( '@videosListPage_Title', 'SmokeTesting.xlsx', 'Contents', 24, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking UI in Links list page ': function ( linksListPage ) {
	  	var linkListPage = linksListPage.page.ContentsPage ( ); 
	  	linkListPage.
	    //Waiting for Videos list page link to be present in Sidebar
	    waitForElementVisible ( "@lnkListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add Video link from the side bar
	    click ( "@lnkListPage_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@lnkListPage_AddBtn', 'SmokeTesting.xlsx', 'Contents', 25, 5, 6, "Unable to find the Specified element" ); 
	    linkListPage.
	    //Checking whether the Search field is dipslayed in Video list page
	    checkUI ( '@lnkListPage_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 26, 5, 6, "Unable to find the Specified element" ); 
	    linkListPage.
	    //Checking whether the Sort DropDown is dipslayed in Video list page
	    checkUI ( '@lnkListPage_SortDrpDwn', 'SmokeTesting.xlsx', 'Contents', 27, 5, 6, "Unable to find the Specified element" ); 
	    linkListPage.
	    //Checking whether the Title page label is dipslayed in Video list page
	    checkUI ( '@lnkListPage_Title', 'SmokeTesting.xlsx', 'Contents', 28, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in add Links page': function ( addLinksPage ) {
	    //Storing the Contents page in a variable
	    var linksAdd = addLinksPage.page.ContentsPage ( ); 
	    linksAdd.
	    //Checking whether the Add icon from the side bar is displayed
	    waitForElementVisible ( "@lnkAddPage_AddIcn", 15000, false ). 
	    click ( "@lnkAddPage_AddIcn" ). 
	    //Checking whether the Title Field is displayed
	    checkUI ( '@lnkAddPage_Title', 'SmokeTesting.xlsx', 'Contents', 29, 5, 6, "Unable to find the Specified element" ); 
	    linksAdd.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@lnkAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 30, 5, 6, "Unable to find the Specified element" ); 
	    linksAdd.
	    //Checking the Save button active status after entering Text
	    setValue ( '@lnkAddPage_TitleTxt', 'this is not a valid URL' ). 
	    checkUI ( '@lnkAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 31, 5, 6, "Unable to find the Specified element" ); 
	    linksAdd.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@lnkAddPage_TitleTxt' ). 
	    checkUI ( '@lnkAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 32, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking UI in Categories list page ': function ( catList ) {
	  	var categoryListPge = catList.page.ContentsPage ( ); 
	  	categoryListPge.	
	    //Waiting for Videos list page link to be present in Sidebar
	    waitForElementVisible ( "@catListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add Video link from the side bar
	    click ( "@catListPage_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@catListPage_AddBtn', 'SmokeTesting.xlsx', 'Contents', 33, 5, 6, "Unable to find the Specified element" ); 
	    categoryListPge.
	    //Checking whether the Search field is dipslayed in Video list page
	    checkUI ( '@catListPage_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 34, 5, 6, "Unable to find the Specified element" ); 
	    categoryListPge.
	    //Checking whether the Sort DropDown is dipslayed in Video list page
	    checkUI ( '@catListPage_SortDrpDwn', 'SmokeTesting.xlsx', 'Contents', 35, 5, 6, "Unable to find the Specified element" ); 
	    categoryListPge.
	    //Checking whether the Title page label is dipslayed in Video list page
	    checkUI ( '@catListPage_Title', 'SmokeTesting.xlsx', 'Contents', 36, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in add Categories page': function ( addCategoryPage ) {
	    //Storing the Contents page in a variable
	    var addCatPage = addCategoryPage.page.ContentsPage ( ); 
	    addCatPage.
	    //Checking whether the Add icon from the side bar is displayed
	    waitForElementVisible ( "@catAddPage_AddIcn", 15000, false ). 
	    //Checking whether the Submenu is displayed
	    moveToElement ( "@catAddPage_AddIcn", 0, 0 ). 
	    //Checking whether the Add Tag menu is displayed
	    waitForElementVisible ( "@catAddPage_Tag", 15000, false ). 
	    //Clicking the Tag menu from Sub menu
	    click ( "@catAddPage_Tag" ). 
	    // Checking whether the Title Field is displayed
	    checkUI ( '@catTagPage_Title', 'SmokeTesting.xlsx', 'Contents', 37, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@catAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 38, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    // //Checking the Save button active status after entering Text
	    setValue ( '@catAddPage_TitleTxt', 'this is to check Save button behaviour' ). 
	    checkUI ( '@catAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 39, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@catAddPage_TitleTxt' ). 
	    checkUI ( '@catAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 40, 5, 6, "Unable to find the Specified element" ); 
	    //Checking the Add Group Page
	    addCatPage.
	    waitForElementVisible ( "@catAddPage_AddIcn", 15000, false ). 
	    //Checking whether the Submenu is displayed
	    moveToElement ( "@catAddPage_AddIcn", 0, 0 ). 
	    //Checking whether the Add Tag menu is displayed
	    waitForElementVisible ( "@catAddPage_Group", 15000, false ). 
	    //Clicking the Tag menu from Sub menu
	    click ( "@catAddPage_Group" ). 
	    // Checking whether the Title Field is displayed
	    checkUI ( '@catTagPage_Title', 'SmokeTesting.xlsx', 'Contents', 41, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@catAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 42, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    // //Checking the Save button active status after entering Text
	    setValue ( '@catAddPage_TitleTxt', 'this is to check Save button behaviour' ). 
	    checkUI ( '@catAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 43, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@catAddPage_TitleTxt' ). 
	    checkUI ( '@catAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 44, 5, 6, "Unable to find the Specified element" ); 
	    //Checking the Add Play Page
	    addCatPage.
	    waitForElementVisible ( "@catAddPage_AddIcn", 15000, false ). 
	    //Checking whether the Submenu is displayed
	    moveToElement ( "@catAddPage_AddIcn", 0, 0 ). 
	    //Checking whether the Add Tag menu is displayed
	    waitForElementVisible ( "@catAddPage_Playlist", 15000, false ). 
	    //Clicking the Tag menu from Sub menu
	    click ( "@catAddPage_Playlist" ). 
	    // Checking whether the Title Field is displayed
	    checkUI ( '@catTagPage_Title', 'SmokeTesting.xlsx', 'Contents', 45, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@catAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 46, 5, 6, "Unable to find the Specified element" ); 	    
	    addCatPage.
	    // //Checking the Save button active status after entering Text
	    setValue ( '@catAddPage_TitleTxt', 'this is to check Save button behaviour' ). 
	    checkUI ( '@catAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 47, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@catAddPage_TitleTxt' ). 
	    checkUI ( '@catAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 48, 5, 6, "Unable to find the Specified element" ); 
	    //Checking the Add Annotation Page
	    addCatPage.
	    waitForElementVisible ( "@catAddPage_AddIcn", 15000, false ). 
	    //Checking whether the Submenu is displayed
	    moveToElement ( "@catAddPage_AddIcn", 0, 0 ). 
	    //Checking whether the Add Tag menu is displayed
	    waitForElementVisible ( "@catAddPage_Annot", 15000, false ). 
	    //Clicking the Tag menu from Sub menu
	    click ( "@catAddPage_Annot" ). 
	    // Checking whether the Title Field is displayed
	    checkUI ( '@catTagPage_Title', 'SmokeTesting.xlsx', 'Contents', 49, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@catAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 50, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    // //Checking the Save button active status after entering Text
	    setValue ( '@catAddPage_TitleTxt', 'this is to check Save button behaviour' ). 
	    checkUI ( '@catAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 51, 5, 6, "Unable to find the Specified element" ); 
	    addCatPage.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@catAddPage_TitleTxt' ). 
	    checkUI ( '@catAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 52, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking UI in Authors list page ': function ( authList ) {
	  	var authorsListPge = authList.page.ContentsPage ( ); 
	  	authorsListPge.
	    //Waiting for Videos list page link to before present in Sidebar
	    waitForElementVisible ( "@authListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add Video link from the side bar
	    click ( "@authListPage_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@authListPage_AddBtn', 'SmokeTesting.xlsx', 'Contents', 53, 5, 6, "Unable to find the Specified element" ); 
	    authorsListPge.
	    //Checking whether the Search field is dipslayed in Video list page
	    checkUI ( '@authListPage_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 54, 5, 6, "Unable to find the Specified element" ); 
	    authorsListPge.
	    //Checking whether the Sort DropDown is dipslayed in Video list page
	    checkUI ( '@authListPage_SortDrpDwn', 'SmokeTesting.xlsx', 'Contents', 55, 5, 6, "Unable to find the Specified element" ); 
	    authorsListPge.
	    //Checking whether the Title page label is dipslayed in Video list page
	    checkUI ( '@authListPage_Title', 'SmokeTesting.xlsx', 'Contents', 56, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in Authors add page': function ( addAuthorPage ) {
	    //Storing the Contents page in a variable
	    var authorAdd = addAuthorPage.page.ContentsPage ( ); 
	    authorAdd.
	    //Checking whether the Add icon from the side bar is displayed
	    waitForElementVisible ( "@authAddPage_AddIcn", 15000, false ). 
	    click ( "@authAddPage_AddIcn" ). 
	    //Checking whether the Title Field is displayed
	    checkUI ( '@authAddPage_Title', 'SmokeTesting.xlsx', 'Contents', 57, 5, 6, "Unable to find the Specified element" ); 
	    authorAdd.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@authAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 58, 5, 6, "Unable to find the Specified element" ); 
	    authorAdd.
	    //Checking the Save button active status after entering Text
	    setValue ( '@authAddPage_TitleTxt', 'this is not a valid URL' ). 
	    checkUI ( '@authAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 59, 5, 6, "Unable to find the Specified element" ); 
	    authorAdd.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@authAddPage_TitleTxt' ). 
	    checkUI ( '@authAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 60, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking UI in Attribution list page ': function ( attribList ) {
	  	var attribListPge = attribList.page.ContentsPage ( ); 
	  	attribListPge.
	    //Waiting for Videos list page link to be present in Sidebar
	    waitForElementVisible ( "@attribListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add Video link from the side bar
	    click ( "@attribListPage_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@attribListPage_AddBtn', 'SmokeTesting.xlsx', 'Contents', 61, 5, 6, "Unable to find the Specified element" ); 
	    attribListPge.
	    //Checking whether the Search field is dipslayed in Video list page
	    checkUI ( '@attribListPage_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 62, 5, 6, "Unable to find the Specified element" ); 
	    attribListPge.
	    //Checking whether the Sort DropDown is dipslayed in Video list page
	    checkUI ( '@attribListPage_SortDrpDwn', 'SmokeTesting.xlsx', 'Contents', 63, 5, 6, "Unable to find the Specified element" ); 
	    attribListPge.
	    //Checking whether the Title page label is dipslayed in Video list page
	    checkUI ( '@attribListPage_Title', 'SmokeTesting.xlsx', 'Contents', 64, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in Attribution add page': function ( attrib ) {
	    //Storing the Contents page in a variable
	    var attribution = attrib.page.ContentsPage ( ); 
	    attribution.
	    //Checking whether the Add icon from the side bar is displayed
	    waitForElementVisible ( "@attribAddPage_AddIcn", 15000, false ). 
	    click ( "@attribAddPage_AddIcn" ). 
	    //Checking whether the Title Field is displayed
	    checkUI ( '@attribAddPage_Title', 'SmokeTesting.xlsx', 'Contents', 65, 5, 6, "Unable to find the Specified element" ); 
	    attribution.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@attribAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 66, 5, 6, "Unable to find the Specified element" ); 
	    attribution.
	    //Checking the Save button active status after entering Text
	    setValue ( '@attribAddPage_TitleTxt', 'this is Sample text' ). 
	    checkUI ( '@attribAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 67, 5, 6, "Unable to find the Specified element" ); 
	    attribution.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@attribAddPage_TitleTxt' ). 
	    checkUI ( '@attribAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 68, 5, 6, "Unable to find the Specified element" ); 
	    //Checking the error message while entering the invalid URL
	    attribution.
	    setValue ( '@attribAddPage_URLTxt',"This is an invalid URL" ). 
	    checkUI ( '@attribAddPage_errMsg','SmokeTesting.xlsx', 'Contents', 69, 5, 6, "Error message is not displaying" ); 
	    //Checking whether the error message is displayed while entering valid URL
	    attribution.
	    clearValue ( '@attribAddPage_URLTxt' ). 
	    setValue ( '@attribAddPage_URLTxt',"www.google.com" ). 
	    waitForElementNotPresent ( '@attribAddPage_errMsg',5000,false,function ( status ) {
	    	if ( status.status==0 ) {
	    		attribution.
	    		writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 70, 5 ); 
	    	}
	    	else
	    	{
	    		attribution.
	    		writeToExcelFail ( 'SmokeTesting.xlsx', 'Contents', 70, 5, 6, "Error message is displaying even after entering Valid URL" ); 
	    	}
	    }); 
	  },
	  'Checking UI in Annotations list page ': function ( annotList ) {
	  	var annotListPge = annotList.page.ContentsPage ( ); 
	  	annotListPge.
	    //Waiting for Videos list page link to be present in Sidebar
	    waitForElementVisible ( "@annotListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add Video link from the side bar
	    click ( "@annotListPage_LnkSideBar" ). 
	    //Checking whether the Add button is displayed
	    checkUI ( '@annotListPage_AddBtn', 'SmokeTesting.xlsx', 'Contents', 71, 5, 6, "Unable to find the Specified element" ); 
	    annotListPge.
	    //Checking whether the Search field is dipslayed in Video list page
	    checkUI ( '@annotListPage_SearchTxt', 'SmokeTesting.xlsx', 'Contents', 72, 5, 6, "Unable to find the Specified element" ); 
	    annotListPge.
	    //Checking whether the Sort DropDown is dipslayed in Video list page
	    checkUI ( '@annotListPage_SortDrpDwn', 'SmokeTesting.xlsx', 'Contents', 73, 5, 6, "Unable to find the Specified element" ); 
	    annotListPge.
	    //Checking whether the Title page label is dipslayed in Video list page
	    checkUI ( '@annotListPage_Title', 'SmokeTesting.xlsx', 'Contents', 74, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Elements visibility in Annotations add page': function ( addAnnotPage ) {
	    //Storing the Contents page in a variable
	    var annotationAdd = addAnnotPage.page.ContentsPage ( ); 
	    annotationAdd.
	    //Checking whether the Add icon from the side bar is displayed
	    waitForElementVisible ( "@annotAddPage_AddIcn", 15000, false ). 
	    click ( "@annotAddPage_AddIcn" ). 
	    //Checking whether the Title Field is displayed
	    checkUI ( '@annotAddPage_Title', 'SmokeTesting.xlsx', 'Contents', 75, 5, 6, "Unable to find the Specified element" ); 
	    annotationAdd.
	    //Checking whether the Text field for Title is present
	    checkUI ( '@annotAddPage_TitleTxt', 'SmokeTesting.xlsx', 'Contents', 76, 5, 6, "Unable to find the Specified element" ); 
	    annotationAdd.
	    //Checking the Save button active status after entering Text
	    setValue ( '@annotAddPage_TitleTxt', 'this is not a valid URL' ). 
	    checkUI ( '@annotAddPage_ActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 77, 5, 6, "Unable to find the Specified element" ); 
	    annotationAdd.
	    //Checking whether the Save button is not active after clearing the Text in Title field
	    clearValue ( '@annotAddPage_TitleTxt' ). 
	    checkUI ( '@annotAddPage_InActiveSaveBtn', 'SmokeTesting.xlsx', 'Contents', 78, 5, 6, "Unable to find the Specified element" ); 
	  },
	  'Checking Error message in Edit videos page': function ( editVideosPage ) {
	  	var editVideoErrPage = editVideosPage.page.ContentsPage ( ); 
	  	editVideoErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@videos_SideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@videos_SideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@videosListPage_AddBtn",15000,false ).
	    //Checking whether the Search field is displayed in List page
	    waitForElementPresent ( "@videosListPage_SearchTxt",15000,false ).
	    //Changing the View Type to List
	    getAttribute ( "@default_ViewType","class",function ( getGridView ) {
	    	if ( getGridView.value == "grid active" ) {
	    		editVideoErrPage.
	    		click ( "@viewInList" );
	    	}
	    });
	    editVideoErrPage.
	    //Checking whether the Search field is visible
	    waitForElementPresent ( "@videosPage_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@videosPage_SearchTxt", "AutomatioQA" );
	     //Triggering the Enter Button
	    editVideosPage.keys ( editVideosPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    editVideosPage.
	    pause ( 5000 );
	    editVideoErrPage.
	    //Clicking the Search result
	    click ( "@videosSearchResult" ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving video' ) {
				editVideoErrPage.
              	writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 79, 5 );
			}
			else {
				editVideoErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',79,5,6,"Error message is not displayed as Error saving video " );
			}
		});
		editVideoErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editVideoErrPage.
              	writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 80, 5 );
			}
			else {
				editVideoErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',80,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	  },
	 	'Checking Error message in Edit Articles page': function ( editArticlesPage ) {
	  	var editArticleErrPage = editArticlesPage.page.ContentsPage ( ); 
	  	editArticleErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@articles_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@articles_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@articles_AddBtn",15000,false ).
	    //Checking whether the Search field is displayed in List page
	    waitForElementPresent ( "@articles_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@articles_SearchTxt", "Article Auto QA" );
	    //Triggering the Enter Button
	    editArticlesPage.keys ( editArticlesPage.Keys.ENTER );
	  	editArticleErrPage.
	    //Checking whether the results displayed in the list
	    waitForElementPresent ( "@articles_SearchResult",15000,false );
	    editArticlesPage.
	    pause ( 5000 );
	    editArticleErrPage.
	    //Clicking the Search result
	    click ( "@articles_SearchResult" ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving article' ) {
				editArticleErrPage.
              	writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 81, 5 );
			}
			else {
				editArticleErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',81,5,6,"Error message is not displayed as Error saving Article " );
			}
		});
		editArticleErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editArticleErrPage.
              	writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 82, 5 );
			}
			else {
				editArticleErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',82,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	  },
	  'Checking Error message in Edit 360Videos page': function ( edit360VideosPage ) {
	  	var edit360VidErrPage = edit360VideosPage.page.ContentsPage ( ); 
	  	edit360VidErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@video360_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@video360_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@articles_AddBtn",15000,false ).
	    //Checking whether the Search field is displayed in List page
	    waitForElementPresent ( "@articles_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@articles_SearchTxt", "FINAL" );
	    //Triggering the Enter button
	    edit360VideosPage.keys ( edit360VideosPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    edit360VidErrPage.
	    waitForElementPresent ( "@videosSearchResult",15000,false );
	    edit360VideosPage.
	    pause ( 5000 );
	    edit360VidErrPage.
	    waitForElementNotPresent ( "@noResultsFound_Errmsg",20000,false,function ( searchResult ) {
	    if ( searchResult.value.length != 0 ) {
	    edit360VidErrPage.
    	writeToExcelFail ( 'SmokeTesting.xlsx','Contents',83,5,6,"Search result not found" );
	    }
	    else {
	    edit360VidErrPage.
        writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 83, 5 ).
	    //Clicking the Search result
	    click ( "@videosSearchResult" ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving three sixty video' ) {
				edit360VidErrPage.
              	writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 84, 5 );
			}
			else {
				edit360VidErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',84,5,6,"Error message is not displayed as Error saving three sixty video" );
			}
		});
		edit360VidErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				edit360VidErrPage.
              	writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 85, 5 );
			}
			else {
				edit360VidErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',85,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	}
});
	  },
	 'Checking Error message in Categories Tag page': function ( editCatTagPage ) {
	 	var editTagErrPage = editCatTagPage.page.ContentsPage ( ); 
	 	editTagErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@catListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@catListPage_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@articles_AddBtn",15000,false ).
	    //Changing the View type to List View
	    getAttribute ( "@default_ViewType","class",function ( getGridView ) {
	    	if ( getGridView.value == "grid active" ) {
	    		editTagErrPage.
	    		click ( "@viewInList" );
	    	}
	    });
	    editTagErrPage.
	  	//Checking whether the Search field is displayed in List page
	  	waitForElementPresent ( "@catListPage_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@catListPage_SearchTxt", "AutomationTag");
	    //Triggering the Enter Button
	    editCatTagPage.keys ( editCatTagPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    editTagErrPage.
	    waitForElementNotPresent ( "@noResultsFound_Errmsg",20000,false,function ( searchResult ) {
	    if ( searchResult.value.length != 0 ) {
	    	editTagErrPage.
	    	writeToExcelFail ( 'SmokeTesting.xlsx','Contents',86,5,6,"Search result not found" );
	    }
	    else {
	   	//Clicking the Search result
	   	editCatTagPage.
	   	pause(5000);
	   	editTagErrPage.
		writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 86, 5 ).
	   	click ( "@catSearchResult" );
	   	editCatTagPage.
	   	pause ( 5000 );
	   	editTagErrPage.
	   	waitForElementPresent ( "@catTitle_Tag_Txt",15000,false ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving tag' ) {
				editTagErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 87, 5 );
			}
			else {
				editTagErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',87,5,6,"Error message is not displayed as Error saving tag " );
			}
		});
		editTagErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editTagErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 88, 5 );
			}
			else {
				editTagErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',88,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	}
});
},
	 'Checking Error message in Categories Annotations page': function ( editCatAnnPage ) {
	 	var editAnnErrPage = editCatAnnPage.page.ContentsPage ( ); 
	 	editAnnErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@catListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@catListPage_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@articles_AddBtn",15000,false ).
	    //Changing the View type to List View
	    getAttribute ( "@default_ViewType","class",function ( getGridView ) {
	    	if ( getGridView.value == "grid active" ) {
	    		editAnnErrPage.
	    		click ( "@viewInList" );
	    	}
	    });
	    editAnnErrPage.
	  	//Checking whether the Search field is displayed in List page
	  	waitForElementPresent ( "@catListPage_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@catListPage_SearchTxt", "AutomationAnnotation");
	    //Triggering the Enter Button
	    editCatAnnPage.keys ( editCatAnnPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    editCatAnnPage.
	   	pause ( 15000 );
	    editAnnErrPage.
	    waitForElementNotPresent ( "@noResultsFound_Errmsg",20000,false,function ( searchResult ) {
	    if ( searchResult.value.length != 0) {
	    	editAnnErrPage.
	    	writeToExcelFail ( 'SmokeTesting.xlsx','Contents',89,5,6,"Search result not found" );
	    }
	    else {
	   	//Clicking the Search result
	   	editCatAnnPage.
	   	pause(5000);
	   	editAnnErrPage.
		writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 89, 5 ).
	   	click ( "@catSearchResult" );
	   	editCatAnnPage.
	   	pause ( 5000 );
	   	editAnnErrPage.
	   	waitForElementPresent ( "@catTitle_Tag_Txt",15000,false ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving annotation' ) {
				editAnnErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 90, 5 );
			}
			else {
				editAnnErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',90,5,6,"Error message is not displayed as Error saving tag " );
			}
		});
		editAnnErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editAnnErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 91, 5 );
			}
			else {
				editAnnErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',91,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	}
});
},
'Checking Error message in Categories Groups page': function ( editCatAnnPage ) {
	 	var editAnnErrPage = editCatAnnPage.page.ContentsPage ( ); 
	 	editAnnErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@catListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@catListPage_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@articles_AddBtn",15000,false ).
	    //Changing the View type to List View
	    getAttribute ( "@default_ViewType","class",function ( getGridView ) {
	    	if ( getGridView.value == "grid active" ) {
	    		editAnnErrPage.
	    		click ( "@viewInList" );
	    	}
	    });
	    editAnnErrPage.
	  	//Checking whether the Search field is displayed in List page
	  	waitForElementPresent ( "@catListPage_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@catListPage_SearchTxt", "AutomationGroup");
	    //Triggering the Enter Button
	    editCatAnnPage.keys ( editCatAnnPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    editCatAnnPage.
	   	pause ( 15000 );
	    editAnnErrPage.
	    waitForElementNotPresent ( "@noResultsFound_Errmsg",20000,false,function ( searchResult ) {
	    if ( searchResult.value.length != 0) {
	    	editAnnErrPage.
	    	writeToExcelFail ( 'SmokeTesting.xlsx','Contents',92,5,6,"Search result not found" );
	    }
	    else {
	   	//Clicking the Search result
	   	editCatAnnPage.
	   	pause(5000);
	   	editAnnErrPage.
		writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 92, 5 ).
	   	click ( "@catSearchResult" );
	   	editCatAnnPage.
	   	pause ( 5000 );
	   	editAnnErrPage.
	   	waitForElementPresent ( "@catTitle_Tag_Txt",15000,false ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving group' ) {
				editAnnErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 93, 5 );
			}
			else {
				editAnnErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',93,5,6,"Error message is not displayed as Error saving tag " );
			}
		});
		editAnnErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editAnnErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 94, 5 );
			}
			else {
				editAnnErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',94,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	}
});
},
'Checking Error message in Categories Playlists page': function ( editCatAnnPage ) {
	 	var editAnnErrPage = editCatAnnPage.page.ContentsPage ( ); 
	 	editAnnErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@catListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@catListPage_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@articles_AddBtn",15000,false ).
	    //Changing the View type to List View
	    getAttribute ( "@default_ViewType","class",function ( getGridView ) {
	    	if ( getGridView.value == "grid active" ) {
	    		editAnnErrPage.
	    		click ( "@viewInList" );
	    	}
	    });
	    editAnnErrPage.
	  	//Checking whether the Search field is displayed in List page
	  	waitForElementPresent ( "@catListPage_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@catListPage_SearchTxt", "AutomationPlaylist");
	    //Triggering the Enter Button
	    editCatAnnPage.keys ( editCatAnnPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    editCatAnnPage.
	   	pause ( 15000 );
	    editAnnErrPage.
	    waitForElementNotPresent ( "@noResultsFound_Errmsg",20000,false,function ( searchResult ) {
	    if ( searchResult.value.length != 0) {
	    	editAnnErrPage.
	    	writeToExcelFail ( 'SmokeTesting.xlsx','Contents',95,5,6,"Search result not found" );
	    }
	    else {
	   	//Clicking the Search result
	   	editCatAnnPage.
	   	pause(5000);
	   	editAnnErrPage.
		writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 95, 5 ).
	   	click ( "@catSearchResult" );
	   	editCatAnnPage.
	   	pause ( 5000 );
	   	editAnnErrPage.
	   	waitForElementPresent ( "@catTitle_Tag_Txt",15000,false ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving playlist' ) {
				editAnnErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 96, 5 );
			}
			else {
				editAnnErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',96,5,6,"Error message is not displayed as Error saving tag " );
			}
		});
		editAnnErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editAnnErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 97, 5 );
			}
			else {
				editAnnErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',97,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	}
});
},
'Checking Error message in Authors page': function ( editAuthPage ) {
	 	var editAuthErrPage = editAuthPage.page.ContentsPage ( ); 
	 	editAuthErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@authListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@authListPage_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@authListPage_AddBtn",15000,false ).
	    //Changing the View type to List View
	    getAttribute ( "@default_ViewType","class",function ( getGridView ) {
	    	if ( getGridView.value == "grid active" ) {
	    		editAuthErrPage.
	    		click ( "@viewInList" );
	    	}
	    });
	    editAuthErrPage.
	  	//Checking whether the Search field is displayed in List page
	  	waitForElementPresent ( "@authListPage_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@authListPage_SearchTxt", "AutomationAuthor");
	    //Triggering the Enter Button
	    editAuthPage.keys ( editAuthPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    editAuthPage.
	   	pause ( 15000 );
	    editAuthErrPage.
	    waitForElementNotPresent ( "@noResultsFound_Errmsg",20000,false,function ( searchResult ) {
	    if ( searchResult.value.length != 0) {
	    	editAuthErrPage.
	    	writeToExcelFail ( 'SmokeTesting.xlsx','Contents',98,5,6,"Search result not found" );
	    }
	    else {
	   	//Clicking the Search result
	   	editAuthPage.
	   	pause(5000);
	   	editAuthErrPage.
		writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 98, 5 ).
	   	click ( "@catSearchResult" );
	   	editAuthPage.
	   	pause ( 5000 );
	   	editAuthErrPage.
	   	waitForElementPresent ( "@catTitle_Tag_Txt",15000,false ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving author' ) {
				editAuthErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 99, 5 );
			}
			else {
				editAuthErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',99,5,6,"Error message is not displayed as Error saving tag " );
			}
		});
		editAuthErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editAuthErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 100, 5 );
			}
			else {
				editAuthErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',100,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	}
});
},
'Checking Error message in Galleries edit page': function ( editAuthPage ) {
	 	var editAuthErrPage = editAuthPage.page.ContentsPage ( ); 
	 	editAuthErrPage.
	    //Waiting for Add videos icon to be present in Sidebar
	    waitForElementVisible ( "@galListPage_LnkSideBar", 15000, false ). 
	    //Clicking the Add videos icon from the side bar
	    click ( "@galListPage_LnkSideBar" ).
	    //Checking whether the Add button in the list page is displayed
	    waitForElementPresent ( "@authListPage_AddBtn",15000,false ).
	    //Changing the View type to List View
	    getAttribute ( "@default_ViewType","class",function ( getGridView ) {
	    	if ( getGridView.value == "grid active" ) {
	    		editAuthErrPage.
	    		click ( "@viewInList" );
	    	}
	    });
	    editAuthErrPage.
	  	//Checking whether the Search field is displayed in List page
	  	waitForElementPresent ( "@authListPage_SearchTxt",15000,false ).
	    //Setting the Value in the Search field
	    setValue ( "@authListPage_SearchTxt", "AutomationGallery");
	    //Triggering the Enter Button
	    editAuthPage.keys ( editAuthPage.Keys.ENTER );
	    //Checking whether the results displayed in the list
	    editAuthPage.
	   	pause ( 15000 );
	    editAuthErrPage.
	    waitForElementNotPresent ( "@noResultsFound_Errmsg",20000,false,function ( searchResult ) {
	    if ( searchResult.value.length != 0) {
	    	editAuthErrPage.
	    	writeToExcelFail ( 'SmokeTesting.xlsx','Contents',101,5,6,"Search result not found" );
	    }
	    else {
	   	//Clicking the Search result
	   	editAuthPage.
	   	pause(5000);
	   	editAuthErrPage.
		writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 101, 5 ).
	   	click ( "@catSearchResult" );
	   	editAuthPage.
	   	pause ( 5000 );
	   	editAuthErrPage.
	   	waitForElementPresent ( "@catTitle_Tag_Txt",15000,false ).
	    //Checking whether the page hasbeen navigated to Edit page
	    waitForElementPresent ( "@titleField",15000,false ).
	    //Clearing the Values in the Title field.
	    clearValue ( "@titleField" ).
	    //Checking whether the Element is displayed in the Edit video page
	    waitForElementPresent ( "@saveBtnNotActive", 15000, false ).
	    //Clicking the save button
	    click ( "@saveBtnNotActive" ).
		//Checking whether the Error message is displayed after clicking on the Save button after clearing the Title
		waitForElementPresent ( "@videoHeadline_ErrorMsg",15000,false ).
		//Checking whether the Content of the alert msg is right
		getText ( "@videoHeadline_ErrorMsg_Desc",function ( getErrMsgContent ) {
			if ( getErrMsgContent.value == '⚠Error saving gallery' ) {
				editAuthErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 102, 5 );
			}
			else {
				editAuthErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',102,5,6,"Error message is not displayed as Error saving tag " );
			}
		});
		editAuthErrPage.
		getText ( "@videoHeadline_ErrorMsg_SubDesc",function ( getErrMsgContents ) {
			if ( getErrMsgContents.value == 'Please enter a headline' ) {
				editAuthErrPage.
				writeToExcelPass ( 'SmokeTesting.xlsx', 'Contents', 103, 5 );
			}
			else {
				editAuthErrPage.
				writeToExcelFail ( 'SmokeTesting.xlsx','Contents',103,5,6,"Error message is not displayed as Please enter a headline" );
			}
		});
	}
});
editAuthPage.end( );
},
}
//this function is for check and Delete the links
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'LinksDelete' ];
var linkTitle = [ ];
var linkShortDesc = [ ];
var currentCount, actualCount, expectedCount;
var searchCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'linksDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'LinksDelete': function ( linkDelete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Links title
      if ( excelData.includes ( 'A' ) ) {
        linkTitle.push ( worksheet[ excelData ].v );
      }      
      //Read Short Description
      if ( excelData.includes ( 'B' ) ) {
        linkShortDesc.push ( worksheet[ excelData ].v );
      }
    }
    if ( linkTitle.length > 1 ) {
    	for ( let getData = 1,rowCount = 1; getData < linkTitle.length; getData++ ) {
    		rowCount++;
	      linkDelete.pause ( 4000 ).useXpath ( ).
	      waitForElementVisible ( "//ul/li/a[ text( ) = 'Links' ]", 4000, false, function ( checkLinksMenu ) {
	      	if ( checkLinksMenu.value == true ) {
			      linkDelete.pause ( 4000 ).useXpath ( ).
			      //Verify the links menu in the CONTENT
			      verify.containsText ( "//ul/li/a[ text( ) = 'Links' ]", "Links" ).
			      pause ( 4000 ).
			      //Click the links menu in the CONTENT
			      click ( "//ul/li/a[ text( ) = 'Links' ]" ).
			      useCss ( ).pause ( 4000 ).
			      //Wait for the Total Count label is visible in links listing page
			      waitForElementVisible ( ".content-count>strong", 4000, false ).
			      pause ( 4000 ).
			      //Verify the Total Count label is visible in links listing page
			      verify.visible ( ".content-count>strong" ).
			      //Get current total count in the links listing page
			      getText ( '.content-count > strong', function ( currentCountResult ) {
			        if ( currentCountResult.status != -1 ) {
			          currentCount = currentCountResult.value;
			          currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
			        }		     
			        linkDelete.pause ( 4000 ).useCss ( ).			        
			        //Wait for the search field visible
			        waitForElementVisible ( ".search-field-input", 4000, false ).
			        pause ( 4000 ).
			        verify.visible ( ".search-field-input" ).
			        //Enter the search data in the field
			        setValue ( ".search-field-input", linkTitle[ getData ] ).
			        //Keys hold the control
			        keys ( linkDelete.Keys.ENTER ). 
			        //click on the search field
			        click ( ".search-field-input" ).
			        //Keys release the control
			        keys ( linkDelete.Keys.NULL ). 
			        pause ( 4000 ).
			        //Wait for the Total Count label is visible in links listing page
			        waitForElementVisible ( ".content-count>strong", 4000, false ).
			        pause ( 4000 ).
			        //Verify the Total Count label is visible in links listing page
			        verify.visible ( ".content-count>strong" ).
			        //Get Actual total count in the links listing page
			        getText ( '.content-count > strong', function ( currentCountResult ) {
			          if ( currentCountResult.status != -1 ) {
			            searchCount = currentCountResult.value;
			            searchCount = searchCount.substring ( 1, searchCount.length - 1 );
			          }
			          if ( searchCount > 0 ) {
			            linkDelete.useXpath ( ).
			            //Wait for the searched data is visible in the listing page
			            waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ linkTitle[ getData ] +"']]", 4000, false, function ( checkSearchedLst ) {
			            	if ( checkSearchedLst.value == true ) {
					            linkDelete.useXpath ( ).pause ( 4000 ).
					            //Click on the Searched data in the listing page
					            click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ linkTitle[ getData ] +"']]" ).
					            useCss().pause ( 4000 ).
					            //Wait for the Properties tab is visible in the links page
					            waitForElementVisible ( ".video-tabs > a[ href='#properties' ]", 4000, false ).
					            pause ( 4000 ).
					            //Verify the Properties tab is visible in the links page
					            verify.visible ( ".video-tabs > a[ href='#properties' ]" ).
					            pause ( 4000 ).
					            //Click on the Properties Tab
					            click ( ".video-tabs > a[ href='#properties' ]" ).           
					            pause ( 4000 ).   
							        //Verify the Short description field is visible
							        verify.visible ( "textarea[ ng-model='artifact.shortDescription' ]" ).
							        pause ( 4000 ).
							        //Clear the links Description in the field
							        clearValue ( "textarea[ ng-model='artifact.shortDescription' ]" ).
							        pause ( 4000 ).
							        //Enter the links Description in the field
							        setValue ( "textarea[ ng-model='artifact.shortDescription' ]", linkShortDesc[ getData ] ).
							        pause ( 4000 ).         
							        waitForElementVisible ( ".btn-delete > span[ ng-click='showDeleteVerification();']", 4000, false, function ( checkDeleteBtn ) {
							        	if ( checkDeleteBtn.value == true ) {
							            //Check the Delete Button.
							            linkDelete.pause ( 4000 ).
							            verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
							            pause ( 4000 ).
							            //Click on the Delete button in the Properties Tab
							            click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
							            pause ( 4000 ).
							            //Check the existance of delete confirmation dialog
							            verify.visible ( "dialog[ name=deleteVerification ]" ).
							            pause ( 4000 ).
							            //Verify the Cancel Button in Delete Dialog is visible
							            verify.visible ( ".link-secondary" ).
							            //Click Cancel Button in Delete Dialog
							            click ( ".link-secondary" ).
							            pause ( 4000 ).
							            //Verify the Delete Button in the Properties Tab is visible
							            verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
							            pause ( 4000 ).
							            //Click on the Delete button in the Properties Tab
							            click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
							            pause ( 4000 ).
							            //Check the existance of delete confirmation to delete
							            verify.visible ( "dialog[ name=deleteVerification ]" ).
							            pause ( 4000 ).
							            //Verify the delete button is visible
							            verify.visible ( "button.btn:nth-child( 2 )" ).
							            pause ( 4000 ).
							            //Click on the Delete Button in Delete Dialog box
							            click ( "button.btn:nth-child( 2 )" ).
							            pause ( 4000 ).useXpath ( ).
							            //Verify the links menu in the CONTENT
							            verify.containsText ( "//ul/li/a[ text( ) = 'Links' ]", "Links" ).
							            pause ( 4000 ).
							            //Click on the links menu in the CONTENT
							            click ( "//ul/li/a[ text( ) = 'Links' ]" ).
							            useCss ( ).pause ( 4000 ).
							            //Wait for the Total Count label is visible in links listing page
							            waitForElementVisible ( ".content-count>strong", 4000,false ).
							            //Verify the Total Count label is visible in links listing page
							            verify.visible ( ".content-count>strong" ).
							            pause ( 4000 ).
							            //Get links total count in the links listing page
							            getText ( '.content-count > strong', function ( actualCountResult ) {
							              if ( actualCountResult.status != -1 ) {
							                actualCount = actualCountResult.value;
							                actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
							                expectedCount = ( ( + currentCount ) - ( 1 ) );
							                if ( actualCount == expectedCount ) {
							                  //Write in the Excel for PASS Result and Reason
							                  linkDelete.writeToExcelPass ( 'boxxspring.xlsx', 'LinksDelete', rowCount, 4 );
							                }
							                else {
							                  //Write in the Excel for FAIL Result and Reason
							                  linkDelete.writeToExcelFail ( 'boxxspring.xlsx', 'LinksDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Added New Categories. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
							                }
							              }
							            } );
							          }
							          else {
							          	//Write in the Excel for FAIL Result and Reason
							            linkDelete.writeToExcelFail ( 'boxxspring.xlsx', 'LinksDelete', rowCount, 4, 5, "Delete button is not available in the links page" );							                
							          }
							        } );
					          }
					          else {
					          	//Write in the Excel for FAIL Result and Reason
					            linkDelete.writeToExcelFail ( 'boxxspring.xlsx', 'LinksDelete', rowCount, 4, 5, "Searched Data is not displayed in the Links Listing page " );
					          }
					        } );
			          }
			          else {
			            //Write in the Excel for Search FAIL Result and Reason
			            linkDelete.writeToExcelFail ( 'boxxspring.xlsx', 'LinksDelete', rowCount, 4, 5, "Searched Result Count,'"+ searchCount +"'" );
			          }
					    } );
						} );
					}
					else {
						//Write in the Excel for Search FAIL Result and Reason
						linkDelete.writeToExcelFail ( 'boxxspring.xlsx', 'LinksDelete', rowCount, 4, 5, "Links Menu is not displayed in the Sidebar" );						          
					}
				} );
		  }
    }	
    else {
    	//Write in the Excel for Search FAIL Result and Reason
      linkDelete.writeToExcelFail ( 'boxxspring.xlsx', 'LinksDelete', rowCount, 4, 5, "Data is not avail in the Excel sheet" );	
    }	    
    //End the Browser
    linkDelete.end ( );
  }
};
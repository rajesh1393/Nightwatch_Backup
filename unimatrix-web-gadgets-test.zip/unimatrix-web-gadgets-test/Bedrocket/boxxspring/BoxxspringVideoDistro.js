//this function is used to check the Videos distribution in the CONTENT Videos 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
var workbook1 = new Excel.Workbook ( );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'BoxxspringVideoDistro' ];
var attributionTitle = [ ];
var attributionHeadline = [ ];
var destinationName = [ ];
var resultStatus = [ ];
var currentCount, actualCount, z;
var expectedCount, destinationTempArray, searchCount;
var getData, rowCount, getData = 1;
var destinationCount, categoryCount, selectedLabelValue = 0;
module.exports = {
  tags: [ 'boxxspringVideoDistro' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'Distribution Videos': function ( videosDistribution ) {
    for ( z in worksheet ) {
      if ( z[ 1 ] === '!' ) continue;
      //Read Videos Title
      if ( z.includes ( 'A' ) ) {
        attributionTitle.push ( worksheet[ z ].v );
      }
      //Read Videos Description
      if ( z.includes ( 'B' ) ) {
        attributionHeadline.push ( worksheet[ z ].v );
      }
      //Read Destination Search Type     
      if ( z.includes ( 'C' ) ) {
        destinationName.push ( worksheet[ z ].v );
      }
    }
    if ( attributionTitle.length > 1 ) {
      videosDistribution.pause ( 4000 ).
      useXpath ( ).
      //Verify the Videos menu in the CONTENT is visible
      verify.containsText ( "//ul/li/a[ text ( ) = 'Videos']", "Videos" ).
      pause ( 4000 ).
      //Click on the Videos menu in the CONTENT
      click ( "//ul/li/a[ text ( ) = 'Videos']" ).
      useCss ( ).pause ( 4000 ).
      //Get the Current Total count in the Videos listing page
      getText ( '.content-count > strong', function ( currentCountResult ) {
        if ( currentCountResult.status !== -1 ) {
          currentCount = currentCountResult.value;
          currentCount = currentCount.substring ( 1, currentCount.length - 1 );
        }
        for ( let getData = 1, rowCount = 1; getData < attributionTitle.length; getData++ ) {
          rowCount++;
          //Wait for the List view option is visible
          var resultStatus = [ ];
          videosDistribution.pause ( 4000 ).waitForElementVisible ( ".list", 4000, false ).
          pause ( 4000 ).
          //Click on the List view option in the Videos listing page
          click ( ".list" ).
          //Wait for the Search Input Field is visible
          pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
          //Verfiy the Search Input Field is visible
          verify.visible ( ".search-field-input" ).
          //Clear the data in Search Input field 
          clearValue ( ".search-field-input" ).
          //Enter the data in Search Input field 
          setValue ( ".search-field-input", attributionTitle[ getData ] ).
          //Press Enter key
          keys ( videosDistribution.Keys.ENTER ).
          click ( ".search-field-input" ).
          //Release Enter Key
          keys ( videosDistribution.Keys.NULL ).
          pause ( 4000 ).
          //Wait for the Search Count label is visible
          waitForElementVisible ( ".content-count>strong", 4000, false ).
          //Verfiy the Search Count label is visible
          verify.visible ( ".content-count>strong" ).
          //Get the Searched data count in the Videos listing page
          getText ( '.content-count > strong', function ( searchCountResult ) {
            if ( searchCountResult.status !== -1 ) {
              var searchCount = searchCountResult.value;
              searchCount = searchCount.substring ( 1, searchCount.length - 1 );
            }            
            videosDistribution.pause ( 4000 ).useXpath ( ).
            //Wait for the Searched data is visible in the Videos listing page
            waitForElementVisible ( " ( //h2[@class='ng-binding'] )[1]", 4000, false ).
            pause ( 4000 ).
            //Verify the Searched data is visible in the Videos listing page
            verify.visible ( " ( //h2[@class='ng-binding'] )[1]" ).
            pause ( 4000 ).
            //Click on the Searched data in the Videos listing page
            click ( " ( //h2[@class='ng-binding'] )[1]" ).
            useCss ( ).pause ( 4000 )
            videosDistribution.pause ( 4000 ).
            //Verify the Content Tab is visible in the Videos page
            verify.visible ( ".video-tabs > a[ href='#content']" ).
            //Click on the Content Tab in the Videos page
            click ( ".video-tabs > a[ href='#content']" ).
            pause ( 4000 ).
            //Wait for the Headline field is visible in the Videos page
            waitForElementVisible ( ".text-input-headline", 4000, false ).
            //Clear the data in the Headline field in the Videos page
            clearValue ( ".text-input-headline" ).
            //Enter the data in the Headline field in the Videos page
            setValue ( ".text-input-headline", attributionHeadline[ getData ] ).
            pause ( 4000 ).
            //Verify the Save button is visible
            verify.visible ( ".btn-active" ).
            pause ( 4000 ).
            //Click on the Save button
            click ( ".btn-active" ).
            pause ( 4000 ).
            //Verify the Properties Tab is visible in the Videos page
            verify.visible ( ".video-tabs a[ href='#distribution']" ).
            pause ( 4000 ).
            //Click on the Properties Tab in the Videos Page
            click ( ".video-tabs a[ href='#distribution']" ).
            pause ( 4000 ).
            //Wait for the Add Distribution button is visible in Distribution Tab page
            waitForElementVisible ( ".distro-button", 4000, false ).
            pause ( 4000 ).
            //Click on the Add Distribution button in Distribution Tab page
            click ( ".distro-button" ).
            pause ( 4000 )   
            var splitUrl = [ ];            
            var categoryTempArray = [ ];
            var destinationTemp = destinationName[ getData ];
            splitUrl = destinationTemp.split(':'); 
            var destinationTempArray = destinationTemp.split(':');
            for ( let destinationCount = 0; destinationCount < destinationTempArray.length; destinationCount++ ) {
              var splitDestination = splitUrl[ destinationCount ].split(','); 
              categoryTempArray[ destinationCount ] = splitDestination[ 0 ].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
              //Wait for the Toggle filter dropdown is visible
              videosDistribution.useCss ( ).waitForElementVisible ( "a.ng-binding[ng-click='toggleFilterDropdown();']", 4000, false ).
              pause ( 4000 ).
              //Verify the Toggle filter dropdown is visible
              verify.visible ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
              pause ( 4000 ).
              //Click on the Toggle filter dropdown option
              click ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
              pause ( 4000 ).useXpath ( ).
              //Wait for the options in the list should be visible
              waitForElementVisible ( "//ul/li/a[contains( .,'"+ categoryTempArray[ destinationCount ] +"' )]", 4000, false, function ( destinationOption ) {
                if ( destinationOption.value === true ) {
                  var splitDestination = splitUrl[ destinationCount ].split ( ',' ); 
                  var destintionsList = splitDestination[1].split ( ";" )
                  videosDistribution.pause ( 4000 ).useXpath ( ).
                  //Verify the options in the listing is visible
                  verify.visible ( "//ul/li/a[contains( .,'"+ categoryTempArray[ destinationCount ] +"' )]" ).
                  pause ( 4000 ).
                  //Click on the options in the dropdown list
                  click ( "//div[@class='field-input filter-destinations-dropdown']/div/ul/li/a[contains( .,'"+ categoryTempArray[ destinationCount ] +"' )]" ).
                  pause ( 4000 )
                  for ( let categoryCount = 0; categoryCount < destintionsList.length; categoryCount++ ) {
                    videosDistribution.useXpath ( ).pause ( 4000 ).
                    waitForElementVisible ( "//div/div[@class='destinations-search-filter']/div/div/div/div/input", 4000, false ).
                    pause ( 4000 ).
                    //Verify the Saerch -Input Field is visible
                    verify.visible ( "//div/div[@class='destinations-search-filter']/div/div/div/div/input" ).
                    pause ( 4000 ).
                    //Clear the data in the Saerch -Input Field
                    clearValue ( "//div/div[@class='destinations-search-filter']/div/div/div/div/input" ).
                    pause ( 4000 ).
                    //Enter the data in the Saerch -Input Field
                    setValue ( "//div/div[@class='destinations-search-filter']/div/div/div/div/input", destintionsList[ categoryCount ] ).
                    pause ( 4000 ).useXpath ( ).
                    //Wait for the searched data in listing down is visible
                    waitForElementVisible ( "//label[@class='label-left ng-binding'][contains( .,'"+ destintionsList[ categoryCount ] +"' )]", 4000, false ).
                    pause ( 4000 ).
                    //Click on the Searched data in the distribution page
                    click ( "//label[@class='label-left ng-binding'][ contains( .,'"+ destintionsList[ categoryCount ] +"' )]" ).
                    useCss ( ).pause ( 4000 )
                    selectedLabelValue++;
                  }
                }
              } );
            }
            videosDistribution.pause ( 4000 ).
            //Wait for the Next button is visible
            waitForElementVisible ( ".btn-next", 4000, false ).
            //Click on the Next Button in the Distribution button
            click ( ".btn-next" ).
            //Get the Text for Selected Destination count in the Distribution page
            getText ( "h3.distributions-title.ng-binding", function ( getSelectedData ) {
              var actualSelectedLabelData = getSelectedData.value;
              var expectedSelectedLabelData = "Selected Destinations "+ selectedLabelValue;
              //Compare the Actual and Expected data in the Distribution page
              if ( actualSelectedLabelData == expectedSelectedLabelData ) {
                videosDistribution.pause ( 4000 ).useCss ( ).
                //Verify the Cancel button in the Distribution page
                verify.visible ( ".cancel-distribution" ).
                pause ( 4000 ).
                //Verify the All Post button is visible in the Distribution page
                verify.visible ( "a.btn-next:nth-child( 2 )" ).
                pause ( 4000 ).
                //Click on the All Post button in the Distribution page
                click ( "a.btn-next:nth-child( 2 )" ).
                pause ( 4000 )
                for ( let getData = 3; getData < selectedLabelValue + 3; getData++ ) {                 
                  //Get the Value for Destination posted in the Distribution page
                  videosDistribution.pause ( 4000 ).getValue ( "ul.post-list li>.ng-scope", function ( allPost ) {              
                    if ( allPost.status == 0 ) {                      
                      videosDistribution.pause ( 5000 ).useCss ( ).
                      //Wait for the Distributed post is visible in the distribution page
                      waitForElementVisible ( "li.completed:nth-child("+ getData +")>span>ng-include>div.description>a", 4000, false, function ( postResult ) {
                        if ( postResult.value == true ) {
                          videosDistribution.pause ( 4000 ).
                          //Get the Distributed post url in the distribution page
                          getText ( "li.completed:nth-child("+ getData +")>span>ng-include>div.description>a", function ( urlResult ) {
                            if ( urlResult.status == 0 ) {
                              //Write in the Excel as PASS Results
                              videosDistribution.pause ( 4000 );
                              resultStatus.push ( "PASS" );
                            }
                            else {
                              videosDistribution.pause ( 4000 );
                              resultStatus.push ( "FAIL" );
                            }
                          } );
                        }
                        else {
                          //Write in the Excel as FAIL Results and Reason
                          videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'BoxxspringVideoDistro', rowCount, 5, 6, "Completed Post is not displayed" );
                        }
                      } );
                    }
                    else {
                      //Write in the Excel as FAIL Results and Reason
                      videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'BoxxspringVideoDistro', rowCount, 5, 6, "Post List is not visible" );
                    }
                  } );
                }
                  videosDistribution.pause ( 4000 ).getValue ( "ul.post-list li>.ng-scope", function ( allPostResult ) {
                  if ( resultStatus.indexOf ( 'FAIL' ) >= 0 ) {
                    videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'BoxxspringVideoDistro', rowCount, 5, 6, "Completed Post URL is not displayed" );
                  }
                  else if ( resultStatus.length == 0 ) {
                  }
                  else {
                    videosDistribution.writeToExcelPass ( 'boxxspring.xlsx', 'BoxxspringVideoDistro', rowCount, 5 );
                  }
                  if ( resultStatus.indexOf ( 'FAIL' ) || resultStatus.indexOf ( 'PASS' ) >= 0 ) {
                    resultStatus.length = 0;
                  }
                } );
              }
              else {
                videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'BoxxspringVideoDistro', rowCount, 5, 6, "Selected Destinations count is mismatch: Actual label count'"+ actualSelectedLabelData +"' and Expected label count'"+ expectedSelectedLabelData +"'");
              }
            } );
            videosDistribution.pause ( 4000 ).useXpath ( ).
            //Verify the Videos menu in the CONTENT is visible
            verify.containsText ( "//ul/li/a[ text ( ) = 'Videos']", "Videos" ).
            pause ( 4000 ).
            //Click on the Videos menu in the CONTENT
            click ( "//ul/li/a[ text ( ) = 'Videos']" ).
            useCss ( )            
          } );
        }
      } );
    }    
    //End the Browser
    videosDistribution.end ( );
  }
};
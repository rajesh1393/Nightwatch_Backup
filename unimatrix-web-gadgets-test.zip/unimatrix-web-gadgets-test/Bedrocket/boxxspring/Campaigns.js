//this function is for add, edit, delete the Campaigns
module.exports = {
  tags: [ 'Campaigns' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'boxxspring.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'CampaignsAdd': function ( campaignsAdd ) {
    var excel = campaignsAdd.globals.excelCol;
    campaignsAdd.useXpath ( ).
    //Wait and click the monetization option in CONTENT
    waitForElementVisible ( "//div[6]/span[@class='side-dropdown-icon']", 3000, false, function ( monetization ) {
      if ( monetization.value == true ) {
        //Click on the monetization option in CONTENT
        campaignsAdd.pause ( 3000 ).
        moveToElement ( "//div[6]/span[@class='side-dropdown-icon']", 0, 0 ).
        click ( "//div[6]/span[@class='side-dropdown-icon']" );
        //loop the 'n' number of excel input
        for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
          var excelRow = 1;
          campaignsAdd.campaignState ( 'CampaignsAdd', excel.H[excelColumn], excelRow ).
          useCss ( ).
          //get the count before adding the campaigns
          getText ( '.content-count > strong', function ( countBeforeAdd ) {
            currentCount = countBeforeAdd.value;
            console.log ( "countBeforeAdd", currentCount );
            campaignsAdd.click ( ".btn.btn-primary.long.ng-scope" ).
            pause ( 5000 ).
            //Add the campaigns data from the excel using custom commands
            addCampaigns ( 'CampaignsAdd', excelRow, excelColumn ).
            useCss ( ).pause ( 15000 ).
            //get the count after adding the campaigns
            getText ( '.content-count > strong', function ( countAfterAdd ) {
              var countBfreAdd = parseInt ( currentCount ) + 1;
              console.log ( "countAfterAdd", countAfterAdd.value );
              if ( countAfterAdd.value == countBfreAdd ) {
                campaignsAdd.writeToExcelPass ( 'boxxspring.xlsx', 'CampaignsAdd', ++excelRow, 9 );
              }
              else {
                this.verify.fail ( countAfterAdd.value, countBfreAdd, 'Fail to add the Campaigns in Portal' );
                campaignsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsAdd', ++excelRow, 9, 10, "ActualResult: '" + countAfterAdd.value + ". ExpectedResult: '" + countBfreAdd + "' ( Fail to add the Campaigns in Portal" );
              }
            } );
          } );
        }
      }
      else {
        //write to fail status as timeout issue while clicking All option
        this.verify.fail ( monetization.value, true, 'Timeout loading issue in clicking the Monetization menu in Content' );
        campaignsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsAdd', ++excelRow, 9, 10, "ActualResult: '" + monetization.value + ". ExpectedResult: 'true' ( Timeout loading issue in clicking the Monetization menu in Content" );
      }
    } );
  },
  'CampaignsEdit': function ( campaignsEdit ) {
    var excel = campaignsEdit.globals.excelCol;
    for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
      var excelRow = 1;
      //check the Active/ Inactive status using custom commands
      campaignsEdit.campaignState ( 'CampaignsEdit', excel.H[excelColumn], excelRow ).
      pause ( 5000 ).useCss ( ).
      //get the count before edit the campaigns
      getText ( '.content-count > strong', function ( countBeforeEdit ) {
        currentCount = countBeforeEdit.value;
        console.log ( "countBeforeEdit", currentCount );
        campaignsEdit.pause ( 5000 ).useXpath ( ).
        //check the search textbox element is visible
        waitForElementPresent ( "//div[@collections='collections']", 5000, false, function ( campaignsSearch ) {
          if ( campaignsSearch.value != false ) {
            campaignsEdit.clearValue ( '//div[@class="suggestion-dropdown-wrap"]/input' ).
            setValue ( '//div[@class="suggestion-dropdown-wrap"]/input', excel.A[excelColumn] ).
            pause ( 5000 );
            if ( currentCount != '0' ) {
              campaignsEdit.
              //click the specific search data from the campaigns to edit
              waitForElementPresent ( "//h2[text ()[normalize-space(.)='" + excel.A[excelColumn] + "']]", 5000, false, function ( searchContent ) {
                if ( searchContent.value != false ) {
                  campaignsEdit.click ( "//h2[text ()[normalize-space(.)='" + excel.A[excelColumn] + "']]" ).
                  pause ( 5000 ).
                  addCampaigns ( 'campaignsEdit', excelRow, excelColumn );
                  campaignsEdit.
                  //check the Active/ Inactive status using custom commands
                  campaignState ( 'CampaignsEdit', excel.I[excelColumn], excelRow ).
                  pause ( 15000 ).useCss ( ).
                  //get the count of campaigns before edit the data
                  getText ( '.content-count > strong', function ( countAfterEdit ) {
                    var countBfreEdit = parseInt ( currentCount );
                    console.log ( "countAfterEdit", countAfterEdit.value );
                    if ( countAfterEdit.value == countBfreEdit ) {
                      //write to excel as "pass" if the campaigns edit successfully
                      campaignsEdit.writeToExcelPass ( 'boxxspring.xlsx', 'CampaignsEdit', ++excelRow, 9 );
                    }
                    else {
                      //write to excel as "fail" if the campaigns unable to edit
                      this.verify.fail ( countAfterEdit.value, countBfreEdit, 'Fail to edit the Campaigns in Portal' );
                      campaignsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsEdit', ++excelRow, 9, 10, "ActualResult: '" + countAfterEdit.value + ". ExpectedResult: '" + countBfreEdit + "' ( Fail to edit the Campaigns in Portal" );
                    }
                  } );
                }
                else {
                  //write to fail status as no results found while search the content title
                  this.verify.fail ( undefined, undefined, 'No result found while search' );
                  campaignsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsEdit', ++excelRow, 9, 10, "No result found while search" );
                }
              } );
            }
            else {
              campaignsEdit.
              waitForElementPresent ( "//div[@class='empty-page-container']", 5000, false, function ( searchResult ) {
                if ( searchResult.value == false ) {
                  //write to fail status as no results found while search the content title
                  this.verify.fail ( undefined, undefined, 'No result found while search' );
                  campaignsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsEdit', ++excelRow, 9, 10, "No result found while search" );
                }
                else {
                  //write to fail status as no results found while search the content title
                  this.verify.fail ( searchResult.value, false, 'Search functionality in Campaigns is not working as expected' );
                  campaignsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsEdit', ++excelRow, 9, 10, "Search functionality in Campaigns is not working as expected" );
                }
              } );
            }
          }
          else {
            //write to fail status as no results found while search the content title
            this.verify.fail ( campaignsSearch.value, true, 'Timeout loading issue in search option in Campaigns' );
            campaignsEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsEdit', ++excelRow, 9, 10, "ActualResult: '" + campaignsSearch.value + ". ExpectedResult: 'true' ( Timeout loading issue in search option in Campaigns " );
          }
        } );
      } );
    }
  },
  'CampaignsDelete': function ( campaignsDelete ) {
    var excel = campaignsDelete.globals.excelCol;
    for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
      var excelRow = 1;
      //check the campaigns state as Active/Inactive
      campaignsDelete.campaignState ( 'CampaignsDelete', excel.B[excelColumn], excelRow ).
      pause ( 5000 ).useCss ( ).
      //get the count before delete the campaigns 
      getText ( '.content-count > strong', function ( countBeforeDel ) {
        currentCount = countBeforeDel.value;
        console.log ( "countBeforeDelete", currentCount );
        campaignsDelete.pause ( 5000 ).useXpath ( ).
        //check the search textbox element visibility
        waitForElementPresent ( '//div[@class="suggestion-dropdown-wrap"]/input', 5000, false, function ( campaignsSearch ) {
          if ( campaignsSearch.value != false ) {
            campaignsDelete.clearValue ( '//div[@class="suggestion-dropdown-wrap"]/input' ).
            setValue ( '//div[@class="suggestion-dropdown-wrap"]/input', excel.A[excelColumn] ).
            pause ( 5000 );
            //check the search data return the exact results
            if ( currentCount != '0' ) {
              campaignsDelete.
              waitForElementPresent ( "//h2[text()[normalize-space(.)='" + excel.A[excelColumn] + "']]", 5000, false, function ( searchContent ) {
                if ( searchContent.value != false ) {
                  campaignsDelete.
                  click ( "//h2[text()[normalize-space(.)='" + excel.A[excelColumn] + "']]" ).
                  pause ( 5000 ).
                  waitForElementVisible ( "//a[contains(.,'Delete')]", 5000, false, function ( delCampaigns ) {
                    if ( delCampaigns.value == true ) {
                      //click the delete button in the campaigns
                      campaignsDelete.click ( "//a[contains(.,'Delete')]" ).
                      click ( "//button[contains(.,'Delete')]" ).
                      //Camapigns state using custom commands
                      campaignState ( 'CampaignsDelete', excel.B[excelColumn], excelRow ).
                      pause ( 15000 ).useCss ( ).
                      getText ( '.content-count > strong', function ( countAfterDel ) {
                        var countBfreDel = parseInt ( currentCount ) - 1;
                        if ( countAfterDel.value == countBfreDel ) {
                          campaignsDelete.writeToExcelPass ( 'boxxspring.xlsx', 'CampaignsDelete', ++excelRow, 3 );
                        }
                        else {
                          campaignsDelete.verify.fail ( countAfterDel.value, countBfreDel, 'Fail to delete the Campaigns in Portal' );
                          campaignsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsDelete', ++excelRow, 3, 4, "ActualResult: '" + countAfterDel.value + ". ExpectedResult: '" + countBfreDel + "' ( Fail to delete the Campaigns in Portal" );
                        }
                      } );
                    }
                    else {
                      campaignsDelete.verify.fail ( delCampaigns.value, true, 'Timeout issue while inspecting delete button in Campaigns' );
                      campaignsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsDelete', ++excelRow, 3, 4, "ActualResult: '" + delCampaigns.value + ". ExpectedResult: 'true' ( Timeout issue while inspecting delete button in Campaigns" );
                    }
                  } );
                }
                else {
                  //write to fail status as no results found while search the content title
                  this.verify.fail ( undefined, undefined, 'No result found while search' );
                  campaignsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsDelete', ++excelRow, 3, 4, "No result found while search" );
                }
              } );
            }
            else {
              campaignsDelete.
              waitForElementVisible ( "//div[@class='empty-page-container']/div[1]", 5000, false, function ( searchResult ) {
                if ( searchResult.value == "No results found" ) {
                  //write to fail status as no results found while search the content title
                  this.verify.fail ( undefined, undefined, 'No result found while search' );
                  campaignsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsDelete', ++excelRow, 3, 4, "No result found while search" );
                }
                else {
                  //write to fail status as no results found while search the content title
                  this.verify.fail ( searchResult.value, "No results found", 'Search functionality in Campaigns is not working as expected' );
                  campaignsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsDelete', ++excelRow, 3, 4, "Search functionality in Campaigns is not working as expected" );
                }
              } );
            }
          }
          else {
            //write to fail status as no results found due to timeout issue
            this.verify.fail ( campaignsSearch.value, true, 'Timeout loading issue in search option in Campaigns' );
            campaignsDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CampaignsDelete', ++excelRow, 3, 4, "ActualResult: '" + campaignsSearch.value + ". ExpectedResult: 'true' ( Timeout loading issue in search option in Campaigns " );
          }
        } );
      } );
    }
  },
};
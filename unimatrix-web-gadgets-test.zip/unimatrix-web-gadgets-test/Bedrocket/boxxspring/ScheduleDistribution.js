//this function is used to check the Videos distribution in the CONTENT Videos 
'use strict';
var xlsx = require ( 'xlsx' );
var datetime = require ( 'node-datetime' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
var workbook1 = new Excel.Workbook ( );
if ( typeof require != 'undefined' )  xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets['ScheduleDistribution'];
var storyTitle = [ ];
var distroName = [ ];
var inputValue = [ ];
var inputNeverValue = [ ];
var currentCount, actualCount, excelData;
var expectedCount, destinationTemp_array, searchCount;
var getData = 1;
var destinationCount, categoryCount, selectedLabelValue, currentNeverMonth = 0;
var checkDates = 0;
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
module.exports = {
  tags: ['distributionVideos'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DistributionVideos': function ( videosDistribution ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' )  continue;
      //Read Videos Title
      if ( excelData.includes ( 'A' ) ) {
        storyTitle.push ( worksheet[excelData].v );
      }
      //Read Videos Description
      if ( excelData.includes ( 'B' ) ) {
        distroName.push ( worksheet[excelData].v );
      }
      //Read Destination Search Type     
      if ( excelData.includes ( 'C' ) ) {
        inputValue.push ( worksheet[excelData].v );
      }
      //Read Destination Search Type     
      if ( excelData.includes ( 'D' ) ) {
        inputNeverValue.push ( worksheet[excelData].v );
      }
    }
    if ( storyTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < storyTitle.length; getData++ ) {
        console.log ( "storyTitle.length", storyTitle.length ) 
        rowCount++;
        var destinationTemp = distroName[getData];
        var destinationTemp_array = destinationTemp.split ( ',' );
        videosDistribution.pause ( 4000 ).useXpath ( ).
        //Wait for Videos menu is visible in the CONTENT sidebar
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Videos']", 9000, false, function ( checkVideosMenu ) {
          if ( checkVideosMenu.value == true ) {
            videosDistribution.pause ( 4000 ).useXpath ( ).
            //Click on the Videos menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Videos']" ) 
            var resultStatus = [ ];
            videosDistribution.pause ( 4000 ).useCss ( ).			        
			      //Wait for the search field visible
			      waitForElementVisible ( ".search-field-input", 4000, false ).
			      pause ( 4000 ).
			      //Enter the search data in the field
			      setValue ( ".search-field-input", storyTitle[getData] ).
			      pause ( 3000 ).
			      //Keys hold the control
			      keys ( videosDistribution.Keys.ENTER )
            //Wait for the Search Input Field is visible
            videosDistribution.pause ( 4000 ).useXpath ( ).
            getLocationInView ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ storyTitle[getData] +"']]" ).
            pause ( 4000 ).
            waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ storyTitle[getData] +"']]", 9000, false, function ( checkSearchedData ) {
            	if ( checkSearchedData.value == true ) {
		            videosDistribution.pause ( 4000 ).useXpath ( ).
		            click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ storyTitle[getData] +"']]" ).
		            useCss ( ).pause ( 4000 ).
		            //Verify the Properties Tab is visible in the Videos page
		            verify.visible ( ".video-tabs a[ href='#distribution']" ).
		            pause ( 4000 ).
		            //Click on the Properties Tab in the Videos Page
		            click ( ".video-tabs a[ href='#distribution']" ).
		            pause ( 4000 ).
		            //Wait for the Add Distribution button is visible in Distribution Tab page
		            waitForElementVisible ( ".distro-button", 4000, false ).
		            pause ( 4000 ).
		            //Click on the Add Distribution button in Distribution Tab page
		            click ( ".distro-button" ).
		            //Wait for the Toggle filter dropdown is visible
		            useCss ( ).waitForElementVisible ( "a.ng-binding[ng-click='toggleFilterDropdown();']", 4000, false ).
		            pause ( 4000 ).
		            //Click on the Toggle filter dropdown option
		            click ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
		            pause ( 4000 ).useXpath ( ).
		            //Wait for the options in the list should be visible
		            waitForElementVisible ( "//ul/li/a[contains(.,'"+ destinationTemp_array[0] +"')]", 4000, false, function ( destinationOption ) {
		              if ( destinationOption.value == true ) {
		                videosDistribution.pause ( 4000 ).useXpath ( ).
		                //Click on the options in the dropdown list
		                click ( "//div[@class='field-input filter-destinations-dropdown']/div/ul/li/a[contains(.,'"+ destinationTemp_array[0] +"')]" ).
		                pause ( 4000 ).useXpath ( ).
		                //Wait for search filter is visible in the page
		                waitForElementVisible ( "//div/div[@class='destinations-search-filter']/div/div/div/div/input", 4000, false ).
		                pause ( 4000 ).
		                //Clear the data in the Saerch -Input Field
		                clearValue ( "//div/div[@class='destinations-search-filter']/div/div/div/div/input" ).
		                pause ( 4000 ).
		                //Enter the data in the Saerch -Input Field
		                setValue ( "//div/div[@class='destinations-search-filter']/div/div/div/div/input", destinationTemp_array[1] ).
		                pause ( 4000 ).useXpath ( ).
		                //Wait for the searched data in listing down is visible
		                waitForElementVisible ( "//label[@class='label-left ng-binding'][contains(.,'"+ destinationTemp_array[1] +"')]", 4000, false ).
		                pause ( 4000 ).
		                //Click on the Searched data in the distribution page
		                click ( "//label[@class='label-left ng-binding'][ contains(.,'"+ destinationTemp_array[1] +"')]" ).		              
				            pause ( 4000 ).
				            getLocationInView ( "//div/a[contains(.,'Next')]" ).
				            pause ( 4000 ).
				            waitForElementVisible ( "//div/a[contains(.,'Next')]",9000, false ).
				            pause ( 4000 ).
				            click ( "//div/a[contains(.,'Next')]" ).
				            pause ( 4000 ).
				            waitForElementVisible ( "//div[1]/ul/li/ng-include/div/div", 7000, false ).
				            pause ( 4000 ).
				            getLocationInView ( "//div[1]/div[4]/div[1]/div" ).
				            pause ( 4000 ).
				            getText ( "//div[1]/div[4]/div[1]/div", function ( checkPostText ) {
				              if ( checkPostText.value != "Immediately" ) {
				                var dt = datetime.create ( );
				                var formatted = dt.format ( 'Y/m/d,I:M p' );
				                console.log ( "date:", formatted ) 
				                var currentDateTime = formatted.split(',');
				                console.log ( "inputValue[getData]", inputValue[getData] ) 
				                var splitDateTime = inputValue[getData];
				                var separateDateTime = splitDateTime.split(',');
				                console.log ( "separateDateTime", separateDateTime ) 
				                var splitDate = separateDateTime[0].split ( '/' );
				                var splitTime = separateDateTime[1].split ( '-' );
				                console.log ( "splitDate", splitDate ) 
				                console.log ( "splitTime", splitTime ) 
				                var convertedMonth = ( months.indexOf ( splitDate[1] ) ) + 1;
				                console.log ( "convertedMonth", convertedMonth ) 
				                if ( ( convertedMonth == 10 ) || ( convertedMonth == 11 ) || ( convertedMonth == 12 ) ) {		                	
				                }
				                else {
				                  convertedMonth = "0" + convertedMonth;
				                }
				                var mergeDate = splitDate[2] + "/" + convertedMonth + "/" + splitDate[0]
				                var mergeTime = splitTime[0] + " " + splitTime[1]
				                var splitHrSec = splitTime[0].split(':');
				                console.log ( "mergeDate", mergeDate ) 
				                console.log ( "mergeDate", mergeTime ) 
				                if ( ( currentDateTime[0] < mergeDate ) || ( currentDateTime[0] = mergeDate && currentDateTime[1] < mergeTime ) ) {
				                  console.log ( "PASSSED Date" ) 
				                  videosDistribution.pause ( 4000 ).click ( "//div[1]/div[4]/div[1]/div/a/i" ).
				                  pause ( 4000 ).
				                  waitForElementVisible ( "//div[4]/div[1]/date-picker/div", 9000, false, function ( checkCalendar ) {
				                    if ( checkCalendar.value == true ) {
				                      for ( let i = 1; i <= convertedMonth; i++ ) {
				                        videosDistribution.pause ( 4000 ).
				                        waitForElementVisible ( "//div[1]/div[4]/div[1]/label", 9000, false, function ( checkLabel ) {
				                          if ( checkLabel.value == true ) {
				                            var calDate = splitDate[1] + " " + splitDate[2];
				                            calDate = calDate.toUpperCase( );
				                            console.log ( "calDate:", calDate ) 
				                            console.log ( "checkDates:", calDate ) 
				                            if ( checkDates != calDate ) {
				                              videosDistribution.pause ( 4000 ).
				                              getText ( "//div[4]/div[1]/date-picker/div/div[1]/header/h2", function ( checkCurrentMonth ) {
				                                console.log ( "calDate", calDate ) 
				                                console.log ( "checkCurrentMonth.value", checkCurrentMonth.value ) 
				                                checkDates = checkCurrentMonth.value
				                                if ( checkDates == calDate ) {
				                                  videosDistribution.pause ( 4000 ).
				                                  getLocationInView ( "//div[4]/div[1]/date-picker/div/div[1]/table/tbody/tr/td[text( ) ='"+ splitDate[0] +"']" ).
				                                  pause ( 4000 ).
				                                  click ( "//div[4]/div[1]/date-picker/div/div[1]/table/tbody/tr/td[text( ) ='"+ splitDate[0] +"']" ).
				                                  pause ( 4000 ).
				                                  waitForElementVisible ( "//div[1]/div[4]/div[1]/date-picker/div/div[@class='time-field']", 7000, false, function ( checkTimeslot ) {
				                                    if ( checkTimeslot.value == true ) {
				                                      videosDistribution.pause ( 4000 ).
				                                      getLocationInView ( "//div[4]/div[1]/date-picker/div/div[2]/input[1]" ).
				                                      pause ( 4000 ).
				                                      clearValue ( "//div[4]/div[1]/date-picker/div/div[2]/input[1]" ).
				                                      pause ( 4000 ).
				                                      setValue ( "//div[4]/div[1]/date-picker/div/div[2]/input[1]", splitHrSec[0] ).
				                                      pause ( 4000 ).
				                                      getLocationInView ( "//div[4]/div[1]/date-picker/div/div[2]/input[2]" ).
				                                      pause ( 4000 ).
				                                      clearValue ( "//div[4]/div[1]/date-picker/div/div[2]/input[2]" ).
				                                      pause ( 4000 ).
				                                      setValue ( "//div[4]/div[1]/date-picker/div/div[2]/input[2]", splitHrSec[1] ).
				                                      getText ( "//div[1]/div[4]/div[1]/date-picker/div/div[2]/button", function ( checkMerdian ) {
				                                        if ( checkMerdian.value != splitTime[1] ) {
				                                          videosDistribution.pause ( 4000 ).
				                                          click ( "//div[1]/div[4]/div[1]/date-picker/div/div[2]/button" ).
				                                          pause ( 3000 ) 
				                                        }
				                                        videosDistribution.pause ( 4000 ).
				                                        getLocationInView ( "//div[4]/div[1]/date-picker/div/div[3]/a[2]" ).
				                                        pause ( 4000 ).
				                                        click ( "//div[4]/div[1]/date-picker/div/div[3]/a[2]" ).
				                                        pause ( 4000 ).
				                                        getText ( "//div/div[1]/div[4]/div[1]/div/span", function ( checkChangeDate ) {
				                                          var changedFormat = splitDate[1] + " " + splitDate[0] + "," + " " + splitDate[2] + " at " + mergeTime
				                                          console.log ( "ChangedFormat", changedFormat ) 
				                                          if ( checkChangeDate.value == changedFormat ) {
				                                            console.log ( "Last Run" ) 
				                                          }
				                                          else {
				                                            console.log ( "Last FAil", checkChangeDate.value ) 
				                                            console.log ( "Last FAil,changedFormat", changedFormat ) 
				                                          }
				                                        } );
				                                      } );
				                                    }
				                                    else {
																							//Write in the Excel as FAIL Results and Reason
				                                			videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Time slot is not displayed in the post" );
				                                    }
				                                  } );
				                                }
				                                else {
				                                  videosDistribution.pause ( 4000 ).
				                                  waitForElementVisible ( "//div[1]/date-picker/div/div[1]/header/a[2]/i", 9000, false ).
				                                  pause ( 4000 ).
				                                  click ( "//div[1]/date-picker/div/div[1]/header/a[2]/i" ) 
				                                }
				                              } );
				                            }
				                          }
				                          else {
				                          	//Write in the Excel as FAIL Results and Reason
				                            videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Label is not displayed in the post" );
				                          }
				                        } );
				                      }
				                    }
				                    else {
				                    	//Write in the Excel as FAIL Results and Reason
				                      videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Calendar is not displayed in the Post" );        
				                    }
				                  } );
				                }
				                else {
				                  console.log ( "FAILED" ) 
				                }

				              }
				              else {
				                console.log ( "Failed to loop in" ) 
				              }
				              videosDistribution.pause ( 4000 ).
				              getText ( "//div[1]/div[4]/div[2]/div", function ( checkNeverText ) {
				                if ( checkNeverText.value != "Never" ) {
				                  var splitNeverDateTime = inputNeverValue[getData];
				                  var separateNeverDateTime = splitNeverDateTime.split(',');
				                  console.log ( "separateNeverDateTime", separateNeverDateTime ) 
				                  var splitNeverDate = separateNeverDateTime[0].split('/');
				                  var splitNeverTime = separateNeverDateTime[1].split('-');
				                  console.log ( "splitNeverDate", splitNeverDate ) 
				                  console.log ( "splitNeverTime", splitNeverTime ) 
				                  var convertedMonthNever = ( months.indexOf ( splitNeverDate[1] ) ) + 1;
				                  console.log ( "convertedMonthNever", convertedMonthNever ) 
				                  if ( ( convertedMonthNever == 10 ) || ( convertedMonthNever == 11 ) || ( convertedMonthNever == 12 ) ) {}
				                  else {
				                    convertedMonthNever = "0" + convertedMonthNever;
				                  }
				                  var mergeNeverDate = splitNeverDate[2] + "/" + convertedMonthNever + "/" + splitNeverDate[0]
				                  var mergeNeverTime = splitNeverTime[0] + " " + splitNeverTime[1]
				                  var splitNeverHrSec = splitNeverTime[0].split ( ':' );
				                  console.log ( "mergeNeverDate", mergeNeverDate ) 
				                  console.log ( "mergeNeverTime", mergeNeverTime ) 
				                  if ( ( mergeDate < mergeNeverDate ) || ( mergeDate = mergeNeverDate && mergeTime < mergeNeverTime ) ) {
				                    console.log ( "PASSSED Date" ) 
				                    videosDistribution.pause ( 4000 ).click ( "//div[1]/div[4]/div[2]/div/a/i" ).
				                    pause ( 4000 ).
				                    waitForElementVisible ( "//div[4]/div[2]/date-picker/div", 9000, false, function ( checkNeverCalendar ) {
				                      if ( checkNeverCalendar.value == true ) {
				                        for ( let i = 1; i <= convertedMonthNever; i++ ) {
				                          videosDistribution.pause ( 4000 ).
				                          waitForElementVisible ( "//div[1]/div[4]/div[1]/label", 9000, false, function ( checkNeverLabel ) {
				                            if ( checkNeverLabel.value == true ) {
				                              var calNeverDate = splitNeverDate[1] + " " + splitNeverDate[2];
				                              calNeverDate = calNeverDate.toUpperCase( );
				                              console.log ( "calNeverDate:", calNeverDate ) 
				                              console.log ( "currentNeverMonth:", currentNeverMonth ) 
				                              if ( currentNeverMonth != calNeverDate ) {
				                                videosDistribution.pause ( 4000 ).
				                                getText ( "//div[4]/div[2]/date-picker/div/div[1]/header/h2", function ( checkNeverCurrentMonth ) {
				                                  console.log ( "calNeverDate IN", calNeverDate ) 
				                                  console.log ( "checkNeverCurrentMonth.value", checkNeverCurrentMonth.value ) 
				                                  var currentNeverMonth = checkNeverCurrentMonth.value
				                                  if ( currentNeverMonth == calNeverDate ) {
				                                    videosDistribution.pause ( 4000 ).
				                                    getLocationInView ( "//div[4]/div[2]/date-picker/div/div[1]/table/tbody/tr/td[text( ) ='"+ splitNeverDate[0] +"']" ).
				                                    pause ( 4000 ).
				                                    click ( "//div[4]/div[2]/date-picker/div/div[1]/table/tbody/tr/td[text( ) ='"+ splitNeverDate[0] +"']" ).
				                                    pause ( 4000 ).
				                                    waitForElementVisible ( "//div[1]/div[4]/div[2]/date-picker/div/div[@class='time-field']", 7000, false, function ( checkNeverTimeslot ) {
				                                      if ( checkNeverTimeslot.value == true ) {
				                                        videosDistribution.pause ( 4000 ).
				                                        getLocationInView ( "//div[4]/div[2]/date-picker/div/div[2]/input[1]" ).
				                                        pause ( 4000 ).
				                                        clearValue ( "//div[4]/div[2]/date-picker/div/div[2]/input[1]" ).
				                                        pause ( 4000 ).
				                                        setValue ( "//div[4]/div[2]/date-picker/div/div[2]/input[1]", splitNeverHrSec[0] ).
				                                        pause ( 4000 ).
				                                        getLocationInView ( "//div[4]/div[2]/date-picker/div/div[2]/input[2]" ).
				                                        pause ( 4000 ).
				                                        clearValue ( "//div[4]/div[2]/date-picker/div/div[2]/input[2]" ).
				                                        pause ( 4000 ).
				                                        setValue ( "//div[4]/div[2]/date-picker/div/div[2]/input[2]", splitNeverHrSec[1] ).
				                                        pause ( 4000 ).
				                                        getText ( "//div[1]/div[4]/div[2]/date-picker/div/div[2]/button", function ( checkMerdianNever ) {
				                                          if ( checkMerdianNever.value != splitNeverTime[1] ) {
				                                            videosDistribution.pause ( 4000 ).
				                                            click ( "//div[1]/div[4]/div[2]/date-picker/div/div[2]/button" ).
				                                            pause ( 3000 ) 
				                                          }
				                                          videosDistribution.pause ( 4000 ).
				                                          getLocationInView ( "//div[4]/div[2]/date-picker/div/div[3]/a[2]" ).
				                                          pause ( 4000 ).
				                                          click ( "//div[4]/div[2]/date-picker/div/div[3]/a[2]" ).
				                                          pause ( 4000 ).
				                                          getText ( "//div/div[1]/div[4]/div[2]/div/span", function ( checkNeverChangeDate ) {
				                                            var changedNeverFormat = splitNeverDate[1] + " " + splitNeverDate[0] + "," + " " + splitNeverDate[2] + " at " + mergeNeverTime
				                                            console.log ( "ChangedFormat", changedNeverFormat ) 
				                                            if ( checkNeverChangeDate.value == changedNeverFormat ) {
				                                              console.log ( "Last Run" ) 
				                                            }
				                                            else {
				                                              console.log ( "Last FAil", checkNeverChangeDate.value ) 
				                                              console.log ( "Last FAil,changedNeverFormat", changedNeverFormat ) 
				                                            }
				                                          } );
				                                        } );
				                                      }
				                                      else {
				                                      	//Write in the Excel as FAIL Results and Reason
				                                				videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Never TimeSlot is not displayed in the post" );
				                                      }
				                                    } );
				                                  }
				                                  else {
				                                    videosDistribution.pause ( 4000 ).
				                                    waitForElementVisible ( "//div[4]/div[2]/date-picker/div/div[1]/header/a[2]/i", 9000, false ).
				                                    pause ( 4000 ).
				                                    click ( "//div[4]/div[2]/date-picker/div/div[1]/header/a[2]/i" ) 
				                                  }
				                                } );
				                              }
				                            }
				                            else {
				                            	//Write in the Excel as FAIL Results and Reason
				                              videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Never label is not displayed in the post" );
				                            }
				                          } );
				                        } 
				                      }
				                      else {
				                      	//Write in the Excel as FAIL Results and Reason
				                        videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Never Calendar is not displayed in the post" );      
				                      }
				                    } );
				                    videosDistribution.pause ( 4000 ).
				                    waitForElementVisible ( "//div[3]/div/a[2]", 9000, false, function ( checkPostBtn ) {
				                      if ( checkPostBtn.value == true ) {
				                        videosDistribution.pause ( 4000 ).
				                        click ( "//div[3]/div/a[2]" ).
				                        //Get the Value for Destination posted in the Distribution page
				                        pause ( 4000 ).useCss ( ).
				                        getValue ( "ul.post-list li>.ng-scope", function ( allPost ) {
				                          if ( allPost.status == 0 ) {
				                            videosDistribution.pause ( 5000 ).useXpath ( ).
				                            //Wait for the Distributed post is visible in the distribution page
				                            waitForElementVisible ( "//div/div[1]/ul/li[1]/span/ng-include[2]/div[1]/h2/span", 4000, false, function ( postResult ) {
				                              if ( postResult.value == true ) {
				                                videosDistribution.pause ( 6000 ).useXpath ( ).
				                                //Get the Distributed post url in the distribution page
				                                getText ( "//ul/li[1]/span/ng-include[2]/div[1]/h2/span", function ( urlResult ) {
				                                  console.log ( "urlResult:", urlResult ) 
				                                  console.log ( "RowCountFirst:", rowCount ) 
				                                  if ( urlResult.value == destinationTemp_array[1] ) {
				                                    //Write in the Excel as PASS Results
				                                    videosDistribution.pause ( 4000 );
				                                    videosDistribution.writeToExcelPass ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6 ) 
				                                    console.log ( "ALL PASSSED" ) 
				                                    console.log ( "RowCountLastPass:", rowCount ) 
				                                  }
				                                  else {
				                                    videosDistribution.pause ( 4000 );
				                                    videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "The story is not Distributed" );
				                                    console.log ( "Failed ALL" ) 
				                                    console.log ( "RowCountLastfail:", rowCount ) 
				                                  }
				                                } );
				                              }
				                              else {
				                                //Write in the Excel as FAIL Results and Reason
				                                videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Completed Post is not displayed" );
				                              }
				                            } );
				                          }
				                          else {
				                            //Write in the Excel as FAIL Results and Reason
				                            videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Post List is not visible" );
				                          }
				                        } );
				                      }
				                      else {
				                      	//Write in the Excel as FAIL Results and Reason
				                        videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Post button is not displayed in the Post" );   
				                      }
				                    } );
				                  }
				                  else {
				                    console.log ( "FAILED" ) 
				                  }
				                }
				              } );
				            } );
									}
									else {
										//Write in the Excel as FAIL Results and Reason
										videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Destination option is not displayed in the page" ); 
														
									}
		        		} );
							}
							else {
								//Write in the Excel as FAIL Results and Reason
		            videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Searched data is not available in the listing page" ); 
							}
						} );
          }
          else {
 						//Write in the Excel as FAIL Results and Reason
            videosDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'ScheduleDistribution', rowCount, 6, 7, "Videos Menu is not displayed in Sidebar" );       
          }
        } );
      }
    }
    //End the Browser
    videosDistribution.end ( );
  }
};
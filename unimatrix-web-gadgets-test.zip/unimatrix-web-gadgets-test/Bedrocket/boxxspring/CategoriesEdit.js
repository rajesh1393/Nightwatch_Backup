//this function is for check and Edit the categories 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CategoriesEdit' ];
var categoryTitle = [ ];
var categoryDescription = [ ];
var categoryShortTitle = [ ];
var categoryShortDesc = [ ];
var categoryCategoryName = [ ];
var categoryNote = [ ];
var categoryImg = [ ];
var getData,rowCount = 1;
var currentCount, actualCount, expectedCount, excelData, searchCount;
module.exports = {
  tags: [ 'categoriesEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CategoriesEdit': function ( categoriesEdit ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        categoryTitle.push ( worksheet[ excelData ].v );
      }
      //Read Category Description
      if ( excelData.includes ( 'B' ) ) {
        categoryDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        categoryShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        categoryShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Category Name
      if ( excelData.includes ( 'E' ) ) {
        categoryCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read Category Note
      if ( excelData.includes ( 'F' ) ) {
        categoryNote.push ( worksheet[ excelData ].v );
      }
      //Read Thumbnil Image
      if ( excelData.includes ( 'G' ) ) {
        categoryImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( categoryTitle.length > 1 ) { 
    	var checkResult = categoriesEdit.globals.excelCol.resultCustomData;
      for ( let getData = 1,rowCount = 1; getData < categoryTitle.length; getData++ ) {     
      	rowCount++;
	      categoriesEdit.pause ( 4000 ).useXpath ( ).
	      //Check and wait for Categories menu is visible in the CONTENT sidebar
	      waitForElementVisible ( "//ul/li/a[ text( ) = 'Categories' ]",4000, false, function ( checkCategoriesMenu ) {
		      if ( checkCategoriesMenu.value == true ) { 
			      categoriesEdit.pause ( 4000 ).useXpath ( ).
			      //Verify the Categories Menu in CONTENT
			      verify.containsText ( "//ul/li/a[ text( ) = 'Categories' ]", "Categories" ).
			      pause ( 4000 ).
			      //Click on the Categories Menu in CONTENT
			      click ( "//ul/li/a[ text( ) = 'Categories' ]" ).
			      useCss ( ).pause ( 4000 ).
			      //Get Total Count in the Categories list page
			      getText ( '.content-count > strong', function ( currentCountResult ) {
			        if ( currentCountResult.status != -1 ) {
			          currentCount = currentCountResult.value;
			          currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
			        }
			        categoriesEdit.pause ( 4000 ).
	            //Check the search field is visible in the 360 videos listing page
	            waitForElementVisible ( ".search-field-input", 4000,false ).
	            pause ( 4000 ).
	            //Verify the search field is visible in the 360 videos listing page
	            verify.visible ( ".search-field-input" ).
	            //Enter the Headline in the field
	            setValue ( ".search-field-input", categoryTitle[ getData ] ).
	            // hold the control
	            keys ( categoriesEdit.Keys.ENTER ). 
	            click ( ".search-field-input" ).
	            // release the control
	            keys ( categoriesEdit.Keys.NULL ). 
	            pause ( 4000 ).
	            //Check the Total videos count label is visible in the 360videos listing page
	            waitForElementVisible ( ".content-count>strong", 4000, false ).
	            pause ( 4000 ).
	            //Verify the Total videos count label is visible in the 360videos listing page
	            verify.visible ( ".content-count>strong" ).
	            pause ( 4000 ).
	            //Get the Current total count in the listing page
	            getText ( '.content-count > strong', function ( currentCountResult ) {
	              if ( currentCountResult.status != -1 ) {
	                searchCount = currentCountResult.value;
	                searchCount = searchCount.substring ( 1, searchCount.length - 1 );
	              }
	              if ( searchCount > 0 ) {
				          categoriesEdit.useXpath ( ).pause ( 4000 ). 
				          //Wait for the Edit categories in the list is visible          
				          waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ categoryTitle[ getData ] +"']]", 4000, false, function ( checkSearchedLst ) {
				          	if ( checkSearchedLst.value == true ) {
						          categoriesEdit.pause ( 4000 ).
						          //Click on the Edit categories in the list
						          click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ categoryTitle[ getData ] +"']]" ).
						          useCss ().pause ( 4000 ).
						          //Verify the Content Tab is visible
						          verify.visible ( ".video-tabs > a[href='#content']" ).
						          pause ( 4000 ).
						          //Click on the Contnet Tab
						          click ( ".video-tabs > a[href='#content']" ).
						          pause ( 4000 ).
						          //Check and Enter Categories Title is visible
						          waitForElementVisible ( ".text-input-headline", 4000, false ).
						          //Clear the Headline in the field
						          clearValue ( ".text-input-headline" ).
						          //Enter the Headline in the field
						          setValue ( ".text-input-headline", categoryTitle[ getData ] ).
						          pause ( 4000 ).
						          //Check and Enter Categories Text Description
						          waitForElementVisible ( ".wmd-input", 4000, false ).
						          //Clear the Categories Description in the field
						          clearValue ( ".wmd-input" ).
						          //Enter the Categories Description in the field
						          setValue ( ".wmd-input", categoryDescription[ getData ] ).
						          pause ( 4000 ).					          
						          //Get the Properties details and Enter in the Properties Tab
						          video_properties ( categoryShortTitle[ getData ], categoryShortDesc[ getData ], categoryCategoryName[ getData ], categoryNote[ getData ], categoryImg[ getData ] ).
						          pause ( 4000 ).useCss ( ).
			                waitForElementVisible ( ".video-tabs > a[ href='#properties']",4000,false,function ( checkProperties ) {
		                    if ( checkProperties.value == true ) {
		                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
		                      	//Write in the spreadsheet: Fail Result and Reason for Thumbnail
		                        categoriesEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesEdit', rowCount, 9, 10, "Thumbnail is not displayed in the properties tab" );
		                        checkResult.length = 0;
		                      }
		                      else if ( checkResult.length == 0 ) {
		                      }
		                      else {
		                        checkResult.length = 0;
		                        //Check and click save button
		                        categoriesEdit.verify.visible ( "a.btn-active" ).
		                        //click on the save button
		                        click ( "a.btn-active" ).
		                        pause ( 4000 ).
		                        waitForElementNotPresent ( "a.btn-active",4000,false,function ( checkSaveBtn ) {
		                          if ( checkSaveBtn.value.length == 0 ) {
		                            categoriesEdit.pause ( 4000 ).useXpath ( ).
		                            //Verify the videos menu in the sidebar
		                            verify.containsText ( "//ul/li/a[ text( ) = 'Categories']", "Categories" ).
		                            pause ( 4000 ).
		                            //click on the videos menu in CONTENT
		                            click ( "//ul/li/a[ text( ) = 'Categories']" ).
		                            useCss ( ).pause ( 4000 ) 
		                            //Check the Actual Count after each video added
		                            categoriesEdit.useCss().pause( 4000 ).
		                            getText ( '.content-count > strong', function ( actualCountResult ) {
		                              if ( actualCountResult.status != -1 ) {
		                                actualCount = actualCountResult.value;
		                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
		                                if ( actualCount == currentCount ) {
		                                  //Write in the spreadsheet: Pass Result and Reason
		                                  categoriesEdit.writeToExcelPass ( 'boxxspring.xlsx', 'CategoriesEdit', rowCount, 9 );
		                                }
		                                else {
		                                  //Write in the spreadsheet: Fail Result and Reason
		                                  categoriesEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesEdit', rowCount, 9, 10, "ActualResult:'"+ actualCount +"'in the Total Count After Edited Categories. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
		                                }
		                              }
		                            } );
		                          }
		                          else {
		                            //Write in the spreadsheet: Fail Result and Reason
		                            categoriesEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesEdit', rowCount, 9, 10, " Save button is not functioning as expected" );
		                          }
		                        } );		                        
		                      }
		                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
		                        checkResult.length = 0;
		                      }
		                    }		                    
			                } );  
						        }
						        else {
						        	//Write in the Excel for FAIL Result and Reason
											categoriesEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesEdit', rowCount, 9, 10, "Searched Data is not avail in the Listing page" );
						        }
						      } );
						    }
						    else {
						      //Write in the Excel for FAIL Result and Reason
								  categoriesEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesEdit', rowCount, 9, 10, "Searched count is displayed as '"+searchCount +"'" );
								}
						  } );		        
						} );
					}
					else {
						//Write in the Excel for FAIL Result and Reason
						categoriesEdit.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesEdit', rowCount, 9, 10, "Categories menu is not displayed in Sidebar" );						              
					}
				} );
			}
		}
    //End the Browser
    categoriesEdit.end ( );
  }
};
//this function is for check and Delete the Attributions
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'AttributionsDelete' ];
var attributionType = [ ];
var attributionTitle = [ ];
var storyShortDesc = [ ];
var currentCount, actualCount, expectedCount, addedCount, searchCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'attributionsDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AttributionsDelete': function ( attributionDelete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Attribution Title
      if ( excelData.includes ( 'A' ) ) {
        attributionTitle.push ( worksheet[ excelData ].v );
      }      
      //Read Attribution Short Description
      if ( excelData.includes ( 'B' ) ) {
        storyShortDesc.push ( worksheet[ excelData ].v );
      }
    }
    if ( attributionTitle.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < attributionTitle.length; getData++ ) {
        rowCount++;
        attributionDelete.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Attributions' ]",4000,false,function ( checkAttributionMenu ) {
          if (checkAttributionMenu.value == true ) {
            //Verify the Attributions menu in the CONTENT
            attributionDelete.pause ( 4000 ).useXpath ( ).
            verify.containsText ( "//ul/li/a[ text( ) = 'Attributions' ]", "Attributions" ).
            pause ( 4000 ).
            //Click the Attributions menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Attributions' ]" ).
            useCss ( ).pause ( 4000 ).
            waitForElementVisible ( ".content-count>strong", 4000, false ).
            pause ( 4000 ).
            verify.visible ( ".content-count>strong" ).            
            pause ( 4000 ).
            //Get Searched Attributions total count in the Attributions listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                addedCount = currentCountResult.value;
                addedCount = addedCount.substring ( 1, ( addedCount.length - 1 ) );
              }
            } );
            attributionDelete.pause ( 4000 ).
            //Wait for the search field visible
            waitForElementVisible ( ".search-field-input", 4000, false ).
            pause ( 4000 ).
            verify.visible ( ".search-field-input" ).
            pause ( 4000 ).
            //Enter the search data in the field
            setValue ( ".search-field-input", attributionTitle[ getData ] ).
            // hold the control
            keys ( attributionDelete.Keys.ENTER ). 
            //click on the search field
            click ( ".search-field-input" ).
            // release the control
            keys ( attributionDelete.Keys.NULL ). 
            pause ( 4000 ).
            waitForElementVisible ( ".content-count>strong", 4000, false ).
            pause ( 3000 ).
            verify.visible ( ".content-count>strong" ).
            //Get Actual total count in the Attributions listing page
            getText ( '.content-count > strong', function ( searchCountResult ) {
              if ( searchCountResult.status !== -1 ) {
                searchCount = searchCountResult.value;
                searchCount = searchCount.substring ( 1, searchCount.length - 1 );
              }
              if ( searchCount > 0 ) {
                attributionDelete.useXpath().
                waitForElementVisible ("//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ attributionTitle[ getData ] +"']]", 4000, false,function ( checkAttributionLst ) {
                  if ( checkAttributionLst.value == true ) {
                    attributionDelete.useXpath().pause ( 4000 ).
                    verify.visible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ attributionTitle[ getData ] +"']]").
                    pause ( 4000 ).
                    //Click on the Searched data in the listing page
                    click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ attributionTitle[ getData ] +"']]" ).
                    useCss().pause ( 4000 ).
                    //Check and Enter Category Title
                    waitForElementVisible ( ".video-tabs > a[ href='#properties' ]", 4000, false ).
                    pause ( 4000 ).
                    verify.visible ( ".video-tabs > a[ href='#properties' ]" ).
                    pause ( 4000 ).
                    //Click on the Properties Tab
                    click ( ".video-tabs > a[ href='#properties' ]" ).           
                    pause ( 4000 ).            
                    //Check the Delete Button.
                    verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                    pause ( 4000 ).
                    //Click on the Delete button in the Properties Tab
                    click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                    pause ( 4000 ).
                    //Check the existance of delete confirmation dialog
                    verify.visible ( "dialog[ name=deleteVerification ]" ).
                    pause ( 4000 ).
                    //Verify the Cancel Button in Delete Dialog is visible
                    verify.visible ( ".link-secondary" ).
                    pause ( 4000 ).
                    //Click Cancel Button in Delete Dialog
                    click ( ".link-secondary" ).
                    pause ( 4000 ).
                    waitForElementVisible (".btn-delete > span[ ng-click='showDeleteVerification();']",4000,false, function ( checkDeleteBtn ) {
                      if ( checkDeleteBtn.value == true ) {
		                    //Verify the Delete Button in the Properties Tab is visible
		                   	attributionDelete.useCss().
		                   	verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
		                    pause ( 4000 ).
		                    //Click on the Delete button in the Properties Tab
		                    click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
		                    pause ( 4000 ).
		                    //Check the existance of delete confirmation to delete
		                    verify.visible ( "dialog[ name=deleteVerification ]" ).
		                    pause ( 4000 ).
		                    verify.visible ( "button.btn:nth-child( 2 )" ).
		                    pause ( 4000 ).
		                    //Click on the Delete Button in Delete Dialog box
		                    click ( "button.btn:nth-child( 2 )" ).
		                    pause ( 4000 ).useXpath ( ).
		                    //Verify the Attributions menu in the CONTENT
		                    verify.containsText ( "//ul/li/a[ text( ) = 'Attributions' ]", "Attributions" ).
		                    pause ( 4000 ).
		                    //Click on the Attributions menu in the CONTENT
		                    click ( "//ul/li/a[ text( ) = 'Attributions' ]" ).
		                    useCss ( ).pause ( 4000 ).
		                    waitForElementVisible ( ".content-count>strong", 4000,false ).
		                    verify.visible ( ".content-count>strong" ).
		                    //Get Attributions total count in the Attributions listing page
		                    getText ( '.content-count > strong', function ( actualCountResult ) {
		                      if ( actualCountResult.status !== -1 ) {
		                        actualCount = actualCountResult.value;
		                        actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
		                        expectedCount = ( ( + addedCount ) - ( 1 ) );
		                        if ( actualCount == expectedCount ) {
		                          //Write in the Excel for Pass Result and Reason
		                          attributionDelete.writeToExcelPass ( 'boxxspring.xlsx', 'AttributionsDelete', rowCount, 4 );
		                        }
		                        else {
		                          //Write in the Excel for Fail Result and Reason
		                          attributionDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Delete Attribution. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
		                        }
		                      }
		                    } );
		                  }
		                  else {
		                    //Write in the Excel for Fail Result and Reason
		                    attributionDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsDelete', rowCount, 4, 5, "Delete Button is not enabled in the Attribution page " );
		                  }
		                } );
		              }
		              else {
		                //Write in the Excel for Search Fail Result and Reason
		                attributionDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsDelete', rowCount, 4, 5, " Searched Data is not displayed in the listing page" );
		              }
		            } );
		          }
		          else {
                //Write in the Excel for Search Fail Result and Reason
                attributionDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsDelete', rowCount, 4, 5, "Searched Result Count,'"+ searchCount +"'" );
		          }
		        } );
		      }
		      else {
		        //Write in the Excel for Search Fail Result and Reason
		        attributionDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsDelete', rowCount, 4, 5, "Attribution menu is not displyed in Sidebar" );		              
		      }
		    } );
		  }
    }
    else {
      //Write in the Excel for Search Fail Result and Reason
      attributionDelete.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsDelete', rowCount, 4, 5, "No Data is availed in Excel" );
    }
    //End the Browser
    attributionDelete.end ( );
  }
};
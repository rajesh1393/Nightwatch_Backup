//This Function is check and Distribute the Articles from Boxxspring Destination
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'ContentArticlesDelete' ];
var categoryTitle = [ ];
var templateSelection = [ ];
var currentCount, actualCount, excelInput;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'contentArticlesDelete' ],
  // Login the Portal Boxxspring
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'ContentArticlesDelete': function ( contentArticles ) {
    for ( excelInput in worksheet ) {
      if ( excelInput[1] === '!' ) continue;
      //Read Articles Title
      if ( excelInput.includes ( 'A' ) ) {
        categoryTitle.push ( worksheet[ excelInput ].v );
      }
      //Read Articles Edit Title
      if ( excelInput.includes ( 'B' ) ) {
        templateSelection.push ( worksheet[ excelInput ].v );
      }
    }
    if ( categoryTitle.length > 1 ) {
      contentArticles.pause ( 4000 ).timeoutsImplicitWait ( 5000 ).useXpath ( ).
      //Verify the Articles Menu in the CONTENT
      verify.containsText ( "//ul/li/a[ text() = 'Articles']", "Articles" ).
      pause ( 4000 ).
      //Click on the Articles Menu in the CONTENT
      click ( "//ul/li/a[ text() = 'Articles']" ).
      useCss ( ).pause ( 4000 ).
      //Get the Current Totla Count in the Articles listing Page
      getText ( '.content-count > strong', function ( currentCountResult ) {
        if ( currentCountResult.status !== -1 ) {
          currentCount = currentCountResult.value;
          currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
        }
        for ( let getData = 1, rowCount = 1; getData < categoryTitle.length; getData++ ) {
          rowCount++;
          contentArticles.pause ( 4000 ).
          //Wait for Add Articles button is visible in the Article listing page
          waitForElementVisible ( ".btn.btn-primary.btn-add", 4000, false ).
          pause ( 4000 ).
          //Click on the Add Article button in the Articles listing page
          click ( ".btn.btn-primary.btn-add" ).
          pause ( 4000 ).useXpath ( ).
          //Wait for the Template selection button is visible in the Articles page
          waitForElementVisible ( "//div/div/div[@class='template "+ templateSelection[ getData ] +"']", 4000, false ).
          pause ( 4000 ).
          //Click on the Template selection button in the Articles page
          click ( "//div/div/div[@class='template "+ templateSelection[ getData ] +"']" ).
          pause ( 4000 ).
          //Wait for label is visible in the Articles page
          waitForElementVisible ( "//div/div/header/div/div[@class='typeName-label']", 4000, false, function ( captionCheck ) {
            if ( captionCheck.value == true ) {
              //Get Text for label in the Articles page
              contentArticles.getText ( "//div/div/header/div/div[@class='typeName-label']", function ( labelName ) {
                if ( labelName.value == 'ARTICLE' ) {
                  contentArticles.pause ( 4000 ).useXpath ( ).
                  //Wait for Text field is visible in the Articles page
                  waitForElementVisible ( "//div/div/header/div/text-field/input", 4000, false ).
                  pause ( 4000 ).
                  //Clear the data in the text field 
                  clearValue ( "//div/div/header/div/text-field/input" ).
                  pause ( 4000 ).
                  //Enter the data in the text field
                  setValue ( "//div/div/header/div/text-field/input", categoryTitle[ getData ] ).
                  pause ( 4000 ).
                  //Wait and check for Save button is visible in the Articles page
                  waitForElementVisible ( "//a[@class='btn btn-icon btn-active']", 4000, false, function ( checkSaveBtn ) {
                    if ( checkSaveBtn.value == true ) {
                      contentArticles.pause ( 4000 ).useXpath ( ).
                      //Verify the Save button is visible in the Articles page
                      verify.visible ( "//a[@class='btn btn-icon btn-active']" ).
                      pause ( 4000 ).
                      //Click on the save button in the Articles page
                      click ( "//a[@class='btn btn-icon btn-active']" ).
                      pause ( 4000 ).
                      //Wait for the Add section button is visible
                      waitForElementVisible("//a/span[@class='tip-text']",4000,false).
                      pause(4000).   
                      //Click on the Add section button                   
                      click ( "//a/span[@class='tip-text']" ).
                      pause ( 4000 ).
                      //Move hover on the + button
                      moveToElement ( "//*/div[2]/div[2]/a[1]/i", 0, 0 ).
                      pause ( 4000 ). 
                      //click on the Headline button                     
                      click ( "//*/div[2]/div[2]/a[2]/i" ).
                      pause ( 4000 ).
                      //Move hover on the + button
                      moveToElement ( "//*/div[2]/div/div/div[1]/div[1]/a[1]/i", 0, 0 ).
                      pause ( 4000 ).
                      //click on the Text field button                        
                      click ( "//*/div[1]/div[1]/a[3]/i" ).
                      pause ( 4000 ).
                      //Move hover on the + button
                      moveToElement ( "//*/div[3]/div/div/div[1]/div[1]/a[1]/i", 0, 0 ).
                      pause ( 4000 ).
                      //click on the Add Thumbnail button                        
                      click ( "//*/div[3]/div/div/div[1]/div[1]/a[4]/i" ).
                      pause ( 4000 ).
                      //Move hover on the + button
                      moveToElement ( "//*/div[3]/div/div/div/div[1]/a[1]/i", 0, 0 ).
                      pause ( 4000 ).     
                      //click on the Add videos button           
                      click ( "//*/div[3]/div/div/div/div[1]/a[5]/i" ).
                      pause ( 4000 ).useCss ( ).
                      keys ( contentArticles.Keys.PAGEDOWN ).useXpath ( ).
                      //Move hover on the + button
                      moveToElement ( "//*/div[4]/div/div/div/div[1]/a[1]/i", 0, 0 ).
                      pause ( 4000 ).  
                      //click on the Add Embed code button                      
                      click ( "//*/div[4]/div/div/div/div[1]/a[6]/i" ).
                      pause ( 5000 ).useCss ( ).
                      keys ( contentArticles.Keys.PAGEUP ).pause ( 2000 ).useXpath ( ).
                      //Wait for Text field delete button is visible in the Articles page
                      waitForElementVisible ( "//*/div[2]/div/div/div/div/div/span/i", 4000, false, function ( firstdeletebtn ) {
                        if ( firstdeletebtn.value == true ) {
                          contentArticles.pause ( 4000 ).useXpath ( ).
                          //Click on the Text field delete button in the Articles page
                          click ( "//*/div[2]/div/div/div/div/div/span/i" ).
                          pause ( 4000 ).
                          //Wait for Videos delete button is visible in the Articles page
                          waitForElementVisible ( "//*/div[2]/div/div/div/div[2]/span/i", 4000, false, function ( seconddeletebtn ) {
                            if ( seconddeletebtn.value == true ) {
                              contentArticles.pause ( 4000 ).useXpath ( ).
                              //Click on the Videos delete button in the Articles page
                              click ( "//*/div[2]/div/div/div/div[2]/span/i" ).
                              pause ( 4000 ).
                              //Wait for Embed code delete button is visible in the Articles page
                              waitForElementVisible ( "//*/div[2]/div/div/div/div/div/div[2]/span/i", 4000, false, function ( thirddeletebtn ) {
                                if ( thirddeletebtn.value == true ) {
                                  contentArticles.pause ( 4000 ).useXpath ( ).
                                  //Click on the Embed code delete button in the Articles page
                                  click ( "//*/div[2]/div/div/div/div/div/div[2]/span/i" ).
                                  pause ( 4000 ).
                                  //Wait for Thumbnail delete button is visible in the Articles page
                                  waitForElementVisible ( "//*/div[2]/div/div/div/div[2]/div/div[1]/span/i", 4000, false, function ( fourthdeletebtn ) {
                                    if ( fourthdeletebtn.value == true ) {
                                      contentArticles.pause ( 4000 ).useXpath ( ).
                                      //Click on the Thumbnail delete button in the Articles page
                                      click ( "//*/div[2]/div/div/div/div[2]/div/div[1]/span/i" ).
                                      pause ( 4000 ).
                                      //Wait for Headline delete button is visible in the Articles page
                                      waitForElementVisible ( "//*/div[2]/div/div/div[1]/div[2]/div/span/i", 4000, false, function ( fifthdeletebtn ) {
                                        if ( fifthdeletebtn.value == true ) {
                                          contentArticles.pause ( 4000 ).useXpath ( ).
                                          //Click on the Headline delete button in the Articles page
                                          click ( "//*/div[2]/div/div/div[1]/div[2]/div/span/i" ).
                                          pause ( 4000 ).
                                          //Move hover on the + button
                                          moveToElement ( "//*/div/div/div[1]/div/div/a/i", 0, 0 ).
                                          pause ( 4000 ).
                                          //Wait for Add Section delete button is visible in the Articles page
                                          waitForElementVisible ( "//*/div/div/div[1]/div/div/a/i", 4000, false, function ( sectionDeleteBtn ) {
                                            if ( sectionDeleteBtn.value == true ) {
                                              contentArticles.pause ( 4000 ).useXpath ( ).
                                              //Click on the Add section delete button in the Articles page
                                              click ( "//*/div/div/div[1]/div/div/a/i" ).
                                              pause ( 4000 ).
                                              //Wait for Delete button is visible in the Articles page
                                              waitForElementVisible ( "//a/span[@ng-click='showDeleteVerification();']", 4000, false ).
                                              pause ( 4000 ).
                                              //Click on the Delete button in the Articles page
                                              click ( "//a/span[@ng-click='showDeleteVerification();']" ).
                                              pause ( 4000 ).
                                              //Wait for Add Dialog popup is visible in the Articles page after click on delete button
                                              waitForElementVisible ( "//dialog/section[@class='dialog-content']", 4000, false, function ( dialogPopup ) {
                                                if ( dialogPopup.value == true ) {
                                                  contentArticles.pause ( 4000 ).useXpath ( ).
                                                  //Wait for Cancel button is visible in the Dailog box
                                                  waitForElementVisible ( "//section/a[@class='link-secondary']", 4000, false ).
                                                  pause ( 4000 ).
                                                  //Wait for Delete button is visible in the Dailog box
                                                  waitForElementVisible ( "//section/button[text()='Delete']", 4000, false ).
                                                  pause ( 4000 ).
                                                  //Click on the Delete button in the Dailog box
                                                  click ( "//section/button[text()='Delete']" ).
                                                  pause ( 4000 ).
                                                  //Verify the Articles menu in the CONTENT
                                                  verify.containsText ( "//ul/li/a[ text() = 'Articles' ]", "Articles" ).
                                                  pause ( 4000 ).
                                                  //Click on the Articles menu in the CONTENT
                                                  click ( "//ul/li/a[ text() = 'Articles' ]" ).
                                                  useCss ( ).pause ( 4000 ).
                                                  waitForElementVisible ( ".content-count>strong", 4000, false ).
                                                  pause ( 4000 ).
                                                  verify.visible ( ".content-count>strong" ).
                                                  //Get Articles total count in the authors listing page
                                                  getText ( '.content-count > strong', function ( actualCountResult ) {
                                                    if ( actualCountResult.status !== -1 ) {
                                                      actualCount = actualCountResult.value;
                                                      actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
                                                      if ( actualCount == currentCount ) {
                                                        //Write in the Excel for Pass Result and Reason
                                                        contentArticles.writeToExcelPass ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4 );
                                                      }
                                                      else {
                                                        //Write in the Excel for Fail Result and Reason
                                                        contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Authors. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                                                      }
                                                    }
                                                  } );
                                                }
                                                else {
                                                  //Write in the Excel for Fail Result and Reason
                                                  contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Delete Alert Popup is not visible" );
                                                }
                                              } );
                                            }
                                            else {
                                              //Write in the Excel for Fail Result and Reason
                                              contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Add Section delete button is not visible" );
                                            }
                                          } );
                                        }
                                        else {
                                          //Write in the Excel for Fail Result and Reason
                                          contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Add Headline delete button is not visible" );
                                        }
                                      } ); 
                                    }
                                    else {
                                      //Write in the Excel for Fail Result and Reason
                                      contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Add Thumbnail delete button is not visible" );
                                    }
                                  } ); 
                                }
                                else {
                                  //Write in the Excel for Fail Result and Reason
                                  contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Add Embed code delete button is not visible" );
                                }
                              } ); 
                            }
                            else {
                              //Write in the Excel for Fail Result and Reason
                              contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Add Videos delete button is not visible" );
                            }
                          } ); 
                        }
                        else {
                          //Write in the Excel for Fail Result and Reason
                          contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Add Text delete button is not visible" );
                        }
                      } ); 
                    } 
                  } );
                } 
                else {
                  //Write in the Excel for Fail Result and Reason
                  contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Article Label is not visible" );
                }
              } ); 
            } 
            else {
              //Write in the Excel for Fail Result and Reason
              contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesDelete', rowCount, 4, 5, "Caption in the page is not visible" );
            } 
          } );
          //Check on the total videos count and input from excel
          if ( getData < categoryTitle.length - 1 ) {
            contentArticles.pause ( 5000 ).useXpath ( ).
            //Verify the Articles Menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text() = 'Articles']", "Articles" ).
            pause ( 4000 ).
            //Click on the Articles Menu in the CONTENT
            click ( "//ul/li/a[ text() = 'Articles']" ).
            useCss ( ).pause ( 4000 ).
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
                console.log ( "currentCountResult", currentCountResult )
              }
            } );
          }
        } //For loop
      } );
    }
    //browser end
    contentArticles.end ( );
  }
}
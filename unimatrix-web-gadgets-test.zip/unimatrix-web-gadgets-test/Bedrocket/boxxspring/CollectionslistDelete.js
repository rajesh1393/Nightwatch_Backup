//this function is for check and Add the Collections list 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
	cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CollectionsListDelete' ];
var collectionTitle = [ ];
var contentTitle = [ ];
var collectionMenu = [ ];
var resultStatus = [ ];
var currentCount, expectedCount, excelData, actualCount, splitCollection, splitArtifactName, finalCount;
var getData, getFirstData, rowCount = 1;
var dataCategory = 0;
module.exports = {
	tags: [ 'collectionsListDelete' ],
	before: function ( portalLogin ) {
		var profile = portalLogin.globals.profile;   
		portalLogin.login ( profile.portalUri, profile.username, profile.password );
	},
	'CollectionsListDelete': function ( collectionsListDelete ) {
    //Read values from excel
    for ( excelData in worksheet ) {
    	if ( excelData[ 1 ] == '!' ) continue;
      //Read Search Collection Title
      if ( excelData.includes ( 'A' ) ) {
      	collectionTitle.push ( worksheet[ excelData ].v );
      }      
     //Read Content Title
     if ( excelData.includes ( 'B' ) ) {
     		collectionMenu.push ( worksheet[ excelData ].v );
     	}      
     }
     if ( collectionTitle.length > 1 ) {
     	for ( let getData = 1, rowCount = 1; getData < collectionTitle.length; getData++ ) {
     		rowCount++;      
     		collectionsListDelete.pause ( 4000 ).useXpath ( ).
     		//Wait for the Collections title menu is visible in the Sidebar
     		waitForElementVisible ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']", 4000, false, function ( checkCollectionsTitle ) {
     			if ( checkCollectionsTitle.value == true ) {
     				collectionsListDelete.pause ( 4000 ).useXpath ( ).
			      //Verify the Collection Title in the menu is visible in the sidebar
			      verify.containsText ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']", collectionTitle[ getData ] ).
			      pause ( 4000 ).
			      //Click on the Collections Title menu in the sidebar
			      click ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']" ).
			      pause ( 4000 ).useCss ( )      
		        //Get the Current Total count in the Collections listing page
		        collectionsListDelete.getText ( '.content-count > strong', function ( currentCountResult ) {
		        	if ( currentCountResult.status != -1 ) {
		        		currentCount = currentCountResult.value;
		        		currentCount = currentCount.substring ( 1, currentCount.length - 1 );
		        	}              
		        	splitArtifactName = collectionMenu[ getData ].split(',');								          
		        	for ( let collectionData = 0, dataCategory = 0; collectionData < splitArtifactName.length; collectionData++ ) {   
		        		dataCategory++; 	
		        		collectionsListDelete.pause ( 4000 ).useXpath ( ).
		        		//Wait for the Delete button is visible in the page
		        		waitForElementVisible ( "//ul/li[2]/a[contains(.,'Delete')]", 4000, false, function ( checkDeleteBtn ) {
		        			if ( checkDeleteBtn.value == true ) {
		        				if ( !( resultStatus.indexOf('FAIL') >= 0 ) || resultStatus.length == 0 ) {
		        					collectionsListDelete.pause ( 4000 ).useXpath ( ).
		        					//Wait for the searched data is visible in the listing page
			        				waitForElementVisible ( ".//*/h2[contains(.,'"+ splitArtifactName[ collectionData ] +"')]//ancestor::div/ul/li[3]", 4000, false, function ( checkCollectionLst ) {
			        					if ( checkCollectionLst.value == true ) {
			        						collectionsListDelete.pause ( 4000 ).useXpath ( ).
			        						//Click on the searched data in the list
			        						click ( ".//*/h2[contains(.,'"+ splitArtifactName[ collectionData ] +"')]//ancestor::div/ul/li[3]" ).
			        						pause ( 4000 )
			        						resultStatus.push("PASS");
			        						if ( dataCategory == splitArtifactName.length ) {		        					
    												collectionsListDelete.pause ( 4000 ).useXpath ( ).
    												//Wait for the Collections Title menu is visible in the sidebar
			        							waitForElementVisible ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']", 4000, false ).		            		
					        					pause ( 4000 ).
					        					//Click on the Collections Title menu in the sidebar
					        					click ( "//ul/li/a[ text( ) = '"+ collectionTitle[ getData ] +"']" ).
					        					pause ( 4000 ).useCss ( ).
					        					//Verify the count label is visible in the listing page
					        					verify.visible ( '.content-count > strong' ).
					        					pause ( 4000 ).
					        					//Get the count value in the listing page
					        					getText ( '.content-count > strong', function ( actualCountResult ) {
					        						if ( actualCountResult.status != -1 ) {
					        							actualCount = actualCountResult.value;
					        							actualCount = actualCount.substring ( 1, actualCount.length - 1 );
					        							expectedCount = ( ( + currentCount ) - ( + splitArtifactName.length ) );
					        							if ( actualCount == expectedCount ) {
			                          	//Write in the Excel file:PASS Result
			                          	collectionsListDelete.writeToExcelPass ( 'boxxspring.xlsx', 'CollectionsListDelete', rowCount, 4 );
			                          }
			                          else {
			                         	  //Write in the Excel file:FAIL Result and Reason
			                         	  collectionsListDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionsListDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Content. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
			                         	}
															}
														} );    									
														if ( resultStatus.indexOf ( 'FAIL' ) || resultStatus.indexOf ( 'PASS' ) >= 0 ) {
			  											resultStatus.length = 0;
			    									}		        				
					        				}		        				  
						            }
						            else {			
						            	resultStatus.push( "FAIL" ); 
						            }				            
						          } );
					        	}
					        	else {
					        		//Write in the Excel file:FAIL Result and Reason
					        		collectionsListDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionsListDelete', rowCount, 4, 5, "Collection Title  is not displayed in the collections listing page" );
										}		
				        	} 			        	
			        	} );	        
				      }
			      } );
        	}
        	else {
        		//Write in the Excel file:FAIL Result and Reason
        		collectionsListDelete.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionsListDelete', rowCount, 5, 6, "Collection Title '"+ collectionTitle[ getData ] +"' is not displayed in the Side Menu" );
        	}
		    } );
		  }
		}
    //End the Browser
    collectionsListDelete.end ( );
  }
}
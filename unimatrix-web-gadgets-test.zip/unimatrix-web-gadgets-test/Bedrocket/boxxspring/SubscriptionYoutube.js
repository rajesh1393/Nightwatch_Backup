//this function is for check and add the Subscription
var YouTube = require ( 'youtube-node' );
var youTube = new YouTube();
var request = require ( 'request' );
var requestURL = "https://api.staging.boxxspring.com/properties/81/artifacts?access_token=bc217390eb363759cb1e2aa758ed7cc3&type_name.in[]=video_artifact&provider.in[]=YouTube&sort_by=updated_at&sort_direction=asc&include[artifact_locators]=true&count=200";
var videoID = [];
var response = [];
var ytPlaylistCount;
var schedulers;
var unique = [];
var subscriptionURL = [];
var searchContent = [];
var categoryName = [];
var title = [];
var ingestionTime = [];
var subscriptionName = [];
var ingestionTimeEdit = [];
var subscriptionURLCheck = [];
var subscriptionTitle = [];
var searchContentDelete = [];
var invalidSubscriptionURLCheck = [];
var excelRow;
var countBeforeAdd;
var expectedCount;
var countAfterAdd;
var date = new Date;
var date1 = new Date;
substring = "list=";
var ingestionTime = [];
var ypi = require ( 'youtube-playlist-info' );
var storeResponse = [];
var afterComma = [];
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
try {
  var workbook = XLSX.readFile ( 'boxxspring.xlsx', {
    cellStyles: true
  });
  var addSubscription = workbook.Sheets[ 'SubscriptionYoutubeAdd' ];
  var editSubscriptionSheet = workbook.Sheets[ 'SubscriptionYoutubeEdit' ];
  var deleteSubscriptionSheet = workbook.Sheets[ 'DeleteYoutubeSubscription' ];
  var InvalidPlaylistURL = workbook.Sheets[ 'InvalidPlaylistURL' ];
}
catch ( err ) {
  console.log ( "Please check File name" );
}
var YoutubeURL = [];
var ingestionTime = [];
var youtube = "youtube";
module.exports = {
  tags:[ 'subscriptionYoutube' ],
  before: function ( browser ) {
    var profile = browser.globals.profile;
    browser.windowMaximize().
    login ( profile.portalUri, profile.username, profile.password );
  },
  'SubscriptionYoutubeAdd': function ( client ) {
    try {
      for ( z in addSubscription ) {
        if ( z[ 0 ] === '!' ) continue;
        else if ( z.includes ( 'A' ) ) {
          title.push ( addSubscription[ z ].v );
        }
        else if ( z.includes ( 'B' ) ) {
          YoutubeURL.push ( addSubscription[ z ].v );
        }
        else if ( z.includes ( 'C' ) ) {
          ingestionTime.push ( addSubscription[ z ].v );
        }
      }
    }
    catch ( err ) {
      client.
      //Writing the Failed status in the Excel sheet
      verify.fail ( "Unable to load file", "Excel file should get updated", "Please check the Parameters in Excel Sheet" );
    }
    client.
    useXpath ().
    pause ( 1200 ).
    //Click on the Curation Button from the SideBar
    click ( " ( //DIV[@class='content-header content ng-scope'])[3]" ).
    pause ( 5000 )
    for ( var incrementer = 1, temp = 0, excelRow = 1, invalidRow = 1; incrementer <= YoutubeURL.length - 1; incrementer++ ) {
      if ( YoutubeURL[ incrementer ].includes ( substring ) == true ) {
        afterComma.push ( YoutubeURL[ incrementer ].substr ( YoutubeURL[ incrementer ].indexOf ( "list=" ) + 5 ) );
        var schedule = require ( 'node-cron' );
        //Defining the Ingestion Time According to the Result from the Excel Sheet
        if ( ingestionTime[ incrementer ] == 'OFF' ) {
          date.setHours ( date.getHours() );
          date.setMinutes ( date.getMinutes() + 3 );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '5 MIN' ) {
          date.setHours ( date.getHours() );
          date.setMinutes ( date.getMinutes() + 3 );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '10 MIN' ) {
          date.setHours ( date.getHours() );
          date.setMinutes ( date.getMinutes() + 10 );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '30 MIN' ) {
          date.setHours ( date.getHours() );
          date.setMinutes ( date.getMinutes() + 30 );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '1 HOUR' ) {
          date.setHours ( date.getHours() + 1 );
          date.setMinutes ( date.getMinutes() );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '3 HOURS' ) {
          date.setHours ( date.getHours() + 3 );
          date.setMinutes ( date.getMinutes() );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '6 HOURS' ) {
          date.setHours ( date.getHours() + 6 );
          date.setMinutes ( date.getMinutes() );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '12 HOURS' ) {
          date.setHours ( date.getHours() + 12 );
          date.setMinutes ( date.getMinutes() );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        else if ( ingestionTime[ incrementer ] == '1 DAY' ) {
          date.setHours ( date.getHours() + 24 );
          date.setMinutes ( date.getMinutes() );
          var min = date.getMinutes();
          var hours = date.getHours();
        }
        //Scheduling the API's to fetch values 
        schedulers = schedule.schedule ( '0 ' + min + ' ' + hours + ' * * *', function() {
          excelRow++;
          //Fetching the Youtube playlists VideoID from Youtube API
          ypi.playlistInfo ( "AIzaSyCZ3TTqlOIlNxpozt1RpymW_af4I1c-2r8", afterComma[ temp ], function ( playlistItems ) {
            playlistItems.forEach ( function ( entry ) {
              //Pushing the VideoID into playlistItems array
              videoID.push ( entry.resourceId.videoId );
            });
            //Storing the Total Count of Videos ID and storing it in the ytPlaylistCount var
            ytPlaylistCount = videoID.length;
          });
          temp++;
          //Paused for 2Mins to fecth the Videos in Boxxspring Portal
          client.pause ( 1200 );
          //Fetching the Total Count of Boxxspring Youtube VideoID using BoxxSpring API
          request ( requestURL, function ( error, response, body ) {
            //Converting the Response to JSON Object and Storing in temp variable
            var temp = JSON.parse ( body );
            //Storing the Total count of the Youtube Videos in Boxxspring in the totalYoutubeCount variable
            var totalYoutubeCount = temp.$this.unlimited_count;
            //Get the Loopcount 
            var loopCount = Math.ceil (( totalYoutubeCount ) / 100 );
            var next = 0;
            //Iterating the API for getting the VideoID
            for ( var scheduler = 0; scheduler < loopCount; scheduler++ ) {
              unique.length = 0;
              request ( requestURL + "&offset=" + ( scheduler * 100 ), function ( error, response, body ) {
                //Storing the Response in the Temporary variable
                var temporary = JSON.parse ( body );
                //Getting the Count of Vide ID from the API Response
                var actualCount = temporary.$this.count;
                for ( apiRes = 0; apiRes < actualCount; apiRes++ ) {
                  var a = apiRes + next;
                  //Pusing the VideoID's into the storeResponse array
                  storeResponse.push ( temporary.artifacts[ apiRes ].provider_uid );
                }
                next = parseInt ( next + 100 );
                var compare = videoID.length;
                var res = [];
                res.length = 0;
                //Checks the VideoID in Boxxspring Array and returns the matched videoID
                for ( var checkLoop = 0; checkLoop < compare; checkLoop++ ) {
                  //Get the Index of the StoreResponse only if it contains the videoID from the Youtube
                  res.push ( storeResponse.indexOf ( videoID[ checkLoop ] ) );
                  //If Empty then continue with the Script
                  if ( res.length == 0 ) {
                    client.
                    this.return;
                  }
                  //Checks if the res Array contains Undefined and Null values
                  else if ( typeof res == 'undefined' && res == 'null' ) {
                    //Updating the Fail Status in Excel
                    client.
                    verify.fail ( "Videos from your youtube Subscription is not updated properly", "All the Videos from the Youtube Subscription should get updated", "Please tryagain with some other youtube Subscriptions" ).
                    writeToExcelFail ( 'boxxspring.xlsx', 'SubscriptionYoutubeAdd', excelRow, 4, 5, "ActualResult: 'Videos are getting updated in Video Property'.ExpectedResult:( Videos should not updated in Video Property) " );
                  }
                  else {
                    //Updating the Pass Status in the Excel
                    client.
                    writeToExcelPass ( 'boxxspring.xlsx', 'SubscriptionYoutubeAdd', excelRow, 4 );
                  }
                }
              });
            }
          });
        });
        client.
        pause ( 300 ).
        useXpath ().
        //Checking the Subscription button is visibility
        waitForElementPresent ( "//ul/li/a[text()='Subscriptions']", 5000, false, function ( activeStatus ) {
          //if the Subscription button is not visible then Click on Curation button and then click on Subscription button 
          if ( activeStatus.value == true ) {
            client.
            useXpath ().
            click ( " ( //DIV[@class='content-header content ng-scope'] )[3]" ).
            pause ( 5000 ).
            click ( "//ul/li/a[text()='Subscriptions']" )
          }
          //if the Subscription button is visible then Click directly on the Subscription button
          else {
            client.
            useXpath ().
            pause ( 5000 ).
            //clicking the Subscription button
            click ( "//ul/li/a[text()='Subscriptions']" );
          }
        });
        client.
        pause ( 5000 ).
        verify.visible ( "//DIV[@class='suggestion-dropdown-wrap']" ).
        pause ( 5000 ).
        useCss ().
        //clicking the Add subscription button from the list page
        waitForElementVisible ( "a.btn-primary", 9000, false ).
        pause ( 7000 ).
        click ( "a.btn-primary" ).
        pause ( 5000 ).
        verify.visible ( "h1.ng-scope" ).
        pause ( 7000 ).
        //Checking the Add Subscription text visibility
        verify.containsText ( "h1.ng-scope", "Add Subscription" ).
        pause ( 7000 );
        //Set the URL in the URL field only if the URL is Youtube and Valid
        if ( new RegExp ( youtube ).test ( YoutubeURL[ incrementer ] ) == true ) {
          client.
          useXpath ().
          //Clicking the Youtube Subscription button
          verify.visible ( "//ul/li/a[contains(.,'YouTube' )]" ).
          pause ( 5000 ).
          click ( "//ul/li/a[contains(.,'YouTube' )]" ).
          useCss ().
          //checking whether the control is in Add Subscription Page
          verify.visible ( ".typeName-label" ).
          useXpath ().
          pause ( 5000 ).
          waitForElementVisible ( "//TEXT-FIELD[@placeholder-text='Subscription']", 5000, false ).
          pause ( 5000 ).
          setValue ( "//INPUT[@rows='1']", title[ incrementer ] ).
          pause ( 5000 ).
          //Passing the Value to the Subscription URL text field.
          setValue ( "//INPUT[@id='subscription_url']", YoutubeURL[ incrementer ] ).
          useCss ().
          pause ( 5000 ).
          //Clicking the Next button in the Add Subscription button
          verify.visible ( "button.btn:nth-child(2)" ).
          pause ( 5000 ).
          click ( "button.btn:nth-child(2)" ).
          pause ( 5000 ).
          //Checking whether the Control has moved to next page.
          waitForElementVisible ( ".typeName-label", 5000, false ).
          pause ( 5000 ).
          //Clicking the Ingestion frequency OFF dropdown      
          click ( ".default-item>a" ).
          pause ( 5000 ).
          useXpath ().
          //Making the Ingestion frequency OFF
          click ( "//a[@class='ellipsis ng-binding'][contains(.,'" + ingestionTime[ incrementer ] + "') ]" ).
          pause ( 5000 ).
          //Checking the Subscribe button visibility
          waitForElementVisible ( "//A[@class='btn btn-primary pull-right button-fetch ng-scope'][contains(.,'Subscribe') ]", 5000, false ).
          //Clicking the Subscribe button
          click ( "//A[@class='btn btn-primary pull-right button-fetch ng-scope'][contains(.,'Subscribe') ]" ).
          pause ( 5000 ).
          //Checking the Subscribe button visibility
          waitForElementNotPresent ( "//A[@class='btn btn-primary pull-right button-fetch ng-scope'][contains(.,'Subscribe') ]", 5000, false ).
          pause ( 5000 ).
          useCss ().
          waitForElementVisible ( "li.selected-item:nth-child(2) > a:nth-child(1)", 5000, false ).
          pause ( 5000 ).
          //Checking the Delete button visibility
          verify.visible ( ".btn-delete" ).
          pause ( 5000 ).
          //Checking the Copy Button in the Subscription URL field
          verify.visible ( ".btn-pullout" ).
          pause ( 5000 ).
          //Checking the Save button visibility
          verify.visible ( ".btn-saved > span:nth-child(2)" ).
          useXpath ().
          //Navigates to the Video List page.
          click ( "//ul/li/a[text () ='Videos']" ).
          //Checks whether the Spinner is Present
          waitForElementVisible ( "//DIV[@class='spinner']", 5000, false ).
          //Checks whether the Spinner is not Present
          waitForElementNotVisible ( "//DIV[@class='spinner']", 5000, false ).
          useCss ().
          pause ( 1200 )
        }
      }
      else {
        //Initializing the incrementer value to invalid row variable
        var invalidRow = incrementer;
        client.
        //If the URL is invalid then it will return as Test fail and updated in the Excel sheet
        verify.fail ( "Invalid URL", "Vlid URL", "Please Enter Valid URL in Excel" ).
        //Writing the Fail result in the Excel Sheet with appropriate reason
        writeToExcelFail ( 'boxxspring.xlsx', 'SubscriptionYoutubeAdd', ++invalidRow, 4, 5, "Invalid URL" );
      }
    }
  },
  'SubscriptionYoutubeAdda': function ( subStatus ) {
    try {
      for ( z in addSubscription ) {
        if ( z[ 0 ] === '!' ) continue;
        else if ( z.includes ( 'B' ) ) {
          subscriptionURLCheck.push ( addSubscription[ z ].v );
        }
      }
    }
    catch ( err ) {
      console.log ( "Unable to load file!" );
    }
    for ( var incrementer = 1; incrementer <= subscriptionURLCheck.length - 1; incrementer++ ) {
      subStatus.
      useXpath ().
      pause ( 5000 ).
      click ( "//ul/li/a[text()='Subscriptions']" ).
      pause ( 5000 ).
      waitForElementPresent ( " ( //INPUT[@autocomplete='off'] )[2]", 5000, false ).
      clearValue ( " ( //INPUT[@autocomplete='off'] )[2]" ).
      pause ( 5000 ).
      useCss ().
      //clicking the Add subscription button from the list page
      waitForElementVisible ( "a.btn-primary", 9000, false ).
      pause ( 7000 ).
      click ( "a.btn-primary" ).
      pause ( 5000 ).
      verify.visible ( "h1.ng-scope" ).
      pause ( 7000 ).
      //Checking the Add Subscription text visibility
      verify.containsText ( "h1.ng-scope", "Add Subscription" ).
      pause ( 7000 ).
      useXpath ().
      //Clicking the Youtube Subscription button
      verify.visible ( "//ul/li/a[contains(.,'YouTube' )]" ).
      pause ( 5000 ).
      click ( "//ul/li/a[contains(.,'YouTube' )]" ).
      useCss ().
      //checking whether the control is in Add Subscription Page
      verify.visible ( ".typeName-label" ).
      waitForElementPresent ( ".text-input-headline", 5000, false ).
      useXpath ().
      //Passing the Value to the Subscription URL text field.
      setValue ( "//INPUT[@id='subscription_url']", subscriptionURLCheck[ incrementer ] ).
      useCss ().
      pause ( 5000 ).
      //Checking the next button visibility.
      verify.visible ( "button.btn:nth-child(2)" ).
      //Clicking the Next button 
      click ( "button.btn:nth-child(2)" ).
      pause ( 10000 ).
      useXpath ().
      pause ( 5000 ).
      waitForElementPresent ( "//SPAN[@class='ng-scope'][text()='This subscription is already in the system.']", 5000, function ( invalidURL ) {
        if ( invalidURL.status === 0 ) {
          subStatus.
          click ( "//ul/li/a[text()='Subscriptions']" ).
          pause ( 5000 )
        }
        else {
          verify.fail ( "Allows Duplicate Subscription", "Should not allow duplicates" )
        }
      });
    }
  },
  'SubscriptionYoutubeEdit': function ( editSubscription ) {
    try {
      for ( z in editSubscriptionSheet ) {
        if ( z[ 0 ] === '!' ) continue;
        else if ( z.includes ( 'D' ) ) {
          ingestionTimeEdit.push ( editSubscriptionSheet[ z ].v );
        }
        else if ( z.includes ( 'B' ) ) {
          searchContent.push ( editSubscriptionSheet[ z ].v );
        }
        else if ( z.includes ( 'C' ) ) {
          subscriptionTitle.push ( editSubscriptionSheet[ z ].v );
        }
      }
    }
    catch ( err ) {
      editSubscription.
      verify.fail ( "Unable to load Excel sheet" );
    }
    for ( var subIncrementer = 1, tempEdit = 1; subIncrementer <= subscriptionTitle.length - 1; subIncrementer++ ) {
      editSubscription.
      useXpath ().
      pause ( 7000 ).
      //Checking the Visibility of the Search Field in the Subscription List page
      verify.visible ( "//DIV[@class='suggestion-dropdown-wrap']" ).
      pause ( 5000 ). //5 seconds
      clearValue ( " ( //INPUT[@autocomplete='off'] )[2]" ).
      //Passing the Values in the Search Field from Excel sheet
      setValue ( " ( //INPUT[@autocomplete='off'] )[2]", searchContent[ subIncrementer ] ).
      pause ( 5000 ).
      //Fetching the results after Searching the Subscription
      getText ( "//DIV[@class='container']", function ( result ) {
        if ( result.value != "⬇Last modified\nNo results found\nTry checking your spelling or using more general keywords" ) {
          editSubscription.
          //Checking the Edit button visibility
          waitForElementPresent ( " ( //SPAN[@class='btn-pullout'] )[1]", 5000, false ).
          pause ( 5000 ). //5 seconds
          //Checking the Update now button visibility
          waitForElementPresent ( " ( //SPAN[@class='btn-pullout'] )[2]", 5000, false ).
          pause ( 5000 ). //5 seconds
          //clicking the Subscription
          click ( "//DIV[@class='content-title']" ).
          pause ( 5000 ). //5 seconds
          //Checking the Edit button visibility
          waitForElementNotPresent ( " ( //SPAN[@class='btn-pullout'] )[1]", 5000, false ).
          pause ( 5000 ). //5 seconds
          //Checking the Update now button visibility
          waitForElementNotPresent ( " ( //SPAN[@class='btn-pullout'] )[2]", 5000, false ).
          pause ( 5000 ). //5 seconds
          useCss ().
          //Checking the Save button visibility
          waitForElementPresent ( ".btn-saved", 5000, false ).
          //Clearing the datas in Subscription title field
          clearValue ( '.text-input-headline' ).
          //Enetering the Subscription values in the Title field
          setValue ( ".text-input-headline", subscriptionTitle[ tempEdit ] ).
          pause ( 5000 ). //5 seconds
          //Clearing the Categories in the Categories field
          pause ( 5000 ). //5 seconds
          //Checking whether the Control has moved to next page.
          waitForElementVisible ( ".typeName-label", 5000, false ).
          //Checking the Subscription URl field visibility
          waitForElementPresent ( "li.selected-item:nth-child(2) > a:nth-child(1)", 5000, false ).
          click ( "li.selected-item:nth-child(2) > a:nth-child(1)" ).
          pause ( 5000 ).
          useXpath ().
          //Making the Ingestion frequency OFF
          click ( "//a[@class='ellipsis ng-binding'][contains(.,'" + ingestionTimeEdit[ tempEdit ] + "' )]" ).
          pause ( 5000 ). //5 seconds
          //Checking the Provider name field visibility
          waitForElementPresent ( "//DIV[@class='input-like subscriptions ng-binding ng-scope']", 5000, false ).
          pause ( 5000 ). //5 seconds
          //Checking the Attribution field visibility
          waitForElementPresent ( "//DIV[@ng-if='attribution.name']", 5000, false ).
          useCss ().
          pause ( 5000 ). //5 seconds
          waitForElementNotPresent ( ".btn-saved", 5000, false ).
          //Clicking on the Save Button
          click ( ".btn-active" ).
          pause ( 15000 ).
          useXpath ().
          //Navigating Back to the Subscription list page
          click ( "//ul/li/a[text()='Subscriptions']" ).
          pause ( 5000 ).
          //Searching for updated Subscription in the Subscription list page
          setValue ( " ( //INPUT[@autocomplete='off'] )[2]", subscriptionTitle[ tempEdit ] ).
          pause ( 5000 ).
          //Fetching the Search results in Subscription list page
          getText ( "//H2[@class='ng-binding']", function ( results ) {
            // checkig the updated Subscription title with the Excel sheet data.
            if ( results.value == subscriptionTitle[ tempEdit ] ) {
              editSubscription.
              //If the Condition pass then Pass status is updated in the Excel sheet
              writeToExcelPass ( 'boxxspring.xlsx', 'SubscriptionYoutubeEdit', ++tempEdit, 5 )
            }
            else {
              editSubscription.
              verify.fail ( "Edit Subscription Failed", "Subscription should get updated", "Please check for the Duplicates in Subscription" ).
              //If the Test fail Fail status will be updated in Excel sheet
              writeToExcelFail ( 'boxxspring.xlsx', 'SubscriptionYoutubeEdit', ++tempEdit, 5, 6, "ActualResult:Subscription Title not updated - please try again" )
            }
          });
        }
        else {
          editSubscription.
          writeToExcelFail ( 'boxxspring.xlsx', 'SubscriptionYoutubeEdit', ++tempEdit, 5, 6, "ActualResult:Subscription does not exist - please try again" ).
          verify.fail ( "Unable to find Subscription", "Subscription should get updated", "Please provide valid Subscription name" )
          //If the Test fail Fail status will be updated in Excel sheet
        }
      });
    }
  },
  'DeleteYoutubeSubscription': function ( deleteSubscription ) {
    try {
      for ( z in deleteSubscriptionSheet ) {
        if ( z[ 0 ] === '!' ) continue;
        else if ( z.includes ( 'B' ) ) {
          searchContentDelete.push ( deleteSubscriptionSheet[ z ].v );
        }
      }
    }
    catch ( err ) {
      console.log ( "Unable to load file!" );
    }
    for ( var subIncrementer = 1, tempDelete = 1; subIncrementer <= searchContentDelete.length - 1; subIncrementer++ ) {
      deleteSubscription.
      useXpath ().
      //Checking the Search Input field visibility in the Subscription list page
      verify.visible ( "//DIV[@class='suggestion-dropdown-wrap']" ).
      pause ( 5000 ).
      //Checking the Search functionality
      getText ( "//DIV[@class='container']", function ( searchResult ) {
        //Checking whether the Search results in the Subscription list page
        if ( searchResult.value != "⬇Last modified\nNo results found\nTry checking your spelling or using more general keywords" ) {
          deleteSubscription.
          //Checking the  Visibility of Edit Button in Subscription list page
          waitForElementPresent ( " ( //SPAN[@class='btn-pullout'] )[1]", 5000, false ).
          pause ( 5000 ). //5 seconds
          //Checking the  Visibility of Update Button in Subscription list page
          waitForElementPresent ( " ( //SPAN[@class='btn-pullout'] )[2]", 5000, false ).
          pause ( 5000 ). //5 seconds
          //Clicking the Searched Subscription
          click ( "//DIV[@class='content-title']" ).
          pause ( 5000 ). //5 seconds
          //Checking whether the Edit button is not present after navigating to Edit Subscription page
          waitForElementNotPresent ( " ( //SPAN[@class='btn-pullout'] )[1]", 5000, false ).
          pause ( 5000 ). //5 seconds
          //Checking whether the Edit button is not present after navigating to Edit Subscription page
          waitForElementNotPresent ( " ( //SPAN[@class='btn-pullout'] )[2]", 5000, false ).
          pause ( 5000 ).
          useCss ().
          //Checking the Save button Visibility
          waitForElementPresent ( ".btn-saved", 5000, false ).
          pause ( 5000 ).
          useXpath ().
          //Checking the Subscription URL in the URL field
          waitForElementPresent ( "//INPUT[@id='subscription_source_url']", 5000, false ).
          pause ( 5000 ).
          //Checking the Provider name in the Provider field
          waitForElementPresent ( "//DIV[@class='input-like subscriptions ng-binding ng-scope']", 5000, false ).
          pause ( 5000 ). //5 seconds
          //Checking the Attribution name in the Attribution field
          waitForElementPresent ( "//DIV[@ng-if='attribution.name']", 5000, false ).
          pause ( 5000 ). //5 seconds
          useCss ().
          //Checking the Delete button visibility
          verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
          //Clicking the Delete button in the Subscription Edit page
          click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
          pause ( 7000 ).
          //Check the existance of delete confirmation to delete
          verify.visible ( "dialog[ name=deleteVerification ]" ).
          //Checking the existance of Delete button in the Delete dialog
          verify.visible ( "button.btn:nth-child(2)" ).
          //Clicking the Delete button in the Delete dialog box
          click ( "button.btn:nth-child(2)" ).
          pause ( 5000 ).
          useXpath ().
          //Clicking the Subscription button from the Side bar
          click ( "//ul/li/a[text()='Subscriptions']" ).
          pause ( 5000 ).
          //Entering the Search content in the Search field
          setValue ( " ( //INPUT[@autocomplete='off'] )[2]", searchContentDelete[ tempDelete ] ).
          pause ( 5000 ).
          //Getting the Search results
          getText ( "//DIV[@class='container']", function ( res ) {
            //Storing the values in getSearchResult variable
            getSearchResult = res.value;
            if ( getSearchResult == "⬇Last modified\nNo results found\nTry checking your spelling or using more general keywords" ) {
              deleteSubscription.
              //If condition results true PASS status will be updated in the Excel Sheet
              writeToExcelPass ( 'boxxspring.xlsx', 'DeleteYoutubeSubscription', ++tempDelete, 3 )
            }
            else {
              deleteSubscription.
              //If condition results false Fail status will be updated in the Excel Sheet
              writeToExcelFail ( 'boxxspring.xlsx', 'DeleteYoutubeSubscription', ++tempDelete, 3, 4, "It seems that there are Duplicates Please delete and Try again" ).
              verify.fail ( "It seems that there are some duplicate exists in Subscription", "Subscription should get deleted Successfully", "Please delete the Duplicates and Try again" )
            }
          });
        }
        else {
          //If there is no search results found then Fail status will get updated in Excel sheet
          deleteSubscription.
          writeToExcelFail ( 'boxxspring.xlsx', 'DeleteYoutubeSubscription', ++tempDelete, 3, 4, "Your Searched content is not available in the Subscription list page" ).
          verify.fail ( "Unable to find Subscription", "Subscription should get deleted Successfully", "Please provide valid Subscription name" )
        }
      });
    }
  },
  'InvalidPlaylistURL': function ( invalidSubscription ) {
    try {
      for ( z in InvalidPlaylistURL ) {
        if ( z[ 0 ] === '!' ) continue;
        else if ( z.includes ( 'B' ) ) {
          invalidSubscriptionURLCheck.push ( InvalidPlaylistURL[ z ].v );
        }
      }
    }
    catch ( err ) {
      console.log ( "Unable to load file!" );
    }
    invalidSubscription.
    pause ( 3000 )
    //Click on the Curation Button from the SideBar
    for ( var incrementer = 1, tempInvalid = 1; incrementer <= invalidSubscriptionURLCheck.length - 1; incrementer++ ) {
      invalidSubscription.
      pause ( 3000 ).
      useXpath ().
      //Checking the Subscription button is visibility
      waitForElementPresent ( "//ul/li/a[text()='Subscriptions']", 5000, false, function ( activeStatus ) {
        //if the Subscription button is not visible then Click on Curation button and then click on Subscription button 
        if ( activeStatus.value == true ) {
          invalidSubscription.
          useXpath ().
          //Clicking the Curation link from the sidebar
          click ( " ( //DIV[@class='content-header content ng-scope'])[3]" ).
          pause ( 5000 ).
          //Clicking the Subscription link from the Sidebar
          click ( "//ul/li/a[text()='Subscriptions']" )
        }
        //if the Subscription button is visible then Click directly on the Subscription button
        else {
          invalidSubscription.
          useXpath ().
          pause ( 5000 ).
          //clicking the Subscription button
          click ( "//ul/li/a[text()='Subscriptions']" );
        }
      });
      invalidSubscription.
      useCss ().
      pause ( 5000 ).
      //Fetching the Total count of Subscription before adding the Subscription
      getText ( '.pull-left.content-count > .ng-binding', function ( beforeCount ) {
        if ( beforeCount.status !== -1 ) {
          //Storing the value in the countBeforeAdd variable.
          countBeforeAdd = beforeCount.value;
          console.log ( "Count", countBeforeAdd );
        }
      });
      invalidSubscription.
      pause ( 5000 ).
      useXpath ().
      verify.visible ( "//DIV[@class='suggestion-dropdown-wrap']" ).
      pause ( 5000 ).
      useCss ().
      //clicking the Add subscription button from the list page
      waitForElementVisible ( "a.btn-primary", 9000, false ).
      pause ( 7000 ).
      click ( "a.btn-primary" ).
      pause ( 5000 ).
      verify.visible ( "h1.ng-scope" ).
      pause ( 7000 ).
      //Checking the Add Subscription text visibility
      verify.containsText ( "h1.ng-scope", "Add Subscription" ).
      pause ( 7000 ).
      useXpath ().
      //Clicking the Vimeo Subscription button
      verify.visible ( "//ul/li/a[contains(.,'YouTube' )]" ).
      pause ( 5000 ).
      click ( "//ul/li/a[contains(.,'YouTube' )]" ).
      useCss ().
      //checking whether the control is in Add Subscription Page
      verify.visible ( ".typeName-label" ).
      waitForElementPresent ( ".text-input-headline", 5000, false ).
      useXpath ().
      //Passing the Value to the Subscription URL text field.
      setValue ( "//INPUT[@id='subscription_url']", invalidSubscriptionURLCheck[ incrementer ] ).
      pause ( 5000 ).
      useCss ().
      pause ( 5000 ).
      //Checking the next button visibility.
      verify.visible ( "button.btn:nth-child(2)" ).
      //Clicking the Next button 
      click ( "button.btn:nth-child(2)" ).
      pause ( 5000 ).
      useXpath ().
      //waiting for the Error message
      waitForElementPresent ( "//span[@class='ng-binding ng-scope']", 5000, function ( invalidURL ) {
        //if error message is displayed then pass status will be updated in Excel.
        if ( invalidURL.status === 0 ) {
          invalidSubscription.
          click ( "//ul/li/a[text()='Subscriptions']" ).
          //writing the Pass status in Excel
          writeToExcelPass ( 'boxxspring.xlsx', 'InvalidPlaylistURL', ++tempInvalid, 3 ).
          pause ( 5000 )
        }
        else {
          //if error message is not displayed then pass status will be updated in Excel.
          invalidSubscription.
          //writing the Fail status in Excel
          writeToExcelFail ( 'boxxspring.xlsx', 'InvalidPlaylistURL', ++tempInvalid, 3, 4, "Error message not found after entering Invalid URL" ).
          verify.fail ( "Allows Invalid Subscription URL", "Should not allow Invalid Subscription URL" )
        }
      });
    }
    invalidSubscription.end ();
    schedulers.stop ();
  }
}
//this function is for check and Delete the Videos 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'VideosDelete' ];
var videosTitle = [ ];
var currentCount, actualCount, expectedCount, excelData, searchCount;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'videosDelete' ],
  //Login in to Application
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'VideosDelete': function ( videoDelete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Videos Title
      if ( excelData.includes ( 'A' ) ) {
        videosTitle.push ( worksheet[ excelData ].v );
      }  
    }
    if ( videosTitle.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < videosTitle.length; getData++ ) {
        rowCount++;
        videoDelete.pause ( 4000 ).useXpath ( ).
        //Check and Wait for Videos menu is visible in the CONTENT
        waitForElementVisible ( "//ul/li/a[text( ) = 'Videos' ]",4000,false,function ( checkVideosmenu ) {
          if ( checkVideosmenu.value == true ) {
            videoDelete.useXpath().
            //Verify the Videos menu is visible in the CONTENT
            verify.containsText ( "//ul/li/a[text( ) = 'Videos' ]", "Videos" ).
            pause ( 4000 ).
            //Click on the Videos Menu in the CONTENT
            click ( "//ul/li/a[text( ) = 'Videos' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get the Current Total Count in the Video listing page before adding story 
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }
            } );
            videoDelete.pause ( 4000 ).       
            //Wait for visible the Search input field
            waitForElementVisible ( ".search-field-input", 4000, false ).
            //Verify the Search input field is visible
            verify.visible ( ".search-field-input" ).
            //Enter the Data in Search input field
            setValue ( ".search-field-input", videosTitle[ getData ] ).
            //hold the control
            keys ( videoDelete.Keys.ENTER ). 
            //Click on the Searched field
            click ( ".search-field-input" ).
            //release the control
            keys ( videoDelete.Keys.NULL ). 
            pause ( 4000 ).
            //Wait for Total count label is visible in the listing page
            waitForElementVisible ( ".content-count>strong", 4000, false ).
            pause ( 4000 ).
            //Get the Search Total count in the Video listing page
            getText ( '.content-count > strong', function ( searchCountResult ) {                
              if ( searchCountResult.status !== -1 ) {
                searchCount = searchCountResult.value;
                searchCount = searchCount.substring ( 1, ( searchCount.length - 1 ) );
              }
              if ( searchCount > 0 ) {
                videoDelete.pause ( 4000 ).useXpath ( ).
                //Verify the Edit pull button in the Videos page
                waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ videosTitle[ getData ] +"']]", 4000, false ).
                pause ( 4000 ).
                //Click on edit pull button in the Videos page
                click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ videosTitle[ getData ] +"']]" ).
                pause ( 4000 ).useCss().
                //Verify the Content Tab in the Videos page
                verify.visible ( ".video-tabs > a[href='#content'] " ).
                //Click on Content Tab in the Videos page
                click ( ".video-tabs > a[href='#content'] " ).
                pause ( 4000 ).
                //Check and Enter Headline in the Videos page
                waitForElementVisible ( ".text-input-headline", 4000 , false ).
                //Clear the Headline in the Videos page
                clearValue ( ".text-input-headline" ).
                pause ( 4000 ).
                //Enter the Headline in the Videos page
                setValue ( ".text-input-headline", "Delete the Video" ).
                pause ( 4000 ).
                //Verify the Save button in the Videos page
                waitForElementVisible ( '.btn-active', 4000, false ).
                pause ( 4000 ).
                verify.visible ( ".btn-active" ).
                pause ( 4000 ).
                //click on Save button in the Videos page
                click ( ".btn-active" ).
                pause ( 4000 ).
                //Check and Click Delete Button in the Videos page
                verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                //Click on the Delete button in the portal
                click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                pause ( 4000 ).
                //Check the existance of delete confirmation dialog
                verify.visible ( "dialog[name=deleteVerification] " ).
                pause ( 4000 ).
                //Click Cancel Button in Delete Dialog
                verify.visible ( ".link-secondary" ).
                //Click on the Cancel button in the pop-up window
                click ( ".link-secondary" ).
                pause ( 4000 ).
                //Verify the Delete button in the Videos page
                verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                //Click on the Delete button in the portal
                click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                pause ( 4000 ).
                //Check the existance of delete confirmation to delete
                verify.visible ( "dialog[ name=deleteVerification ]" ).
                pause ( 4000 ).
                //Verify the delete button in dialog window
                verify.visible ( "button.btn:nth-child( 2 )" ).
                pause ( 4000 ).
                //Click on the Delete button in the pop-up window
                click ( "button.btn:nth-child(2)" ).
                pause ( 4000 ).useXpath ( ).
                //Verify the Videos menu is visible in the CONTENT
                verify.containsText ( "//ul/li/a[text( ) = 'Videos'] ", "Videos" ).
                pause ( 4000 ).
                //Click on the Videos menu is visible in the CONTENT
                click ( "//ul/li/a[ text( ) = 'Videos']" ).
                useCss ( ).pause ( 4000 ).
                waitForElementVisible ( ".content-count>strong", 4000, false ).
                pause ( 4000 ).
                verify.visible ( ".content-count>strong" ).
                pause ( 4000 ).
                //get Actual count in the videos list page
                getText ( '.content-count > strong', function ( actualCountResult ) {
                  if ( actualCountResult.status !== -1 ) {
                    actualCount = actualCountResult.value;
                    actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
                    expectedCount = ( ( + currentCount ) - ( 1 ) );
                    if ( actualCount == expectedCount ) {
                      //Write in the Excel: Pass Result
                      videoDelete.writeToExcelPass ( 'boxxspring.xlsx', 'VideosDelete', rowCount, 3 );
                    }
                    else {
                      //Write in the Excel: Fail Result and Reason
                      videoDelete.writeToExcelFail ( 'boxxspring.xlsx', 'VideosDelete', rowCount, 3, 4, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Videos. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
                    }
                  }
                } );
              }
              else {
                //Write in the Excel: Searched Fail Result and Reason
                videoDelete.writeToExcelFail ( 'boxxspring.xlsx', 'VideosDelete', rowCount, 3, 4, "Searched Result Count,'"+ searchCount +"'" );
              }
            } );
          }
          else {
            //Write in the Excel: Searched Fail Result and Reason
            videoDelete.writeToExcelFail ( 'boxxspring.xlsx', 'VideosDelete', rowCount, 3, 4, "Videos Menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    videoDelete.end ( );
  }
};
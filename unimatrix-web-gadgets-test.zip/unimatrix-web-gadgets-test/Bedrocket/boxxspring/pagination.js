//this function is to check the pagination functionality
var currentPagelist = [ ];
var currentCount;
var totalCount;
module.exports = {
  tags: [ 'pagination' ],
  before: function ( portalLogin ) {   
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CheckingThe Pagination functionality in Video list page': function ( paginationVideoList ) {   
    paginationVideoList.
    pause ( 5000 ).
    useCss ( ).
    pause ( 5000 ).
    //Getting the Page title for checking whether page is navigated to expected page
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Videos" ) {   
        paginationVideoList.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 2, 6 );
      }
      else {
        paginationVideoList.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 2, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationVideoList.
    useCss ( ).
    //Checking whether the list page is displayed
    waitForElementPresent ( ".list", 5000, false ).
    //Getting active Grid type
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      //Checking the Active Grid Type 
      if ( getGridView.value == "grid active" ) {   
        paginationVideoList.
        useCss ( ).
        //Clicking the List view type
        click ( "div.container div.presentation-toggle.clearfix div.list" ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridViewVideo ) {   
          console.log ( "Get grid view", getGridViewVideo.value ) 
          if ( getGridViewVideo.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        paginationVideoList.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    paginationVideoList.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 3, 6, 7 );
  },
  'Checking the Pagination functionality in Articles list page': function ( paginationArticle ) {   
    paginationArticle.
    useXpath ( ).
    //Navigating to Articles from sidebar of the application
    click ( "//a[text()= 'Articles' ]" ).
    pause ( 8000 ).
    useCss ( ).
    pause ( 5000 ).
    //Getting the Page title for checking whether page is navigated to expected page
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Articles" ) {   
        paginationArticle.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 7, 6 );
      }
      else {
        paginationArticle.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 7, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationArticle.
    waitForElementPresent ( ".presentation-toggle.clearfix >div.active", 5000, false ).
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      if ( getGridView.value == "grid active" ) {   
        paginationArticle.
        useXpath ( ).
        pause ( 5000 ).
        waitForElementPresent ( "//DIV[@class='list']", 5000, false ).
        click ( "//DIV[@class='list']" ).
        pause ( 5000 ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridViewArticles ) {   
          console.log ( "Get grid view", getGridViewArticles.value ) 
          if ( getGridViewArticles.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        paginationArticle.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    paginationArticle.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 8, 6, 7 );
  },
  'Checking the Pagination functionality in 360videos list page': function ( pagination360 ) {   
    pagination360.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to 360Videos from sidebar of the application
    click ( "//a[text()= '360videos' ]" ).
    pause ( 8000 ).
    useCss ( ).
    pause ( 5000 ).
    //Getting the Page title for checking whether page is navigated to expected page
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "360videos" ) {   
        pagination360.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 12, 6 );
      }
      else {
        pagination360.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 12, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    pagination360.
    waitForElementPresent ( ".presentation-toggle.clearfix >div.active", 5000, false ).
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      if ( getGridView.value == "grid active" ) {   
        pagination360.
        useXpath ( ).
        pause ( 5000 ).
        waitForElementPresent ( "//DIV[@class='list']", 5000, false ).
        click ( "//DIV[@class='list']" ).
        pause ( 5000 ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView360videos ) {   
          console.log ( "Get grid view", getGridView360videos.value ) 
          if ( getGridView360videos.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        pagination360.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    pagination360.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 13, 6, 7 );
  },
  'Checking the Pagination functionality in Links list page ': function ( paginationLink ) {   
    paginationLink.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to Links from sidebar of the application
    click ( "//a[text()= 'Links' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Links" ) {   
        paginationLink.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 17, 6 );
      }
      else {
        paginationLink.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 17, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationLink.
    waitForElementPresent ( ".presentation-toggle.clearfix >div.active", 5000, false ).
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      if ( getGridView.value == "grid active" ) {   
        paginationLink.
        useXpath ( ).
        pause ( 5000 ).
        waitForElementPresent ( "//DIV[@class='list']", 5000, false ).
        click ( "//DIV[@class='list']" ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridViewLinks ) {   
          console.log ( "Get grid view", getGridViewLinks.value ) 
          if ( getGridViewLinks.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        paginationLink.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    paginationLink.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 18, 6, 7 );
  },
  'Checking the Pagination functionality in Categories list page': function ( paginationCategories ) {   
    paginationCategories.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to Categories from sidebar of the application
    click ( "//a[text()= 'Categories' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Categories" ) {   
        paginationCategories.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 22, 6 );
      }
      else {
        paginationCategories.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 22, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationCategories.
    waitForElementPresent ( ".presentation-toggle.clearfix >div.active", 5000, false ).
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      if ( getGridView.value == "grid active" ) {   
        paginationCategories.
        useXpath ( ).
        pause ( 5000 ).
        waitForElementPresent ( "//DIV[@class='list']", 5000, false ).
        click ( "//DIV[@class='list']" ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        useCss ( ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridViewCategories ) {   
          console.log ( "Get grid view", getGridViewCategories.value ) 
          if ( getGridViewCategories.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        paginationCategories.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    paginationCategories.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 23, 6, 7 );
  },
  'Checking the Pagination functionality in Authors list page ': function ( paginationAuthors ) {   
    paginationAuthors.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to Authors from sidebar of the application
    click ( "//a[text()= 'Authors' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Authors" ) {   
        paginationAuthors.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 27, 6 );
      }
      else {
        paginationAuthors.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 27, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationAuthors.
    waitForElementPresent ( ".presentation-toggle.clearfix >div.active", 5000, false ).
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      if ( getGridView.value == "grid active" ) {   
        console.log ( "Im in If loop" );
        paginationAuthors.
        useXpath ( ).
        pause ( 5000 ).
        waitForElementPresent ( "//DIV[@class='list']", 5000, false ).
        click ( "//DIV[@class='list']" ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        useCss ( ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridViewAuthors ) {   
          console.log ( "Get grid view", getGridViewAuthors.value ) 
          if ( getGridViewAuthors.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        paginationAuthors.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    paginationAuthors.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 28, 6, 7 );
  },
  'Checking the Pagination functionality in VideoList list page ': function ( paginationVideoListPage ) {   
    paginationVideoListPage.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to VideoList from sidebar of the application
    click ( "//a[text()= 'VideoList' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "VideoList" ) {   
        paginationVideoListPage.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 32, 6 );
      }
      else {
        paginationVideoListPage.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 32, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationVideoListPage.
    waitForElementPresent ( ".presentation-toggle.clearfix >div.active", 5000, false ).
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      if ( getGridView.value == "grid active" ) {   
        paginationVideoListPage.
        useXpath ( ).
        pause ( 5000 ).
        waitForElementPresent ( "//DIV[@class='list']", 5000, false ).
        click ( "//DIV[@class='list']" ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        useCss ( ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridViewVideoList ) {   
          console.log ( "Get grid view", getGridViewVideoList.value ) 
          if ( getGridViewVideoList.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        paginationVideoListPage.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    paginationVideoListPage.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 33, 6, 7 );
  },
  'Checking the Pagination functionality in Attributions list page': function ( paginationAttributions ) {   
    paginationAttributions.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to Attributions from sidebar of the application
    click ( "//a[text()= 'Attributions' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Attributions" ) {   
        paginationAttributions.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 37, 6 );
      }
      else {
        paginationAttributions.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 37, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationAttributions.
    waitForElementPresent ( ".presentation-toggle.clearfix >div.active", 5000, false ).
    getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridView ) {   
      console.log ( "Get grid view", getGridView.value ) 
      if ( getGridView.value == "grid active" ) {   
        paginationAttributions.
        useXpath ( ).
        pause ( 5000 ).
        waitForElementPresent ( "//DIV[@class='list']", 5000, false ).
        pause ( 5000 ).
        click ( "//DIV[@class='list']" ).
        //checking whether the clicked element is List view
        pause ( 10000 ).
        useCss ( ).
        getAttribute ( '.presentation-toggle.clearfix >div.active', "class", function ( getGridViewattribution ) {   
          console.log ( "Get grid view", getGridViewattribution.value ) 
          if ( getGridViewattribution.value == "list active" ) {   
            console.log ( "View type changed to List View" ) 
          }
          else {
            console.log ( "Unable to change the View Type." ) 
          }
        } );
      }
      else {
        paginationAttributions.
        useXpath ( ).
        waitForElementPresent ( "//DIV[@class='list active']", 5000, false );
      }
    } );
    paginationAttributions.
    pause ( 5000 ).
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 38, 6, 7 );
  },
  'Checking the Pagination functionality in Subscription list page': function ( paginationSubscriptions ) {   
    paginationSubscriptions.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to Attributions from sidebar of the application
    click ( " ( //DIV[@class='content-header content ng-scope'] ) [3]" ).
    pause ( 5000 ).
    click ( "//a[text()= 'Subscriptions' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Subscriptions" ) {   
        paginationSubscriptions.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 42, 6 );
      }
      else {
        paginationSubscriptions.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 42, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationSubscriptions.
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 43, 6, 7 );
  },
  'Checking the Pagination functionality in Destination list page': function ( paginationDestination ) {   
    paginationDestination.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to Attributions from sidebar of the application
    click ( " ( //DIV[@class='content-header content ng-scope']) [4]" ).
    pause ( 5000 ).
    click ( "//a[text()='Destinations' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Destinations" ) {   
        paginationDestination.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 47, 6 );
      }
      else {
        paginationDestination.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 47, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationDestination.
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 3, 6, 7 );
  },
  'Checking the Pagination functionality in Advertising list page': function ( paginationAdvertising ) {   
    paginationAdvertising.
    pause ( 3000 ).
    useXpath ( ).
    //Navigating to Attributions from sidebar of the application
    click ( "(//DIV[@class='content-header content ng-scope'])[5]" ).
    pause ( 5000 ).
    click ( "//a[text()= 'Advertising' ]" ).
    pause ( 8000 ).
    useCss ( ).
    getText ( "h1.pull-left.content-count span.ng-binding", function ( getCurrPageName ) {   
      //Checking whether page is navigated to expected page
      if ( getCurrPageName.value == "Ad Source" ) {   
        paginationAdvertising.
        //Writing Pass status to Excel sheet
        writeToExcelPass ( 'Pagination.xlsx', 'Pagination', 52, 6 );
      }
      else {
        paginationAdvertising.
        //Writing Fail status to Excel sheet
        writeToExcelFail ( 'Pagination.xlsx', 'Pagination', 52, 6, 7, "Unable to navigate to requested Page" );
      }
    } );
    paginationAdvertising.
    //Invoking the Pagination function from custom commands
    pagination ( 'Pagination.xlsx', 'Pagination', 53, 6, 7 );
    paginationAdvertising.end ();
  }
}
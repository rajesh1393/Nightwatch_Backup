var xlsx = require('xlsx');
var fs = require('fs');
var Excel = require('exceljs');
if (typeof require !== 'undefined') XLSX = require('xlsx');
var workbook = XLSX.readFile('boxxspring.xlsx', {
  cellStyles: true
});
var worksheet = workbook.Sheets['DistributionAttributions'];
var attributionTitle = [];
var attributionHeadline = [];
var distribSearch = [];
var resultStatus = [];
var currentCount;
var actualCount;
var expectedCount;
var getData, convertData = 1;
var rowCount = 1;
module.exports = {
  tags: ['distributionAttributions'],
  before: function(portalLogin) {
    var profile = portalLogin.globals.profile;
    portalLogin.login(profile.portalUri, profile.username, profile.password);
  },
  'Distribution Attributions': function(attributionsDistribution) {
    for (z in worksheet) {
      if (z[1] === '!') continue;
      //Read Category Title
      if (z.includes('A')) {
        attributionTitle.push(worksheet[z].v);
      }
      //Read Category Description
      if (z.includes('B')) {
        attributionHeadline.push(worksheet[z].v);
      }
      //Read Destination Search Type
      if (z.includes('C')) {
        distribSearch.push(worksheet[z].v);
      }
    }
    if (attributionTitle.length > 1) {
      console.log("Length:", +attributionTitle.length)
      attributionsDistribution.pause(9000).
      useXpath().
      //Verify the Attributions menu in the CONTENT is visible
      verify.containsText("//ul/li/a[ text ( ) = 'Attributions']", "Attributions").
      pause(3000).
      //Click on the Attributions menu in the CONTENT
      click("//ul/li/a[ text ( ) = 'Attributions']").
      useCss().pause(9000).
      //Get the Current Total count in the Attributions listing page
      getText('.content-count > strong', function(currentCountResult) {
        if (currentCountResult.status !== -1) {
          currentCount = currentCountResult.value;
          currentCount = currentCount.substring(1, currentCount.length - 1);
          console.log('Count - Before adding an Attributions: ', +currentCount);
        }
        for (var getData = 1, rowCount = 1; getData < attributionTitle.length; getData++) {
          //Wait for the List view option is visible
          var resultStatus = [];
          attributionsDistribution.pause(7000).waitForElementVisible(".list", 9000, false).
          pause(7000).
          //Click on the List view option in the Attributions listing page
          click(".list").
          //Wait for the Search Input Field is visible
          pause(9000).waitForElementVisible(".search-field-input", 9000, false).
          //Verfiy the Search Input Field is visible
          verify.visible(".search-field-input").
          //Clear the data in Search Input field 
          clearValue(".search-field-input").
          //Enter the data in Search Input field 
          setValue(".search-field-input", attributionTitle[getData]).
          //Press Enter key
          keys(attributionsDistribution.Keys.ENTER).
          click(".search-field-input").
          //Release Enter Key
          keys(attributionsDistribution.Keys.NULL).
          pause(10000)
          console.log("I 1st", getData)
          //Wait for the Search Count label is visible
          attributionsDistribution.waitForElementVisible(".content-count>strong", 5000).
          //Verfiy the Search Count label is visible
          verify.visible(".content-count>strong").
          //Get the Searched data count in the Attributions listing page
          getText('.content-count > strong', function(searchCountResult) {
            if (searchCountResult.status !== -1) {
              searchCount = searchCountResult.value;
              searchCount = searchCount.substring(1, searchCount.length - 1);
              console.log('Searched Article Count: ', +searchCount);
            }
            if (getData >= attributionTitle.length) {
              var convertData = getData - (attributionTitle.length - 1);
              getData++;
            }
            console.log("K-convertData", convertData)
            attributionsDistribution.pause(9000).useXpath().
            //Wait for the Searched data is visible in the Attributions listing page
            waitForElementVisible("(//h2[@class='ng-binding'])[1]", 9000, false).
            pause(7000).
            //Verify the Searched data is visible in the Attributions listing page
            verify.visible("(//h2[@class='ng-binding'])[1]").
            pause(9000).
            //Click on the Searched data in the Attributions listing page
            click("(//h2[@class='ng-binding'])[1]").
            useCss().pause(9000)
            console.log('Count - I12: ', +convertData);
            attributionsDistribution.pause(9000).
            //Verify the Content Tab is visible in the Attributions page
            verify.visible(".video-tabs > a[ href='#content']").
            //Click on the Content Tab in the Attributions page
            click(".video-tabs > a[ href='#content']").
            pause(9000).
            //Wait for the Headline field is visible in the Attributions page
            waitForElementVisible(".text-input-headline", 9000, false).
            //Clear the data in the Headline field in the Attributions page
            clearValue(".text-input-headline").
            //Enter the data in the Headline field in the Attributions page
            setValue(".text-input-headline", attributionHeadline[convertData]).
            pause(10000).
            //Verify the Save button is visible
            verify.visible(".btn-active").
            pause(7000).
            //Click on the Save button
            click(".btn-active").
            pause(9000).
            //Verify the Properties Tab is visible in the Attributions page
            verify.visible(".video-tabs a[ href='#distribution']").
            pause(10000).
            //Click on the Properties Tab in the Attributions Page
            click(".video-tabs a[ href='#distribution']").
            pause(9000).
            //Wait for the Add Distribution button is visible in Distribution Tab page
            waitForElementVisible(".distro-button", 9000, false).
            pause(9000).
            //Click on the Add Distribution button in Distribution Tab page
            click(".distro-button").
            pause(9000).
            //Wait for the Toggle filter dropdown is visible
            waitForElementVisible("a.ng-binding[ng-click='toggleFilterDropdown();']", 9000, false).
            pause(7000).
            //Verify the Toggle filter dropdown is visible
            verify.visible("a.ng-binding[ng-click='toggleFilterDropdown();']").
            pause(7000).
            //Click on the Toggle filter dropdown option
            click("a.ng-binding[ng-click='toggleFilterDropdown();']").
            pause(9000).useXpath().
            //Wait for the options in the list should be visible
            waitForElementVisible("//ul/li/a[contains (.,'boxxspring')]", 9000, false, function(destinationList) {
              if (destinationList.value === true) {
                console.log("destinationList", destinationList)
                attributionsDistribution.pause(7000).
                //Verify the options in the listing is visible
                verify.visible("//ul/li/a[contains (.,'boxxspring')]").
                pause(7000).
                //Click on the options in the dropdown list
                click("//ul/li/a[contains (.,'boxxspring')]")
                var categoryTemp = distribSearch[convertData];
                var categoryTemp_array = categoryTemp.split(',');
                for (var categoryCount = 0; categoryCount < categoryTemp_array.length; categoryCount++) {
                  //Split the Category data and store in the Temp variable
                  categoryTemp_array[categoryCount] = categoryTemp_array[categoryCount].replace(/^\s*/, "").replace(/\s*$/, "");
                  console.log("Comma Separated:", categoryTemp_array[categoryCount])
                  attributionsDistribution.useCss().pause(12000).
                  //Wait for the Saerch -Input Field is visible
                  waitForElementVisible(".full-width-search-field-input", 9000, false).
                  pause(7000).
                  //Verify the Saerch -Input Field is visible
                  verify.visible(".full-width-search-field-input").
                  pause(7000).
                  //Clear the data in the Saerch -Input Field
                  clearValue(".full-width-search-field-input").
                  pause(7000).
                  //Enter the data in the Saerch -Input Field
                  setValue(".full-width-search-field-input", categoryTemp_array[categoryCount]).
                  pause(9000).useXpath().
                  //Wait for the searched data in listing down is visible
                  waitForElementVisible("//label[@class='label-left ng-binding'][contains ( .,'" + categoryTemp_array[categoryCount] + "' )]", 9000, false).
                  pause(7000).
                  //Click on the Searched data in the distribution page
                  click("//label[@class='label-left ng-binding'][ contains ( .,'" + categoryTemp_array[categoryCount] + "' )]").
                  useCss().pause(5000)
                }
                attributionsDistribution.pause(8000).
                //Wait for the Next button is visible
                waitForElementVisible(".btn-next", 9000, false).
                //Click on the Next Button in the Distribution button
                click(".btn-next").
                //Get the Text for Selected Destination count in the Distribution page
                getText("h3.distributions-title.ng-binding", function(test) {
                  var rest = test.value;
                  console.log("rest", rest);
                  var rest1 = "Selected Destinations " + categoryTemp_array.length;
                  console.log("rest1", rest1)
                  //Compare the Actual and Expected data in the Distribution page
                  if (rest === rest1) {
                    console.log("paasssssed");
                    attributionsDistribution.pause(7000).useCss().
                    //Verify the Cancel button in the Distribution page
                    verify.visible(".cancel-distribution").
                    pause(7000).
                    //Verify the All Post button is visible in the Distribution page
                    verify.visible("a.btn-next:nth-child( 2 )").
                    pause(7000).
                    //Click on the All Post button in the Distribution page
                    click("a.btn-next:nth-child( 2 )").
                    pause(7000)
                    for (var getData = 3; getData < categoryTemp_array.length + 3; getData++) {
                      console.log("forloop getdata", getData)
                      console.log("rowCount11:Value:", rowCount)
                      console.log("forloop categoryTemp_array.length", categoryTemp_array.length)
                      //Get the Value for Destination posted in the Distribution page
                      attributionsDistribution.pause(9000).getValue("ul.post-list li>.ng-scope", function(allPost) {
                        console.log("allPost", allPost)
                        console.log("allPost getData", getData)
                        if (allPost.status === 0) {
                          if (getData >= categoryTemp_array.length + 3) {
                            convertData = getData - (categoryTemp_array.length);
                            getData++;
                            console.log("rowCount22:value:", rowCount)
                            console.log("Viss", convertData)
                            //attributionsDistribution.pause ( 9000 ).useCss ( ).waitForElementVisible ( "li.completed:nth-child ( "+convertData+" )", 9000, false,function ( result ){                
                            attributionsDistribution.pause(9000).useCss().
                            //Wait for the Distributed post is visible in the distribution page
                            waitForElementVisible("li.completed:nth-child(" + convertData + ")>span>ng-include>div.description>a", 9000, false, function(result1) {
                              console.log("Vishnu", getData)
                              if (result1.value === true) {
                                console.log("result", result1)
                                console.log("result12", result1.value)
                                attributionsDistribution.pause(7000).
                                //getText ( "//div/a[@class='ng-binding ng-scope']",function (  urlResult  ) {
                                //Get the Distributed post url in the distribution page
                                getText("li.completed:nth-child(" + convertData + ")>span>ng-include>div.description>a", function(urlResult) {
                                  console.log("urlResult::", urlResult);
                                  console.log("urlResult:value:", urlResult.value)
                                  if (urlResult.status == 0) {
                                    //Write in the Excel as PASS Results
                                    console.log("rowCount:rowCount:", rowCount);
                                    attributionsDistribution.pause(3000);
                                    resultStatus.push("PASS");
                                    console.log("result pass", resultStatus);
                                    console.log("rowCount:After count:", rowCount, resultStatus)
                                  }
                                  else {
                                    attributionsDistribution.pause(3000);
                                    resultStatus.push("FAIL");
                                    console.log("result fail", resultStatus);

                                  }
                                });
                              }
                              else {
                                console.log("Else Result", result1.value)
                                //Write in the Excel as FAIL Results and Reason
                                attributionsDistribution.writeToExcelFail('boxxspring.xlsx', 'Distributionattributions', ++rowCount, 5, 6, "Completed Post is not displayed");
                              }
                              console.log("hi-->>li.completed:nth-child(" + convertData + ")")
                            });
                          }
                        }
                        else {
                          console.log("Else allPost", allPost.value)
                          //Write in the Excel as FAIL Results and Reason
                          attributionsDistribution.writeToExcelFail('boxxspring.xlsx', 'Distributionattributions', ++rowCount, 5, 6, "Post List is not visible");
                        }
                      });
                      // rowCount++;
                    }
                    attributionsDistribution.pause(9000).getValue("ul.post-list li>.ng-scope", function(allPostResult) {
                      console.log("result array", resultStatus);
                      console.log("allPostResult", allPostResult);
                      if (resultStatus.indexOf('FAIL') >= 0) {
                        attributionsDistribution.writeToExcelFail('boxxspring.xlsx', 'DistributionAttributions', ++rowCount, 5, 6, "Completed Post URL is not displayed");
                        console.log("rowCount plus plusfail:Value:", rowCount)
                      }
                      else if (resultStatus.length == 0) {
                        console.log("result empty", resultStatus);
                      }
                      else {
                        attributionsDistribution.writeToExcelPass('boxxspring.xlsx', 'DistributionAttributions', ++rowCount, 5);
                        console.log("rowCount plus plus pass:Value:", rowCount)
                      }
                      if (resultStatus.indexOf('FAIL') || resultStatus.indexOf('PASS') >= 0) {
                        resultStatus.length = 0;
                      }
                    });
                  }
                });
                attributionsDistribution.pause(9000).useXpath().
                //Verify the Attributions menu in the CONTENT is visible
                verify.containsText("//ul/li/a[ text ( ) = 'Attributions']", "Attributions").
                pause(9000).
                //Click on the Attributions menu in the CONTENT
                click("//ul/li/a[ text ( ) = 'Attributions']").
                useCss()
              }
              else {
                console.log("Failed List in destination")
                attributionsDistribution.writeToExcelFail('boxxspring.xlsx', 'DistributionAttributions', ++rowCount, 5, 6, "There is no Destinations in the page").
                pause(9000).useXpath().
                //Verify the Attributions menu in the CONTENT is visible
                verify.containsText("//ul/li/a[ text ( ) = 'Attributions']", "Attributions").
                pause(9000).
                //Click on the Attributions menu in the CONTENT
                click("//ul/li/a[ text ( ) = 'Attributions']").
                useCss()
              }
            });
          });
        }
      });
    }
    //End the Browser
    attributionsDistribution.end();
  }
};
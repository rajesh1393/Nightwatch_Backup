//this function is for check and Edit the Links
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'LinksEdit' ];
var linkTitle = [ ];
var linkSearch = [ ];
var linkDescription = [ ];
var linkshortTitle = [ ];
var linkshortDesc = [ ];
var linkCategoryName = [ ];
var linkNote = [ ];
var linkImg = [ ];
var currentCount, actualCount;
var expectedCount, searchCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'LinksEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'LinksEdit': function ( editLink ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        linkTitle.push ( worksheet[ excelData ].v );
      }
      //Read Search_Links Data
      if ( excelData.includes ( 'B' ) ) {
        linkSearch.push ( worksheet[ excelData ].v );
      }
      //Read the Links Description for Content tab
      if ( excelData.includes ( 'C' ) ) {
        linkDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'D' ) ) {
        linkshortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'E' ) ) {
        linkshortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Links category Name
      if ( excelData.includes ( 'F' ) ) {
        linkCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read Links Note
      if ( excelData.includes ( 'G' ) ) {
        linkNote.push ( worksheet[ excelData ].v );
      }
      //Read Links Image
      if ( excelData.includes ( 'H' ) ) {
        linkImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( linkTitle.length > 1 ) {
      var checkResult = editLink.globals.excelCol.resultCustomData;
      for ( let getData = 1,rowCount = 1; getData < linkTitle.length; getData++ ) {
        rowCount++;
        editLink.pause ( 9000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Links' ]", 9000, false, function ( checkLinksMenu ) {
          if ( checkLinksMenu.value == true ) {
            editLink.pause ( 9000 ).useXpath ( ).
            //Verify the Links menu is visible in the CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Links' ]", "Links" ).
            pause ( 9000 ).
            //Click on the Links menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Links' ] " ).
            useCss ( ).pause ( 9000 ).
            //Get the Current Total count in the Links listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              //Wait for the Search field is visible
              editLink.pause ( 9000 ).
              waitForElementVisible ( ".search-field-input", 5000, false ).
              //Verify the Search field is visible
              verify.visible ( ".search-field-input" ).
              pause ( 9000 ).
              //Enter the Data in the search field
              setValue ( ".search-field-input", linkSearch[ getData ] )
              //Keys hold the control
              editLink.keys ( editLink.Keys.ENTER ). 
              click ( ".search-field-input" ).
              //Keys release the control
              keys ( editLink.Keys.NULL ). 
              pause ( 9000 ).
              //Wait for the Searched Total count label is visible in the Links listing page
              waitForElementVisible ( ".content-count>strong", 9000, false ).
              pause ( 9000 ).
              //Verify the Searched Total count label is visible in the Links listing page
              verify.visible ( ".content-count>strong" ).
              //Get the Searched Total count in the Links listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {                
                if ( searchCountResult.status != -1 ) {
                  searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                }
                if ( searchCount > 0 ) {
                  editLink.useXpath ( ).pause ( 9000 ).
                  //Wait for the searched data listed is visible
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ linkSearch[ getData ] +"']]", 9000, false, function ( checkSearchedLst ) {
                    if ( checkSearchedLst.value == true ) {
                      editLink.pause ( 9000 ).useXpath ( ).
                      verify.visible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ linkSearch[ getData ] +"']]" ).
                      pause ( 9000 ).
                      //Click on the searched data in the Links listing page
                      click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ linkSearch[ getData ] +"']]" ).
                      pause ( 9000 ).useCss ( ).
                      //Verify the Content tab is visible
                      verify.visible ( ".video-tabs>a[href='#content']" ).
                      //Click on the Content tab
                      click ( ".video-tabs>a[href='#content']" ).
                      pause ( 9000 ).
                      //Wait for the headline field is visible
                      waitForElementVisible ( ".text-input-headline", 9000, false ).
                      //Clear the data in the headline field
                      clearValue ( ".text-input-headline" ).
                      pause ( 9000 ).
                      //Enter the data in the headline field
                      setValue ( ".text-input-headline", linkTitle[ getData ] ).
                      pause ( 9000 ).
                      //Check and Enter Links Text Description
                      waitForElementVisible ( ".wmd-input", 9000, false ).
                      //Clear the data in the description field
                      clearValue ( ".wmd-input" ).
                      //Enter the data in the description field
                      setValue ( ".wmd-input", linkDescription[ getData ] ).
                      pause ( 9000 ).
                      //Wait for the Save button is visible in the content tab
                      waitForElementVisible ( '.btn-active', 9000, false ).
                      //Verify the Save button is visible in the content tab
                      verify.visible ( ".btn-active" ).
                      pause ( 9000 ).
                      //Click on the Save button
                      click ( ".btn-active" ).
                      pause ( 9000 ).
                      //Check the visibility and Enter the Data in the respective fields
                      video_properties ( linkshortTitle[ getData ], linkshortDesc[ getData ], linkCategoryName[ getData ], linkNote[ getData ], linkImg[ getData ] ).
                      pause ( 9000 ).useCss ( ).
                      waitForElementVisible ( ".video-tabs > a[ href='#properties']", 9000, false, function ( checkProperties ) {
                        if ( checkProperties.value == true ) {
                          if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                            editLink.writeToExcelFail ( 'boxxspring.xlsx', 'LinksEdit', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                            checkResult.length = 0;
                          }
                          else if ( checkResult.length == 0 ) {
                          }
                          else {
                            checkResult.length = 0;
                            //Check and click save button
                            editLink.verify.visible ( "a.btn-active" ).
                            //click on the save button
                            click ( "a.btn-active" ).
                            pause ( 7000 ).
                            waitForElementNotPresent ( "a.btn-active",9000,false,function ( checkSaveBtn ) {
                              if ( checkSaveBtn.value.length == 0 ) {
                                editLink.pause ( 9000 ).useXpath ( ).
                                //Verify the videos menu in the sidebar
                                verify.containsText ( "//ul/li/a[ text( ) = 'Links']", "Links" ).
                                pause ( 9000 ).
                                //click on the videos menu in CONTENT
                                click ( "//ul/li/a[ text( ) = 'Links']" ).
                                useCss ( ).pause ( 9000 ) 
                                //Check the Actual Count after each video added
                                editLink.useCss ( ).pause( 9000 ).
                                getText ( '.content-count > strong', function ( actualCountResult ) {
                                  if ( actualCountResult.status !== -1 ) {
                                    actualCount = actualCountResult.value;
                                    actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                    if ( actualCount == currentCount ) {
                                      //Write in the spreadsheet: Pass Result and Reason
                                      editLink.writeToExcelPass ( 'boxxspring.xlsx', 'LinksEdit', rowCount, 10 );
                                    }
                                    else {
                                      //Write in the spreadsheet: Fail Result and Reason
                                      editLink.writeToExcelFail ( 'boxxspring.xlsx', 'LinksEdit', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Videos(URL). ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                    }
                                  }
                                } );
                              }
                              else {
                                //Write in the spreadsheet: Fail Result and Reason
                                editLink.writeToExcelFail ( 'boxxspring.xlsx', 'LinksEdit', rowCount, 10, 11, "Save button is not functioning as expected" );
                              }
                            } );                            
                          }
                          if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                            checkResult.length = 0;
                          }
                        }                        
                      } );  
                    }
                    else {
                      //Write in the Excel for FAIL Result and Reason
                      editLink.writeToExcelFail ( 'boxxspring.xlsx', 'LinksEdit', rowCount, 10, 11, "Searched Data is not listed in the Links listing page" );
                       
                    } 
                  } );              
                }
                else {
                  //Write in the Excel for FAIL Result and Reason
                  editLink.writeToExcelFail ( 'boxxspring.xlsx', 'LinksEdit', rowCount, 10, 11, "Searched Result Count,'"+ searchCount +"'" );
                }
              } );            
            } );
          }
          else {
            //Write in the Excel for FAIL Result and Reason
            editLink.writeToExcelFail ( 'boxxspring.xlsx', 'LinksEdit', rowCount, 10, 11, "Links Menu is not displayed in Sidebar" );                        
          }
        } );
      }
    }
    //End the Browser
    editLink.end ( );
  }
};
//this function is for checking the Portal Cancel button functionality
module.exports = {
  tags: [ 'portalCancelButton' ],
  before: function ( portalLogin ) {
    //login the portal and check the theme
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  after: function ( closeBrowser ) {
    //End the Browser
    closeBrowser.end ( );
  },
  beforeEach: function ( addXlData, done ) {
    setTimeout ( function ( ) {
      //get the excel sheet name from the function name
      var sheetName = addXlData.currentTest.name;
      //read values from excel
      addXlData.excelInput ( 'boxxspring.xlsx', sheetName );
      done ( );
    }, 200 );
  },
  afterEach: function ( clearXlData, done ) {
    setTimeout ( function ( ) {
      //clear the input array allocated in the global
      clearXlData.emptyExcelInput ( );
      done ( );
    }, 200 );
  },
  'PortalCancelButton': function ( cancel ) {
    //Access the variable globally defined
    var excel = cancel.globals.excelCol;
    if ( excel.A.length > 0 ) {
      console.log ( "Excel row count: " + excel.A.length );
      //loop the 'n' number of excel input
      for ( let excelColumn = 1; excelColumn != excel.A.length; excelColumn++ ) {
        var excelRow = 1;
        cancel.pause ( 9000 ).
        useXpath ( ).
        //Wait and click the side menu in Portal
        waitForElementPresent ( '//div[@ng-click="collapse.' + excel.A[ excelColumn ] + ' = !collapse.' + excel.A[ excelColumn ] + '"]', 9000, false, function ( hiddenSidebar ) {
        	if ( hiddenSidebar.status == 0 ) {
        		cancel.pause ( 5000 ).
        		click ( '//div[@ng-click="collapse.' + excel.A[ excelColumn ] + ' = !collapse.' + excel.A[ excelColumn ] + '"]' );
        	}
        } );
				//Wait and click the side menu and the respective sub menu in Portal
        cancel.waitForElementVisible ( "//div[@ng-show='collapse." + excel.A[ excelColumn ] + "']//*/li/a[contains(.,'" + excel.B[ excelColumn ] + "' )]", 9000, false, function ( sidebar ) {
          if ( sidebar.value == true ) {
            //Click on the option in the side menu bar in Portal
            cancel.click ( "//div[@ng-show='collapse." + excel.A[ excelColumn ] + "']//*/li/a[contains(.,'" + excel.B[ excelColumn ] + "' )]" ).
            pause ( 3000 ).
            //check the visibility of the search textbox
            waitForElementPresent ( "//div[@class='suggestion-dropdown-wrap']/input", 5000, false, function ( searchFieldInput ) {
              if ( searchFieldInput.status == 0 ) {
                cancel.clearValue ( "//div[@class='suggestion-dropdown-wrap']/input" ).
                setValue ( "//div[@class='suggestion-dropdown-wrap']/input", excel.C[ excelColumn ] ).
                keys ( cancel.Keys.ENTER );
              }
            } );
            cancel.waitForElementVisible ( "//h2[@class='ng-binding'][text()[normalize-space(.)='" + excel.C[ excelColumn ] + "']]", 5000, false, function ( searchFieldResult ) {
              if ( searchFieldResult.status == 0 ) {
                cancel.pause ( 5000 ).
                click ( "//h2[@class='ng-binding'][text()[normalize-space(.)='" + excel.C[ excelColumn ] + "']]" );
                //check the cancel button functionality and close button in dialog box
                for ( let checkCancelButn = 1; checkCancelButn < 3; checkCancelButn++ ) {
                  //check the visibility of the delete button
                  cancel.waitForElementPresent ( '//ng-include/ul/li/a[@class="btn btn-icon btn-delete"]', 5000, false, function ( deleteButton ) {
                    if ( deleteButton.status == 0 ) {
                      cancel.pause ( 9000 ).
                      click ( '//ng-include/ul/li/a[@class="btn btn-icon btn-delete"]' );
                      if ( checkCancelButn === 1 ) {
                        cancel.pause ( 3000 ).
                        //check the visibility of the cancel button
                        waitForElementVisible ( "//a[contains(.,'Cancel' )]", 5000, false ).
                        click ( "//a[contains(.,'Cancel' )]" ).
                        pause ( 3000 );
                      }
                      else {
                        cancel.pause ( 3000 ).
                        //check the visibility of the close button in dialog box
                        waitForElementVisible ( "//i[@ng-click='closeDeleteVerification()']", 5000, false ).
                        click ( "//i[@ng-click='closeDeleteVerification()']" ).
                        pause ( 3000 );
                      }
                      cancel.waitForElementVisible ( "//div/text-field/input", 5000, false, function ( titleValue ) {
                        if ( titleValue.value == true ) {
                          //get the headline value
                          cancel.getValue ( "//div/text-field/input", function ( getHeadline ) {
                            if ( getHeadline.value == excel.C[ excelColumn ] ) {
                              if ( checkCancelButn === 2 ) {
                                //write to excel as PASS if the cancel functionality working fine
                                cancel.writeToExcelPass ( 'boxxspring.xlsx', 'PortalCancelButton', ++excelRow, 4 );
                              }
                            }
                            else if ( checkCancelButn === 2 ) {
                              //write to fail status as Fail to load the same page after clicking Cancel button or close the dialogbox
                              this.verify.fail ( getHeadline.value, excel.C[ excelColumn ], 'Fail to load the same page after clicking Cancel button or close the dialogbox' );
                              cancel.writeToExcelFail ( 'boxxspring.xlsx', 'PortalCancelButton', ++excelRow, 4, 5, "ActualResult: '" + getHeadline.value + ". ExpectedResult: '" + excel.C[ excelColumn ] + "' ( Fail to load the same page after clicking Cancel button or close the dialogbox )" );
                            }
                          } );
                        }
                        else if ( checkCancelButn === 2 ) {
                          //write to fail status as Cancel button or close the dialog box icon is not working properly as defined
                          this.verify.fail ( titleValue.value, true, 'Cancel button or close the dialog box icon is not working properly as defined' );
                          cancel.writeToExcelFail ( 'boxxspring.xlsx', 'PortalCancelButton', ++excelRow, 4, 5, "ActualResult: '" + titleValue.value + ". ExpectedResult: 'true' ( Cancel button or close the dialog box icon is not working properly as defined )" );
                        }
                      } );
                    }
                    else if ( checkCancelButn === 2 ) {
                      //write to fail status as Error in displaying Delete Button
                      this.verify.fail ( deleteButton.status, 0, 'Error in displaying Delete Button' );
                      cancel.writeToExcelFail ( 'boxxspring.xlsx', 'PortalCancelButton', ++excelRow, 4, 5, "ActualResult: '" + deleteButton.status + ". ExpectedResult: '0' ( Error in displaying Delete Button )" );
                    }
                  } );
                }
              }
              else {
                //write to fail status as 'No' Result found while search the Title
                this.verify.fail ( searchFieldResult.status, 0, 'No Result found while search the Title' );
                cancel.writeToExcelFail ( 'boxxspring.xlsx', 'PortalCancelButton', ++excelRow, 4, 5, "ActualResult: '" + searchFieldResult.status + ". ExpectedResult: '0' ( No Result found while search the Title )" );
              }
            } );
          }
          else {
            //write to fail status as Timeout loading issue while clicking sidebar menu and sub menu
            this.verify.fail ( sidebar.value, true, 'Timeout loading issue while clicking sidebar menu and sub menu' );
            cancel.writeToExcelFail ( 'boxxspring.xlsx', 'PortalCancelButton', ++excelRow, 4, 5, "ActualResult: '" + sidebar.value + ". ExpectedResult: 'true' ( Timeout loading issue while clicking sidebar menu and sub menu )" );
          }
        } );
      }
    }
    else {
      //write to excel 'fail' if error in the excelsheet name
      console.log ( "No input in Excel or Check the Excel Name for the script 'PortalCancelButton'" );
    }
  }
};
//this function is for check and Delete the Destintaion in DISTRIBUTION
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var currentCount;
var worksheet = workbook.Sheets['DestinationsDelete'];
var socialSearch = [ ];
var playlistTitle = [ ];
var expectedCount,searchCount, actualCount, excelData;
var rowCount, getData = 1;
module.exports = {
  tags: [ 'destinationsDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DestinationsDelete': function ( destinationDelete ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 0 ] == '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        socialSearch.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'B' ) ) {
        playlistTitle.push ( worksheet[ excelData ].v );
      }
    }
    if ( socialSearch.length > 0 ) {
      for ( let getData = 1, rowCount = 1; getData < socialSearch.length; getData++ ) {
        rowCount++;
        destinationDelete.pause ( 9000 ).useXpath ( ).
        waitForElementPresent ( "//div/a[@class='content-header-link content'][text()[normalize-space(.)='Distribution']]", 9000, false, function ( checkDistributionMenu ) {
          if ( checkDistributionMenu.value.length != 0 ) {
            destinationDelete.pause ( 9000 ).useXpath ( ).
            waitForElementVisible ( "//i[@ng-if='!collapse.distribution']", 9000, false, function ( checkArrow ) {
              if ( checkArrow.value == true ) {
                destinationDelete.pause ( 9000 ).useCss ( ).
                verify.visible ( "div.content-header:nth-child( 7 )" ).
                pause ( 9000 ).
                //Click on the Distribution menu in the side bar
                click ( "div.content-header:nth-child( 7 )" ).
                pause ( 9000 );
              }
            } );
            destinationDelete.pause ( 4000 ).useXpath ( ).
            waitForElementVisible ( "//a[text ( ) = 'Destinations']", 9000, false, function ( checkDestinationMenu ) {
            	if ( checkDestinationMenu.value == true ) {
            		destinationDelete.pause ( 4000 ).useXpath ( ).
				        //Verify the Destination menu in DISTRIBUTION is visible
				        verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
				        pause ( 9000 ).
				        //Click on the Destination menu in DISTRIBUTION
				        click ( "//a[ text ( ) = 'Destinations']" ).
				        useCss ( ).pause ( 9000 ).
				        verify.visible ( ".content-count>strong" ).
				        pause ( 9000 ).
				        //Get the Current Total count in Destination listing page
				        getText ( '.content-count > strong', function ( currentCountResult ) {
				          if ( currentCountResult.status != -1 ) {
				            currentCount = currentCountResult.value;
				          }     
				          destinationDelete.pause ( 9000 ).useXpath ( ).
				          //Wait for the Search input Field is visible
				          waitForElementVisible ( "//div[@class='suggestion-dropdown-wrap']/input", 9000, false ).
				          pause ( 9000 ).
				          //Verify the Search input Field is visible
				          verify.visible ( "//div[@class='suggestion-dropdown-wrap']/input" ).
				          pause ( 9000 ).
				          //Clear the data in the search input field
				          clearValue ( "//div[@class='suggestion-dropdown-wrap']/input" ).
				          pause ( 9000 ).
				          //Enter the data in the search input field
				          setValue ( "//div[@class='suggestion-dropdown-wrap']/input", socialSearch[ getData ] ).useCss ( )
				          destinationDelete.pause ( 9000 ).         
				          waitForElementVisible ( ".content-count>strong", 9000, false ).
				          pause ( 9000 ).
				          verify.visible ( ".content-count>strong" ).
				          pause ( 9000 ).
				          //Get the Saerched Total count in Destination listing page
				          getText ( '.content-count > strong', function ( searchCountResult ) {
				              if ( searchCountResult.status != -1 ) {
				              searchCount = searchCountResult.value;
				            }
				            //Check IF Searched Video Count is greater than zero,it will continue in the statement or it will be move else part
				            if ( searchCount > 0 ) {
				              destinationDelete.pause ( 9000 ).useXpath ( ).
				              //Wait for the Searched listed in the page is visible
				              waitForElementVisible ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ socialSearch[ getData ] +"']]", 9000, false, function ( checkSearchedLst ) {
				              	if ( checkSearchedLst.value == true ) {
						              destinationDelete.pause ( 9000 ).
						              //Verify the Searched listed in the page is visible
						              verify.visible ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ socialSearch[ getData ] +"']]" ).
						              pause ( 9000 ).
						              //Click on the Searched listed title
						              click ( "//h2[@class='ng-binding'][text()[normalize-space(.)='"+ socialSearch[ getData ] +"']]" ).
						              pause ( 9000 ).
						              //Verify the Contains Text in the Destination page is visible
						              verify.containsText ( "//div[@class='input-like'][ contains (.,'"+ playlistTitle[ getData ] +"')]", playlistTitle[ getData ] ).
						              pause ( 9000 ).
						              //Verify the the Contains Text in the Destination page is visible
						              verify.visible ( "//div[@class='input-like'][ contains (.,'"+ playlistTitle[ getData ] +"')]").
						              pause ( 9000 ).useCss ( ).
						              //Wait for the Delete button is visible in the page              
						              waitForElementVisible ( "a.btn-delete [ng-click='showDeleteVerification();']", 9000, false, function ( checkDeleteBTN ) {
						              	if ( checkDeleteBTN.value == true ) {
								              destinationDelete.pause ( 9000 ).
								              //Verify the Delete button is visible in the page  
								              verify.visible ( ".btn-delete > span[ng-click='showDeleteVerification();']" ).
								              pause ( 9000 ).
								              //Click on the Delete button is visible in the page  
								              click ( ".btn-delete > span[ng-click='showDeleteVerification();']" ).
								              pause ( 9000 ).
								              //Check the existance of delete confirmation dialog
								              verify.visible ( "dialog[name=deleteVerification]" ).
								              pause ( 9000 ).
								              //Verify the Cancel Button is visible in Delete Dialog
								              verify.visible ( ".link-secondary" ).
								              //Click on the Cancel Button in Delete Dialog
								              click ( ".link-secondary" ).
								              pause ( 9000 ).
								              waitForElementVisible ( ".btn-delete > span[ng-click='showDeleteVerification();']", 9000, false, function ( checkDeletepopBTN ) {
								              	if ( checkDeletepopBTN.value == true ) {
								              		destinationDelete.pause ( 9000 ).
										              //Verify the Delete button is visible in the page						              
										              verify.visible ( ".btn-delete > span[ng-click='showDeleteVerification();']" ).
										              pause ( 9000 ).
										              //Click on the Delete button is visible in the page  
										              click ( ".btn-delete > span[ng-click='showDeleteVerification();']" ).
										              pause ( 9000 ).
										              //Verify the Delete Dialog box is visible
										              verify.visible ( "dialog[ name=deleteVerification]" ).
										              //Verify the Delete Button is visible in Delete Dialog
										              verify.visible ( "button.btn:nth-child( 2 )" ).
										              pause ( 9000 ).
										              //Click on the Cancel Button in Delete Dialog
										              click ( "button.btn:nth-child( 2 )" ).
										              pause ( 9000 ).useXpath ( ).
										              //Verify the Contains Text as Destinations is visible
										              verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
										              pause ( 9000 ).
										              //Click on the Contains Text as Destinations
										              click ( "//a[ text ( ) = 'Destinations']" ).
										              useCss ( ).pause ( 9000 ).										              
										              //Get the Actual Total count in Destination listing page
										              getText ( '.content-count > strong', function ( actualCountResult ) {
										                if ( actualCountResult.status != -1 ) {
										                  actualCount = actualCountResult.value;
										                  expectedCount = ( ( currentCount ) - 1 );
										                  if ( actualCount == expectedCount ) {
										                    //Write in the spreadsheet: PASS Result
										                    destinationDelete.writeToExcelPass ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4 );
										                  }
										                  else {
										                    //Write in the spreadsheet: Fail Result and Reason
										                    destinationDelete.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Destination. ExpectedResult: should be 0 in the Total Count" );
										                  }
										                }
										              } );
									              }
									              else {
									              	//Write in the spreadsheet: Fail Result and Reason
								                destinationDelete.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4, 5, "Delete Button is not displayed in the pop-up windows" );                  
								                } 
									            } );
								            }
								            else {
								            	//Write in the spreadsheet: Fail Result and Reason
							                destinationDelete.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4, 5, "Delete Button is not displayed in the Destination page" );                  
							              }
							          	} );
					              }
					              else {
					              	//Write in the spreadsheet: Fail Result and Reason
					                destinationDelete.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4, 5, "Searched Data is not listed in the listing page" );                  
					              }
				              } );                
				            }
				            else {
				              //Write in the spreadsheet: Fail Result and Reason
				              destinationDelete.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4, 5, "0 No Results" )                         
				            }
				          } );        
				        } );
							}
							else {
								//Write in the spreadsheet: Fail Result and Reason
								destinationDelete.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4, 5, "Destination Menu is not displayed in the Sidebar" )                         
							}
						} );
					}
					else {
						//Write in the spreadsheet: Fail Result and Reason
					  destinationDelete.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationsDelete', rowCount, 4, 5, "Distribution Menu is not displayed in the Sidebar" )                                
					}
				} );
      }
    }
    //End the Browser
    destinationDelete.end ( );
  }
}
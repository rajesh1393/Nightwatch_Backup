//this function is for check and Add the Collections Menu
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CollectionmenuAdd' ];
var collectionTitle = [ ];
var collectiondesc = [ ];
var collectionPublic = [ ];
var expectedCount, actualCount, currentCount, excelData;
var rowCount,getData = 1;
var expectedYES = "YES";
var expectedNO = "NO";
module.exports = {
  tags: [ 'collectionmenuAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CollectionmenuAdd': function ( collectionsAdd ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Collection Title
      if ( excelData.includes ( 'A' ) ) {
        collectionTitle.push ( worksheet[ excelData ].v );
      }
      //Read Collection Description
      if ( excelData.includes ( 'B' ) ) {
        collectiondesc.push ( worksheet[ excelData ].v );
      }
      //Read Collection Public
      if ( excelData.includes ( 'C' ) ) {
        collectionPublic.push ( worksheet[ excelData ].v );
      }
    }
    if ( collectionTitle.length > 1 ) {
    	for ( let getData = 1,rowCount = 1; getData < collectionTitle.length; getData++ ) {
    		rowCount++;
	      collectionsAdd.pause ( 4000 ).useXpath ( ).
	      //Wait to visible for the All button
	      waitForElementVisible ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false, function ( checkALLMenu ) {
	      	if ( checkALLMenu.value == true ) {
			      collectionsAdd.pause ( 4000 ).useXpath ( ).
			      //Click on the All button
			      click ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]" ).
			      pause ( 4000 ).useCss ( ).
			      //Get the Collections total count in the Collections Listing page
			      getText ( '.content-count > strong', function ( currentCountResult ) {
			        if ( currentCountResult.status != -1 ) {
			          currentCount = currentCountResult.value;
			          currentCount = currentCount.substring ( 1, currentCount.length - 1 );
			        }
		          collectionsAdd.pause ( 9000 ).          
		          waitForElementVisible ( "div.content-header:nth-child( 4 ) > a:nth-child( 2 )", 4000, false ).
		          pause ( 4000 ).
		          //Verift the text as COLLECTIONS in the Page
		          verify.containsText ( "div.content-header:nth-child( 4 ) > a:nth-child( 2 )", "COLLECTIONS" ).
		          pause ( 4000 ).
		          waitForElementVisible ( "div.content-header:nth-child( 4 ) > span:nth-child( 3 )", 4000, false ).
		          pause ( 4000 ).
		          verify.visible ( "div.content-header:nth-child( 4 ) > span:nth-child( 3 )" ).
		          pause ( 4000 ).
		          //Click on the Collection Add
		          click ( "div.content-header:nth-child( 4 ) > span:nth-child( 3 )" ).
		          pause ( 4000 ).
		          waitForElementVisible ( ".text-input-headline", 4000, false ).
		          pause ( 4000 ).
		          //Verify the Collection title in the field
		          verify.visible ( ".text-input-headline" ).
		          pause ( 4000 ).
		          //Enter the Collection title in the field
		          setValue ( ".text-input-headline", collectionTitle[ getData ] ).
		          pause ( 4000 ).
		          //Check the valid URL from given URL
		          waitForElementVisible ( ".btn-slider", 4000, false ).
		          pause ( 4000 )	
		          if ( collectionPublic[ getData] != undefined ) {                           
			          //Check the condition for YES option
			          if ( expectedYES == collectionPublic[ getData ] ) {
			            collectionsAdd.pause ( 4000 ).
			            //Wait for the public button is visible in the page
			            waitForElementVisible ( ".btn-secondary", 4000, false ).
			            pause ( 4000 ).
			            verify.visible ( ".btn-secondary" ).
			            pause ( 4000 ).
			            //Click on the Yes button
			            click ( ".btn-secondary" ).
			            pause ( 4000 ).
			            //Wait for the YES option is visible
			            waitForElementVisible ( ".text-success", 4000, false ).
			            pause ( 4000 ).
			            //Verify the YES option is visible
			            verify.visible ( ".text-success" ).
			            pause ( 4000 )
			          }
			          //Check the condition for NO option
			          else if ( expectedNO == collectionPublic[ getData ] ) {
			            collectionsAdd.waitForElementVisible ( ".btn-secondary", 4000, false ).
			            pause ( 4000 ).
			            //Wait for the NO option is visible
			            waitForElementVisible ( ".text-private", 4000, false ).
			            pause ( 4000 )
			          }
		        	}
		          //Wait for the Collection description in the field is visible
		          collectionsAdd.waitForElementVisible ( "#artifact-url>.ng-pristine", 4000, false ).
		          pause ( 4000 ).
		          //Verify the Collection description in the field is visible
		          verify.visible ( "#artifact-url>.ng-pristine" ).
		          pause ( 4000 ).
		          //Enter the Collection description in the field
		          setValue ( "#artifact-url>.ng-pristine", collectiondesc[ getData ] ).
		          pause ( 4000 ).
		          //Wait for the SAve button is visible
		          waitForElementVisible ( ".btn-active", 4000, false ).
		          pause ( 4000 ).
		          //Click on the Save button
		          click ( ".btn-active" ).
		          pause ( 4000 ).useXpath ( ).
		          //Wait for visible for the All button
		          waitForElementVisible ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false ).
		          pause ( 4000 ).
		          //Click on the All button
		          click ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]" ).
		          pause ( 4000 ).useCss ( ).
		          //Get the Collections Actual total count in the Collections Listing page
		          getText ( '.content-count > strong', function ( actualCountResult ) {
		            if ( actualCountResult.status != -1 ) {
		              actualCount = actualCountResult.value;
		              actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
		              expectedCount = ( ( +currentCount ) + ( 1 ) );
		              if ( actualCount == expectedCount ) {
		                //Write the Excel for Pass Result and Reason
		                collectionsAdd.writeToExcelPass ( 'boxxspring.xlsx', 'CollectionmenuAdd', rowCount, 5 );
		              }
		              else {
		              	this.verify.fail ( actualCount, expectedCount, "ActualResult: '"+ actualCount +"' in the Total Count After Added New story. ExpectedResult: should be 1 in the Total Count" );
		                //Write the Excel for Fail Result and Reason
		                collectionsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuAdd', rowCount, 5, 6, "ActualResult: '"+ actualCount +"' in the Total Count After Added New Collections Menu. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
		              }
		            }
		          } );		                  
		        } );
					}
					else {
						//Write the Excel for Fail Result and Reason
					  collectionsAdd.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuAdd', rowCount, 5, 6, "ALL Menu is not displayed under the COLLECTIONS Title on Sidebar  " );
					}
				} );
      }
    }
    //End the Browser
    collectionsAdd.end ( );
  }
}
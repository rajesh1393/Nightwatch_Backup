var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require( 'xlsx' );
var workbook = XLSX.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var addSheet = workbook.Sheets [ 'AdvertisingAdd' ];
var vastURL = [ ];
var adTitle = [ ];
var advertisementProvider = [ ];
var currentCount;
var actualCount;
var expectedCount;
module.exports = {
  tags: [ 'advertisingAdd' ],
  before: function( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AdvertisingAdd': function ( advertisementAdd ) {
    for ( z in addSheet ) {
      if ( z [ 0 ] === '!' ) continue;
      //Read advertisement Title from Excel
      if ( z.includes ( 'A' ) ) {
        adTitle.push ( addSheet[ z ].v );
      }
      //Read URL title from Excel
      if ( z.includes ( 'B' ) ) {
        vastURL.push ( addSheet[ z ].v );
      }
      //Read Provider name from Excel
      if ( z.includes ( 'C' ) ) {
        advertisementProvider.push ( addSheet[ z ].v );
      }
    }
    if ( adTitle.length > 0 ) {
      advertisementAdd.
      pause ( 3000 ).
      useXpath ( ).
      //Verify the Distribution menu in Side bar is visible
      verify.visible ( "( //DIV[@class='content-header content ng-scope'] )[5]" ).
      pause ( 3000 ).
      //Click on the Distribution menu in Side bar
      click ( "( //DIV[@class='content-header content ng-scope'] )[5]" ).
      pause( 3000 ).
      //Click on the Destination menu in DISTRIBUTION
      click ( "//a[text() = 'Advertising' ]" ).
      useCss ( ).
      pause ( 3000 );
        //Looping until total number of advertisement title is present
        for ( var getData = 1, rowCount = 1; getData < adTitle.length; getData++ ) {
          advertisementAdd.
          getText ( '.content-count > strong', function( currentCountResult ) {
            if ( currentCountResult.status !== -1 ) {
              currentCount = currentCountResult.value;
            }
            advertisementAdd.
            useXpath ( ).
            pause ( 5000 ).
          //Clicking on the Add advertisement button
          click ( "//A[@class='btn btn-primary long ng-scope']" ).
          pause ( 3000 ).
          useCss ( ).
          //Waiting for the Vast button to be visible
          waitForElementVisible ( ".vast-button", 5000, false ).
          pause ( 3000 );
          //Clicking on the Vast button
          if ( advertisementProvider[ rowCount ] == "VAST" ) {
            advertisementAdd.  
            click ( ".vast-button" );
          }
          //Clicking on the dfp button
          else if ( advertisementProvider[ rowCount ] == "DFP" ) {
            advertisementAdd.  
            click ( ".dfp-button" );
          }
          //Clicking on the freewheel button
          else if ( advertisementProvider[ rowCount ] == "FREEWHEEL" ) {
            advertisementAdd.  
            click ( ".freewheel-button" );
          }
          //Clicking on the spotx button
          else if ( advertisementProvider[ rowCount ] == "SPOTX" ) {
            advertisementAdd.  
            click ( ".spotx-button" );
          }
          //Updating the Status in Excel sheet
          else{
            advertisementAdd.
            writeToExcelFail ( 'boxxspring.xlsx', 'AdvertisingAdd', ++rowCount, 5, 6, "Please Provide a valid Advertisement Brand Name" );
          }
          advertisementAdd.  
          pause( 3000 ).
          //Checking whether the Input field is present 
          verify.visible ( ".text-input-headline" ).
          //Clicking the Input field 
          click ( ".text-input-headline" ).
          pause ( 3000 ).
          //Passing the Title in the Title field
          setValue ( ".text-input-headline", adTitle[ rowCount ] ).
          pause ( 3000 ).
          //Checking whether the URL field is present
          click ( "#advertisement-tag-url" ).
          pause ( 3000 ).
          //passing the URL to the URL field
          setValue ( "#advertisement-tag-url", vastURL[ rowCount ] ).
          pause ( 3000 ).
          //Clicking on the Save button.
          click ( "a.btn-primary" ).
          pause ( 9000 ).
          useXpath ( ).
          //Clicking the Advertising button from the sidebar of the application
          click ( "//a[text() = 'Advertising' ]" ).
          pause ( 5000 ).
          useCss ( ).
          //Checking the Current Count with the Expected Count in the Advertisement list page
          getText ( '.content-count > strong', function ( actualCountResult ) {
            if ( actualCountResult.status !== -1 ) {
              actualCount = actualCountResult.value;
              expectedCount = ( ( +currentCount ) + ( +1 ) );
              if ( actualCount == expectedCount ) {
                  //Write in the Excel: Pass Result and Reason
                  advertisementAdd.
                  writeToExcelPass ( 'boxxspring.xlsx', 'AdvertisingAdd', ++rowCount, 5 );
                }
                else {
                  //Write in the Excel: Fail Result and Reason
                  advertisementAdd.
                  writeToExcelFail ( 'boxxspring.xlsx', 'AdvertisingAdd', ++rowCount, 5, 6, "Adding the Advertising failed" );
                }
              }
            } );

        } )
        }
      }
    }
  }
//this function is for check and Edit the Feeds on Facebook Destintaion in DISTRIBUTION
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'FeedsEdit' ];
var feedTitle = [ ];
var provider = [ ];
var videoFiles = [ ];
var videoPlayer = [ ];
var content = [ ];
var permaLink = [ ];
var categoryType = [ ];
var categories = [ ];
var currentCount, actualCount, expectedCount, excelData, permaLinkUpper;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'feedsEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'FeedsEdit': function ( feedEdit ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Provider Title
      if ( excelData.includes ( 'A' ) ) {
        provider.push ( worksheet[ excelData ].v );
      }
      //Read Feed Title 
      if ( excelData.includes ( 'B' ) ) {
        feedTitle.push ( worksheet[ excelData ].v );
      }
      //Read Video Files Title
      if ( excelData.includes ( 'C' ) ) {
        videoFiles.push ( worksheet[ excelData ].v );
      }
      //Read Video Player 
      if ( excelData.includes ( 'D' ) ) {
        videoPlayer.push ( worksheet[ excelData ].v );
      }
      //Read Permanent Link 
      if ( excelData.includes ( 'E' ) ) {
        permaLink.push ( worksheet[ excelData ].v );
      }
      //Read Content 
      if ( excelData.includes ( 'F' ) ) {
        content.push ( worksheet[ excelData ].v );
      }
      //Read Category Type
      if ( excelData.includes ( 'G' ) ) {
        categoryType.push ( worksheet[ excelData ].v );
      }
      //Read Categories
      if ( excelData.includes ( 'H' ) ) {
        categories.push ( worksheet[ excelData ].v );
      }
    }
    if ( provider.length > 0 ) {
      for ( let getData = 1, rowCount = 1; getData < provider.length; getData++ ) {
        rowCount++;
        feedEdit.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ("//i[@ng-if='!collapse.distribution']",9000,false,function ( checkArrow ) {
          if ( checkArrow.value == true ) {
            feedEdit.pause ( 4000 ).useCss ( ).
            verify.visible ( "div.content-header:nth-child( 7 )" ).
            pause ( 4000 ).
            //Click on the Distribution menu in the side bar
            click ( "div.content-header:nth-child( 7 )" ).
            pause ( 4000 )
          }            
        } );
        feedEdit.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ("//a[text ( ) = 'Feeds']",9000,false,function ( checkFeedMenu ) {
          if ( checkFeedMenu.value == true ) {
            feedEdit.pause ( 4000 ).useXpath ( ).
            //Verify the Feeds menu is visible in the DISTRIBUTION
            verify.containsText ( "//a[text ( ) = 'Feeds']", "Feeds" ).
            pause ( 15000 ).
            //Click on the Feeds menu in the DISTRIBUTION
            click ( "//a[ text ( ) = 'Feeds']" ).
            useCss ( ).pause ( 4000 ).
            //Get the total count value in the feeds listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
              }        
              feedEdit.pause ( 4000 ).useXpath ( ).
              //Wait for the Search field is visible in the feeds listing page
              waitForElementVisible ( "//div/div/div[1]/div/div/div/input", 5000, false ).
              pause ( 4000 ).
              //Verify the Search field is visible in the feeds listing page
              verify.visible ( "//div/div/div[1]/div/div/div/input" ).
              //Clear the Feeds Title in the Search field in the feeds listing page
              clearValue ( "//div/div/div[1]/div/div/div/input" ).
              pause ( 4000 ). 
              //Enter the Feeds Title in the Search field in the feeds listing page  
              setValue ( "//div/div/div[1]/div/div/div/input", feedTitle[ getData ] ).
              pause ( 4000 )
              //Hold the control
              feedEdit.keys ( feedEdit.Keys.ENTER ). 
              //Click on the Search option in the feeds listing page
              click ( "//div/div/div[1]/div/div/div/input" ).
              //Release the control
              keys ( feedEdit.Keys.NULL ). 
              pause ( 4000 ).useCss ( ).
              //Wait for the total searched count is visible in the feeds listing page
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              //Verify the total searched count is visible in the feeds listing page
              verify.visible ( ".content-count>strong" )
              //Check the Searched Video Count
              feedEdit.getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  var searchCount = searchCountResult.value;
                }
                //Check IF Searched Video Count is greater than zero,it will continue in the statement or it will be move else part
                if ( searchCount > 0 ) {
                  feedEdit.pause ( 4000 ).useXpath ( ).
                  //Wait for the Searched data is visible in the Videos listing page
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ feedTitle[ getData ] +"']]", 3000, false, function ( checkSearchedVideo ) {
                    if ( checkSearchedVideo.value == true ) {
                      feedEdit.pause ( 4000 ).useXpath ( ).
                      //Click on edit pull button
                      click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ feedTitle[ getData ] +"']]" ).
                      pause ( 4000 ).
                      getText ( "//div[@class='typeName-label']", function ( labelValue ) {
                        if ( labelValue.value == "FEED" ) {                        
                          feedEdit.pause ( 4000 ).
                          //Wait for Feed Title Text field is visible in the Feed page
                          waitForElementVisible ( "//div/text-field[@class='ng-scope field-input ng-valid ng-not-empty']/input", 4000, false ).
                          pause ( 4000 ).
                          //Clear the Feed Title in the Text field 
                          clearValue ( "//div/text-field[@class='ng-scope field-input ng-valid ng-not-empty']/input" ).
                          pause ( 4000 ).
                          //Enter the Feed Title in the Text field 
                          setValue ( "//div/text-field[@class='ng-scope field-input ng-valid ng-empty']/input", feedTitle[ getData ] ).
                          pause ( 4000 ).
                          //Wait for Feed Provider field is visible in the Feed page
                          waitForElementVisible ( "//div[@class='input-like']", 4000, false ).
                          pause ( 4000 ).useXpath ( ).
                          //Verify the Contains Text in the Provider field are as same in the excel
                          verify.containsText ( "//div[@class='input-like'][contains ( .,'"+ provider[ getData ] +"')]", provider[ getData ] ).
                          pause ( 4000 ).
                          //Wait for Feed Urlslug field is visible in the Feed page
                          waitForElementVisible ( "//div[@class='field-input slug-field ng-scope']/input[@placeholder]", 4000, false ).
                          pause ( 4000 ).useXpath ( ).
                          //Get the Feed Urlslug field attribute in the Feed page
                          getAttribute ( "//div[@class='field-input slug-field ng-scope']/label/ul/li/a", "data-clipboard-text", function ( urlSlugValue ) {
                            var requireText = feedTitle[ getData ] +".xml";
                            var requireTextcase = requireText.toUpperCase();
                            var urlSlugRequire = urlSlugValue.value.toUpperCase();
                            if ( new RegExp ( requireTextcase ).test ( urlSlugRequire ) == true ) {
                              feedEdit.useXpath ( ).
                              //Wait for the Video files field is visible in the feed page
                              waitForElementVisible ( "//div/div[1]/div[3]/div/ul/li[1]/a", 4000, false ).
                              pause ( 4000 ).
                              //Click on the Video files field in the feed page
                              click ( "//div/div[1]/div[3]/div/ul/li[1]/a" ).
                              pause ( 4000 ).
                              //Wait for the Video files listing the dropdown is visible in the feed page
                              waitForElementVisible ( "//ul/li/a[@class='ellipsis ng-binding'][text ( )='"+ videoFiles[ getData ] +"']", 4000, false ).
                              pause ( 4000 ).
                              //Click on the the Video files listing the dropdown in the feed page
                              click ( "//ul/li/a[@class='ellipsis ng-binding'][text ( )='"+ videoFiles[ getData ] +"']" ).
                              pause ( 4000 ).
                              //Wait for the Video player field is visible in the feed page
                              waitForElementVisible ( "//div/div/section/div/div[1]/div[4]/div/a[1]/i", 4000, false ).
                              pause ( 4000 ).
                              //Click on the Video player field in the feed page
                              click ( "//div/div/section/div/div[1]/div[4]/div/a[1]/i" ).
                              pause ( 4000 ).
                              //Wait for the Video player listing the dropdown is visible in the feed page
                              waitForElementVisible ( "//ul/li/a[@class='ellipsis'][text ( )='"+ videoPlayer[ getData ] +"']", 4000, false ).
                              pause ( 4000 ).
                              //Click on the the Video player listing the dropdown in the feed page
                              click ( "//ul/li/a[@class='ellipsis'][text ( )='"+ videoPlayer[ getData ] +"']" ).
                              pause ( 4000 ).
                              //Wait for the permanent link checkbox is visible in the feed page
                              waitForElementVisible ( "//ul/li/div/label[@class='select'][@for='permalink']", 4000, false ).
                              pause ( 4000 ).
                              //Get the Attribute for permanent link checkbox in the feed page
                              getAttribute ( "//ul/li/div/input", "checked", function ( permaLinkCheck ) {
                                permaLinkUpper = permaLinkCheck.value;
                                if ( permaLinkUpper != null ) {
                                  permaLinkUpper = permaLinkUpper.toUpperCase();
                                  if ( permaLinkUpper != permaLink[ getData ] ) {
                                    feedEdit.useXpath ( ).pause ( 4000 ).
                                    click ( "//ul/li/div/input[@id='permalink']" ).
                                    pause ( 4000 )
                                  }                                  
                                }
                                else {
                                  //compare the parmenent link checked should equal from excel data
                                  if ( permaLinkUpper == permaLink[ getData ] ) {
                                  }
                                  else {
                                    feedEdit.useXpath ( ).pause ( 4000 ).
                                    //Click on the permanent link checkbox in the feed page
                                    click ( "//ul/li/div/input[@id='permalink']" ).
                                    click ( "//ul/li/div/label[@class='select']" ).
                                    pause ( 4000 )
                                  }
                                }
                                feedEdit.useCss().keys ( feedEdit.Keys.END ).pause ( 5000 ).useXpath ( ).
                                //Wait for the Condition dropdown option is visible
                                waitForElementVisible ( "//div/div[1]/div/div/div/a", 4000, false ).
                                pause ( 4000 ).
                                //Click on the Condition dropdown option
                                click ( "//div/div[1]/div/div/div/a" ).
                                pause ( 4000 ).
                                //Wait for the Content dropdown option is visible
                                waitForElementVisible ( "//ul/li/a[text( )[normalize-space(.)='"+ content[ getData ] +"']]", 4000, false ).
                                pause ( 4000 ).
                                //Click on the Content dropdown option
                                click ( "//ul/li/a[text( )[normalize-space(.)='"+ content[ getData ] +"']]" ).
                                pause ( 4000 )
                             //Permalink function End Brace
                             } ); 
                              var splitContent = [ ];
                              var splitCondition = [ ];
                              var categoriesTemp_content = [ ];
                              var categoriesTemp_category = [ ];
                              var categoryTypeTemp = categoryType[ getData ];
                              splitContent = categoryTypeTemp.split ( ':' );
                              for ( let contentCount = 0; contentCount < splitContent.length; contentCount++ ) {
                                feedEdit.useXpath ( ).pause ( 4000 ).
                                waitForElementVisible ( "//div[@class='field-input filter-conditions ng-scope']", 4000, false, function ( conditionVisible ) {
                                  if ( conditionVisible.value == true ) {
                                    var splitCondition = splitContent[contentCount].split ( ',' );
                                    categoriesTemp_content = splitCondition[ 0 ].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
                                    if ( splitCondition.length != 1 ) {
                                      categoriesTemp_category = splitCondition[ 1 ].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
                                    }
                                    feedEdit.useXpath ( ).pause ( 4000 ).
                                    //Verify the Category in the field is visible 
                                    verify.visible ( "//div/a[@class='ng-binding'][text( )[normalize-space(.)='Category']]" ).
                                    pause ( 4000 )
                                    var categoryCountValue = contentCount + 2;
                                    //Wait for the condition dropdown is visible in the content/condition
                                    feedEdit.waitForElementVisible ( "//filter/div/div["+ categoryCountValue +"]/div[2]/section/div/div/div/a", 4000, false ).
                                    pause ( 4000 ).
                                    //Click on the condition dropdown option
                                    click ( "//filter/div/div["+ categoryCountValue +"]/div[2]/section/div/div/div/a" ).
                                    pause ( 4000 ).
                                    //Wait for the content is visible in the dropdown list
                                    waitForElementVisible ( "//ul/li/a[text( )[normalize-space(.)='"+ categoriesTemp_content +"']]", 4000, false ).
                                    pause ( 4000 ).
                                    //Click on the content in the dropdown list 
                                    click ( "//ul/li/a[text( )[normalize-space(.)='"+ categoriesTemp_content +"']]" ).
                                    pause ( 4000 ).
                                    //Wait for the Categories field is visible in the content/condition
                                    waitForElementVisible ( "//filter/div/div["+ categoryCountValue +"]/div[3]/div/div/div/input", 4000, false ).
                                    pause ( 4000 ).
                                    //Clear the Categories field data in the content/condition
                                    clearValue ( "//filter/div/div["+ categoryCountValue +"]/div[3]/div/div/div/input" ).
                                    pause ( 4000 ).
                                    //Enter the Categories field data in the content/condition
                                    setValue ( "//filter/div/div["+ categoryCountValue +"]/div[3]/div/div/div/input", categoriesTemp_category ).
                                    pause ( 4000 ).
                                    //Wait for Categories data listing is visible in the content/condition
                                    waitForElementVisible ( "//div/div[@class='suggestion-item']/span[text( )[normalize-space(.)='"+ categoriesTemp_category +"']]", 4000, false ).
                                    pause ( 4000 ).
                                    //Click on the Categories data listing in the content/condition
                                    click ( "//div/div[@class='suggestion-item']/span[text( )[normalize-space(.)='"+ categoriesTemp_category +"']]" ).
                                    pause ( 4000 )
                                  }
                                } ); 
                              } 
                              feedEdit.useXpath ( ).pause ( 4000 ).
                              //Wait for Save button is visibleand get function value in the feed page
                              waitForElementVisible ( "//ul/li/a[@class='btn btn-icon ng-scope btn-active']", 4000, false, function ( saveActive ) {
                                if ( saveActive.value == true ) {
                                  feedEdit.useXpath ( ).verify.visible ( "//ul/li/a/span[text( )[normalize-space(.)='Save']]" ).
                                  pause ( 4000 ).
                                  //Click on the save button in the Feeds Edit page
                                  click ( "//ul/li/a/span[text( )[normalize-space(.)='Save']]" )
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "Save Button is In-Active" );
                                }
                              } ); 
                              //Wait for Save button is visibleand get function value in the feed page
                              feedEdit.useXpath ( ).waitForElementVisible ( "//ul/li/a[@class='btn btn-icon ng-scope btn-saved']", 4000, false, function ( saveinActive ) {
                                if ( saveinActive.value == true ) {
                                  feedEdit.pause ( 4000 ).useXpath ( ).
                                  //Verify the Feeds menu in the DISTRIBUTION
                                  verify.containsText ( "//a[text ( ) = 'Feeds']", "Feeds" ).
                                  pause ( 4000 ).
                                  //Click on the Feeds menu in the DISTRIBUTION
                                  click ( "//a[ text ( ) = 'Feeds']" ).
                                  useCss ( ).pause ( 4000 ).
                                  //Wait for the total count is visible in the feed listing page
                                  waitForElementVisible ( ".content-count>strong", 4000, false ).
                                  pause ( 4000 ).
                                  //Verify the the total count is visible in the feed listing page
                                  verify.visible ( ".content-count>strong" ).
                                  pause ( 4000 ).
                                  //Get the total count in the feed listing page
                                  getText ( '.content-count > strong', function ( actualCountResult ) {
                                    if ( actualCountResult.status !== -1 ) {
                                      actualCount = actualCountResult.value;
                                      if ( actualCount == currentCount ) {
                                        //Write in the spreadsheet: Pass Result and Reason
                                        feedEdit.writeToExcelPass ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10 );
                                      }
                                      else {
                                        //Write in the spreadsheet: Fail Result and Reason
                                        feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "ActualResult: '"+ actualCount +"' in the Total Count After Edit Feeds. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                      }
                                    }
                                  } );
                                }
                                else {
                                  feedEdit.useXpath ( ).pause ( 4000 ).
                                  //Wait for the categories error alert is visible in the feed page 
                                  waitForElementVisible ( "//field-error/div/span/span[2]/span", 4000, false, function ( categoryErrAlert ) {
                                    if ( categoryErrAlert.value == true ) {
                                      //Write in the spreadsheet: Pass Result and Reason
                                      feedEdit.writeToExcelPass ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10 );
                                      //feedEdit.writeToExcelPass ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "Validation Alerts are Working as Expected" );
                                    }
                                    else {
                                      //Write in the spreadsheet: Fail Result and Reason
                                      feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "Save Button is Active but Not Saving the feeds" );
                                    }
                                    feedEdit.pause ( 4000 ).useXpath ( ).
                                    //Verify the Feeds menu in the DISTRIBUTION
                                    verify.containsText ( "//a[text ( ) = 'Feeds']", "Feeds" ).
                                    pause ( 4000 ).
                                    //Click on the Feeds menu in the DISTRIBUTION
                                    click ( "//a[ text ( ) = 'Feeds']" ).
                                    useCss ( ).pause ( 4000 )
                                  } );
                                }
                              } );
                            }
                            else {
                              //Write in the spreadsheet: Fail Result and Reason
                              feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "urlslug is Mismatched " );
                            }
                          } ); //urlslug function End brace
                        }
                        else {
                          //Write in the spreadsheet: Fail Result and Reason
                          feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsAdd', rowCount, 10, 11, "Feed caption is not displayed" );
                        }
                      } );
                    }
                    else {
                      //Write in the spreadsheet: Fail Result and Reason
                      feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "Searched Data is not displayed in the Listing page" );             
                    }
                  } );
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
               	  feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "No Result shown in Searched Data" );             
                }
              } );                       
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            feedEdit.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsEdit', rowCount, 10, 11, "Feeds menu is not displayed in the Sidebar" );  
          }
        } );
      }
    }
    //End the Browser
    feedEdit.end ( );
  }
};
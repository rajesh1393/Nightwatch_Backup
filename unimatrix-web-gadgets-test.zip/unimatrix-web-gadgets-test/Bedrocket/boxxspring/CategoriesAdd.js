//this function is for check and add the categories 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CategoriesAdd' ];
var categoryTitle = [ ];
var categoryDescription = [ ];
var categoryShortTitle = [ ];
var categoryShortDesc = [ ];
var categoryCategoryName = [ ];
var categoryNote = [ ];
var categoryImg = [ ];
var categoryType = [ ];
var getData,rowCount = 1;
var currentCount, actualCount, expectedCount, excelData;
module.exports = {
  tags: [ 'categoriesAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CategoriesAdd': function ( allCategories ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Category Title
      if ( excelData.includes ( 'A' ) ) {
        categoryTitle.push ( worksheet[ excelData ].v );
      }
      //Read Category Description
      if ( excelData.includes ( 'B' ) ) {
        categoryDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        categoryShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        categoryShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Category Name
      if ( excelData.includes ( 'E' ) ) {
        categoryCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read Category Note
      if ( excelData.includes ( 'F' ) ) {
        categoryNote.push ( worksheet[ excelData ].v );
      }
      //Read Thumbnail Image
      if ( excelData.includes ( 'G' ) ) {
        categoryImg.push ( worksheet[ excelData ].v );
      }
      //Read category Type
      if ( excelData.includes ( 'H' ) ) {
        categoryType.push ( worksheet[ excelData ].v );
      }
    }
    if ( categoryTitle.length > 1 ) {
      var checkResult = allCategories.globals.excelCol.resultCustomData;
      for ( let getData = 1,rowCount = 1; getData < categoryTitle.length; getData++ ) {
        rowCount++;
        allCategories.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Categories' ]",4000, false, function ( checkCategoriesMenu ) {
          if( checkCategoriesMenu.value == true ) {
            allCategories.pause ( 4000 ).useXpath ( ).
            //Verify the Categories menu in the CONTENT is visible
            verify.containsText ( "//ul/li/a[ text( ) = 'Categories' ]", "Categories" ).
            pause ( 4000 ).
            //Click on the Categories menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Categories' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get Total Count in the Categories
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              //Wait for Add button visible
              allCategories.waitForElementVisible ( ".btn-add", 4000, false, function ( checkAddBtn ) {
                if ( checkAddBtn.value == true ) {
                  allCategories.pause ( 4000 ).
                  //Move the element to add button
                  moveToElement ( ".btn-add", 0, 0 ).
                  pause ( 4000 ). useXpath ( ).
                  //Click on Add categories Button             
                  click ( "//ul[ @class='dropdown-submenu' ]//a[ contains ( .,'"+ categoryType[ getData ] +"' ) ]" ).
                  useCss ( ).pause ( 4000 ).
                  //Verfiy the Content Tab
                  verify.visible ( ".video-tabs > a[href='#content' ]" ).
                  //Click on the Content Tab
                  click ( ".video-tabs > a[href='#content' ]" ).
                  pause ( 4000 ).
                  //Wait and verify the Categories Title
                  waitForElementVisible ( ".text-input-headline", 4000, false ).
                  //Enter the Catgories Title
                  setValue ( ".text-input-headline", categoryTitle[ getData ] ).
                  pause ( 4000 ).
                  //Check the Categories Text Description
                  waitForElementVisible ( ".wmd-input", 4000, false ).
                  //Clear the Categories Text Description
                  clearValue ( ".wmd-input" ).
                  pause ( 7000 ).
                  //Enter the Categories Text Description
                  setValue ( ".wmd-input", categoryDescription[ getData ] ).
                  pause ( 4000 ).              
                  //Set details in Attribution Properties Tab
                  all_properties ( categoryShortTitle[ getData ], categoryShortDesc[ getData ], categoryCategoryName[ getData ], categoryNote[ getData ], categoryImg[ getData ] ).
                  pause ( 4000 ).useCss ( ).
                  waitForElementVisible ( ".video-tabs > a[ href='#properties']",4000,false,function ( checkProperties ) {
                    if ( checkProperties.value == true ) {
                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                        allCategories.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesAdd', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                        checkResult.length = 0;
                      }
                      else if ( checkResult.length == 0 ) {
                      }
                      else {
                        checkResult.length = 0;
                        //Check and click save button
                        allCategories.verify.visible ( "a.btn-active" ).
                        //click on the save button
                        click ( "a.btn-active" ).
                        pause ( 7000 ).
                        waitForElementNotPresent ( "a.btn-active",4000,false,function ( checkSaveInactive ) {
                          if ( checkSaveInactive.value.length == 0 ) {
                            allCategories.pause ( 4000 ).useXpath ( ).
                            //Verify the videos menu in the sidebar
                            verify.containsText ( "//ul/li/a[ text( ) = 'Categories']", "Categories" ).
                            pause ( 4000 ).
                            //click on the videos menu in CONTENT
                            click ( "//ul/li/a[ text( ) = 'Categories']" )
                            //Check the Actual Count after each video added
                            allCategories.useCss().pause( 4000 ).
                            waitForElementVisible ('.content-count > strong',4000,false ).
                            pause ( 7000 ).
                            getText ( '.content-count > strong', function ( actualCountResult ) {
                              if ( actualCountResult.status != -1 ) {
                                actualCount = actualCountResult.value;
                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                expectedCount = ( ( + currentCount ) + ( 1 ) );
                                if ( actualCount == expectedCount ) {
                                  //Write in the spreadsheet: Pass Result and Reason
                                  allCategories.writeToExcelPass ( 'boxxspring.xlsx', 'CategoriesAdd', rowCount, 10 );
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  allCategories.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesAdd', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Attributions. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                }
                              }
                            } );
                          }
                          else {
                            //Write in the spreadsheet: Fail Result and Reason
                            allCategories.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesAdd', rowCount, 10, 11, "Save functionality is not working as expected" );
                          }
                        } );
                      }
                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                        checkResult.length = 0;
                      }
                    }                    
                  } );
                }
                else {
                  //Write in the Excel for Fail Result and Reason
                  allCategories.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesAdd', rowCount, 10, 11, "Add button is not functioning in the Attributions page" );          
                }
              } );
            } );
          }
          else {
            //Write in the Spreadsheet for Fail Result and Reason
            allCategories.writeToExcelFail ( 'boxxspring.xlsx', 'CategoriesAdd', rowCount, 10, 11, " Categories Menu is not displayed in Sidebar" );                  
          }
        })
      }
    }
    //End the Browser
    allCategories.end ( );
  }
};
//this function is for check and Add the Videos URL 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs-rtl' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'VideourlAdd' ];
var videoUrl = [ ];
var videoTitle = [ ];
var shortTitle = [ ];
var shortDesc = [ ];
var author = [ ];
var attribution = [ ];
var categoryName = [ ];
var shortNote = [ ];
var dragImg = [ ];
var result = [ ];
var getData, rowCount = 1;
var currentCount,expectedCount,actualCount,excelData;
module.exports = {
  tags: [ 'videourlAdd' ],
  //Login in to Application
  before: function ( portallogin ) {
    var profile = portallogin.globals.profile;
    portallogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'VideourlAdd': function ( urlVideo ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read video URL
      if ( excelData.includes ( 'A' ) ) {
        videoUrl.push ( worksheet[ excelData ].v );
      }
      //Read Video Title
      if ( excelData.includes ( 'B' ) ) {
        videoTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        shortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        shortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Author Name
      if ( excelData.includes ( 'E' ) ) {
        author.push ( worksheet[ excelData ].v );
      }
      //Read Attribution Name
      if ( excelData.includes ( 'F' ) ) {
        attribution.push ( worksheet[ excelData ].v );
      }
      //Read Category Name
      if ( excelData.includes ( 'G' ) ) {
        categoryName.push ( worksheet[ excelData ].v );
      }
      //Read Short Notes
      if ( excelData.includes ( 'H' ) ) {
        shortNote.push ( worksheet[ excelData ].v );
      }
      //Read Replace Thumbnail
      if ( excelData.includes ( 'I' ) ) {
        dragImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( videoUrl.length > 1 ) {
        var checkResult = urlVideo.globals.excelCol.resultCustomData; 
      for ( let getData = 1, rowCount = 1; getData < videoUrl.length; getData++ ) {
        rowCount++;
        urlVideo.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text ( ) = 'Videos']", 9000, false, function ( checkVideoMenu ) {
          if ( checkVideoMenu.value == true ) {
            urlVideo.pause ( 4000 ).useXpath ( ).
            //Verify the Videos menu in CONTENT is visible
            verify.containsText ( "//ul/li/a[ text ( ) = 'Videos']", "Videos" ).
            pause ( 4000 ).
            //Click on the Videos Menu in CONTENT
            click ( "//ul/li/a[ text ( ) = 'Videos']" ).
            useCss ( ).pause ( 4000 ).
            //Getting Current Total video count
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }
              //Wait for the Add videos button is visible in the Videos listing page
              urlVideo.pause ( 4000 ).waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false,function ( checkAddbtn ) {
                if ( checkAddbtn.value.length == 0 ) {
                  urlVideo.pause ( 4000 ).verify.visible ( ".btn.btn-primary.btn-add" ).
                  pause ( 4000 ).
                  click ( ".btn.btn-primary.btn-add" ).
                  pause ( 4000 )
                  //Wait for the Video url field is visible
                  urlVideo.waitForElementVisible ( "#video_url", 4000, false ).
                  pause ( 4000 ).
                  //Verify the Video url field is visible
                  verify.visible ( "#video_url" ).
                  pause ( 4000 ).
                  //Enter the Video url in the Field
                  setValue ( "#video_url", videoUrl[ getData ] ).
                  pause ( 9000 )                
                  //Check and valid the URL from given spreadsheet input URL
                  if ( videoUrl[ getData ].match ( /www.dailymotion.com/g ) || ( videoUrl[ getData ].match ( /www.youtube.com/g ) ) || ( videoUrl[ getData ].match ( /www.youtube.com/g ) ) ) {
                    urlVideo.pause ( 4000 ).
                    //Wait for the Video Preview field is visible
                    waitForElementVisible ( '.video-preview', 4000, false ).
                    //Verify the Video Preview field is visible
                    verify.visible ( ".video-preview" ).
                    //Verify the Video Title is visible
                    verify.visible ( ".video-title" ).
                    pause ( 4000 ).useXpath().
                    //Verify the Cancel button is visible
                    verify.visible ( "//div/a[text()='cancel']" ).
                    pause ( 4000 ).
                    //Verify the Continue button is visible in videos page
                    verify.visible ( "//button[text()[normalize-space(.)='Continue']]" ).
                    pause ( 4000 ).
                    waitForElementVisible("//*/div/div/form/div[1]/button",9000,false).
                    //Click on the Continue button
                    click ( "//*/div/div/form/div[1]/button" ).
                    pause ( 5000 ).useCss ( ).
                    waitForElementVisible ( '.container-head > text-field > input' , 3000 , false ).
                    pause ( 5000 ).
                    //Verify the Video title field is visbile
                    verify.visible ( ".container-head > text-field > input" ).
                    //Clear the Video title data in field
                    clearValue ( '.container-head > text-field > input' ).
                    //Enter the Video title data in field
                    setValue ( '.container-head > text-field > input', videoTitle[ getData ] ).
                    //Check video player
                    waitForElementVisible ( '.player-container >.preview-embed' , 3000 , false ).
                    pause ( 3000 ).
                    //Verify the Preview embed field is visbile
                    verify.visible ( ".player-container >.preview-embed" ).
                    //Check the title display is visible
                    verify.visible ( ".edit-form > section >.input-headline-min" ).
                    pause ( 4000 ).
                    //Check the description display is visible
                    verify.visible ( ".edit-form > section >.input-description-min" ).
                    pause ( 4000 )
                    //Check in the Properties Tab for verifying all the fields:
                    urlVideo.video_properties ( shortTitle[ getData ], shortDesc[ getData ], categoryName[ getData ], shortNote[ getData ],dragImg[ getData ] ).
                    pause ( 4000 ).
                    propertiesAdd ( author[ getData ], attribution[ getData ]).
                    pause ( 4000 ).useCss ( ).
                    waitForElementVisible ( ".video-tabs > a[ href='#properties']",9000,false,function ( checkProperties ) {
                      if ( checkProperties.value == true ) {
                        if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                        urlVideo.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlAdd', rowCount, 11, 12, "Properties field as Failed in the page" );
                        }
                        else if ( checkResult.length == 0 ) {
                        }
                        else {
                          //Check and click save button
                          urlVideo.verify.visible ( "a.btn-active" ).
                          //click on the save button
                          click ( "a.btn-active" ).
                          pause ( 4000 ).useXpath ( ).
                          //Verify the videos menu in the sidebar
                          verify.containsText ( "//ul/li/a[ text( ) = 'Videos']", "Videos" ).
                          pause ( 3000 ).
                          //click on the videos menu in CONTENT
                          click ( "//ul/li/a[ text( ) = 'Videos']" ).
                          useCss ( ).
                          pause ( 3000 ) 
                          //Check the Actual Count after each video added
                          urlVideo.useCss ( ).pause( 4000 ).getText ( '.content-count > strong', function ( actualCountResult ) {
                            if ( actualCountResult.status !== -1 ) {
                              actualCount = actualCountResult.value;
                              actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                              expectedCount = ( ( +currentCount ) + ( 1 ) );
                              if ( actualCount == expectedCount ) {
                                //Write in the spreadsheet: Pass Result and Reason
                                urlVideo.writeToExcelPass ( 'boxxspring.xlsx', 'VideourlAdd', rowCount, 11 );
                              }
                              else {
                                //Write in the spreadsheet: Fail Result and Reason
                                urlVideo.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlAdd', rowCount, 11, 12, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Videos(URL). ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                              }
                            }
                          } );
                        }
                        if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                          checkResult.length = 0;
                        }

                      }
                      else {
                      }
                    } );                     
                  }
                  else {
                    //Check the Invalid URL and total video count
                    urlVideo.pause ( 4000 ).useCss ( ).
                    waitForElementVisible ( '.field-error > span:nth-child( 1 ) > span:nth-child( 2 ) > span:nth-child( 1 ) ', 7000, false ).
                    getText ( '.field-error > span:nth-child( 1 ) > span:nth-child( 2 ) > span:nth-child( 1 ) ', function ( urlErrorMsg ) {
                      if ( urlErrorMsg.status !== -1 ) {
                        var errmsg = urlErrorMsg.value;
                        var expectedmsg = "Please enter a valid URL.";
                        if ( expectedmsg == errmsg ) {
                          urlVideo.pause ( 7000 );
                          //Write in the spreadsheet: Invalid url pass Result and Reason
                          workbook.xlsx.readFile ( 'boxxspring.xlsx', {
                            cellStyles: true
                          } ).then ( function ( ) {
                            var worksheet = workbook.getWorksheet ( 'VideourlAdd' );
                            var row = worksheet.getRow ( rowCount );
                            row.getCell ( 11 ).font = {
                              bold: true,
                              color: {
                                argb: '0c891e'
                              }
                            };
                            row.alignment = {
                              wrapText: true
                            }
                            row.getCell ( 11 ).value = "PASS";
                            row.getCell ( 12 ).font = {
                              color: {
                                argb: '0c891e'
                              }
                            };
                            row.getCell ( 12 ).value = "Invalid Url alert is displayed in the Videos";
                            result.push ( 'Invalid URL Passed' );
                            for ( var col = 1; col < 50; col++ ) {
                              worksheet.getColumn ( col ).hidden = false;
                              for ( var rows = 1; rows < 50; rows++ ) {
                                worksheet.getRow ( rows ).hidden = false;
                              }
                            }
                            workbook.xlsx.writeFile ( 'boxxspring.xlsx' );
                            row.commit ( );
                          } );
                        }
                        else {
                          urlVideo.pause ( 4000 ).
                          //Write in the spreadsheet: Invalid url pass Result and Reason
                          writeToExcelFail ( 'boxxspring.xlsx', 'VideourlAdd', rowCount, 11, 12, "Invalid Url alert is not displayed in the Videos" );
                        }
                      }
                    } );                
                  }
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
                  urlVideo.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlAdd', rowCount, 11, 12, "Add Button is not clickable in the Vidoes Listing Page" ); 
                }
              } );
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            urlVideo.writeToExcelFail ( 'boxxspring.xlsx', 'VideourlAdd', rowCount, 11, 12, "Videos Menu is not displayed in the Sidebar" ); 
          }
        } );
      }
    }
    //End the browser
    urlVideo.end ( );
  }
}
//this function is for check and Destination Add in Boxxspring
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'DestinationBoxxspringAdd' ];
var provider = [ ];
var playlistTitle = [ ];
var destinationTitle = [ ];
var currentCount, actualCount, expectedCount, excelData;
var boxxspring = "Boxxspring";
var expectedTitleValue = "Add Boxxspring Destination"
var getData, rowCount = 1;
module.exports = {
  tags: [ 'destinationBoxxspringAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DestinationBoxxspringAdd': function ( boxxspringDestinationAdd ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Boxxspring provider
      if ( excelData.includes ( 'A' ) ) {
        provider.push ( worksheet[ excelData ].v );
      }
      //Read Boxxspring Destination playlist
      if ( excelData.includes ( 'B' ) ) {
        playlistTitle.push ( worksheet[ excelData ].v );
      }
      //Read Boxxspring Destination Title
      if ( excelData.includes ( 'C' ) ) {
        destinationTitle.push ( worksheet[ excelData ].v );
      }
    }
    if ( provider.length > 0 ) {
      for ( let getData = 1, rowCount = 1; getData < provider.length; getData++ ) {
        rowCount++;
        boxxspringDestinationAdd.pause ( 4000 ).useXpath ( ).
         waitForElementPresent ( "//div/a[@class='content-header-link content'][text()[normalize-space(.)='Distribution']]", 4000, false, function ( checkDistributionMenu ) {
          if ( checkDistributionMenu.value.length != 0 ) {
            boxxspringDestinationAdd.pause ( 4000 ).useXpath ( ).
            waitForElementVisible ( "//i[@ng-if='!collapse.distribution']", 4000, false, function ( checkArrow ) {
              if ( checkArrow.value == true ) {
                boxxspringDestinationAdd.pause ( 4000 ).useCss ( ).
                verify.visible ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 ).
                //Click on the Distribution menu in the side bar
                click ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 );
              }
            } );
            boxxspringDestinationAdd.pause ( 4000 ).useXpath ( ).
            waitForElementVisible ( "//a[text ( ) = 'Destinations']", 4000, false, function ( checkDestinationMenu ) {
              if ( checkDestinationMenu.value == true ) {
                boxxspringDestinationAdd.pause ( 4000 ).useXpath ( ).
                //Verify the Destination Menu is visible in the DISTRIBUTION
                verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
                pause ( 4000 ).
                //Click on the Destination Menu in the DISTRIBUTION
                click ( "//a[ text ( ) = 'Destinations']" ).
                useCss ( ).pause ( 4000 ).
                waitForElementVisible ( '.content-count > strong',4000, false, function ( checkTotalLabel ) {
                  if ( checkTotalLabel.value == true ) {
                    //Get the Current Total count in the Destination listing page
                    boxxspringDestinationAdd.pause ( 4000 ).useCss ( ).
                    getText ( '.content-count > strong', function ( currentCountResult ) {
                      if ( currentCountResult.status != -1 ) {
                        currentCount = currentCountResult.value;
                      }
                      boxxspringDestinationAdd.pause ( 4000 ).
                      waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false, function ( checkAddBtn ) {
                        if ( checkAddBtn.value.length == 0 ) {
                          boxxspringDestinationAdd.pause ( 4000 ).useCss ( ).
                          //Wait for the Add Destination button is visible
                          waitForElementVisible ( "a.btn-primary", 4000, false ).
                          pause ( 4000 ).
                          //verify the Add Destination button is visible
                          verify.visible ( "a.btn-primary" ).
                          pause ( 4000 ).
                          //Click on the Add Destination Button
                          click ( "a.btn-primary" ).            
                          pause ( 4000 ).useXpath ( ).              
                          //Wait for the Add Destination label is visible
                          waitForElementVisible ( "//h1[@class='ng-scope'][text ( ) ='Add Destination']", 4000, false, function ( checkLabelDestination ) {
                            if ( checkLabelDestination.value == true ) {
                              boxxspringDestinationAdd.pause ( 4000 ).
                              //Verify the Add Destination text is visible in the Add destination page
                              verify.containsText ( "//h1[@class='ng-scope'][text ( ) ='Add Destination']", "Add Destination" )
                              if ( boxxspring == provider[ getData ] ) {
                                boxxspringDestinationAdd.useXpath ( ).
                                //Wait for the Boxxspring Button is visible
                                waitForElementVisible ( "//li/a/div[text()[normalize-space(.)='"+ provider[ getData ] +"']]", 4000, false, function ( checkDestinationBTN ) {
                                  if ( checkDestinationBTN.value == true ) {
                                    boxxspringDestinationAdd.useXpath ( ).pause ( 4000 ).
                                    //Verify the Boxxspring Button is visible
                                    verify.visible ( "//li/a/div[text()[normalize-space(.)='"+ provider[ getData ] +"']]" ).
                                    pause ( 4000 ).
                                    //Click on the Boxxspring Button
                                    click ( "//li/a/div[text()[normalize-space(.)='"+ provider[ getData ] +"']]" ).
                                    pause ( 4000 ).
                                    //Wait for the Add Boxxspring Destination label is visible
                                    waitForElementVisible ( "//h1[@class='ng-scope'][text()[normalize-space(.)='Add Boxxspring Destination']]", 4000, false ).
                                    pause ( 4000 ).
                                    //Get the Add Boxxspring Destination label text in the page
                                    getText ( "//h1[@class='ng-scope']", function ( getTitleValue ) {
                                      var actualTitleValue = getTitleValue.value;
                                      if ( actualTitleValue == expectedTitleValue ) {
                                        boxxspringDestinationAdd.useXpath ( ).pause ( 4000 ).
                                        //Verify the Add Boxxspring Destination text is visible in the Add destination page
                                        verify.containsText ( "//h1[@class='ng-scope'][text()[normalize-space(.)='Add Boxxspring Destination']]", "Add Boxxspring Destination" ).
                                        pause ( 4000 ).
                                        //Wait for the Boxxspring Theme dropdown option is visible
                                        waitForElementVisible ( "//div[@class = 'dropdown-list-container ng-scope']/a/i[@class='ss-icon ss-gizmo ng-scope']", 4000, false ).
                                        pause ( 4000 ).
                                        //Click on the Boxxspring Theme dropdown option
                                        click ( "//div[@class = 'dropdown-list-container ng-scope']/a/i[@class='ss-icon ss-gizmo ng-scope']" ).
                                        pause ( 4000 ).
                                        //Wait for the Boxxspring Theme dropdown option list is visible
                                        waitForElementVisible ( "//ul/li[@class='ng-scope']/a[@class='ng-binding'][text()[normalize-space(.)='"+ playlistTitle[ getData ] +"']]", 4000, false, function ( checkPlaylistData ) {
                                          if ( checkPlaylistData.value == true ) {
                                            boxxspringDestinationAdd.useXpath ( ).pause ( 4000 ).
                                            //Click on the Boxxspring Theme dropdown Selected in the option
                                            click ( "//ul/li[@class='ng-scope']/a[@class='ng-binding'][text()[normalize-space(.)='"+ playlistTitle[ getData ] +"']]" ).
                                            pause ( 4000 ).
                                            //Wait for the Boxxspring Theme selected option is visible in the dropdown
                                            waitForElementVisible ( "//ul/li/a[@class='ng-binding'][@ng-click ='toggleFilterDropdown()'][text()[normalize-space(.)='"+ playlistTitle[ getData ] +"']]", 4000, false ).
                                            pause ( 4000 ).
                                            //Verify the Boxxspring Theme selected option is visible in the dropdown
                                            verify.containsText ( "//ul/li/a[@class='ng-binding'][@ng-click ='toggleFilterDropdown()'][text()[normalize-space(.)='"+ playlistTitle[ getData ] +"']]", playlistTitle[ getData ] ).useCss ( ).
                                            pause ( 4000 ).
                                            //Wait for the Add button is visible
                                            waitForElementVisible ( "a.btn-primary", 4000, false, function ( checkContinueBTN ) {
                                              if ( checkContinueBTN.value == true ) {
                                                boxxspringDestinationAdd.useCss ( ).pause ( 4000 ).
                                                //Click on the Add button
                                                click ( "a.btn-primary" ).
                                                pause ( 4000 ).
                                                //Wait for the Destination caption is visible in the add page
                                                waitForElementVisible ( ".typeName-label", 4000, false ).
                                                pause ( 4000 ).
                                                getText ( ".typeName-label", function ( getCaptionText ) {
                                                  if ( getCaptionText.value == "DESTINATION" ) {
                                                    boxxspringDestinationAdd.pause ( 4000 ).
                                                    //Wait for the Headline text field is visible
                                                    waitForElementVisible ( ".text-input-headline", 4000, false ).
                                                    pause ( 4000 ).
                                                    //Clear the Data in the Headline text filed
                                                    clearValue ( ".text-input-headline" ).
                                                    pause ( 4000 ).
                                                    //Enter the Data in the Headline text filed
                                                    setValue ( ".text-input-headline", destinationTitle[ getData ] ).
                                                    pause ( 4000 ).useXpath ( ).
                                                    //Wait for the Boxxspring Provider is visible
                                                    verify.visible ( "//div[@class='input-like'][text()[normalize-space(.)='"+ provider[ getData ] +"']]" ).
                                                    pause ( 4000 ).
                                                    //Verify the content text for Boxxspring Provider is visible
                                                    verify.containsText ( "//div[@class='input-like'][text()[normalize-space(.)='"+ provider[ getData ] +"']]", provider[ getData ] ).
                                                    pause ( 4000 ).
                                                    //Verify the Boxxspring playlist is visible
                                                    verify.visible ( "//div[@class='input-like ng-binding'][text()[normalize-space(.)='"+ playlistTitle[ getData ] +"']]" ).
                                                    pause ( 4000 ).
                                                    //Verify the content text for Boxxspring playlist is visible
                                                    verify.containsText ( "//div[@class='input-like ng-binding'][text()[normalize-space(.)='"+ playlistTitle[ getData ] +"']]", playlistTitle[ getData ] ).
                                                    pause ( 4000 ).useCss ( ).
                                                    //Verify the Cancel button is visible
                                                    verify.visible ( "a.btn-cancel" ).
                                                    pause ( 4000 ).
                                                    //Wait for the Save button is visible
                                                    waitForElementVisible ( "a.btn.btn-primary.btn-180.pull-right", 4000, false, function ( checkSaveBTN ) {
                                                      if ( checkSaveBTN.value == true ) {
                                                        boxxspringDestinationAdd.useCss ( ).pause ( 4000 ).
                                                        verify.visible ( "a.btn.btn-primary.btn-180.pull-right" ).
                                                        pause ( 4000 ).
                                                        //Click on the Save button
                                                        click ( "a.btn.btn-primary.btn-180.pull-right" ).
                                                        useXpath ( ).pause ( 4000 ).
                                                        //Verify the Destination menu is visible in the DISTRIBUTION
                                                        verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
                                                        pause ( 4000 ).
                                                        //Click on the Destination menu in the DISTRIBUTION
                                                        click ( "//a[ text ( ) = 'Destinations']" ).
                                                        useCss ( ).pause ( 4000 ).
                                                        //Get the Actual total count in the destination listing page
                                                        getText ( '.content-count > strong', function ( actualCountResult ) {
                                                          if ( actualCountResult.status != -1 ) {
                                                            actualCount = actualCountResult.value;
                                                            expectedCount = ( ( +currentCount ) + ( 1 ) );
                                                            if ( actualCount == expectedCount ) {
                                                              //Write in the spreadsheet: PASS Results
                                                              boxxspringDestinationAdd.writeToExcelPass ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6 );
                                                            }
                                                            else {
                                                              //Write in the spreadsheet: FAIL Result and Reason
                                                              boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "ActualResult: '"+ actualCount +"' in the Total Count After Added Destination. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                                                            }                  
                                                          }
                                                        } );
                                                      }
                                                      else {
                                                        //Write in the spreadsheet: FAIL Result and Reason
                                                        boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Save Button is not visible in the page" );
                                                      }
                                                    } );
                                                  }
                                                  else {
                                                    //Write in the spreadsheet: FAIL Result and Reason
                                                    boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Actual Caption Name is '"+getCaptionText.value+"'but Expected Caption Name as DESTINATION" );
                                                  }
                                                } );
                                              }
                                              else {
                                                //Write in the spreadsheet: FAIL Result and Reason
                                                boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Continue Button is not displayed in the page" );
                                              }
                                            } );
                                          }
                                          else {
                                            //Write in the spreadsheet: FAIL Result and Reason
                                            boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "The Expected Playlist Data is not avail in the page" );
                                          }
                                        } );
                                      }
                                      else {
                                        //Write in the spreadsheet: FAIL Result and Reason
                                        boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Expected Title as '"+ expectedTitleValue +"' and Actual Title as '"+ actualTitleValue +"'" );
                                      }
                                    } );
                                  }
                                  else {
                                    //Write in the spreadsheet: FAIL Result and Reason
                                    boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Expected Destination is not displayed in the button label" );
                                  }
                                } );
                              }
                              else {
                                //Write in the spreadsheet: FAIL Result and Reason
                                boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, " Destination '"+ provider[ getData ] +"' is not avail in the selection page" );                        
                              }
                            }
                            else {
                              //Write in the spreadsheet: FAIL Result and Reason
                              boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, " ALL DESTINATION Heading is not dispalyed in the selection page" );                        
                            }
                          } );
                        }
                        else {
                          //Write in the spreadsheet: FAIL Result and Reason
                          boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Add Destination button is not functioning as expected" );         
                        }
                      } );
                    } );
                  }
                  else {
                    //Write in the spreadsheet: FAIL Result and Reason
                    boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Total count label is not displayed in the page" );         
                  }
                } );
              }
              else {
                //Write in the spreadsheet: FAIL Result and Reason
                boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Destination Menu is not displayed in the Sidebar" );         
              }
            } );
          }
          else {
            //Write in the spreadsheet: FAIL Result and Reason
            boxxspringDestinationAdd.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationBoxxspringAdd', rowCount, 5, 6, "Distribution Menu is not displayed in the Sidebar" );         
          }
        } );          
      }
    }
    //End of the Browser
    boxxspringDestinationAdd.end ( );
  }
};
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'DistributionPictures' ];
var picturesTitle = [ ];
var picturesHeadline = [ ];
var distribSearch = [ ];
var resultStatus = [ ];
var currentCount, actualCount, expectedCount, excelData, searchCount;
var getData = 1, rowCount = 1;
module.exports = {
  tags: [ 'distributionPictures' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DistributionPictures': function ( picturesDistribution ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read pictures Title
      if ( excelData.includes ( 'A' ) ) {
        picturesTitle.push ( worksheet[ excelData ].v );
      }
      //Read pictures Description
      if ( excelData.includes ( 'B' ) ) {
        picturesHeadline.push ( worksheet[ excelData ].v );
      }
      //Read Destination Search Type
      if ( excelData.includes ( 'C' ) ) {
        distribSearch.push ( worksheet[ excelData ].v );
      }
    }
    if ( picturesTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < picturesTitle.length; getData++ ) {
        rowCount++;
        picturesDistribution.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text ( ) = 'Pictures']", 4000, false, function ( checkPicturesMenu ) {
          if ( checkPicturesMenu.value == true ) {
            picturesDistribution.pause ( 4000 ).useXpath ( ).
            //Verify the Pictures menu in the CONTENT is visible
            verify.containsText ( "//ul/li/a[ text ( ) = 'Pictures']", "Pictures" ).
            pause ( 4000 ).
            //Click on the Pictures menu in the CONTENT
            click ( "//ul/li/a[ text ( ) = 'Pictures']" ).
            useCss ( ).pause ( 4000 ).
            //Get the Current Total count in the Pictures listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              //Wait for the List view option is visible
              var resultStatus = [ ];
              picturesDistribution.pause ( 4000 ).waitForElementVisible ( ".list", 4000, false ).
              pause ( 4000 ).
              //Click on the List view option in the Pictures listing page
              click ( ".list" ).
              //Wait for the Search Input Field is visible
              pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
              //Verfiy the Search Input Field is visible
              verify.visible ( ".search-field-input" ).
              pause ( 4000 ).
              //Clear the data in Search Input field 
              clearValue ( ".search-field-input" ).
              pause ( 4000 ).
              //Enter the data in Search Input field 
              setValue ( ".search-field-input", picturesTitle[ getData ] ).
              //Press Enter key
              keys ( picturesDistribution.Keys.ENTER ).
              click ( ".search-field-input" ).
              //Release Enter Key
              keys ( picturesDistribution.Keys.NULL ).
              pause ( 4000 )
              //Wait for the Search Count label is visible
              picturesDistribution.waitForElementVisible ( ".content-count>strong", 4000, false ).
              //Verfiy the Search Count label is visible
              verify.visible ( ".content-count>strong" ).
              //Get the Searched data count in the pictures listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                } 
                if ( searchCount.value != 0 ) {               
                  picturesDistribution.pause ( 4000 ).useXpath ( ).
                  //Wait for the Searched data is visible in the pictures listing page
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ picturesTitle[ getData ] +"']]", 4000, false, function ( checkSearchedLst ) {
                    if ( checkSearchedLst.value == true ) {
                      picturesDistribution.pause ( 4000 ).
                      //Verify the Searched data is visible in the pictures listing page
                      verify.visible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ picturesTitle[ getData ] +"']]" ).
                      pause ( 4000 ).
                      //Click on the Searched data in the pictures listing page
                      click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ picturesTitle[ getData ] +"']]" ).
                      useCss ( ).pause ( 4000 ).
                      //Verify the Content Tab is visible in the pictures page
                      verify.visible ( ".video-tabs > a[ href='#content']" ).
                      pause ( 4000 ).
                      //Click on the Content Tab in the pictures page
                      click ( ".video-tabs > a[ href='#content']" ).
                      pause ( 4000 ).
                      //Wait for the Headline field is visible in the pictures page
                      waitForElementVisible ( ".text-input-headline", 4000, false ).
                      //Clear the data in the Headline field in the pictures page
                      clearValue ( ".text-input-headline" ).
                      //Enter the data in the Headline field in the pictures page
                      setValue ( ".text-input-headline", picturesHeadline[ getData ] ).
                      pause ( 4000 ).                      
                      //Verify the Properties Tab is visible in the pictures page
                      waitForElementVisible ( ".video-tabs a[ href='#distribution']", 4000, false ).
                      pause ( 4000 ).
                      //Click on the Properties Tab in the pictures Page
                      click ( ".video-tabs a[ href='#distribution']" ).
                      pause ( 4000 ).
                      //Wait for the Add Distribution button is visible in Distribution Tab page
                      waitForElementVisible ( ".distro-button", 4000, false, function ( checkdistributeBtn ) {
                      	if ( checkdistributeBtn.value == true ) {
		                      picturesDistribution.pause ( 4000 ).
		                      //Click on the Add Distribution button in Distribution Tab page
		                      click ( ".distro-button" ).
		                      pause ( 4000 ).
		                      //Wait for the Toggle filter dropdown is visible
		                      waitForElementVisible ( "a.ng-binding[ng-click='toggleFilterDropdown();']", 4000, false ).
		                      pause ( 4000 ).
		                      //Verify the Toggle filter dropdown is visible
		                      verify.visible ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
		                      pause ( 4000 ).
		                      //Click on the Toggle filter dropdown option
		                      click ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
		                      pause ( 4000 ).useXpath ( ).
		                      //Wait for the options in the list should be visible
		                      waitForElementVisible ( "//ul/li/a[contains(.,'boxxspring')]", 4000, false, function ( destinationList ) {
		                        if ( destinationList.value == true ) {
		                          picturesDistribution.pause ( 4000 ).
		                          //Verify the options in the listing is visible
		                          verify.visible ( "//ul/li/a[contains(.,'boxxspring')]" ).
		                          pause ( 4000 ).
		                          //Click on the options in the dropdown list
		                          click ( "//ul/li/a[contains(.,'boxxspring')]" )
		                          var categoryTemp = distribSearch[ getData ];
		                          var categoryTemp_array = categoryTemp.split ( ',' );
		                          for ( let categoryCount = 0; categoryCount < categoryTemp_array.length; categoryCount++ ) {
		                            //Split the Category data and store in the Temp variable
		                            categoryTemp_array[ categoryCount ] = categoryTemp_array[ categoryCount ].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
		                            picturesDistribution.useCss ( ).pause ( 4000 ).
		                            //Wait for the Saerch -Input Field is visible
		                            waitForElementVisible ( ".full-width-search-field-input", 4000, false ).
		                            pause ( 4000 ).
		                            //Verify the Saerch -Input Field is visible
		                            verify.visible ( ".full-width-search-field-input" ).
		                            pause ( 4000 ).
		                            //Clear the data in the Saerch -Input Field
		                            clearValue ( ".full-width-search-field-input" ).
		                            pause ( 4000 ).
		                            //Enter the data in the Saerch -Input Field
		                            setValue ( ".full-width-search-field-input", categoryTemp_array[ categoryCount ] ).
		                            pause ( 4000 ).useXpath ( ).
		                            //Wait for the searched data in listing down is visible
		                            waitForElementVisible ( "//label[@class='label-left ng-binding'][contains(.,'"+ categoryTemp_array[ categoryCount ] +"')]", 4000, false ).
		                            pause ( 4000 ).
		                            //Click on the Searched data in the distribution page
		                            click ( "//label[@class='label-left ng-binding'][ contains(.,'"+ categoryTemp_array[ categoryCount ] +"')]" ).
		                            useCss ( ).pause ( 4000 )
		                          }
		                          picturesDistribution.pause ( 4000 ).
		                          //Wait for the Next button is visible
		                          waitForElementVisible ( ".btn-next", 4000, false ).
		                          //Click on the Next Button in the Distribution button
		                          click ( ".btn-next" ).
		                          //Get the Text for Selected Destination count in the Distribution page
		                          getText ( "h3.distributions-title.ng-binding", function ( selectedDestinationLabel ) {
		                            var getLabelData = selectedDestinationLabel.value;
		                            var labelDataExpected = "Selected Destinations " + categoryTemp_array.length;
		                            //Compare the Actual and Expected data in the Distribution page
		                            if ( getLabelData == labelDataExpected ) {
		                              picturesDistribution.pause ( 4000 ).useCss ( ).
		                              //Verify the Cancel button in the Distribution page
		                              verify.visible ( ".cancel-distribution" ).
		                              pause ( 4000 ).
		                              //Verify the All Post button is visible in the Distribution page
		                              verify.visible ( "a.btn-next:nth-child( 2 )" ).
		                              pause ( 4000 ).
		                              //Click on the All Post button in the Distribution page
		                              click ( "a.btn-next:nth-child( 2 )" ).
		                              pause ( 4000 )
		                              for ( let getPostData = 3; getPostData < categoryTemp_array.length + 3; getPostData++ ) {
		                                //Get the Value for Destination posted in the Distribution page
		                                picturesDistribution.pause ( 4000 ).getValue ( "ul.post-list li>.ng-scope", function ( allPost ) {
		                                  if ( allPost.value == null ) {			                                                                                           
	                                      picturesDistribution.pause ( 4000 ).useCss ( ).
	                                      //Wait for the Distributed post is visible in the distribution page
	                                      waitForElementVisible ( "li.completed:nth-child("+ getPostData +")>span>ng-include>div.description>a", 4000, false, function ( postAllList ) {
	                                        if ( postAllList.value == true ) {
	                                          picturesDistribution.pause ( 4000 ).
	                                          //Get the Distributed post url in the distribution page
	                                          getText ( "li.completed:nth-child("+ getPostData +")>span>ng-include>div.description>a", function ( urlResult ) {
	                                            if ( urlResult.value != null ) {
	                                              //Write in the Excel as PASS Results
	                                              picturesDistribution.pause ( 4000 );
	                                              resultStatus.push ( "PASS" );
	                                            }
	                                            else {
	                                              picturesDistribution.pause ( 4000 );
	                                              resultStatus.push ( "FAIL" );
	                                            }
	                                          } );
	                                        }
	                                        else {
	                                          //Write in the Excel as FAIL Results and Reason
	                                          picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "Completed Post is not displayed" );
	                                        }
	                                      } );		                                    
		                                  }
		                                  else {
		                                    //Write in the Excel as FAIL Results and Reason
		                                    picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "Post List is not visible" );
		                                  }
		                                } );
		                              }
		                              picturesDistribution.pause ( 4000 ).
		                              getValue ( "ul.post-list li>.ng-scope", function ( allPostResult ) {
		                                if ( resultStatus.indexOf ( 'FAIL' ) >= 0 ) {
		                                  //Write in the Excel as FAIL Results and Reason
		                                  picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "Completed Post URL is not displayed" );
		                                }
		                                else if ( resultStatus.length == 0 ) {
		                                }
		                                else {
		                                	//Write in the Excel as PASS Results
		                                  picturesDistribution.writeToExcelPass ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5 );
		                                }
		                                if ( resultStatus.indexOf ( 'FAIL' ) || resultStatus.indexOf ( 'PASS' ) >= 0 ) {
		                                  resultStatus.length = 0;
		                                }
		                              } );
		                            }
		                          } );                    
		                        }
		                        else {
		                          //Write in the Excel as FAIL Results and Reason
		                          picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "There is no Destinations in the page" )                    
		                        }
		                      } );
												}
												else {
													//Write in the Excel as FAIL Results and Reason
		                      picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "Add Distribution Button is not displayed in the pictures page" )                    
		         						}
											} );
                    }
                    else {
                      //Write in the Excel as FAIL Results and Reason
                      picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "Searched Data is not listed in the Listing page" )                    
                    }
                  } );
                }
                else {
                  //Write in the Excel as FAIL Results and Reason
                  picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "Searched Results got as '0'" )                    
                }
              } );
            } );
          }
          else {
            //Write in the Excel as FAIL Results and Reason
            picturesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionPictures', rowCount, 5, 6, "pictures Menu is not displayed in the Sidebar" );       
          }
        } );
      }
    }
    //End the Browser
    picturesDistribution.end ( );
  }
};
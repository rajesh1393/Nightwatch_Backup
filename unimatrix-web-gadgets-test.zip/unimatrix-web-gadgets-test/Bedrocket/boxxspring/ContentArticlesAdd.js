//This Function is check and Distribute the Articles from Boxxspring Destination
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'ContentArticlesAdd' ];
var categoryTitle = [ ];
var templateSelection = [ ];
var articleTextDescription = [ ];
var articleHeadline = [ ];
var articleShortTitle = [ ];
var articleShortDesc = [ ];
var articleEmbed = [ ];
var articleURL = [ ];
var articleImage = [ ];
var articleCategoryName = [ ];
var articleNote = [ ];
var articleImg = [ ];
var thumbnail = [ ];
var contentType = [ ];
var contentValues = [ ];
var presentationView = [ ];
var switchData = [ ];
var resultStatus = [ ];
var currentCount, excelData;
var getData, rowCount = 1;
var increamentList = 0;
var increamentedcount = [ ];
module.exports = {
  tags: [ 'contentArticlesAdd' ],
  // Login the Portal Boxxspring
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'ContentArticlesAdd': function ( contentArticles ) {
    for ( excelData in worksheet ) {
      if ( excelData[1] === '!' ) continue;
      //Read Articles Title
      if ( excelData.includes ( 'A' ) ) {
        categoryTitle.push ( worksheet[ excelData ].v );
      }
      //Read Articles Template Selection
      if ( excelData.includes ( 'B' ) ) {
        templateSelection.push ( worksheet[ excelData ].v );
      }
      //Read Text Description
      if ( excelData.includes ( 'C' ) ) {
        articleTextDescription.push ( worksheet[ excelData ].v );
      }
      //Read Headlines
      if ( excelData.includes ( 'D' ) ) {
        articleHeadline.push ( worksheet[ excelData ].v );
      }
      //Read Thumbnail
      if ( excelData.includes ( 'E' ) ) {
        articleImage.push ( worksheet[ excelData ].v );
      }
      //Read Video url
      if ( excelData.includes ( 'F' ) ) {
        articleURL.push ( worksheet[ excelData ].v );
      }
      //Read Embed code
      if ( excelData.includes ( 'G' ) ) {
        articleEmbed.push ( worksheet[ excelData ].v );
      }
      //Read Article Short Title
      if ( excelData.includes ( 'H' ) ) {
        articleShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Article Short Description
      if ( excelData.includes ( 'I' ) ) {
        articleShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Article Categories
      if ( excelData.includes ( 'J' ) ) {
        articleCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read Article Note
      if ( excelData.includes ( 'K' ) ) {
        articleNote.push ( worksheet[ excelData ].v );
      }
      //Read Article thumbnail
      if ( excelData.includes ( 'L' ) ) {
        thumbnail.push ( worksheet[ excelData ].v );
      }
      //Read Article Content Type
      if ( excelData.includes ( 'M' ) ) {
        contentType.push ( worksheet[ excelData ].v );
      }
      //Read Article presentationView
      if ( excelData.includes ( 'N' ) ) {
        presentationView.push ( worksheet[ excelData ].v );
      }
    }
    if ( categoryTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < categoryTitle.length; getData++ ) {
        rowCount++;
        contentArticles.pause ( 4000 ).timeoutsImplicitWait ( 4000 ).useXpath( ).
        waitForElementVisible ( "//ul/li/a[ text ( ) = 'Articles']",9000,false,function ( checkArticlesMenu ) {
          if ( checkArticlesMenu.value == true ) {
            contentArticles.pause ( 4000 ).useXpath( ).
            //Verify the Articles Menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text ( ) = 'Articles']", "Articles" ).
            pause ( 4000 ).
            //Click on the Articles Menu in the CONTENT
            click ( "//ul/li/a[ text ( ) = 'Articles']" ).
            useCss( ).pause ( 4000 ).
            //Get the Current Totla Count in the Articles listing Page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }
              contentArticles.pause ( 4000 ).
              //Wait for Add button to visible in the listing page 
              waitForElementVisible ( ".btn.btn-primary.btn-add", 4000, false ).
              pause ( 4000 ).
              //Click on the Add button in the listing page
              click ( ".btn.btn-primary.btn-add" ).
              pause ( 4000 ).useXpath( ).
              //Wait for template selection to visible in the articles page
              waitForElementVisible ( "//div/div/div[@class='template " + templateSelection[ getData ] +"']", 4000, false ).
              //div/div/div[@class='template default selected']
              pause ( 4000 ).
              //Click on the template selection in the articles page
              click ( "//div/div/div[@class='template " + templateSelection[ getData ] +"']" ).
              pause ( 4000 ).
              //Wait and check the Caption field is visible in the Articles page
              waitForElementVisible ( "//div/div/header/div/div[@class='typeName-label']", 4000, false, function ( captionCheck ) {
                if ( captionCheck.value == true ) {
                  //Get the Text value as "Article" in the label
                  contentArticles.getText ( "//div/div/header/div/div[@class='typeName-label']", function ( labelName ) {
                    if ( labelName.value == 'ARTICLE' ) {
                      contentArticles.pause ( 4000 ).useXpath( ).
                      //Wait for text field is visible in the articles page
                      waitForElementVisible ( "//div/div/header/div/text-field/input", 4000, false ).
                      pause ( 4000 ).
                      //Clear the data in the text field
                      clearValue ( "//div/div/header/div/text-field/input" ).
                      pause ( 4000 ).
                      //Enter the data in the text field
                      setValue ( "//div/div/header/div/text-field/input", categoryTitle[ getData ] ).
                      pause ( 4000 ).
                      //Wait for Content tab is visible in the Article page
                      waitForElementVisible ( "//div/div/header/div/div[2]/div/a[1]", 4000, false ).
                      pause ( 4000 ).
                      //Click on the Content tab in the Article page
                      click ( "//div/div/header/div/div[2]/div/a[1]" ).
                      pause ( 4000 ).
                      //Wait for text field is visible in the articles page
                      waitForElementVisible ( "//div/div[2]/form/section/text-field[1]/textarea", 4000, false ).
                      pause ( 4000 ).
                      //Clear the data in the text field
                      clearValue ( "//div/div[2]/form/section/text-field[1]/textarea" ).
                      pause ( 4000 ).
                      //Enter the data in the text field
                      setValue ( "//div/div[2]/form/section/text-field[1]/textarea", categoryTitle[ getData ] ).
                      pause ( 4000 ).
                      //Wait for text description is visible in the articles page
                      waitForElementVisible ( "//div/div[2]/form/section/text-field[2]/textarea", 4000, false ).
                      pause ( 4000 ).
                      //Clear the data in the text description
                      clearValue ( "//div/div[2]/form/section/text-field[2]/textarea" ).
                      pause ( 4000 ).
                      //Enter the data in the text description
                      setValue ( "//div/div[2]/form/section/text-field[2]/textarea", articleTextDescription[ getData ] ).
                      pause ( 4000 ).
                      //Wait for Add section button is visible in the Article page
                      waitForElementVisible ( "//div/div[2]/form/section/section/ng-include/section/section/a/span", 4000, false ).
                      pause ( 4000 ).
                      //Click on the Add section button in the Article page
                      click ( "//div/div[2]/form/section/section/ng-include/section/section/a/span" ).
                      pause ( 4000 ).
                      //Wait for Headlines is visible in the articles page
                      waitForElementVisible ( "//div/div/div[2]/div[1]/div/text-field/textarea", 4000, false ).
                      pause ( 4000 ).
                      //Clear the data in the Headlines 
                      clearValue ( "//div/div/div[2]/div[1]/div/text-field/textarea" ).
                      pause ( 4000 ).
                      //Enter the data in the Headlines 
                      setValue ( "//div/div/div[2]/div[1]/div/text-field/textarea", articleHeadline[ getData ] ).
                      pause ( 4000 ).useCss( ).
                      //Move to element is to highlight the '+' menu tab
                      moveToElement ( "div.section-add-chrome.ng-scope > a.add-btn > i", 0, 0 ).
                      pause ( 4000 ).
                      //Wait for image button is visible in the menu tab
                      waitForElementVisible ( ".image-btn.ng-isolate-scope>i", 4000, false ).
                      pause ( 4000 ).
                      //Click on the image button in the menu tab
                      click ( ".image-btn.ng-isolate-scope>i" ).
                      pause ( 4000 ).
                      //Wait for Thumbnail upload field is visible in the Article page
                      waitForElementVisible ( "div.image-upload.image-drop.ng-scope", 4000, false ).
                      pause ( 4000 ).
                      //Send the Thumbnail path in the field on the Article page
                      setValue ( 'span.hidden-input:nth-child( 1 ) > input:nth-child( 1 )', require ( 'path' ).resolve ( articleImage[ getData ] ) ).
                      pause ( 12000 ).keys ( contentArticles.Keys.END ).keys ( contentArticles.Keys.END )
                      //Condition for valid format to allow to continue the process
                      if ( ( articleImage[ getData ].match ( /.jpg/g ) ) || ( articleImage[ getData ].match ( /.png/g ) ) || ( articleImage[ getData ].match ( /.gif/g ) ) || ( articleImage[ getData ].match ( /.jpeg/g ) ) ) {
                        //Wait for Credit Title field is visible in the Article page
                        contentArticles.useXpath( ).pause ( 4000 ).waitForElementVisible ( "//div/input[@id='story_seo_title'][@placeholder='Credit title']", 4000, false ).
                        pause ( 4000 ).
                        //Enter the Credit Title in the field on the Article page
                        setValue ( "//div/input[@id='story_seo_title'][@placeholder='Credit title']", "Credit the Image name" ).
                        pause ( 4000 ).
                        //Wait for Credit Hyperlink field is visible in the Article page
                        waitForElementVisible ( "//div/input[@placeholder='Credit hyperlink']", 4000, false ).
                        pause ( 4000 ).
                        //Enter the Credit Hyperlink in the field on the Article page
                        setValue ( "//div/input[@placeholder='Credit hyperlink']", "https://portal.staging.boxxspring.com" ).
                        pause ( 4000 ).useCss( ).
                        //Move to element is to highlight the '+' menu tab
                        moveToElement ( "div.section-add-chrome:nth-child( 2 ) > a:nth-child( 1 ) > i:nth-child( 1 )", 0, 0 ).
                        pause ( 4000 ).
                        //Wait for '+' menu tab is visible in the Article page
                        waitForElementVisible ( "div.section-add-chrome:nth-child( 2 ) > a:nth-child( 1 ) > i:nth-child( 1 )", 4000, false ).
                        pause ( 4000 ).
                        //Wait for Video url button is visible in the '+' menu tab 
                        waitForElementVisible ( "a.video-btn:nth-child( 6 ) > i:nth-child( 1 )", 4000, false ).
                        pause ( 4000 ).
                        //Click on the Video url button in the '+' menu tab 
                        click ( "a.video-btn:nth-child( 6 ) > i:nth-child( 1 )" ).
                        pause ( 4000 ).useXpath( ).
                        //Wait for Video url field is visible in the Article page
                        waitForElementVisible ( "//div[@class='field-input']/input", 4000, false ).
                        pause ( 4000 ).
                        //Enter the Video url field in the Article page
                        setValue ( "//div[@class='field-input']/input", articleURL[ getData ] ).
                        keys ( contentArticles.Keys.END ).pause ( 4000 ).keys ( contentArticles.Keys.END )
                        //Check the valid URL from given URL           
                        if ( ( articleURL[ getData ].match ( /www.dailymotion.com/g ) ) || ( articleURL[ getData ].match ( /www.youtube.com/g ) ) || ( articleURL[ getData ].match ( /vimeo.com/g ) ) ) {
                          contentArticles.pause ( 4000 ).useXpath( ).
                          //Wait and check for Error message should not displayed in the Article page
                          waitForElementNotPresent ( "//field-error/div/span/span[2]/span[@class='ng-scope']", 4000, false, function ( urlErrCheck ) {
                            if ( ( urlErrCheck.value.length !== 0 ) && ( urlErrCheck.value == false ) ) {
                              //Write the FAIL Result and Reason on Excel sheet 
                              contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Error alert displayed for Valid URL" );
                            }
                            else {
                              contentArticles.useCss( ).pause ( 4000 ).
                              //Move to element is to highlight the '+' menu tab
                              moveToElement ( "div.section-add-chrome:nth-child( 2 ) > a:nth-child( 1 ) > i:nth-child( 1 )", 0, 0 ).
                              pause ( 4000 ).
                              //Wait for '+' menu tab is visible in the Article page
                              waitForElementVisible ( "div.section-add-chrome:nth-child( 2 ) > a:nth-child( 1 ) > i:nth-child( 1 )", 4000, false ).
                              pause ( 4000 ).
                              //Wait for Embed button is visible in the '+' menu tab
                              waitForElementVisible ( "a.embed-btn:nth-child( 7 ) > i:nth-child( 1 )", 4000, false ).
                              pause ( 4000 ).
                              //Click on the Embed button in the '+' menu tab
                              click ( "a.embed-btn:nth-child( 7 ) > i:nth-child( 1 )" ).
                              pause ( 4000 ).keys ( contentArticles.Keys.END ).useXpath( ).
                              //Wait for Embed field is visible in the Article page
                              waitForElementVisible ( "//div[@class='field-input']/input[@class='ng-pristine ng-untouched ng-valid ng-empty']", 4000, false ).
                              pause ( 4000 ).
                              //Enter the Embed data in the field on Article page
                              setValue ( "//div[@class='field-input']/input[@class='ng-pristine ng-untouched ng-valid ng-empty']", articleEmbed[ getData ] ).
                              pause ( 14000 ).keys ( contentArticles.Keys.END ).keys ( contentArticles.Keys.END )
                              //Check the valid URL from given URL           
                              if ( ( articleEmbed[ getData ].match ( /www.dailymotion.com/g ) ) || ( articleEmbed[ getData ].match ( /www.youtube.com/g ) ) || ( articleEmbed[ getData ].match ( /widgets.staging.boxxspring.com/g ) ) || ( articleEmbed[ getData ].match ( /www.facebook.com/g ) ) || ( articleEmbed[ getData ].match ( /platform.instagram.com/g ) ) || ( articleEmbed[ getData ].match ( /platform.twitter.com/g ) ) || ( articleEmbed[ getData ].match ( /www.wufoo.com/g ) ) || ( articleEmbed[ getData ].match ( /www.ustream.tv/g ) ) || ( articleEmbed[ getData ].match ( /www.snappytv.com/g ) ) || ( articleEmbed[ getData ].match ( /soundcloud.com/g ) ) || ( articleEmbed[ getData ].match ( /vine.co/g ) ) || ( articleEmbed[ getData ].match ( /ooyala.com/g ) ) ) {
                                //Wait and check for Error message should not displayed in the Article page
                                contentArticles.useXpath( ).waitForElementNotPresent ( "//field-error/div/span/span[2]/span[@class='ng-scope']", 4000, false, function ( embedErrCheck ) {
                                  if ( ( embedErrCheck.value.length !== 0 ) && ( embedErrCheck.value == false ) ) {
                                    //Write the FAIL Result and Reason on Excel sheet
                                    contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Error alert displayed for Valid EMBED code" );
                                  }
                                  else {
                                    //Move to element is to highlight the '+' menu tab
                                    contentArticles.useCss( ).pause ( 4000 ).moveToElement ( "div.section-add-chrome:nth-child( 2 ) > a:nth-child( 1 ) > i:nth-child( 1 )", 0, 0 ).
                                    pause ( 4000 ).
                                    //Wait for '+' menu tab is visible in the Article page
                                    waitForElementVisible ( "div.section-add-chrome:nth-child( 2 ) > a:nth-child( 1 ) > i:nth-child( 1 )", 4000, false ).
                                    pause ( 4000 ).
                                    //Wait for Galleries button is visible in the Article page
                                    waitForElementVisible ( "a.media-btn:nth-child( 5 ) > i:nth-child( 1 )", 4000, false ).
                                    pause ( 4000 ).
                                    //Click on the Galleries button in the Article page
                                    click ( "a.media-btn:nth-child( 5 ) > i:nth-child( 1 )" ).
                                    pause ( 4000 ).keys ( contentArticles.Keys.END ).keys ( contentArticles.Keys.END ).pause ( 4000 ).useXpath( ).
                                    //Wait for Gallery Add button is visible in the Article page
                                    waitForElementVisible ( "//button[@class = 'btn btn-primary btn-fluid gallery']", 4000, false ).
                                    pause ( 4000 ).useCss( ).
                                    //Wait for New Gallery button is visible in the Article page
                                    waitForElementVisible ( "button.btn:nth-child( 5 )", 4000, false ).
                                    pause ( 4000 ).
                                    //Wait for Existing Gallery button is visible in the Article page
                                    waitForElementVisible ( "button.btn:nth-child( 4 )", 4000, false ).
                                    pause ( 4000 ).
                                    //Click on the New Gallery button in the Article page
                                    click ( "button.btn:nth-child( 5 )" ).
                                    pause ( 4000 ).keys ( contentArticles.Keys.END ).pause ( 4000 ).
                                    //Wait for Add Media frame is visible in the Article page
                                    waitForElementVisible ( ".media-gallery-item", 4000, false ).
                                    pause ( 4000 ).
                                    //Wait for Add Media button is vsible in the Article page
                                    waitForElementVisible ( "button.btn:nth-child( 3 )", 4000, false ).
                                    pause ( 4000 ).
                                    //Click on the Add Media button in the Article page
                                    click ( "button.btn:nth-child( 3 )" ).
                                    pause ( 4000 ).
                                    //Wait for Gallery dialog page is visible in the Article page
                                    waitForElementVisible ( "dialog-include>dialog.dialog-full-page.dialog-tan", 4000, false ).
                                    pause ( 4000 ).useXpath ( ).
                                    //Wait for checkbox label is visible in the gallery dialog page
                                    waitForElementVisible ( "//ul/li[1]/div[@class='checkbox']/label", 4000, false ).
                                    pause ( 4000 )
                                    var splitArtifact = contentType[ getData ];
                                    var splitGallery = splitArtifact.split ( ':' );
                                    var splitContentType = [ ];
                                    var categoriesSplit = [ ];
                                    for ( let contentCount = 0; contentCount < splitGallery.length; contentCount++ ) {
                                      if ( !( resultStatus.indexOf ( 'FAIL' ) >= 0 ) || resultStatus.length == 0 ) {
                                        contentArticles.useXpath( ).pause ( 4000 ).
                                        //Wait and check for Condition value is visible in the Article page
                                        waitForElementVisible ( "//ul/li[1]/div[@class='checkbox']/label", 4000, false, function ( conditionVisible ) {
                                          if ( conditionVisible.value === true ) {
                                            var splitCondition = splitGallery[contentCount].split ( ';' );
                                            splitContentType = splitCondition[0].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
                                            contentArticles.useXpath( ).pause ( 4000 )
                                            switchData = splitContentType;
                                            switch ( switchData ) {
                                              case "MediaGalleries":
                                                contentValues = "gallery_artifact";
                                                break;
                                              case "Videos":
                                                contentValues = "video_artifact";
                                                break;
                                              case "Threesixtyvideos":
                                                contentValues = "three_sixty_video_artifact";
                                                break;
                                              case "Streams":
                                                contentValues = "stream_artifact";
                                                break;
                                              case "Pictures":
                                                contentValues = "picture_artifact";
                                                break;
                                              case "Articles":
                                                contentValues = "article_artifact";
                                                break;
                                              case "Links":
                                                contentValues = "link_artifact";
                                            }
                                            contentArticles.useXpath( ).pause ( 4000 ).
                                            //Wait for content value is visible in the Gallery page
                                            waitForElementVisible ( "//ul/li/div[@class='checkbox']/label[@for='"+ contentValues +"']", 4000, false, function ( contentPresent ) {
                                              if ( contentPresent.value == true ) {
                                                contentArticles.useXpath( ).pause ( 4000 ).
                                                //Get Attribute for content value in the Gallery page
                                                getAttribute ( "//ul/li/div[@class='checkbox']/input[@id='"+ contentValues +"']", "checked", function ( checkContentType ) {
                                                  if ( checkContentType.value == null ) {
                                                    contentArticles.useXpath( ).pause ( 4000 ).
                                                    //Click on the Content value
                                                    click ( "//ul/li/div[@class='checkbox']/label[@for='"+ contentValues +"']" )
                                                  }                                                  
                                                } );
                                                categoriesSplit = splitCondition[1].split ( ',' );
                                                for ( let contentTypeCount = 0; contentTypeCount < categoriesSplit.length; contentTypeCount++ ) {
                                                  contentArticles.useXpath( ).pause ( 4000 ).
                                                  //Wait and check the suggestion dropdown input in the gallery page
                                                  waitForElementVisible ( "//div/div[@class='suggestion-dropdown-wrap']/input", 4000, false, function ( searchField ) {
                                                    if ( ( !( resultStatus.indexOf ( "FAIL" ) >= 0 ) == true ) || resultStatus.length == 0 ) {
                                                      contentArticles.useXpath( ).pause ( 4000 ).
                                                      //Verify the suggestion dropdown input is visible in the gallery page
                                                      verify.visible ( "//div/div[@class='suggestion-dropdown-wrap']/input" ).
                                                      pause ( 4000 ).keys ( contentArticles.Keys.BACK_SPACE ).keys ( contentArticles.Keys.BACK_SPACE ).
                                                      //Clear the data in suggestion dropdown input field on the gallery page
                                                      clearValue ( "//div/div[@class='suggestion-dropdown-wrap']/input" ).
                                                      pause ( 4000 ).
                                                      //Enter the data in suggestion dropdown input field on the gallery page
                                                      setValue ( "//div/div[@class='suggestion-dropdown-wrap']/input", categoriesSplit[contentTypeCount] ).
                                                      pause ( 4000 ).keys ( contentArticles.Keys.ENTER ).keys ( contentArticles.Keys.ENTER ).pause ( 4000 ).
                                                      //Wait and check for content title in the gallery page
                                                      waitForElementVisible ( "//div[@class='content-title']/h2[@class='ng-binding'][contains ( .,'"+ categoriesSplit[contentTypeCount] +"' )]", 4000, false, function ( categoriesVisible ) {
                                                        if ( categoriesVisible.value == true ) {
                                                          contentArticles.useXpath( ).pause ( 4000 ).
                                                          //Verify the content title in the gallery page
                                                          verify.visible ( "//div[@class='content-title']/h2[@class='ng-binding'][contains ( .,'"+ categoriesSplit[contentTypeCount] +"' )]" ).
                                                          pause ( 4000 ).
                                                          //Wait and check for gallery content collection should not present in the gallery page
                                                          waitForElementNotPresent ( "//gallery-content-collection/ul/li[@class='content-container ng-scope active']//h2[text( )[normalize-space ( . )='"+ categoriesSplit[contentTypeCount] +"']]", 4000, false, function ( activeStory ) {
                                                            if ( activeStory.value.length == 0 ) {
                                                              contentArticles.useXpath( ).pause ( 4000 ).
                                                              //Click on the content title in the gallery page
                                                              click ( "//div[@class='content-title']/h2[@class='ng-binding'][contains ( .,'"+ categoriesSplit[contentTypeCount] +"' )]" ).
                                                              pause ( 4000 )                                                              
                                                              resultStatus.push ( "PASS" )
                                                              increamentList = ( increamentList ) + 1;
                                                            }                                                        
                                                            if ( contentTypeCount == categoriesSplit.length - 1 && contentCount == splitGallery.length - 1 ) {
                                                              contentArticles.writeToExcelPass ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16 );
                                                              if ( increamentList > 0 ) {
                                                                contentArticles.pause ( 4000 ).useCss( ).
                                                                //Verify the Presentation view option is visible in the gallery page 
                                                                verify.visible ( "." + presentationView[ getData ] ).
                                                                pause ( 4000 ).
                                                                //Click on the Presentation view option in the gallery page 
                                                                click ( "." + presentationView[ getData ] ).
                                                                pause ( 4000 ).useXpath( ).
                                                                //Wait for Cancel button is visible in the gallery page
                                                                waitForElementVisible ( "//section/a[@class='link-secondary']", 4000, false ).
                                                                pause ( 4000 ).
                                                                //Click on the Cancel button in the gallery page
                                                                verify.visible ( "//section/a[@class='link-secondary']" ).
                                                                pause ( 4000 ).
                                                                //Wait for Save button is visible in the gallery page
                                                                waitForElementVisible ( "//section/button[text( )='Save']", 4000, false ).
                                                                pause ( 4000 ).
                                                                //Click on the Save button in the gallery page
                                                                click ( "//section/button[text( )='Save']" ).
                                                                pause ( 6000 ).
                                                                //Check the reorder list element in the Article page
                                                                elements ( "xpath", "//section/div/ul[@class='reorder-list']/li[@draggable='true']", function ( collectionCount ) {
                                                                  if ( collectionCount.value.length == increamentList ) {
                                                                  }
                                                                  else {
                                                                    //Write in the spreadsheet: Fail Result and Reason
                                                                    contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Else in collectionCount function Failed" );
                                                                  }
                                                                } );
                                                                contentArticles.useCss( ).keys ( contentArticles.Keys.HOME ).pause ( 4000 ).
                                                                //Check the properties tab details and add data in the page
                                                                allproperties ( articleShortTitle[ getData ], articleShortDesc[ getData ], articleCategoryName[ getData ], articleNote[ getData ], thumbnail[ getData ] )
                                                                contentArticles.pause ( 4000 ).timeoutsImplicitWait ( 4000 ).useXpath( ).
                                                                //Verify the Articles Menu in the CONTENT
                                                                verify.containsText ( "//ul/li/a[ text ( ) = 'Articles']", "Articles" ).
                                                                pause ( 4000 ).
                                                                //Click on the Articles Menu in the CONTENT
                                                                click ( "//ul/li/a[ text ( ) = 'Articles']" ).
                                                                useCss( ).pause ( 4000 ).
                                                                //Wait for Total count label is visible in the listing page
                                                                waitForElementVisible ( ".content-count > strong", 4000, false ).
                                                                pause ( 4000 ).
                                                                //Get Text count in the listing page
                                                                getText ( '.content-count > strong', function ( actualCountResult ) {
                                                                  if ( actualCountResult.status !== -1 ) {
                                                                    var actualCount = actualCountResult.value;
                                                                    actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                                                    var expectedCount = ( ( +currentCount ) + 1 );
                                                                    if ( actualCount == expectedCount ) {
                                                                      //Write in the spreadsheet: Pass Result and Reason
                                                                      contentArticles.writeToExcelPass ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16 );
                                                                    }
                                                                    else {
                                                                      //Write in the spreadsheet: Fail Result and Reason
                                                                      contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "ActualResult: '"+ actualCount +"' in the Total Count After Added New Articles. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                                                                    }
                                                                  }
                                                                } );
                                                              }
                                                              else {
                                                                contentArticles.pause ( 4000 ).useXpath( ).
                                                                //Get text the value for gallery title in the gallery page
                                                                getText ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1', function ( getTitle ) {
                                                                  if ( getTitle.value == "Add Media Content\n␡" ) {
                                                                    contentArticles.pause ( 4000 ).useXpath( ).
                                                                    //Wait for gallery title is visible in the gallery page
                                                                    waitForElementVisible ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1/i', 4000, false ).
                                                                    pause ( 4000 ).
                                                                    //Click on the close button in the Gallery dialog page
                                                                    click ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1/i' )
                                                                    contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Galleries search functionality is not working properply" );
                                                                  }
                                                                } );
                                                              }
                                                            }                                                            
                                                          } );
                                                        }
                                                        else {
                                                          //Write in the spreadsheet: Fail Result and Reason
                                                          contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Searched Data is not displayed" );
                                                          resultStatus.push ( "FAIL" )
                                                          if ( contentCount < splitGallery.length - 1 ) {
                                                          }
                                                          else {
                                                            contentArticles.pause ( 4000 ).useXpath( ).
                                                            //Get text the value for gallery title in the gallery page
                                                            getText ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1', function ( getTitle ) {
                                                              if ( getTitle.value == "Add Media Content\n␡" ) {
                                                                contentArticles.pause ( 4000 ).useXpath( ).waitForElementVisible ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1/i', 4000, false ).
                                                                pause ( 4000 ).
                                                                //Click on the Close button in the gallery dialog page
                                                                click ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1/i' )
                                                              }
                                                            } );
                                                          }
                                                        }
                                                      } );
                                                    }
                                                    else {
                                                      console.log ( "Second For loop has been failed" )
                                                      contentArticles.pause ( 4000 ).useXpath( ).
                                                      //Get text the value for gallery title in the gallery page
                                                      getText ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1', function ( getTitle ) {
                                                        if ( getTitle.value == "Add Media Content\n␡" ) {
                                                          contentArticles.pause ( 4000 ).useXpath( ).
                                                          //Wait for close button is visible in the gallery dialog page
                                                          waitForElementVisible ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1/i', 4000, false ).
                                                          pause ( 4000 ).
                                                          //Click on the close button in the gallery dialog page
                                                          click ( '//dialog-include[@template-path="assets/templates/edit_partials/_gallery_dialog.html"]//h1/i' )
                                                        }
                                                      } );
                                                    }
                                                  } ); 
                                                } 
                                              } 
                                              else {
                                                //Write in the spreadsheet: Fail Result and Reason
                                                contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Artifact is not displayed in the chechbox field" );
                                              }
                                            } ); 
                                          }
                                          else {
                                            //Write in the spreadsheet: Fail Result and Reason
                                            contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "There is no Artifact in the Checkbox" );
                                          }                                      
                                        } );
                                      }
                                      else {
                                        console.log ( "First For loop Condition has been failed" );
                                      }
                                    } 
                                  }
                                } );
                              }
                              else {
                                //Wait for error field is visible in the Article page
                                contentArticles.waitForElementVisible ( '.field-error', 14000, false ).
                                pause ( 4000 ).useCss( ).
                                //Get the text value for Error message for Embed
                                getText ( ".field-error", function ( urlErrorMsgemb ) {
                                  if ( urlErrorMsgemb.value == "⚠Please enter a valid embed code or URL" ) {
                                    //Write in the spreadsheet: Pass Result
                                    contentArticles.writeToExcelPass ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16 );
                                  }
                                  else {
                                    //Write in the spreadsheet: Fail Result and Reason
                                    contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Invalid alert as" + urlErrorMsgemb.value );
                                  }
                                } );
                              }
                            }
                          } );                    
                        } 
                        else {
                          //Wait for error field is visible in the Article page
                          contentArticles.waitForElementVisible ( '.field-error', 14000, false ).
                          pause ( 4000 ).useCss( ).
                          //Get the text value for Error message for URL
                          getText ( ".field-error", function ( urlErrorMsgurl ) {
                            if ( urlErrorMsgurl.value == "⚠Please enter a valid video URL" ) {
                              //Write in the spreadsheet: Pass Result
                              contentArticles.writeToExcelPass ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16 );
                            }
                            else {
                              //Write in the spreadsheet: Fail Result and Reason
                              contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Invalid alert as" + urlErrorMsgurl.value );
                            }
                          } );                    
                        }                  
                      } 
                      else {
                        //Wait for error field is visible in the Article page
                        contentArticles.waitForElementVisible ( '.field-error', 14000, false ).
                        pause ( 4000 ).useCss( ).
                        //Get the text value for Error message for Image
                        getText ( ".field-error", function ( urlErrorMsgimg ) {
                          if ( urlErrorMsgimg.value == "⚠Invalid file type" ) {
                            //Write in the spreadsheet: Pass Result
                            contentArticles.writeToExcelPass ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16 );
                          }
                          else {
                            //Write in the spreadsheet: Fail Result and Reason
                            contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Invalid alert as" + urlErrorMsgimg.value );
                          }
                        } );
                      }                
                    }                           
                  } );             
                }               
              } );                 
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            contentArticles.writeToExcelFail ( 'boxxspring.xlsx', 'ContentArticlesAdd', rowCount, 16, 17, "Invalid alert as" + urlErrorMsgimg.value );
          }
        } );
      }
    }
    //End the browser
    contentArticles.end( );
  } 
}
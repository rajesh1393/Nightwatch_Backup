//this function is for check and add the Attribution
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'AttributionsAdd' ];
var attributionTitle = [ ];
var attributionUrl = [ ];
var attributionDescription = [ ];
var attributionShortTitle = [ ];
var attributionShortDesc = [ ];
var attributionCategoryName = [ ];
var attributionNote = [ ];
var attributionImg = [ ];
var currentCount, actualCount, expectedCount, excelData;
module.exports = {
  tags: [ 'attributionsAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AttributionsAdd': function ( addAttributions ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read authors Title
      if ( excelData.includes ( 'A' ) ) {
        attributionTitle.push ( worksheet[ excelData ].v );
      }
      //Read authors Description
      if ( excelData.includes ( 'B' ) ) {
        attributionUrl.push ( worksheet[ excelData ].v );
      }
      if ( excelData.includes ( 'C' ) ) {
        attributionDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'D' ) ) {
        attributionShortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'E' ) ) {
        attributionShortDesc.push ( worksheet[ excelData ].v );
      }
      //Read authors category Name
      if ( excelData.includes ( 'F' ) ) {
        attributionCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read authors Note
      if ( excelData.includes ( 'G' ) ) {
        attributionNote.push ( worksheet[ excelData ].v );
      }
      //Read Thumbnail Image
      if ( excelData.includes ( 'H' ) ) {
        attributionImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( attributionTitle.length > 1 ) {
      var checkResult = addAttributions.globals.excelCol.resultCustomData; 
      for ( let getData = 1, rowCount = 1; getData < attributionTitle.length; getData++ ) {
        rowCount++;
        addAttributions.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text ( ) = 'Attributions' ]", 9000, false, function ( checkAttributeMenu ) {
          if ( checkAttributeMenu.value == true ) {
            addAttributions.pause ( 4000 ).useXpath ( ).
            //Verify the Attributions in CONTENT menu is visible
            verify.containsText ( "//ul/li/a[ text( ) = 'Attributions' ]", "Attributions" ).
            pause ( 4000 ).
            //Click on the Attribution in the CONTENT menu
            click ( "//ul/li/a[ text( ) = 'Attributions' ]" ).
            useCss ( ).
            pause ( 4000 ).
            //Get the Total Count before  create Attribution in the list 
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              //Wait for the Add videos button is visible in the Videos listing page
              addAttributions.pause ( 4000 ).
              waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false,function ( checkAddbtn ) {
                console.log("checkAddbtn",checkAddbtn)
                if ( checkAddbtn.value.length == 0 ) {
                  addAttributions.waitForElementVisible ( ".btn-add", 4000, false ).
                  pause ( 4000 ).
                  //Click on the Add button in Attribution
                  click ( ".btn-add" ).
                  pause ( 4000 ).
                  //Verify the Content tab in the Attribution page is visible
                  verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                  //Click on the Content tab in the Attribution Page
                  click ( ".video-tabs > a[ href='#content' ]" ).
                  pause ( 4000 ).
                  //Check and Enter attribution Title
                  waitForElementVisible ( ".text-input-headline", 4000, false ).
                  //Enter the Headline in the Field
                  setValue ( ".text-input-headline", attributionTitle[ getData ] ).
                  pause ( 4000 ).
                  //Check and Enter attribution Text Description
                  waitForElementVisible ( ".wmd-input", 4000, false ).
                  //Clear the data in the field
                  clearValue ( ".wmd-input" ).
                  //Enter the Attribution description in the Field
                  setValue ( ".wmd-input", attributionDescription[ getData ] ).
                  pause ( 4000 ).
                  //Check the attribution URL field is visible
                  waitForElementVisible ( "#attribution_provider_url", 4000, false ).
                  //Enter the Attribution Provider url
                  setValue ( "#attribution_provider_url", attributionUrl[ getData ] ).
                  pause ( 4000 ).                  
                  //Set details in Attribution Properties Tab
                  all_properties ( attributionShortTitle[ getData ], attributionShortDesc[ getData ], attributionCategoryName[ getData ], attributionNote[ getData ], attributionImg[ getData ] ).
                  pause ( 4000 ).useCss ( ).
                  waitForElementVisible ( ".video-tabs > a[ href='#properties']",9000,false,function ( checkProperties ) {
                    if ( checkProperties.value == true ) {
                      if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                        addAttributions.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsAdd', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                        checkResult.length = 0;
                      }
                      else if ( checkResult.length == 0 ) {
                      }
                      else {
                        checkResult.length = 0;
                        //Check and click save button
                        addAttributions.verify.visible ( "a.btn-active" ).
                        //click on the save button
                        click ( "a.btn-active" ).
                        pause ( 4000 ).
                        //Wait and check the Save button is active in the Attribution page
                        waitForElementNotPresent ( "a.btn-active",9000,false,function ( checkSaveInactive ) {
                          if ( checkSaveInactive.value.length == 0 ) {
                            addAttributions.pause ( 4000 ).useXpath ( ).
                            //Verify the videos menu in the sidebar
                            verify.containsText ( "//ul/li/a[ text( ) = 'Attributions']", "Attributions" ).
                            pause ( 4000 ).
                            //click on the videos menu in CONTENT
                            click ( "//ul/li/a[ text( ) = 'Attributions']" )
                            //Check the Actual Count after each video added
                            addAttributions.useCss().pause( 9000 ).
                            //Wait for label count in the listing page
                            waitForElementVisible ('.content-count > strong',9000,false ).
                            pause ( 4000 ).
                            getText ( '.content-count > strong', function ( actualCountResult ) {
                              if ( actualCountResult.status !== -1 ) {
                                actualCount = actualCountResult.value;
                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                expectedCount = ( ( +currentCount ) + ( 1 ) );
                                if ( actualCount == expectedCount ) {
                                  //Write in the spreadsheet: Pass Result and Reason
                                  addAttributions.writeToExcelPass ( 'boxxspring.xlsx', 'AttributionsAdd', rowCount, 10 );
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  addAttributions.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsAdd', rowCount, 10, 11, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Attributions. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                }
                              }
                            } );
                          }
                          else {
                            //Write in the spreadsheet: Fail Result and Reason
                            addAttributions.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsAdd', rowCount, 10, 11, "Save functionality is not working as expected" );
                          }
                        } );
                      }
                      if ( checkResult.indexOf ( 'FAIL' ) || checkResult.indexOf ( 'PASS' ) >= 0 ) {
                        checkResult.length = 0;
                      }
                    }                   
                  } );
                }
                else {
                  //Write in the Excel for Fail Result and Reason
                  addAttributions.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsAdd', rowCount, 10, 11, "Add button is not functioning in the Attributions page" );          
                }
              } );
            } );                  
          }
          else {
            //Write in the Excel for Fail Result and Reason
            addAttributions.writeToExcelFail ( 'boxxspring.xlsx', 'AttributionsAdd', rowCount, 10, 11, "Attributions menu is not displayed in Sidebar" );          
          }
        } );
      }
    }
    //End the Browser
    addAttributions.end ( );
  }
};
//this function is for check and Edit the Collections Menu
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'CollectionmenuEdit' ];
var searchCollection = [ ];
var collectionTitle = [ ];
var collectiondesc = [ ];
var collectionPublic = [ ];
var currentCount, actualCount, excelData, collectPub;
var getData,rowCount = 1;
module.exports = {
  tags: [ 'collectionmenuEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'CollectionmenuEdit': function ( collectionsEditMenu ) {
    //Read values from excel
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Search Collection Title
      if ( excelData.includes ( 'A' ) ) {
        searchCollection.push ( worksheet[ excelData ].v );
      }
      //Read Collection Title
      if ( excelData.includes ( 'B' ) ) {
        collectionTitle.push ( worksheet[ excelData ].v );
      }
      //Read Collection Description
      if ( excelData.includes ( 'C' ) ) {
        collectiondesc.push ( worksheet[ excelData ].v );
      }
      //Read Collection Public
      if ( excelData.includes ( 'D' ) ) {
        collectionPublic.push ( worksheet[ excelData ].v );
      }
    }
    if ( collectionTitle.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < collectionTitle.length; getData++ ) {
        rowCount++;
        collectionsEditMenu.pause ( 4000 ).useXpath ( ).
        //Wait for ALL button in COLLECTION menu is visble
        waitForElementVisible ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false, function ( checkALLMenu ) {
          if ( checkALLMenu.value == true ) {
            collectionsEditMenu.pause ( 4000 ).useXpath ( ).
            //Click on the ALL button in COLLECTION menu
            click ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]" ).
            pause ( 4000 ).useCss ( ).
            //Get the Current Total count in the collection listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }
              collectionsEditMenu.pause ( 4000 ).useXpath ( ).
              //Wait for the Search collection is visible
              waitForElementVisible ( "//h2[contains ( .,'"+ searchCollection[ getData ] +"' )]", 4000, false, function ( checkSearchedLst ) {
                if ( checkSearchedLst.value == true ) {
                  collectionsEditMenu.pause ( 4000 ).useXpath ( ).
                  //Click on the Search collection
                  click ( "//h2[contains ( .,'"+ searchCollection[ getData ] +"' )]" ).
                  useCss ( ).pause ( 4000 ).
                  //Wait for the Headline field is visible
                  waitForElementVisible ( ".text-input-headline", 4000, false ).
                  pause ( 4000 ).
                  //Verify the Headline field is visible
                  verify.visible ( ".text-input-headline" ).
                  pause ( 4000 ).
                  //Clear the Headline data in the field
                  clearValue ( ".text-input-headline" ).
                  pause ( 4000 ).
                  //Enter the Headline data in the field
                  setValue ( ".text-input-headline", collectionTitle[ getData ] ).
                  pause ( 4000 ).
                  //Check the valid URL from given URL
                  waitForElementVisible ( ".btn-slider", 4000, false ).
                  pause ( 4000 )
                  if ( collectionPublic[ getData] != undefined ) { 
                    collectionsEditMenu.pause ( 4000 ).useXpath ( ).
                    //Get the Public values(YES/NO) in the collections page
                    getText ( "//*[contains ( @class,'field-input' )]/span", function ( collectionPub ) {
                      collectPub = collectionPub.value;           
                      //Check the condition for Public as YES or NO in the expected condition
                      if ( collectPub != collectionPublic[ getData ] && ( ( collectionPublic[ getData ] == "YES" ) || ( collectionPublic[ getData ] == "NO" ) ) ) {
                        collectionsEditMenu.useCss ( ).pause ( 4000 ).
                        //Wait for the Public button is visible in the page
                        waitForElementVisible ( ".btn-false", 4000, false ).
                        pause ( 4000 ).
                        //Click on the public to select NO option
                        click ( ".btn-false" ).
                        pause ( 4000 )
                      }                      
                    } );
                  }                  
                  collectionsEditMenu.useCss( ).pause ( 4000 ).
                  //Wait for the Title field is visible
                  waitForElementVisible ( "text-field >textarea[ng-model='collection.description']", 4000, false ).
                  pause ( 4000 ).
                  //Verify the Title field is visible
                  verify.visible ( "text-field >textarea[ng-model='collection.description']" ).
                  pause ( 4000 ).
                  //Clear the title data in the field
                  clearValue ( "text-field >textarea[ng-model='collection.description']" ).
                  pause ( 4000 ).
                  //Enter the title data in the field
                  setValue ( "text-field >textarea[ng-model='collection.description']", collectiondesc[ getData ] ).
                  pause ( 4000 ).
                  //Wait for the save button is visible
                  waitForElementVisible ( ".btn-active", 4000, false ).
                  pause ( 4000 ).
                  //Click on the Save button
                  click ( ".btn-active" ).
                  pause ( 4000 ).
                  //Wait for the Save active status should not present in the collections page
                  waitForElementNotPresent ( ".btn-active", 4000, false, function ( checkSaveBtn ) {
                    if ( checkSaveBtn.value.length == 0 ) {
                      collectionsEditMenu.pause ( 4000 ).useXpath ( ).
                      //Wait for the ALL button is visible
                      waitForElementVisible ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]", 4000, false ).
                      pause ( 4000 ).
                      //Click on the ALL in the Collections Menu
                      click ( "//div[4]/ul/li/a[text()[normalize-space(.)='All']]" ).
                      pause ( 4000 ).useCss ( ).
                      //Get the Actual Total count in the collection listing page
                      getText ( '.content-count > strong', function ( actualCountResult ) {
                        if ( actualCountResult.status != -1 ) {
                          actualCount = actualCountResult.value;
                          actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                          if ( actualCount == currentCount ) {
                            //Write the Excel:PASS Result and Reason
                            collectionsEditMenu.writeToExcelPass ( 'boxxspring.xlsx', 'CollectionmenuEdit', rowCount, 6 );
                          }
                          else {
                            this.verify.fail ( actualCount, currentCount, "ActualResult: '"+ actualCount +"' in the Total Count After Added New story. ExpectedResult: should be 1 in the Total Count" );
                            //Write the Excel:FAIL Result and Reason
                            collectionsEditMenu.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuEdit', rowCount, 6, 7, "ActualResult: '"+ actualCount +"' in the Total Count After Collections Menu Edit. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                          }
                        }
                      } );  
                    }
                    else {
                      //Write the Excel:FAIL Result and Reason
                      collectionsEditMenu.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuEdit', rowCount, 6, 7, "Save Button is still ACTIVE in the page" );
                    } 
                  } );
                }
                else {
                  //Write the Excel:FAIL Result and Reason
                  collectionsEditMenu.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuEdit', rowCount, 6, 7, "Searched Data is not listed in the Collections listing page" );
                } 
              } );                     
            } );
          }
          else {
            //Write the Excel:FAIL Result and Reason
            collectionsEditMenu.writeToExcelFail ( 'boxxspring.xlsx', 'CollectionmenuEdit', rowCount, 6, 7, "ALL menu is not displayed under the COLLECTIONS in the Sidebar" );    
          }
        } );
      }
    }
    //End the Browser
    collectionsEditMenu.end ( );
  }
}
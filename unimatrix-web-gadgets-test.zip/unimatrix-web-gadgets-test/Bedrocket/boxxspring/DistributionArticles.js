//This function is using for Articles Distribution in the portal
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'DistributionArticles' ];
var articlesTitle = [ ];
var articlesHeadline = [ ];
var distribSearch = [ ];
var resultStatus = [ ];
var currentCount;
var actualCount;
var expectedCount;
var getData, convertData,rowCount = 1;
module.exports = {
  tags: [ 'distributionArticles' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'Distribution Articles': function ( ArticlesDistribution ) {
    for ( z in worksheet ) {
      if ( z[ 1 ] === '!' ) continue;
      //Read Articles Title
      if ( z.includes ( 'A' ) ) {
        articlesTitle.push ( worksheet[ z ].v );
      }
      //Read Articles Description
      if ( z.includes ( 'B' ) ) {
        articlesHeadline.push ( worksheet[ z ].v );
      }
      //Read Destination Search Type
      if ( z.includes ( 'C' ) ) {
        distribSearch.push ( worksheet[ z ].v );
      }
    }
    if ( articlesTitle.length > 1 ) {
      ArticlesDistribution.pause ( 4000 ).useXpath ( ).
      //Verify the Articles menu in the CONTENT is visible
      verify.containsText ( "//ul/li/a[ text ( ) = 'Articles']", "Articles" ).
      pause ( 4000 ).
      //Click on the Articles menu in the CONTENT
      click ( "//ul/li/a[ text ( ) = 'Articles']" ).
      useCss ( ).pause ( 4000 ).
      //Get the Current Total count in the Articles listing page
      getText ( '.content-count > strong', function ( currentCountResult ) {
        if ( currentCountResult.status !== -1 ) {
          currentCount = currentCountResult.value;
          currentCount = currentCount.substring ( 1, currentCount.length - 1 );
        }
        for ( var getData = 1, rowCount = 1; getData < articlesTitle.length; getData++ ) {
          //Wait for the List view option is visible
          var resultStatus = [ ];
          ArticlesDistribution.pause ( 4000 ).waitForElementVisible ( ".list", 4000, false ).
          pause ( 4000 ).
          //Click on the List view option in the Articles listing page
          click ( ".list" ).
          //Wait for the Search Input Field is visible
          pause ( 4000 ).waitForElementVisible ( ".search-field-input", 4000, false ).
          //Verfiy the Search Input Field is visible
          verify.visible ( ".search-field-input" ).
          //Clear the data in Search Input field 
          clearValue ( ".search-field-input" ).
          //Enter the data in Search Input field 
          setValue ( ".search-field-input", articlesTitle[ getData ] ).
          //Press Enter key
          keys ( ArticlesDistribution.Keys.ENTER ).
          click ( ".search-field-input" ).
          //Release Enter Key
          keys ( ArticlesDistribution.Keys.NULL ).
          pause ( 4000 ).
          //Wait for the Search Count label is visible
          waitForElementVisible ( ".content-count>strong", 5000, false ).
          //Verfiy the Search Count label is visible
          verify.visible ( ".content-count>strong" ).
          //Get the Searched data count in the Articles listing page
          getText ( '.content-count > strong', function ( searchCountResult ) {
            if ( searchCountResult.status !== -1 ) {
              searchCount = searchCountResult.value;
              searchCount = searchCount.substring ( 1, searchCount.length - 1 );
            }
            if ( getData >= articlesTitle.length ) {
              var convertData = getData - ( articlesTitle.length - 1 );
              getData++;
            }
            ArticlesDistribution.pause ( 4000 ).useXpath ( ).
            //Wait for the Searched data is visible in the Articles listing page
            waitForElementVisible ( "(//h2[@class='ng-binding'])[1]", 4000, false ).
            pause ( 4000 ).
            //Verify the Searched data is visible in the Articles listing page
            verify.visible ( " (//h2[@class='ng-binding'])[1]" ).
            pause ( 4000 ).
            //Click on the Searched data in the Articles listing page
            click ( "(//h2[@class='ng-binding'])[1]" ).
            useCss ( ).pause ( 4000 )
            ArticlesDistribution.pause ( 4000 ).
            //Verify the Content Tab is visible in the Articles page
            verify.visible ( ".video-tabs > a[ href='#content']" ).
            //Click on the Content Tab in the Articles page
            click ( ".video-tabs > a[ href='#content']" ).
            pause ( 4000 ).
            //Wait for the Headline field is visible in the Articles page
            waitForElementVisible ( ".text-input-headline", 4000, false ).
            //Clear the data in the Headline field in the Articles page
            clearValue ( ".text-input-headline" ).
            //Enter the data in the Headline field in the Articles page
            setValue ( ".text-input-headline", articlesHeadline[ convertData ] ).
            pause ( 4000 ).
            //Verify the Save button is visible
            verify.visible ( ".btn-active" ).
            pause ( 4000 ).
            //Click on the Save button
            click ( ".btn-active" ).
            pause ( 4000 ).
            //Verify the Properties Tab is visible in the Articles page
            verify.visible ( ".video-tabs a[ href='#distribution']" ).
            pause ( 10000 ).
            //Click on the Properties Tab in the Articles Page
            click ( ".video-tabs a[ href='#distribution']" ).
            pause ( 4000 ).
            //Wait for the Add Distribution button is visible in Distribution Tab page
            waitForElementVisible ( ".distro-button", 4000, false ).
            pause ( 4000 ).
            //Click on the Add Distribution button in Distribution Tab page
            click ( ".distro-button" ).
            pause ( 4000 ).
            //Wait for the Toggle filter dropdown is visible
            waitForElementVisible ( "a.ng-binding[ng-click='toggleFilterDropdown();']", 4000, false ).
            pause ( 4000 ).
            //Verify the Toggle filter dropdown is visible
            verify.visible ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
            pause ( 4000 ).
            //Click on the Toggle filter dropdown option
            click ( "a.ng-binding[ng-click='toggleFilterDropdown();']" ).
            pause ( 4000 ).useXpath ( ).
            //Wait for the options in the list should be visible
            waitForElementVisible ( "//ul/li/a[contains(.,'boxxspring')]", 4000, false ).
            pause ( 4000 ).
            //Verify the options in the listing is visible
            verify.visible ( "//ul/li/a[contains(.,'boxxspring')]" ).
            pause ( 4000 ).
            //Click on the options in the dropdown list
            click ( "//ul/li/a[contains(.,'boxxspring')]" )
            var categoryTemp = distribSearch[ convertData ];
            var categoryTemp_array = categoryTemp.split ( ',' );
            for ( var categoryCount = 0; categoryCount < categoryTemp_array.length; categoryCount++ ) {
              //Split the Category data and store in the Temp variable
              categoryTemp_array[ categoryCount ] = categoryTemp_array[ categoryCount ].replace ( /^\s*/, "" ).replace ( /\s*$/, "" );
              ArticlesDistribution.useCss ( ).pause ( 4000 ).
              //Wait for the Saerch -Input Field is visible
              waitForElementVisible ( ".full-width-search-field-input", 4000, false ).
              pause ( 4000 ).
              //Verify the Saerch -Input Field is visible
              verify.visible ( ".full-width-search-field-input" ).
              pause ( 4000 ).
              //Clear the data in the Saerch -Input Field
              clearValue ( ".full-width-search-field-input" ).
              pause ( 4000 ).
              //Enter the data in the Saerch -Input Field
              setValue ( ".full-width-search-field-input", categoryTemp_array[ categoryCount ] ).
              pause ( 4000 ).useXpath ( ).
              //Wait for the searched data in listing down is visible
              waitForElementVisible ( "//label[@class='label-left ng-binding'][contains(.,'"+ categoryTemp_array[ categoryCount ] +"')]", 4000, false ).
              pause ( 4000 ).
              //Click on the Searched data in the distribution page
              click ( "//label[@class='label-left ng-binding'][ contains(.,'"+ categoryTemp_array[ categoryCount ] +"')]" ).
              useCss ( ).pause ( 4000 )
            }
            ArticlesDistribution.pause ( 4000 ).
            //Wait for the Next button is visible
            waitForElementVisible ( ".btn-next", 4000, false ).
            //Click on the Next Button in the Distribution button
            click ( ".btn-next" ).
            //Get the Text for Selected Destination count in the Distribution page
            getText ( "h3.distributions-title.ng-binding", function ( test ) {
              var rest = test.value;
              var rest1 = "Selected Destinations "+ categoryTemp_array.length;
              //Compare the Actual and Expected data in the Distribution page
              if ( rest === rest1 ) {
                ArticlesDistribution.pause ( 4000 ).useCss ( ).
                //Verify the Cancel button in the Distribution page
                verify.visible ( ".cancel-distribution" ).
                pause ( 4000 ).
                //Verify the All Post button is visible in the Distribution page
                verify.visible ( "a.btn-next:nth-child( 2 )" ).
                pause ( 4000 ).
                //Click on the All Post button in the Distribution page
                click ( "a.btn-next:nth-child( 2 )" ).
                pause ( 4000 )
                for ( var getData = 3; getData < categoryTemp_array.length + 3; getData++ ) {
                  //Get the Value for Destination posted in the Distribution page
                  ArticlesDistribution.pause ( 4000 ).getValue ( "ul.post-list li>.ng-scope", function ( allPost ) {
                    if ( allPost.status === 0 ) {
                      if ( getData >= categoryTemp_array.length + 3 ) {
                        convertData = getData - ( categoryTemp_array.length );
                        getData++;
                        ArticlesDistribution.pause ( 4000 ).useCss ( ).
                        //Wait for the Distributed post is visible in the distribution page
                        waitForElementVisible ( "li.completed:nth-child("+ convertData +")>span>ng-include>div.description>a", 4000, false, function ( result1 ) {
                          if ( result1.value === true ) {
                            ArticlesDistribution.pause ( 4000 ).
                            //Get the Distributed post url in the distribution page
                            getText ( "li.completed:nth-child("+ convertData +")>span>ng-include>div.description>a", function ( urlResult ) {
                              if ( urlResult.status == 0 ) {
                                //Write in the Excel as PASS Results
                                ArticlesDistribution.pause ( 4000 );
                                resultStatus.push ( "PASS" );
                              }
                              else {
                                ArticlesDistribution.pause ( 4000 );
                                resultStatus.push ( "FAIL" );                               
                              }
                            } );
                          }
                          else {
                            console.log ( "Else Result", result1.value )
                            //Write in the Excel as FAIL Results and Reason
                            ArticlesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionArticles', ++rowCount, 5, 6, "Completed Post is not displayed" );
                          }
                          console.log ( "hi-->>li.completed:nth-child("+ convertData +")" )
                        } );
                      }
                    }
                    else {
                      console.log ( "Else allPost", allPost.value )
                      //Write in the Excel as FAIL Results and Reason
                      ArticlesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionArticles', ++rowCount, 5, 6, "Post List is not visible" );
                    }
                  } );
                }
                //Get the Value for all posted in the Distribution page
                ArticlesDistribution.pause ( 4000 ).getValue ( "ul.post-list li>.ng-scope", function ( allPostResult ) {
                  if ( resultStatus.indexOf ( 'FAIL' ) >= 0 ) {
                     //Write in the Excel as FAIL Results and Reason
                    ArticlesDistribution.writeToExcelFail ( 'boxxspring.xlsx', 'DistributionArticles', ++rowCount, 5, 6, "Completed Post URL is not displayed" );
                  }
                  else if ( resultStatus.length == 0 ) {
                  }
                  else {
                     //Write in the Excel as PASS Results
                    ArticlesDistribution.writeToExcelPass ( 'boxxspring.xlsx', 'DistributionArticles', ++rowCount, 5 );
                  }
                  if ( resultStatus.indexOf ( 'FAIL' ) || resultStatus.indexOf ( 'PASS' ) >= 0 ) {
                    resultStatus.length = 0;
                  }
                } );
              }
            } );
            ArticlesDistribution.pause ( 4000 ).useXpath ( ).
            //Verify the Articles menu in the CONTENT is visible
            verify.containsText ( "//ul/li/a[ text ( ) = 'Articles']", "Articles" ).
            pause ( 4000 ).
            //Click on the Articles menu in the CONTENT
            click ( "//ul/li/a[ text ( ) = 'Articles']" ).
            useCss ( )
          } );
        }
      } );
    }
    //End the Browser
    ArticlesDistribution.end( );
  }
};
//this function is for check and Delete the Feeds Conditions on Facebook Destintaion in DISTRIBUTION
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', { cellStyles: true } );
var worksheet = workbook.Sheets[ 'FeedsDelete' ];
var feedTitle = [ ];
var provider = [ ];
var videoFiles = [ ];
var videoPlayer = [ ];
var content = [ ];
var permaLink = [ ];
var categoryType = [ ];
var categories = [ ];
var currentCount, excelData;
var getData, rowCount = 1;
module.exports = {
  tags: [ 'feedsDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'FeedsDelete': function ( feedDelete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read Provider Title
      if ( excelData.includes ( 'A' ) ) {
        provider.push ( worksheet[ excelData ].v );
      }
      //Read Feed Title 
      if ( excelData.includes ( 'B' ) ) {
        feedTitle.push ( worksheet[ excelData ].v );
      }
    }
    if ( provider.length > 0 ) {
      for ( let getData = 1, rowCount = 1; getData < provider.length; getData++ ) {
        rowCount++;
        feedDelete.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//i[@ng-if='!collapse.distribution']", 4000, false, function ( checkArrow ) {
          if ( checkArrow.value == true ) {
            feedDelete.pause ( 4000 ).useCss ( ).
            verify.visible ( "div.content-header:nth-child( 7 )" ).
            pause ( 4000 ).
            //Click on the Distribution menu in the side bar
            click ( "div.content-header:nth-child( 7 )" ).
            pause ( 4000 )        
          }         
        } );
        feedDelete.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//a[text ( ) = 'Feeds']",4000,false,function ( checkFeedMenu ) {
          if ( checkFeedMenu.value == true ) {        
            feedDelete.useXpath ( ).pause ( 4000 ).
            //Verify the Feeds menu is visible in the DISTRIBUTION 
            verify.containsText ( "//a[text ( ) = 'Feeds']", "Feeds" ).
            pause ( 4000 ).
            //Click on the Feeds menu in the DISTRIBUTION 
            click ( "//a[ text ( ) = 'Feeds']" ).
            useCss ( ).pause ( 4000 ).
            //Get the total count in th efeeds listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
              }
              feedDelete.pause ( 4000 ).useXpath ( ).
              //Wait for the search field is visible in the feeds listing page
              waitForElementVisible ( "//div/div/div[1]/div/div/div/input", 4000, false ).
              pause ( 4000 ).
              //Verify the search field is visible in the feeds listing page
              verify.visible ( "//div/div/div[1]/div/div/div/input" ).
              pause ( 4000 ).
              //Clear the data in the search field in the feeds listing page
              clearValue ( "//div/div/div[1]/div/div/div/input" ).
              pause ( 4000 ). 
              //Enter the data in the search field in the feeds listing page
              setValue ( "//div/div/div[1]/div/div/div/input", feedTitle[ getData ] ).
              pause ( 4000 )
              //Hold the control
              feedDelete.keys ( feedDelete.Keys.ENTER ). 
              //Clcikc on the Search option in the feeds listing page
              click ( "//div/div/div[1]/div/div/div/input" ).
              //Release the control
              keys ( feedDelete.Keys.NULL ). 
              pause ( 4000 ).useCss ( ).
              //Wait for the total searched count is visible in the feeds listing page 
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              //Verify for the total searched count is visible in the feeds listing page 
              verify.visible ( ".content-count>strong" )
              //Check the Searched Video Count
              feedDelete.getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  var searchCount = searchCountResult.value;
                }
                //Check IF Searched Video Count is greater than zero,it will continue in the statement or it will be move else part
                if ( searchCount > 0 ) {
                  feedDelete.pause ( 4000 ).useXpath ( ).
                  //Wait for the Searched data is visible in the Videos listing page
                  waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ feedTitle[ getData ] +"']]", 4000, false, function ( checkSearchedLst ) {
                    if ( checkSearchedLst.value == true ) {
                      feedDelete.pause ( 4000 ).useXpath ( ).
                      //Click on searched feed in the feeds listing page
                      click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ feedTitle[ getData ] +"']]" ).
                      pause ( 4000 ).useXpath ( ).
                      //Get the label text in the feed page
                      getText ( "//div[@class='typeName-label']", function ( labelValue ) {
                        if ( labelValue.value == "FEED" ) {
                        
                          feedDelete.pause ( 4000 ).useXpath ( ).
                          //Wait for the Feed title field is visible in the feeds page
                          waitForElementVisible ( "//div/text-field[@class='ng-scope field-input ng-valid ng-not-empty']/input", 4000, false ).
                          pause ( 4000 ).
                          //Clear the data in the feed title field in the feeds page
                          clearValue ( "//div/text-field[@class='ng-scope field-input ng-valid ng-not-empty']/input" ).
                          pause ( 4000 ).
                          //Enter the data in the feed title field in the feeds page
                          setValue ( "//div/text-field[@class='ng-scope field-input ng-valid ng-empty']/input", feedTitle[ getData ] ).
                          pause ( 4000 ).
                          //Wait for the provider field is visible in the feeds page
                          waitForElementVisible ( "//div[@class='input-like']", 4000, false ).
                          pause ( 4000 ).useXpath ( ).
                          //Wait for the provider field is visible and get function value in th efeed page
                          waitForElementVisible ( "//div[@class='input-like'][contains ( .,'"+ provider[ getData ] +"' )]", 4000, false, function ( providerCheck ) {
                            if ( providerCheck.value == true ) {
                              feedDelete.useXpath ( ).pause ( 4000 ).
                              //Verify contains Text in the provider field is visible in the feeds page
                              verify.containsText ( "//div[@class='input-like'][contains ( .,'"+ provider[ getData ] +"' )]", provider[ getData ] ).
                              pause ( 4000 ).
                              //Get the Element value for condition data listed
                              elements ( "xpath", "//div[@class='field-input filter-conditions ng-scope']", function ( conditionListResult ) {
                                var conditionCount = conditionListResult.value.length;
                                for ( let categoryLen = 0; categoryLen <= conditionCount; categoryLen++ ) {
                                  feedDelete.useXpath ( ).pause ( 4000 ).
                                  waitForElementPresent ( "//div/div[2]/div[5]/span/i", 4000, false, function ( conditionCheck ) {
                                    if ( conditionCheck.value == true ) {
                                      feedDelete.useXpath ( ).pause ( 4000 ).
                                      //Verify the Condition field is visble in the content/condition
                                      verify.visible ( "//div/div[2]/div[5]/span/i" ).
                                      pause ( 4000 ).
                                      //Click on the delete option in the contnet/condition
                                      click ( "//div/div[2]/div[5]/span/i" )
                                    } 
                                    else {
                                      feedDelete.useXpath ( ).pause ( 4000 ).
                                      //Wait for the Add condition button is visible in the content/condition
                                      waitForElementVisible ( "//div/div[2]/filter/div/div[2]/a[@class='btn btn-primary centered']", 4000, false ).
                                      pause ( 4000 ).
                                      //Click on the Add condition button in the content/condition
                                      click ( "//div/div[2]/filter/div/div[2]/a[@class='btn btn-primary centered']" ).
                                      pause ( 4000 ).
                                      //Verify the Condition field is visble in the content/condition
                                      verify.visible ( "//div/div[2]/div[5]/span/i" ).
                                      pause ( 4000 ).
                                      //Click on the delete option in the contnet/condition
                                      click ( "//div/div[2]/div[5]/span/i" ).
                                      pause ( 4000 ).
                                      //Wait for the Save button is visible in the feeds page
                                      waitForElementVisible ( "//ul/li/a[@class='btn btn-icon ng-scope btn-active']", 4000, false ).
                                      pause ( 4000 ).
                                      //Click on the Save button in the feeds page
                                      click ( "//ul/li/a[@class='btn btn-icon ng-scope btn-active']" ).
                                      pause ( 4000 ).
                                      //Wait for the Save button is not visible and get the function value in the feeds page
                                      waitForElementNotPresent ( "//div/div[2]/div[5]/span/i", 4000, false, function ( conditionCheckfalse ) {
                                        if ( ( conditionCheckfalse.value.length == 0 ) && ( conditionCheckfalse.value != true ) ) {
                                          //Write in the spreadsheet: Pass Result and Reason
                                          feedDelete.writeToExcelPass ( 'boxxspring.xlsx', 'FeedsDelete', rowCount, 4 );
                                        }
                                        else {
                                          //Write in the spreadsheet: Fail Result and Reason
                                          feedDelete.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsDelete', rowCount, 4, 5, "Delete Functionality is not working properly" );
                                        }
                                      } );
                                    } 
                                  } ); 
                                }
                              } );                                     
                            }
                            else {
                               //Write in the spreadsheet: Fail Result and Reason
                              feedDelete.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsDelete', rowCount, 4, 5, "Provider is mismatched" );
                            }
                          } ); 
                        }
                        else {
                          //Write in the spreadsheet: Fail Result and Reason
                          feedDelete.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsDelete', rowCount, 10, 12, "Feed caption is not displayed" );
                        }
                      } );
                    }
                    else {
                       //Write in the spreadsheet: Fail Result and Reason
                      feedDelete.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsDelete', rowCount, 4, 5, "Checked Searched Feeds is not visible in the Feeds listing page" );
                    }
                  } );
                }
                else {
                   //Write in the spreadsheet: Fail Result and Reason
                  feedDelete.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsDelete', rowCount, 4, 5, "Search Count is zero" );
                }
              } );             
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            feedDelete.writeToExcelFail ( 'boxxspring.xlsx', 'FeedsDelete', rowCount, 4, 5, "Feeds menu is not displayed in the Sidebar" );
          }
        } );
      }
    }
    //End the Browser
    feedDelete.end ( );
  }
};
//this function is for check and add the Players
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'PlayersAdd' ];
var playerTitle = [ ];
var playerDescription = [ ];
var playershortTitle = [ ];
var playershortDesc = [ ];
var playerCategoryName = [ ];
var playerNote = [ ];
var playerImg = [ ];
var currentCount, actualCount, expectedCount, excelData;
var getData,rowCount = 1;
module.exports = {
  tags: ['playersAdd'],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'PlayersAdd': function ( playersAdd ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read Players Title
      if ( excelData.includes ( 'A' ) ) {
        playerTitle.push ( worksheet[ excelData ].v );
      }
      //Read Players Description
      if ( excelData.includes ( 'B' ) ) {
        playerDescription.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'C' ) ) {
        playershortTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'D' ) ) {
        playershortDesc.push ( worksheet[ excelData ].v );
      }
      //Read Players category Name
      if ( excelData.includes ( 'E' ) ) {
        playerCategoryName.push ( worksheet[ excelData ].v );
      }
      //Read Players Note
      if ( excelData.includes ( 'F' ) ) {
        playerNote.push ( worksheet[ excelData ].v );
      }
      //Read Players Image
      if ( excelData.includes ( 'G' ) ) {
        playerImg.push ( worksheet[ excelData ].v );
      }
    }
    if ( playerTitle.length > 1 ) {
      var checkResult = playersAdd.globals.excelCol.resultCustomData; 
      for ( let getData = 1,rowCount = 1; getData < playerTitle.length; getData++ ) {
        rowCount++;
        playersAdd.pause ( 4000 ).useXpath ( ).
        //Wait for Players menu is visible in the Sidebar
        waitForElementVisible ("//ul/li/a[ text( ) = 'Players' ]", 4000, false, function ( checkPlayerMenu ) {
          if ( checkPlayerMenu.value == true ) {
            playersAdd.pause ( 4000 ).useXpath ( ).
            //Verify the Players Menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Players' ]", "Players" ).
            pause ( 4000 ).
            //Click on the Players Menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Players' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get the Total Players count in the Players listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length  - 1 ) );
              }
              playersAdd.useCss ( ).
              //Wait for the Add button dropdown should not present in the listing page
              waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false, function ( checkAddbtn ) {
                if ( checkAddbtn.value.length == 0 ) {
                  playersAdd.pause ( 4000 ).
                  //Click on the Add button to create an author
                  click ( ".btn-add" ).
                  pause ( 4000 ).
                  //Get the caption label text in the Players page
                  getText ( ".typeName-label.ng-binding", function ( labelName ) {
                    if ( labelName.value == "PLAYER" ) {
                      playersAdd.pause ( 4000 ).
                      //Verify the Content Tab in the Players page
                      verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                      //Click on the Content Tab
                      click ( ".video-tabs > a[ href='#content' ]" ).
                      pause ( 4000 ).
                      //Check and Enter Players Title
                      waitForElementVisible ( ".text-input-headline", 4000, false ).
                      //Enter the Players Title in the Headline
                      setValue ( ".text-input-headline", playerTitle[ getData ] ).
                      pause ( 4000 ).
                      //Check and Enter Players Text Description
                      waitForElementVisible ( ".wmd-input", 4000, false ).
                      pause ( 4000 ).
                      //Clear the data in the field
                      clearValue ( ".wmd-input" ).
                      pause ( 4000 ).
                      //Enter the data in the field
                      setValue ( ".wmd-input", playerDescription[ getData ] ).
                      pause ( 4000 ).
                      //Check and click Save button
                      waitForElementVisible ( '.btn-active', 4000, false ).
                      pause ( 4000 ).
                      //Click on the Save button
                      click ( ".btn-active" ).
                      pause ( 4000 ).
                      //Check and Enter the valid input in the Properties Tab
                      all_properties ( playershortTitle[ getData ], playershortDesc[ getData ], playerCategoryName[ getData ], playerNote[ getData ], playerImg[ getData ] ).
                      pause ( 4000 ).useCss ( ).
                      //Wait for the Properties tab is visible in the Players page
                      waitForElementVisible ( ".video-tabs > a[ href='#properties']", 4000, false, function ( checkProperties ) {
                        if ( checkProperties.value == true ) {
                          if ( checkResult.indexOf ( 'FAIL' ) >= 0 ) {
                            //Write in the spreadsheet: Fail Result and Reason
                            playersAdd.writeToExcelFail ( 'boxxspring.xlsx', 'PlayersAdd', rowCount, 10, 11, "Thumbnail is not displayed in the properties tab" );
                            checkResult.length = 0;
                          }
                          else if ( checkResult.length == 0 ) {
                          }
                          else {
                            checkResult.length = 0;
                            //Check and click save button
                            playersAdd.verify.visible ( "a.btn-active" ).
                            //click on the save button
                            click ( "a.btn-active" ).
                            pause ( 4000 ).
                            //Wait for the Save active should not present in the Players page
                            waitForElementNotPresent ( "a.btn-active", 4000, false, function ( checkSaveInactive ) {
                              if ( checkSaveInactive.value.length == 0 ) {
                                playersAdd.pause ( 4000 ).useXpath ( ).
                                //Verify the videos menu in the sidebar
                                verify.containsText ( "//ul/li/a[ text( ) = 'Players']", "Players" ).
                                pause ( 4000 ).
                                //click on the videos menu in CONTENT
                                click ( "//ul/li/a[ text( ) = 'Players']" )
                                //Check the Actual Count after each video added
                                playersAdd.useCss ( ).pause( 4000 ).
                                //Wait for the count label is visible in the listing page
                                waitForElementVisible ('.content-count > strong', 4000, false ).
                                pause ( 4000 ).
                                //Get the count label text in the listing page
                                getText ( '.content-count > strong', function ( actualCountResult ) {
                                  if ( actualCountResult.status != -1 ) {
                                    actualCount = actualCountResult.value;
                                    actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                    expectedCount = ( ( + currentCount ) + ( 1 ) );
                                    if ( actualCount == expectedCount ) {
                                      //Write in the spreadsheet: Pass Result and Reason
                                      playersAdd.writeToExcelPass ( 'boxxspring.xlsx', 'PlayersAdd', rowCount, 9 );
                                    }
                                    else {
                                      //Write in the spreadsheet: Fail Result and Reason
                                      playersAdd.writeToExcelFail ( 'boxxspring.xlsx', 'PlayersAdd', rowCount, 9, 10, "ActualResult:'"+ actualCount +"'in the Total Count After Added New Players. ExpectedResult: should be'"+ currentCount +"' in the Total Count" );
                                    }
                                  }
                                } );
                              }
                              else {
                                //Write in the spreadsheet: Fail Result and Reason
                                playersAdd.writeToExcelFail ( 'boxxspring.xlsx', 'PlayersAdd', rowCount, 9, 10, "Save functionality is not working as expected" );
                              }
                            } );
                          }                          
                        }                        
                      } );
                    }
                    else {
                      //Write in the spreadsheet: Fail Result and Reason
                      PlayersAdd.writeToExcelFail ( 'boxxspring.xlsx', 'PlayersAdd', rowCount, 9, 10, "Lable Name as Expected 'PLAYER' but Actual as '"+labelName.value+"'" );                         
                    }
                  } );
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
                  playersAdd.writeToExcelFail ( 'boxxspring.xlsx', 'PlayersAdd', rowCount, 9, 10, "Add button is not working in the Players Listing page" );                    
                }
              } );
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            playersAdd.writeToExcelFail ( 'boxxspring.xlsx', 'PlayersAdd', rowCount, 9, 10, "Players menu is not displayed in Sidebar" ); 
          }
        } );
      }
    }
    //End the browser
    playersAdd.end ( );
  }
};
'use strict'
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ '360VideosDelete' ];
var storyTitle = [ ];
var storyEditTitle = [ ];
var currentCount, actualCount, expectedCount;
var searchCount, excelData;
var getData, rowCount = 1;
module.exports = {
  tags: [ '360VideosDelete' ],
  //Login in to Application
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  '360VideosDelete': function ( videos360Delete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] === '!' ) continue;
      //Read story title
      if ( excelData.includes ( 'A' ) ) {
        storyTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Title
      if ( excelData.includes ( 'B' ) ) {
        storyEditTitle.push ( worksheet[ excelData ].v );
      }
    }
    if ( storyTitle.length > 1 ) {
      for ( let getData = 1, rowCount = 1; getData < storyTitle.length; getData++ ) {
        rowCount++;
        videos360Delete.pause ( 4000 ).useXpath ( ).
        waitForElementVisible ( "//ul/li/a[ text( ) = '360videos' ]",4000,false,function ( check360VideoMenu ) {
          if ( check360VideoMenu.value == true ) {
            videos360Delete.pause ( 4000 ).useXpath ( ).
            //Verify the 360videos menu is visible in the CONTENT
            verify.containsText ( "//ul/li/a[text ( ) = '360videos' ]", "360videos" ).
            pause ( 4000 ).
            //Click on the 360videos menu in the CONTENT
            click ( "//ul/li/a[text ( ) = '360videos']" ).
            useCss ( ).pause ( 4000 ).
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
            } );            
            videos360Delete.pause ( 4000 ).
            //Check the search field is visible in the 360 videos listing page
            waitForElementVisible ( ".search-field-input", 4000 ).
            pause ( 4000 ).
            //Verify the search field is visible in the 360 videos listing page
            verify.visible ( ".search-field-input" ).
            //Enter the Headline in the field
            setValue ( ".search-field-input", storyTitle[ getData ] ).
            // hold the control
            keys ( videos360Delete.Keys.ENTER ). 
            click ( ".search-field-input" ).
            // release the control
            keys ( videos360Delete.Keys.NULL ). 
            pause ( 4000 ).
            //Check the Total videos count label is visible in the 360videos listing page
            waitForElementVisible ( ".content-count>strong", 4000, false ).
            pause ( 4000 ).
            //Verify the Total videos count label is visible in the 360videos listing page
            verify.visible ( ".content-count>strong" ).
            pause ( 4000 ).
            //Get the Current total count in the listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status !== -1 ) {
                searchCount = currentCountResult.value;
                searchCount = searchCount.substring ( 1, searchCount.length - 1 );
              }
              if ( searchCount > 0 ) {
                videos360Delete.pause ( 4000 ).useXpath ( ).
                //Wait for the Searched data is visible in the Videos listing page
                waitForElementVisible ( "(//h2[@class='ng-binding'])[text( )[normalize-space(.)='"+ storyTitle[ getData ] +"']]", 4000, false ).
                pause ( 4000 ).
                //Verify the Searched data is visible in the Videos listing page
                verify.visible ( "(//h2[@class='ng-binding'])[text( )[normalize-space(.)='"+ storyTitle[ getData ] +"']]" ).
                pause ( 4000 ).
                //Click on the Searched data in the Videos listing page
                click ( "(//h2[@class='ng-binding'])[text( )[normalize-space(.)='"+ storyTitle[ getData ] +"']]" ).
                useCss ( ).pause ( 4000 )
                videos360Delete.verify.visible ( ".video-tabs > a[href='#content']" ).
                click ( ".video-tabs > a[href='#content']" ).
                pause ( 4000 ).
                //Check and Enter Videos Title
                waitForElementVisible ( ".text-input-headline", 4000, false ).
                clearValue ( ".text-input-headline" ).
                pause ( 4000 ).
                //Enter the Headline in the 360videos page
                setValue ( ".text-input-headline", storyEditTitle[ getData ] ).
                pause ( 4000 ).
                //Check and click Save button
                waitForElementVisible ( '.btn-active', 4000, false ).
                //Verify the save button is visible in the 360videos page
                verify.visible ( ".btn-active" ).
                pause ( 4000 ).
                //Click on the save button in the 360videos page
                click ( ".btn-active" ).
                pause ( 40000 ).
                //Check and Click Delete Button.
                verify.visible ( ".btn-delete >span[ng-click='showDeleteVerification();']" ).
                pause ( 4000 ).
                //click on the Delete button in the 360videos page
                click ( ".btn-delete >span[ng-click='showDeleteVerification();']" ).
                pause ( 4000 ).
                //Check the existance of delete confirmation dialog
                verify.visible ( "dialog[name=deleteVerification]" ).
                pause ( 4000 ).useCss ( ).
                //Verify the Delete button is visible in the 360videos Page
                verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                pause ( 4000 ).
                click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                pause ( 4000 ).
                //Check the existance of delete confirmation to delete
                verify.visible ( "dialog[ name=deleteVerification ]" ).
                pause ( 4000 ).useXpath ( ).
                //Check the delete confirmation popup alert is visible
                verify.visible ( "//section/button[text()='Delete']" ).
                pause ( 4000 ).
                //Click on the Delete button in the alert popup
                click ( "//section/button[text()='Delete']" ).
                pause ( 4000 ).
                //Verify the 360videos menu is visible in the CONTENT
                verify.containsText ( "//ul/li/a[text() = '360videos']", "360videos" ).
                pause ( 4000 ).
                //Click on the 360videos menu in the CONTENT
                click ( "//ul/li/a[ text() = '360videos' ]" ).
                useCss ( ).pause ( 4000 ).
                //Check the total count label is visible in the 360videos listing page
                waitForElementVisible ( ".content-count>strong", 4000, false ).
                verify.visible ( ".content-count>strong" ).
                getText ( '.content-count > strong', function ( actualCountResult ) {
                  if ( actualCountResult.status !== -1 ) {
                    actualCount = actualCountResult.value;
                    actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                    expectedCount = ( ( + currentCount ) - ( 1 ) );
                    if ( actualCount == expectedCount ) {
                      //Write in the spreadsheet: Pass Result and Reason
                      videos360Delete.writeToExcelPass ( 'boxxspring.xlsx', '360VideosDelete', rowCount, 4, 5 );
                    }
                    else {
                      //Write in the spreadsheet: Fail Result and Reason
                      videos360Delete.writeToExcelFail ( 'boxxspring.xlsx', '360VideosDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Delete videos. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
                    }
                  }
                } );            
              }
              else {
                //Write in the spreadsheet: Searched Fail Result and Reason
                videos360Delete.writeToExcelFail ( 'boxxspring.xlsx', '360VideosDelete', rowCount, 4, 5, "Searched Result Count,'"+ searchCount +"'" );
              }
            } );
          }
          else {
            //Write in the spreadsheet: Searched Fail Result and Reason
            videos360Delete.writeToExcelFail ( 'boxxspring.xlsx', '360VideosDelete', rowCount, 4, 5, "360videos menu is not displayed in Sidebar" );
          }
        } );
      }
    }
    //End the browser
    videos360Delete.end ( );
  }
};
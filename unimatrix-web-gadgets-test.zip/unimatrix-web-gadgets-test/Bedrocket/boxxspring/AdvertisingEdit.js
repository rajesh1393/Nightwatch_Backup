var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require !== 'undefined' ) XLSX = require ( 'xlsx' );
var workbook = XLSX.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var editSheet = workbook.Sheets [ 'AdvertisingEdit' ];
var searchContent = [ ];
var adTitle = [ ];
var urlEdit = [ ];
var editTitle = [ ];
var currentCount;
var actualCount;
var expectedCount;
module.exports = {
  tags: [ 'advertisingEdit' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'AdvertisingEdit': function ( advertisingEdit ) {
    for ( z in editSheet ) {
      if ( z[0] === '!' ) continue;
      //Read Provider Name as Dailymotion
      if ( z.includes( 'A' ) ) {
        searchContent.push( editSheet[ z ].v );
      }
      //Read Playlist title
      if ( z.includes( 'B' ) ) {
        editTitle.push( editSheet[ z ].v );
      }
      if ( z.includes( 'C' ) ) {
        urlEdit.push( editSheet[ z ].v );
      }
    }
    if ( urlEdit.length > 0 ) {
      advertisingEdit.
      useXpath ( ).
      //Verify the Distribution menu in Side bar is visible
      verify.visible ( "( //DIV[@class='content-header content ng-scope'] )[5]" ).
      pause ( 3000 ).
      //Click on the Distribution menu in Side bar
      click ( "( //DIV[@class='content-header content ng-scope'] )[5]" ).
      pause ( 3000 ).
      //Click on the Destination menu in DISTRIBUTION
      click ( "//a[text() = 'Advertising' ]" ).
      pause ( 3000 );
      //loop untill the Search content
      for ( var getDataEdit = 1, rowCountEdit = 1; getDataEdit < searchContent.length; getDataEdit++ ) {
        advertisingEdit.
        useXpath ( ).
        //Clicking the Advertisement button from the Sidebar
        click ( "//a[text() = 'Advertising' ]" ).
        useCss ().
        pause ( 3000 ).
        //Waiting for the Search field to be present
        waitForElementVisible ( ".full-width-search-field-input", 5000, false ).
        pause ( 3000 ).
        //Clearing the value in the Search field
        clearValue ( ".full-width-search-field-input" ).
        pause ( 5000 ).
        //Again clicking on the Search field
        click ( ".full-width-search-field-input" ).
        //Passing the values to the Search content
        setValue ( ".full-width-search-field-input", searchContent[ getDataEdit ] ).
        pause ( 5000 ).
        //Validating the Search result
        waitForElementNotPresent ( ".empty-page-container", 5000, false, function ( getResult ) {
          if ( getResult.value == false ) {
            advertisingEdit.
            useXpath ().
            pause ( 3000 ).
            //Clicking the Searched result 
            click ( "( //NG-INCLUDE[@class='ng-scope'] )[1]" ).
            pause ( 3000 ).
            useCss ().
            //Checking the page has navigated to Edit page by checking the visibility of the Headline field
            verify.visible ( ".text-input-headline" ).
            pause ( 3000 ).
            //Clicking on the Title field
            click ( ".text-input-headline" ).
            pause ( 3000 ).
            //Clearing the value in the Title field
            clearValue ( ".text-input-headline" ).
            pause ( 3000 ).
            //Passing the Updated title in the title field
            setValue ( ".text-input-headline", editTitle [ rowCountEdit ] ).
            pause ( 3000 ).
            //Clicking the URL in the Url field
            click ( "#advertisement-tag-url" ).
            pause ( 3000 ).
            //Clearing the value in the Url field
            clearValue ( "#advertisement-tag-url" ).
            pause ( 5000 ).
            //Passing the value in the URL field
            setValue ( "#advertisement-tag-url", urlEdit [ rowCountEdit ] ).
            pause ( 3000 ).
            //Clicking the Save button
            click ( ".btn-icon" ).
            pause ( 9000 ).
            useXpath ( ).
            //Clicking the Advertisement button from the sidebar of the application
            click ( "//a[text() = 'Advertising' ]" ).
            pause ( 5000 ).
            useCss ( ).
            //Checking the visibility of the Search field in the advertisement list page
            verify.visible ( ".full-width-search-field-input" ).
            pause ( 5000 ).
            //Clicking the Search field in the advertisement list page
            click ( ".full-width-search-field-input" ).
            pause ( 5000 ).
            //Passing the value in the Search field
            setValue ( ".full-width-search-field-input", editTitle [ rowCountEdit ] ).
            pause ( 5000 ).
            //Checking the Count in the Advertisement list page
            waitForElementNotPresent ( ".empty-page-container", 5000, false, function ( getResult ){
              if ( getResult.value == false )
              {
               advertisingEdit.
               getText ( 'ng-include.ng-scope:nth-child(1)', function ( actualCountResult ) {
                 var string = actualCountResult.value;
                 var searchedString = editTitle [ rowCountEdit ] ;
                 string.indexOf ( searchedString ) !== -1;
                 if ( string.indexOf ( searchedString ) !== -1) {
                  if ( actualCount == expectedCount ) {
                  //Write in the Excel: Pass Result and Reason
                  advertisingEdit.
                  writeToExcelPass ( 'boxxspring.xlsx', 'AdvertisingEdit', ++rowCountEdit, 4 );
                }
                else {
                  //Write in the Excel: Fail Result and Reason
                  advertisingEdit.
                  writeToExcelFail ( 'boxxspring.xlsx', 'AdvertisingEdit', ++rowCountEdit, 4, 5, "Updating the Edit Advertising failed" );
                }
              }
            } );
             }
             else
             {
              //Write in the Excel: Fail Result and Reason
              advertisingEdit.
              writeToExcelFail ( 'boxxspring.xlsx', 'AdvertisingEdit', ++rowCountEdit, 4, 5, "Your Searched content is not avail in Advertising" );
            }
          });

          }
          else {
            //Write in the Excel: Fail Result and Reason
            advertisingEdit.
            writeToExcelFail ( 'boxxspring.xlsx', 'AdvertisingEdit', ++rowCountEdit, 4, 5, "Your Searched content is not avail in Advertising" );
          }
        })
      }
    }
  }
}
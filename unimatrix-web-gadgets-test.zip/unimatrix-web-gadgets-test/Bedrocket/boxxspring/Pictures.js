//this function is for check for add,edit and delete the Picutres
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
var pictureURL = [ ];
var pictureHeadline = [ ];
var pictureShortName = [ ];
var pictureShortDescription = [ ];
var pictureCategories = [ ];
var pictureNotes = [ ];
var picturesImg = [ ];
var pictureURLEdit = [ ];
var pictureHeadlineEdit = [ ];
var pictureShortNameEdit = [ ];
var pictureShortDescriptionEdit = [ ];
var pictureCategoriesEdit = [ ];
var pictureNotesEdit = [ ];
var pictureHeadlineDelete = [ ];
var pictureShortNameDelete = [ ];
var currentCount, excelDeleteData, excelAddData, excelEditData, getDeleteData, getEditData, getAddData;
var actualCount, expectedCount;
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
  try {
    var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
      cellStyles: true
    } );
    var addPictureSheet = workbook.Sheets['PicturesAdd'];
    var editPictureSheet = workbook.Sheets['PicturesEdit'];
    var deletePictureSheet = workbook.Sheets['PicturesDelete'];
  }
  catch ( err ) {
    console.log ( "Respective File not avail,Please check File name" );
  }
module.exports = {
  tags: [ 'pictures' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.windowMaximize ( ).
    login ( profile.portalUri, profile.username, profile.password );
  },
  'PicturesAdd': function ( addPictures ) {
    try {
      //Read values from excel
      for ( excelAddData in addPictureSheet ) {
        if ( excelAddData[ 1 ] == '!' ) continue;
        //Read pictureHeadline from excel
        else if ( excelAddData.includes ( 'A' ) ) {
          pictureHeadline.push ( addPictureSheet[ excelAddData ].v );
        }
        //Read pictureURL from excel
        else if ( excelAddData.includes ( 'B' ) ) {
          pictureURL.push ( addPictureSheet[ excelAddData ].v );
        }
        //Read pictureShortName from excel
        else if ( excelAddData.includes ( 'C' ) ) {
          pictureShortName.push ( addPictureSheet[ excelAddData ].v );
        }
        //Read pictureShortDescription from excel
        else if ( excelAddData.includes ( 'D' ) ) {
          pictureShortDescription.push ( addPictureSheet[ excelAddData ].v );
        }
        //Read pictureCategories from excel
        else if ( excelAddData.includes ( 'E' ) ) {
          pictureCategories.push ( addPictureSheet[ excelAddData ].v );
        }
        //Read pictureNotes from excel
        else if ( excelAddData.includes ( 'F' ) ) {
          pictureNotes.push ( addPictureSheet[ excelAddData ].v );
        }
        //Read pictureImage from excel
        else if ( excelAddData.includes ( 'Z' ) ) {
          picturesImg.push ( addPictureSheet[ excelAddData ].v );
        }
      }
    }
    catch ( err ) {
      //Writing the Failed status in the Terminal
      addPictures.verify.fail ( "Unable to load file", "Excel file should get updated", "Please check the Parameters in Excel Sheet" );
    }
    if ( pictureHeadline.length > 1 ) {
      for ( let getAddData = 1, rowCount = 1; getAddData < pictureHeadline.length; getAddData++ ) {
        rowCount++;
        addPictures.pause ( 4000 ).useXpath ( ).
        //Check and Wait for the Pictures menu is visible in CONTENT
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Pictures' ]", 4000, false, function ( checkPicturesMenu ) {
          if ( checkPicturesMenu.value == true ) {
            addPictures.pause ( 4000 ).useXpath ( ).
            //Verify the Pictures menu is visible in CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Pictures' ]", "Pictures" ).
            pause ( 4000 ).
            //Click on the Pictures menu in CONTENT
            click ( "//ul/li/a[ text( ) = 'Pictures' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get the total count in the pictures listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                var currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }    
              //Wait for the Add button is visble in the pictures listing page
              addPictures.waitForElementNotPresent ( "div>section.hover-dropdown-toggle", 4000, false, function ( checkAddBtn ) {
                if ( checkAddBtn.value.length == 0 ) {
                  addPictures.pause ( 4000 ).
                  //Click on the Add button in the pictures listing page
                  click ( ".btn-add" ).
                  pause ( 4000 ).
                  //Verify the Content tab is visible in the pictures page
                  verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                  pause ( 4000 ).
                  //Click on the Content tab in the pictures page
                  click ( ".video-tabs > a[ href='#content' ]" ).
                  pause ( 4000 ).
                  //Wait for the Pictures Headline field is visible in the pictures page
                  waitForElementVisible ( ".text-input-headline", 4000, false ).
                  pause ( 4000 ).
                  //Clear the data in the Pictures Headline field in the pictures page
                  clearValue ( ".text-input-headline" ).
                  pause ( 4000 ).
                  //Enter the data in the Pictures Headline field in the pictures page
                  setValue ( ".text-input-headline", pictureHeadline[ getAddData ] ).
                  pause ( 4000 ).
                  //Wait for image field is visible in the pictures page
                  waitForElementVisible ( ".image-upload", 4000, false ).
                  pause ( 4000 ).
                  //Wait for checking the image upload class should not visible in the pictures page
                  waitForElementNotPresent ( ".uploaded-image-container", 4000, false ).
                  pause (4000 ).useXpath ( ).
                  //Get the attribute for picture add value in the pictures page
                  getAttribute ( "//div[@class='filepicker-widget ng-scope']", 'id', function ( pictureAddValue ) {
                    addPictures.useCss ( ).
                    //Enter the values image input field
                    setValue ( "#"+ pictureAddValue.value +">span>input", require ( 'path' ).resolve ( pictureURL[ getAddData ] ) ).
                    pause ( 17000 )   
                	} );
                  addPictures.useCss( ).pause ( 4000 ).
                  //Get the attribute value for uploaded image in the pictures page
                  getAttribute ( ".uploaded-image", "src", function ( imageCheck ) {
                    var imageValue = imageCheck.value;
                    var imageStatus = imageCheck.status;
                    if ( imageStatus == 0 ) {
                      addPictures.pause ( 4000 ).
                      //Verify the Replace the image button is visible in the pictures page
                      verify.visible ( ".content-menu > li:nth-child( 3 ) > a:nth-child( 1 )" ).
                      pause ( 4000 ).
                      //Verify the Download the image button is visible in the pictures page
                      verify.visible ( ".content-menu > li:nth-child( 2 ) > a:nth-child( 1 )" ).
                      pause ( 4000 ).
                      //Verify the Delete the image button is visible in the pictures page
                      verify.visible ( ".content-menu > li:nth-child( 1 ) > a:nth-child( 1 )" ).
                      pause ( 4000 )
                    }
                  } );
                  //Wait for Save button is visible in the Pictures page
                  addPictures.waitForElementVisible ( '.btn-active', 4000, false ).
                  pause ( 4000 ).
                  //Verify the Save button is visible in the Pictures page
                  verify.visible ( ".btn-active" ).
                  pause ( 4000 ).
                  //Click on Save button is visible in the Pictures page
                  click ( ".btn-active" ).
                  pause ( 4000 ).
                  //Check and Enter the valid input in the Properties Tab
                  all_properties ( pictureShortName[ getAddData ], pictureShortDescription[ getAddData ], pictureCategories[ getAddData ], pictureNotes[ getAddData ], picturesImg[ getAddData ] ).
                  pause ( 4000 ).useCss ( ).
                  //Verify the Save button is visible in the Pictures page
                  verify.visible ( ".btn-active" ).
                  pause ( 4000 ).
                  //Click on Save button is visible in the Pictures page
                  click ( ".btn-active" ).
                  pause ( 4000 ).
                  //Wait for Save button should not visible in the Pictures page
                  waitForElementNotPresent ( '.btn-active', 4000, false, function ( checkSaveBtn ) {
                    if ( checkSaveBtn.value.length == 0 ) {                     
                      addPictures.useXpath ( ).pause ( 4000 ).
                      //Verify the Pictures menu is visible in CONTENT
                      verify.containsText ( "//ul/li/a[ text( ) = 'Pictures' ]", "Pictures" ).
                      pause ( 4000 ).
                      //Click on the Pictures menu is visible in CONTENT
                      click ( "//ul/li/a[ text( ) = 'Pictures' ]" ).
                      useCss ( ).pause ( 4000 ).
                      //Get the value for Total label in the pictures listing page 
                      getText ( '.content-count > strong', function ( actualCountResult ) {
                        if ( actualCountResult.status != -1 ) {
                          var actualCount = actualCountResult.value;
                          actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                          expectedCount = ( ( + currentCount ) + ( 1 ) );
                          if ( actualCount == expectedCount ) {
                            //Write in the spreadsheet: Pass Result and Reason
                            addPictures.writeToExcelPass ( 'boxxspring.xlsx', 'PicturesAdd', rowCount, 8 );
                          }
                          else {
                            //Write in the spreadsheet: Fail Result and Reason
                            addPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesAdd', rowCount, 8, 9, "ActualResult: '"+ actualCount +"' in the Total Count After Added New story. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
                          }
                        }
                      } ); 
                    }
                    else {
                      //Write in the spreadsheet: Fail Result and Reason
                      addPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesAdd', rowCount, 8, 9, "Save button is still ACTIVE in the Pictures page" );
                    }
                  } );
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
                  addPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesAdd', rowCount, 8, 9, "Add button is not working as Expected in Pictures Listing page" );         
                } 
              } );              
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            addPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesAdd', rowCount, 8, 9, "Pictures Menu is not displayed in the Sidebar " );
          }
        } );
      }
    }
  },
  'PicturesEdit': function ( editPictures ) {
    try {
      //Read values from excel
      for ( excelEditData in editPictureSheet ) {
        if ( excelEditData[ 1 ] == '!' ) continue;
        //Read pictureHeadlineEdit
        if ( excelEditData.includes ( 'A' ) ) {
          pictureHeadlineEdit.push ( editPictureSheet[excelEditData].v );
        }
        //Read pictureURLEdit
        if ( excelEditData.includes ( 'B' ) ) {
          pictureURLEdit.push ( editPictureSheet[excelEditData].v );
        }
        //Read pictureShortNameEdit
        if ( excelEditData.includes ( 'C' ) ) {
          pictureShortNameEdit.push ( editPictureSheet[excelEditData].v );
        }
        //Read pictureShortDescriptionEdit
        if ( excelEditData.includes ( 'D' ) ) {
          pictureShortDescriptionEdit.push ( editPictureSheet[excelEditData].v );
        }
        //Read pictureCategoriesEdit
        if ( excelEditData.includes ( 'E' ) ) {
          pictureCategoriesEdit.push ( editPictureSheet[excelEditData].v );
        }
        //Read pictureNotesEdit
        if ( excelEditData.includes ( 'F' ) ) {
          pictureNotesEdit.push ( editPictureSheet[excelEditData].v );
        }
        //Read picturesImage
        if ( excelEditData.includes ( 'Z' ) ) {
          picturesImg.push ( editPictureSheet[excelEditData].v );
        }
      }
    }
    catch ( err ) {
      //Writing the Failed status in the Terminal
      editPictures.verify.fail ( "Unable to load file", "Excel file should get updated", "Please check the Parameters in Excel Sheet" );
    }
    if ( pictureHeadlineEdit.length > 1 ) {
      for ( let getEditData = 1, rowCount = 1; getEditData < pictureHeadlineEdit.length; getEditData++ ) {
        rowCount++;
        editPictures.pause ( 4000 ).useXpath ( ).
        //Wait for Pictures menu is visible in CONTENT
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Pictures' ]", 4000, false, function ( checkPicturesMenu ) {
          if ( checkPicturesMenu.value == true ) {
            editPictures.pause ( 4000 ).useXpath ( ).
            //Verify the Pictures menu is visible in CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Pictures' ]", "Pictures" ).
            pause ( 4000 ).
            //Click on Pictures menu in CONTENT
            click ( "//ul/li/a[ text( ) = 'Pictures' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get the value for Total count in the Pictures listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                var currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              //Verify the searched field is visible in the listing page
              editPictures.verify.visible ( ".search-field-input" ).
              pause ( 4000 ).
              //Clear the search result data in listing page 
              clearValue ( ".search-field-input" ).
              pause ( 4000 ).
              //Enter the search result data in listing page 
              setValue ( ".search-field-input", pictureHeadlineEdit[ getEditData ] ).
              pause ( 4000 ).
              // Hold the control
              keys ( editPictures.Keys.ENTER ). 
              click ( ".search-field-input" ).
              // Release the control
              keys ( editPictures.Keys.NULL ). 
              pause ( 4000 ).
              //Wait for count label is visible in the listing page
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              pause ( 4000 ).
              //Verify the count label is visible in the listing page
              verify.visible ( ".content-count>strong" )
              editPictures.pause ( 4000 ).
              //Get the Text on total count label in the listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  var searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                  if ( searchCount > 0 ) {
                    editPictures.pause ( 4000 ).useXpath ( ).
                    //Wait for searched data listed is visible in the listing page
                    waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ pictureHeadlineEdit[ getEditData ] +"']]", 4000, false, function ( checkSearchedLst ) {
                      if ( checkSearchedLst.value == true ) {
                        editPictures.pause ( 4000 ).useXpath ( ).
                        //Click on the searched data listed in the listing page
                        click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ pictureHeadlineEdit[ getEditData ] +"']]" ).
                        useCss ( ).pause ( 4000 ).
                        //Verify the Content tab is visible in the pictures page
                        verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                        pause ( 4000 ).
                        //click on the Content tab is visible in the pictures page
                        click ( ".video-tabs > a[ href='#content' ]" ).
                        pause ( 4000 ).
                        //Check and Enter Pictures Title
                        waitForElementVisible ( ".text-input-headline", 4000, false ).
                        pause ( 4000 ).
                        //Clear the data in the text input field in the Pictures page
                        clearValue ( ".text-input-headline" ).
                        pause ( 4000 ).
                        //Enter the data in the text input field in the Pictures page
                        setValue ( ".text-input-headline", pictureHeadlineEdit[ getEditData ] ).
                        pause ( 4000 ).
                        //Check Thumbnail ADD and Delete
                        waitForElementVisible ( ".uploaded-image-container", 4000, false, function ( checkImgAvail ) {
                          if ( checkImgAvail.value == true ) {
                            editPictures.pause ( 4000 ).
                            getAttribute ( ".uploaded-image", "src", function ( imageCheck ) {
                              var imageValue = imageCheck.value;
                              var imageStatus = imageCheck.status;
                              if ( imageStatus == 0 ) {
                                editPictures.useXpath ( ).
                                //Get the attribute value for filepicker picture edit value in the pictures page
                                getAttribute ( "//div[@class='filepicker-widget ng-scope']", 'id', function ( pictureEditValue ) {
                                  editPictures.pause ( 4000 ).useCss ( ).
                                  //Verify the delete button is visible in the pictures page
                                  verify.visible ( " .content-menu > li:nth-child( 3 ) > a:nth-child( 1 )" ).
                                  pause ( 4000 ).
                                  //Click on the delete button in the pictures page
                                  click ( ".content-menu > li:nth-child( 3 ) > a:nth-child( 1 )" ).
                                  pause ( 4000 ).
                                  //Wait to check uploaded image container should not present in the pictures page
                                  waitForElementNotPresent ( ".uploaded-image-container", 4000, false, function ( imageContainer ) {
                                    if ( imageContainer.status == 0 ) {
                                      editPictures.pause ( 15000 ).
                                      //Wait for the image input field is visible on the pictures page
                                      waitForElementVisible ( "#"+ pictureEditValue.value +">span>input", 4000, false ).
                                      pause ( 4000 ).useCss ( ).
                                      //Enter the image data in the input field on the pictures page
                                      setValue ( "#"+ pictureEditValue.value +">span>input", require ( 'path' ).resolve ( pictureURLEdit[ getEditData ] ) ).
                                      pause ( 20000 ).useCss ( ).
                                      //Wait for the Save button is visible in the pictures page
                                      waitForElementVisible ( '.btn-active', 4000, false ).
                                      pause ( 4000 ).
                                      //Verify the Save button is visible in the pictures page
                                      verify.visible ( ".btn-active" ).
                                      pause ( 4000 ).
                                      //Click on the the Save button in the pictures page
                                      click ( ".btn-active" ).
                                      pause ( 10000 ).
                                      //Check and Enter the valid input in the Properties Tab
                                      all_properties ( pictureShortNameEdit[ getEditData ], pictureShortDescriptionEdit[ getEditData ], pictureCategoriesEdit[ getEditData ], pictureNotesEdit[ getEditData ], picturesImg[ getEditData ] ).
                                      pause ( 4000 ).
                                      //Verify the Save button is visible in the pictures page
                                      verify.visible ( ".btn-active" ).
                                      pause ( 4000 ).
                                      //Click on the the Save button in the pictures page
                                      click ( ".btn-active" ).
                                      pause ( 4000 ).
                                      //Wait for Save button should not present in the Pictures page
                                      waitForElementNotPresent ( '.btn-active', 4000, false, function ( checkSaveBtn ) {
                                        if ( checkSaveBtn.value.length == 0) {
                                          editPictures.useXpath ( ).pause ( 4000 ).
                                          //Verify the Pictures menu is visible in the CONTENT
                                          verify.containsText ( "//ul/li/a[ text( ) = 'Pictures' ]", "Pictures" ).
                                          pause ( 4000 ).
                                          //Click on the Pictures menu in the CONTENT
                                          click ( "//ul/li/a[ text( ) = 'Pictures' ]" ).
                                          useCss ( ).pause ( 4000 ).
                                          //Get the text value for Total count in the listing page
                                          getText ( '.content-count > strong', function ( actualCountResult ) {
                                            if ( actualCountResult.status != -1 ) {
                                              var actualCount = actualCountResult.value;
                                              actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                              if ( actualCount == currentCount ) {
                                                //Write in the spreadsheet: Pass Result and Reason
                                                editPictures.writeToExcelPass ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8 );
                                              }
                                              else {
                                                //Write in the spreadsheet: Fail Result and Reason
                                                editPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8, 9, "ActualResult: '"+ actualCount +"' in the Total Count After Added New story. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                                              }
                                            }
                                          } );
                                        }
                                        else {
                                          //Write in the spreadsheet: Fail Result and Reason
                                          editPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8, 9, "After Edited Save button is still ACTIVE in the pictures page" );                         
                                        }
                                      } );
                                    }
                                    else {
                                    	//Write in the spreadsheet: Fail Result and Reason
                                      editPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8, 9, "Uploaded Image Container is visible after deleted Thumbnail" )
                                    }
                                  } );
                                } );
                              }
                              else {
                              	//Write in the spreadsheet: Fail Result and Reason
                                editPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8, 9, "Thumbnail Image Container is not visible in the pictures page" )
                              }
                            } );
                          }                         
                        } );
                      }
                      else {
                      	//Write in the spreadsheet: Fail Result and Reason
                        editPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8, 9, "Searched Data is not displayed in Listing page" )
                      }
                    } );
                  }
                  else {
                  	//Write in the spreadsheet: Fail Result and Reason
                    editPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8, 9, "Searched Result as '0'" )
                  }
                }
              } );                       
            } );
          }
          else {
          	//Write in the spreadsheet: Fail Result and Reason
            editPictures.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesEdit', rowCount, 8, 9, "Pictures Menu is not displayed in the Sidebar" )
          }
        } );
      }
    }
  },
  'PicturesDelete': function ( deletePicture ) {
    try {
      //Read values from excel
      for ( excelDeleteData in deletePictureSheet ) {
        if ( excelDeleteData[ 1 ] == '!' ) continue;
        //Read pictureHeadlineDelete
        if ( excelDeleteData.includes ( 'A' ) ) {
          pictureHeadlineDelete.push ( deletePictureSheet[ excelDeleteData ].v );
        }
        //Read pictureShortNameDelete
        if ( excelDeleteData.includes ( 'B' ) ) {
          pictureShortNameDelete.push ( deletePictureSheet[ excelDeleteData ].v );
        }
      }
    }
    catch ( err ) {
      //Writing the Failed status in the Terminal
      deletePicture.verify.fail ( "Unable to load file", "Excel file should get updated", "Please check the Parameters in Excel Sheet" );
    }
    if ( pictureHeadlineDelete.length > 1 ) {
      for ( let getDeleteData = 1, rowCount = 1; getDeleteData < pictureHeadlineDelete.length; getDeleteData++ ) {
        rowCount++;
        deletePicture.pause ( 4000 ).useXpath ( ).
        //Wait for the Picures menu is visible in CONTENT
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Pictures' ]", 4000, false, function ( checkPicturesMenu ) {
          if ( checkPicturesMenu.value == true ) {
            deletePicture.pause ( 4000 ).useXpath ( ).
            //Verify the Picures menu is visible in CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Pictures' ]", "Pictures" ).
            pause ( 4000 ).
            //Click on the the Picures menu in CONTENT
            click ( "//ul/li/a[ text( ) = 'Pictures' ]" ).
            useCss ( ).pause ( 4000 ).
            //Get the text value in the total count in the listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                var currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, currentCount.length - 1 );
              }
              //Verify the searched result field is visible in the listing page
              deletePicture.verify.visible ( ".search-field-input" ).
              pause ( 5000 ).
              //Clear the searched result in the field on listing page
              clearValue ( ".search-field-input" ).
              pause ( 7000 ).
              //Enter the searched result in the field on listing page
              setValue ( ".search-field-input", pictureHeadlineDelete[ getDeleteData ] ).
              pause ( 5000 ).
              //Hold the control
              keys ( deletePicture.Keys.ENTER ). 
              click ( ".search-field-input" ).
              //Release the control
              keys ( deletePicture.Keys.NULL ). 
              pause ( 10000 ).
              //Wait for total count label is visible in the listing page
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              pause ( 4000 ).
              //Verify the Total count label is visible in the pictures listing page
              verify.visible ( ".content-count>strong" ).
              //Get the text value for total count in the listing page
              pause ( 4000 ).getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  var searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                  if ( searchCount > 0 ) {
                    deletePicture.pause ( 7000 ).useXpath ( ).
                    //Wait for searched result listed data is visible in the listing page
                    waitForElementVisible ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ pictureHeadlineDelete[ getDeleteData ] +"']]", 4000, false, function ( checkSearchedLst ) {
                      if ( checkSearchedLst.value == true ) {
                        deletePicture.pause ( 4000 ).
                        //Click on the searched result listed data in the listing page
                        click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ pictureHeadlineDelete[ getDeleteData ] +"']]" ).
                        useCss ( ).pause ( 4000 ).
                        //Verify the content tab is visible in the pictures page
                        verify.visible ( ".video-tabs > a[ href='#content' ]" ).
                        pause ( 7000 ).
                        //click on the content tab is visible in the pictures page
                        click ( ".video-tabs > a[ href='#content' ]" ).
                        pause ( 4000 ).
                        //Check and Enter Pictures Title
                        waitForElementVisible ( ".text-input-headline", 4000, false ).
                        pause ( 7000 ).
                        //Clear the data in the text input field in the pictures page
                        clearValue ( ".text-input-headline" ).
                        pause ( 7000 ).
                        //Enter the data in the text input field in the pictures page
                        setValue ( ".text-input-headline", pictureHeadlineDelete[ getDeleteData ] ).
                        pause ( 4000 ).  
                        //Wait and check for the delete button is visible in the pictures page
                        waitForElementVisible ( ".btn-delete > span[ ng-click='showDeleteVerification();']",4000, false, function ( checkDeleteBtn ) {  
                          if ( checkDeleteBtn.value == true ) {                   
                            deletePicture.pause ( 4000 ).
                            //Verify the delete button is visible in the pictures page
                            verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                            pause ( 4000 ).
                            //Click on the delete button in the pictures page
                            click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                            pause ( 4000 ).
                            //Check the existance of delete confirmation dialog
                            verify.visible ( "dialog[ name=deleteVerification ]" ).
                            pause ( 4000 ).
                            //Click Cancel Button in Delete Dialog
                            verify.visible ( ".link-secondary" ).
                            pause ( 4000 ).
                            //Click on the Cancel button in the pictures page
                            click ( ".link-secondary" ).
                            pause ( 4000 ).
                            //Verify the delete button is visible in the pictures page
                            verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                            pause ( 4000 ).
                            //Click on the delete button in the pictures page
                            click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                            pause ( 7000 ).
                            //Check the existance of delete confirmation to delete
                            verify.visible ( "dialog[ name=deleteVerification ]" ).
                            pause ( 7000  ).
                            //Verify the delete button is visible in the pictures page
                            verify.visible ( "button.btn:nth-child( 2 )" ).
                            pause ( 7000 ).
                            //Click on the delete button in the pictures page
                            click ( "button.btn:nth-child( 2 )" ).
                            pause ( 4000 ).useXpath ( ).
                            //Verify the Pictures menu is visible in the CONTENT
                            verify.containsText ( "//ul/li/a[ text( ) = 'Pictures' ]", "Pictures" ).
                            pause ( 4000 ).
                            //Click on the Pictures menu in the CONTENT
                            click ( "//ul/li/a[ text( ) = 'Pictures' ]" ).
                            useCss ( ).pause ( 4000 ).
                            //Get the text value for total count in the listing page
                            getText ( '.content-count > strong', function ( actualCountResult ) {
                              if ( actualCountResult.status != -1 ) {
                                var actualCount = actualCountResult.value;
                                actualCount = actualCount.substring ( 1, actualCount.length - 1 );
                                var expectedCount = ( ( + currentCount ) - ( 1 ) );
                                if ( actualCount == expectedCount ) {
                                  //Write in the spreadsheet: Pass Result and Reason
                                  deletePicture.writeToExcelPass ( 'boxxspring.xlsx', 'PicturesDelete', rowCount, 4 );
                                }
                                else {
                                  //Write in the spreadsheet: Fail Result and Reason
                                  deletePicture.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesDelete', rowCount, 4, 5, "ActualResult: '"+ actualCount +"' in the Total Count After Added New story. ExpectedResult: should be'"+ expectedCount +"' in the Total Count " );
                                }
                              }
                            } );
                          }
                          else {
                            //Write in the spreadsheet: Fail Result and Reason
                            deletePicture.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesDelete', rowCount, 4, 5, "Delete button is not displayed in the Pictures page" );                                
                          }
                        } );
                      }
                      else {
                        //Write in the spreadsheet: Fail Result and Reason
                        deletePicture.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesDelete', rowCount, 4, 5, "Searched Data is not displayed in the pictures listing page " );                            
                      }
                    } );
                  }
                  else {
                    //Write in the spreadsheet: Fail Result and Reason
                    deletePicture.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesDelete', rowCount, 4, 5, "Searched Result as '0'" )
                  }
                }
                else {
                  //Write in the spreadsheet: Fail Result and Reason
                  deletePicture.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesDelete', rowCount, 4, 5, "Pictures Total Count label is not displayed in the listing page" )
                }
              } );            
            } );
          }
          else {
            //Write in the spreadsheet: Fail Result and Reason
            deletePicture.writeToExcelFail ( 'boxxspring.xlsx', 'PicturesDelete', rowCount, 4, 5, "Pictures Menu is not displayed in the Sidebar" )
          }
        } );
      }          
    }
    //End the browser
    deletePicture.end ( );
  }
};
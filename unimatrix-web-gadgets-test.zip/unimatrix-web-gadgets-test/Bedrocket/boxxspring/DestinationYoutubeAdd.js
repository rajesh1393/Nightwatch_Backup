//this function is for check and Add the Youtube Destinations 
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
var workbook1 = new Excel.Workbook ( );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'DestinationYoutubeAdd' ];
var playlistTitle = [ ];
var socialBtn = [ ];
var destinationTitle = [ ];
var username = [ ];
var password = [ ];
var currentCount;
var actualCount;
var expectedCount;
var youtube, youtubeData;
var getData, rowCount, getData = 1;
module.exports = {
  tags: [ 'destinationYoutubeAdd' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'DestinationYoutubeAdd': function ( destinationAddYoutube ) {
    for ( youtubeData in worksheet ) {
      if ( youtubeData[ 1 ] == '!' ) continue;
      //Read Category Title
      if ( youtubeData.includes ( 'A' ) ) {
        socialBtn.push ( worksheet[ youtubeData ].v );
      }
      //Read Category Description
      if ( youtubeData.includes ( 'B' ) ) {
        playlistTitle.push ( worksheet[ youtubeData ].v );
      }
      //Read Short Title
      if ( youtubeData.includes ( 'C' ) ) {
        destinationTitle.push ( worksheet[ youtubeData ].v );
      }
      //Read User name
      if ( youtubeData.includes ( 'D' ) ) {
        username.push ( worksheet[ youtubeData ].v );
      }
      //Read Password
      if ( youtubeData.includes ( 'E' ) ) {
        password.push ( worksheet[ youtubeData ].v );
      }
    }
    if ( socialBtn.length > 0 ) {
    	for ( let getData = 1, rowCount = 1; getData < socialBtn.length; getData++ ) {
        rowCount++;
	      destinationAddYoutube.pause ( 4000 ).useXpath ( ).
	      waitForElementPresent ( "//div/a[@class='content-header-link content'][text()[normalize-space(.)='Distribution']]", 4000, false, function ( checkDistributionMenu ) {
          console.log ( "checkDistributionMenu",checkDistributionMenu)
          if ( checkDistributionMenu.value.length != 0 ) {
            destinationAddYoutube.pause ( 4000 ).useXpath ( ).
            waitForElementVisible ( "//i[@ng-if='!collapse.distribution']", 4000, false, function ( checkArrow ) {
              if ( checkArrow.value == true ) {
                destinationAddYoutube.pause ( 4000 ).useCss ( ).
                verify.visible ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 ).
                //Click on the Distribution menu in the side bar
                click ( "div.content-header:nth-child( 7 )" ).
                pause ( 4000 );
              }
            } );
			      destinationAddYoutube.pause ( 4000 ).useXpath ( ).
			      waitForElementVisible ( "//a[text ( ) = 'Destinations']", 4000, false, function ( checkDistributionMenu ) {
			      	if ( checkDistributionMenu.value == true ) {
			      		destinationAddYoutube.pause ( 4000 ).useXpath ( ).
					      //Verify the Destination menu in DISTRIBUTION is visible
					      verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
					      pause ( 4000 ).
					      //Click on the Destination menu in DISTRIBUTION
					      click ( "//a[ text ( ) = 'Destinations']" ).
					      useCss ( ).pause ( 4000 ).
					      getText ( '.content-count > strong', function ( currentCountResult ) {
					        if ( currentCountResult.status != -1 ) {
					          currentCount = currentCountResult.value;
					        }        
				          destinationAddYoutube.pause ( 4000 ).useCss ( ).
				          //Wait for the Add destination button is visible
				          waitForElementVisible ( "a.btn-primary", 4000, false ).
				          pause ( 4000 ).
				          //Verify the Add destination button is visible
				          verify.visible ( "a.btn-primary" ).
				          pause ( 4000 ).
				          //Click on Add destination button in destination page
				          click ( "a.btn-primary" ).
				          pause ( 4000 ).useXpath ( ).
				          //Wait for the Add Destination caption is visible in the Add Destination page
				          waitForElementVisible ( "//h1[@class='ng-scope'][text ( )='Add Destination']", 4000, false ).
				          pause ( 4000 ).
				          //Verify the Add Destination caption is visible in the Add Destination page
				          verify.containsText ( "//h1[@class='ng-scope'][text ( )='Add Destination']", "Add Destination" )
				          if ( ( "youtube" ) == socialBtn[ getData ] ) {
				            destinationAddYoutube.useXpath ( ).
				            //Wait for the youtube Social button is visible in add destination page
				            waitForElementVisible ( "//li/a/div/span[contains (.,'"+ socialBtn[ getData ] +"')]", 4000, false ).
				            pause ( 4000 ).
				            //Verify the youtube Social button is visible in add destination page
				            verify.visible ( "//li/a/div/span[contains (.,'"+ socialBtn[ getData ] +"')]" ).
				            pause ( 4000 ).
				            //Click on youtube Social button in add destination page
				            click ( "//li/a/div/span[contains (.,'"+ socialBtn[ getData ] +"')]" ).
				            useCss ( ).pause ( 4000 ).
				              //Switch the window to Youtube
				              switchToSecondaryWindow ( 'google' );
				              //Get the current URL Response and value
				              destinationAddYoutube.url ( function ( responseUrl ) {
				                var resturl = responseUrl.value;
				                var rest = "oauth";
				                if ( new RegExp ( rest ).test ( resturl ) == true ) {
				                  //Wait to check for email field should be visible in the login page
				                  destinationAddYoutube.waitForElementVisible ( "#identifierId", 3000, false, function ( google_login ) {
				                    if ( google_login.value == true ) {
				                      destinationAddYoutube.setValue ( "#identifierId", username[ getData ] ).
				                      pause ( 4000 ).
				                      //Click on Next button
				                      click ( "#identifierNext > content > span" ).
				                      pause ( 4000 ).useXpath().
				                      //Wait to check for email error message should not visible in the login page                      
				                      waitForElementNotVisible ( "//div/div[1]/div[1]/div/div[2]/div[2]", 4000, false, function ( google_login_error ) {
				                        if ( google_login_error.value == false ) {                          
				                          //check the password field is visible
				                          destinationAddYoutube.useCss().waitForElementVisible ( "#password > div.aCsJod.oJeWuf > div > div.Xb9hP > input", 4000, false ).
				                          //sign in with the google account using password
				                          setValue ( "#password > div.aCsJod.oJeWuf > div > div.Xb9hP > input", password[ getData ] ).
				                          pause ( 4000 ).
				                          //click submit button to sign in
				                          click ( "#passwordNext > content > span" ).
				                          pause ( 4000 ).
				                          //Wait to check for Password error message should not present in the login page
				                          waitForElementNotPresent ( "#password > div.LXRPh > div.dEOOab.RxsGPe", 4000, false, function ( google_pwd_error ) {
				                            if ( google_pwd_error.value == false ) {
				                              destinationAddYoutube.pause ( 4000 ).
				                              //Get the current URL Response and value              
				                              url ( function ( responseUrl ) {
				                                var permissionPanel = responseUrl.value;
				                                var requirePathe = "oauth";
				                                if ( new RegExp ( requirePathe ).test ( permissionPanel ) == true ) {
				                                  //Verify the Post page in youtube window is visible
				                                  destinationAddYoutube.pause ( 4000 ).
				                                  verify.visible ( "div.FgbZLd>div#profileIdentifier" ).
				                                  pause ( 5000 ).
				                                  getText ( "div.FgbZLd>div#profileIdentifier", function ( profileIdentifierID ) {
				                                    if ( profileIdentifierID.value == username[ getData ] ) {
				                                      //Verify the Post Button in youtube window is visible
				                                      destinationAddYoutube.verify.visible ( "div#submit_approve_access" ).
				                                      pause ( 4000 ).
				                                      //Click on the Post Button in youtube window
				                                      click ( "div#submit_approve_access" )
				                                      destinationAddYoutube.deleteCookies ( function ( currentCookiesDelete ) {
				                                      } );
				                                      destinationAddYoutube.pause ( 4000 ).
				                                      //Windows Handling Switch to portal
				                                      window_handles ( function ( switchwindowresult ) {
				                                        var currentWindows = switchwindowresult.value[ 0 ];
				                                        destinationAddYoutube.switchWindow ( currentWindows );
				                                      } );
				                                      destinationAddYoutube.pause ( 4000 ).
				                                      //Wait for the DESTINATION caption is visible in the add destination page
				                                      waitForElementVisible ( ".typeName-label", 4000, false ).
				                                      pause ( 4000 ).
				                                      //Verify the DESTINATION caption is visible in the add destination page
				                                      verify.containsText ( ".typeName-label", "DESTINATION" ).
				                                      pause ( 4000 ).
				                                      //Clear the Headline data in the field
				                                      clearValue ( ".text-input-headline" ).
				                                      pause ( 4000 ).
				                                      //Enter the Headline data in the field
				                                      setValue ( ".text-input-headline", destinationTitle[ getData ] ).
				                                      pause ( 4000 ).
				                                      //Wait for the Save button in the destiantion page is visible
				                                      waitForElementVisible ( "form[ng-if='destination.service && !authorizing']>div>a.btn.btn-primary.btn-180.pull-right", 4000, false ).
				                                      pause ( 4000 ).
				                                      //Click on the Save button in the destiantion page
				                                      click ( "form[ng-if='destination.service && !authorizing']>div>a.btn.btn-primary.btn-180.pull-right" ).
				                                      useXpath ( ).pause ( 4000 ).
				                                      //Verify the Destination menu in DISTRIBUTION is visible
				                                      verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
				                                      pause ( 4000 ).
				                                      //Click on the Destination menu in DISTRIBUTION 
				                                      click ( "//a[ text ( ) = 'Destinations']" ).
				                                      useCss ( ).
				                                      pause ( 4000 ).
				                                      //Get the Actual Total count in the Destination listing page
				                                      getText ( '.content-count > strong', function ( actualCountResult ) {
				                                        if ( actualCountResult.status != -1 ) {
				                                          var actualCount = actualCountResult.value;
				                                          var expectedCount = ( ( + currentCount ) + ( 1 ) );
				                                          if ( actualCount == expectedCount ) {
				                                            //Write in the spreadsheet: Pass Result and Reason
				                                            destinationAddYoutube.writeToExcelPass ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7 );
				                                          }
				                                          else {
				                                            //Write in the spreadsheet: Fail Result and Reason
				                                            destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7, 8, "ActualResult: '"+ actualCount +"' in the Total Count After Added Youtube Destination. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
				                                          }
				                                        }
				                                      } );
				                                      //Check the input after each destination added
				                                      if ( getData < socialBtn.length - 1 ) {
				                                        //Get the Current Total count in the Destination listing page
				                                        destinationAddYoutube.getText ( '.content-count > strong', function ( currentCountResult ) {
				                                          if ( currentCountResult.status != -1 ) {
				                                            currentCount = currentCountResult.value;
				                                          }
				                                        } );
				                                      }
				                                    }
				                                    else {
				                                      destinationAddYoutube.closeWindow ( ).
				                                      //Windows Handling Switch to portal
				                                      window_handles ( function ( switchwindowresult ) {
				                                        var currentWindows = switchwindowresult.value[ 0 ];
				                                        destinationAddYoutube.switchWindow ( currentWindows );
				                                      } );
				                                      destinationAddYoutube.useXpath ( ).pause ( 4000 ).
				                                      //Verify the Destination menu in DISTRIBUTION is visible
				                                      verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
				                                      pause ( 4000 ).
				                                      //Click on the Destination menu in DISTRIBUTION
				                                      click ( "//a[ text ( ) = 'Destinations']" ).
				                                      useCss ( ).pause ( 4000 ).
				                                      //video title display in google page mismatch with the videoplayer title 
				                                      writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7, 8, "Profile Id is Mismatched in Access permission page " );
				                                    }
				                                  } );
				                                }
				                                else {
				                                  destinationAddYoutube.closeWindow ( ).
				                                  //Windows Handling Switch to portal
				                                  window_handles ( function ( switchwindowresult ) {
				                                    var currentWindows = switchwindowresult.value[ 0 ];
				                                    destinationAddYoutube.switchWindow ( currentWindows );
				                                  } );
				                                  destinationAddYoutube.useXpath ( ).pause ( 4000 ).
				                                  //Verify the Destination menu in DISTRIBUTION is visible
				                                  verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
				                                  pause ( 4000 ).
				                                  //Click on the Destination menu in DISTRIBUTION
				                                  click ( "//a[ text ( ) = 'Destinations']" ).
				                                  useCss ( ).pause ( 4000 ).
				                                  //video title display in google page mismatch with the videoplayer title 
				                                  writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7, 8, "Youtube details are not valid" );
				                                }
				                              } );
				                            }
				                            else {
				                              destinationAddYoutube.closeWindow ( ).
				                              //Windows Handling Switch to portal
				                              window_handles ( function ( switchwindowresult ) {
				                                var currentWindows = switchwindowresult.value[ 0 ];
				                                destinationAddYoutube.switchWindow ( currentWindows );
				                              } );
				                              destinationAddYoutube.useXpath ( ).pause ( 4000 ).
				                              verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
				                              pause ( 4000 ).
				                              click ( "//a[ text ( ) = 'Destinations']" ).
				                              useCss ( ).pause ( 4000 )
				                              //get the error message for the invalid password                              
				                              destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7, 8, "Incorrect user password" );
				                            }
				                          } );
				                        }
				                        else {
				                          //get the error message for the invalid email
				                          destinationAddYoutube.closeWindow ( ).
				                          //Windows Handling Switch to portal
				                          window_handles ( function ( switchwindowresult ) {
				                            var currentWindows = switchwindowresult.value[ 0 ];
				                            destinationAddYoutube.switchWindow ( currentWindows );
				                          } );
				                          destinationAddYoutube.useXpath ( ).pause ( 4000 ).
				                          //Verify the Destination menu in Distribution is visible
				                          verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
				                          pause ( 4000 ).
				                          //Click on the Destination menu in Distribution
				                          click ( "//a[ text ( ) = 'Destinations']" ).
				                          useCss ( ).pause ( 4000 )
				                          destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7, 8, "Incorrect user Email Id" );
				                          if ( getData < socialBtn.length - 1 ) {
				                            //Get the Current Total count in the Destination listing page
				                            destinationAddYoutube.getText ( '.content-count > strong', function ( currentCountResult ) {
				                              if ( currentCountResult.status != -1 ) {
				                                currentCount = currentCountResult.value;
				                              }
				                            } );
				                          }
				                        }
				                      } );
				                    }
				                  } );
				                }
				                else {
				                  //check the relevant details displayed in google after auto login in youtube
				                  destinationAddYoutube.pause ( 4000 ).
				                  //Get the current URL Response and value
				                  url ( function ( responseUrl ) {
				                    var permissionPanel = responseUrl.value;
				                    var requirePathe = "oauth2";
				                    if ( new RegExp ( requirePathe ).test ( permissionPanel ) == true ) {
				                      destinationAddYoutube.pause ( 4000 ).
				                      verify.visible ( "div.FgbZLd>div#profileIdentifier" ).
				                      pause ( 5000 ).
				                      getText ( "div.FgbZLd>div#profileIdentifier", function ( profileIdentifierID ) {
				                      if ( profileIdentifierID.value == username[ getData ] ) {
					                      //Verify the Post Button in youtube window is visible
					                      destinationAddYoutube.verify.visible ( "div#submit_approve_access" ).
					                      pause ( 4000 ).
					                      //Click on the Post Button in youtube window
					                      click ( "div#submit_approve_access" ).                      
					                      deleteCookies ( function ( currentCookiesDelete ) {
					                      } );
					                      destinationAddYoutube.pause ( 4000 ).
					                      //Windows Handling Switch to portal
					                      window_handles ( function ( switchwindowresult ) {
					                        var currentWindows = switchwindowresult.value[ 0 ];
					                        destinationAddYoutube.switchWindow ( currentWindows );
					                      } );
					                      destinationAddYoutube.pause ( 4000 ).
					                      //Wait for the DESTINATION caption is visible in the add destination page
					                      waitForElementVisible ( ".typeName-label", 4000, false ).
					                      pause ( 4000 ).
					                      //Verify the DESTINATION caption is visible in the add destination page
					                      verify.containsText ( ".typeName-label", "DESTINATION" ).
					                      pause ( 4000 ).
					                      //Clear the Headline data in the field
					                      clearValue ( ".text-input-headline" ).
					                      pause ( 4000 ).
					                      //Enter the Headline data in the field
					                      setValue ( ".text-input-headline", destinationTitle[ getData ] ).
					                      pause ( 4000 ).
					                      //Wait for the Save button in the destiantion page is visible
					                      waitForElementVisible ( "form[ng-if='destination.service && !authorizing']>div>a.btn.btn-primary.btn-180.pull-right", 4000, false ).
					                      pause ( 4000 ).
					                      //Click on the Save button in the destiantion page
					                      click ( "form[ng-if='destination.service && !authorizing']>div>a.btn.btn-primary.btn-180.pull-right" ).
					                      useXpath ( ).pause ( 4000 ).
					                      //Verify the Destination menu in DISTRIBUTION is visible
					                      verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
					                      pause ( 4000 ).
					                      //Click on the Destination menu in DISTRIBUTION 
					                      click ( "//a[ text ( ) = 'Destinations']" ).
					                      useCss ( ).pause ( 4000 ).
					                      //Get the Actual Total count in the Destination listing page
					                      getText ( '.content-count > strong', function ( actualCountResult ) {
					                        if ( actualCountResult.status != -1 ) {
					                          var actualCount = actualCountResult.value;
					                          var expectedCount = ( ( +currentCount ) + ( 1 ) );
					                          if ( actualCount == expectedCount ) {
					                            //Write in the spreadsheet: Pass Result and Reason
					                            destinationAddYoutube.writeToExcelPass ( 'boxxspring.xlsx', 'DestinationYoutubeAdd',rowCount, 7 );
					                          }
					                          else {
					                            //Write in the spreadsheet: Fail Result and Reason
					                            destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7, 8, "ActualResult: '"+ actualCount +"' in the Total Count After Addded Youtube Destination. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
					                          }
					                        }
					                      } );
					                      //Check the input after each destination added
					                      if ( getData < socialBtn.length - 1 ) {
					                        //Get the Current Total count in the Destination listing page
					                        destinationAddYoutube.getText ( '.content-count > strong', function ( currentCountResult ) {
					                        if ( currentCountResult.status != -1 ) {
					                          currentCount = currentCountResult.value;
					                        }
					                      } );
					                    }
				                    }
				                    else {
				                      destinationAddYoutube.closeWindow ( ).
				                      //Windows Handling Switch to portal
				                      window_handles ( function ( switchwindowresult ) {
				                        var currentWindows = switchwindowresult.value[ 0 ];
				                        destinationAddYoutube.switchWindow ( currentWindows );
				                      } );
				                      destinationAddYoutube.useXpath ( ).pause ( 4000 ).
				                      //Verify the Destination menu in DISTRIBUTION is visible
				                      verify.containsText ( "//a[text ( ) = 'Destinations']", "Destinations" ).
				                      pause ( 4000 ).
				                      //Click on the Destination menu in DISTRIBUTION
				                      click ( "//a[ text ( ) = 'Destinations']" ).
				                      useCss ( ).pause ( 4000 ).
				                      //video title display in google page mismatch with the videoplayer title 
				                      writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd', rowCount, 7, 8, "Profile Id is Mismatched in Access permission page " );
				                    }
				                  } );
			                  }
			                  else {
			                    //video title display in google page mismatch with the videoplayer title while autologin
			                    destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd',rowCount, 7, 8, "Issue in the Youtube" );
			                  }				              
				              } );    
			              }			            
			            } );      
				        }
				        else {
				        	//video title display in google page mismatch with the videoplayer title while autologin
								  destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd',rowCount, 7, 8, "Mismatched Youtube name as '"+ socialBtn[ getData ] +"'" );
							  }      
						  } );
						}
						else {
							//video title display in google page mismatch with the videoplayer title while autologin
							destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd',rowCount, 7, 8, "Destinations Menu is not displayed in Sidebar" );
						}
					} );
					}
					else {
						//video title display in google page mismatch with the videoplayer title while autologin
					  destinationAddYoutube.writeToExcelFail ( 'boxxspring.xlsx', 'DestinationYoutubeAdd',rowCount, 7, 8, "Distribution Menu is not displayed in Sidebar" );
				  }
				} );
  		}
  	}
	  //End the Browser
	  destinationAddYoutube.end ( );
  }
};
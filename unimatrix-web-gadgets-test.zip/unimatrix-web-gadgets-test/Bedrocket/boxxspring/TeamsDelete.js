//this function is for check and Delete the Teams
'use strict';
var xlsx = require ( 'xlsx' );
var fs = require ( 'fs' );
var Excel = require ( 'exceljs' );
if ( typeof require != 'undefined' ) xlsx = require ( 'xlsx' );
var workbook = xlsx.readFile ( 'boxxspring.xlsx', {
  cellStyles: true
} );
var worksheet = workbook.Sheets[ 'TeamsDelete' ];
 var teamTitle = [ ];
var teamEditTitle = [ ];
var storyShortDesc = [ ];
var currentCount, expectedCount, actualCount;
var addedCount, searchCount, excelData;
var getData,rowCount = 1;

module.exports = {
  tags: [ 'teamsDelete' ],
  before: function ( portalLogin ) {
    var profile = portalLogin.globals.profile;
    portalLogin.login ( profile.portalUri, profile.username, profile.password );
  },
  'TeamsDelete': function ( teamDelete ) {
    for ( excelData in worksheet ) {
      if ( excelData[ 1 ] == '!' ) continue;
      //Read story title
      if ( excelData.includes ( 'A' ) ) {
        teamTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Edit Title
      if ( excelData.includes ( 'B' ) ) {
        teamEditTitle.push ( worksheet[ excelData ].v );
      }
      //Read Short Description
      if ( excelData.includes ( 'C' ) ) {
        storyShortDesc.push ( worksheet[ excelData ].v );
      }
    }
    if ( teamTitle.length > 1 ) {
      for ( let getData = 1,rowCount = 1; getData < teamTitle.length; getData++ ) {
        rowCount++;
        teamDelete.pause ( 4000 ).useXpath ( ).
        //Check and wait for Teams Menu is visible in the CONTENT
        waitForElementVisible ( "//ul/li/a[ text( ) = 'Teams' ]", 4000, false, function ( checkTeamsMenu ) {
          if ( checkTeamsMenu.value == true ) {
            teamDelete.pause ( 4000 ).useXpath ( ).
            //Verify the Teams menu in the CONTENT
            verify.containsText ( "//ul/li/a[ text( ) = 'Teams' ]", "Teams" ).
            pause ( 4000 ).
            //Click the Teams menu in the CONTENT
            click ( "//ul/li/a[ text( ) = 'Teams' ]" ).
            useCss ( ).pause ( 4000 ).
            //Wait for the count label is visible in the listing page
            waitForElementVisible ( ".content-count>strong", 4000, false ).
            pause ( 4000 ).
            //Get current total count in the Teams listing page
            getText ( '.content-count > strong', function ( currentCountResult ) {
              if ( currentCountResult.status != -1 ) {
                currentCount = currentCountResult.value;
                currentCount = currentCount.substring ( 1, ( currentCount.length - 1 ) );
              }            
              teamDelete.useCss ( ).pause ( 4000 ).                          
              //Wait for the search field visible
              waitForElementVisible ( ".search-field-input", 4000, false ).
              verify.visible ( ".search-field-input" ).
              //Enter the search data in the field
              setValue ( ".search-field-input", teamTitle[ getData ] ).
              //Hold the control
              keys ( teamDelete.Keys.ENTER ).
              //Release the control
              keys ( teamDelete.Keys.NULL ).
              pause ( 4000 ).
              //Wait for the Total count label is visible in the listing page
              waitForElementVisible ( ".content-count>strong", 4000, false ).
              pause ( 4000 ).
              //Get Actual total count in the Teams listing page
              getText ( '.content-count > strong', function ( searchCountResult ) {
                if ( searchCountResult.status != -1 ) {
                  searchCount = searchCountResult.value;
                  searchCount = searchCount.substring ( 1, searchCount.length - 1 );
                }
                if ( searchCount > 0 ) {
                  teamDelete.useXpath ( ).pause ( 4000 ).
                  //Wait for the searched data listed is visible in the listing page
                  waitForElementVisible ("//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ teamTitle[ getData ] +"']]", 4000, false, function ( checkSearchedData ) {
                    if ( checkSearchedData.value == true ) {
                      teamDelete.useXpath ( ).pause ( 4000 ).
                      //Click on the Searched data in the listing page
                      click ( "//h2[@class='ng-binding'][text( )[normalize-space(.)='"+ teamTitle[ getData ] +"']]" ).
                      useCss ( ).pause ( 4000 ).
                      //Check and Enter Category Title
                      waitForElementVisible ( ".video-tabs > a[ href='#properties' ]", 4000, false ).
                      pause ( 4000 ).
                      //Click on the Properties Tab
                      click ( ".video-tabs > a[  href='#properties' ]" ).
                      pause ( 4000 ).
                      //Verify the Headline is visible
                      verify.visible ( ".text-input-headline" ).
                      //Clear the Author Title data in the field
                      clearValue ( ".text-input-headline" ).
                      pause ( 4000 ).
                      //Enter the Author Title data in the field
                      setValue ( ".text-input-headline", teamEditTitle[ getData ] ).
                      pause ( 4000 ).
                      //Check the Save button
                      waitForElementVisible ( '.btn-active', 4000, false ).
                      //Verify the Save button is visible
                      verify.visible ( ".btn-active" ).
                      pause ( 4000 ).
                      //Click on the Save button
                      click ( ".btn-active" ).
                      pause ( 4000 ).
                      //Check the Delete Button.
                      verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Click on the Delete button in the Properties Tab
                      click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Check the existance of delete confirmation dialog
                      verify.visible ( "dialog[ name=deleteVerification ]" ).
                      pause ( 4000 ).
                      //Verify the Cancel Button in Delete Dialog is visible
                      verify.visible ( ".link-secondary" ).
                      //Click Cancel Button in Delete Dialog
                      click ( ".link-secondary" ).
                      pause ( 4000 ).
                      //Verify the Delete Button in the Properties Tab is visible
                      verify.visible ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Click on the Delete button in the Properties Tab
                      click ( ".btn-delete > span[ ng-click='showDeleteVerification();']" ).
                      pause ( 4000 ).
                      //Check the existance of delete confirmation to delete
                      verify.visible ( "dialog[ name=deleteVerification ]" ).
                      pause ( 4000 ).
                      verify.visible ( "button.btn:nth-child( 2 )" ).
                      pause ( 4000 ).
                      //Click on the Delete Button in Delete Dialog box
                      click ( "button.btn:nth-child( 2 )" ).
                      pause ( 4000 ).useXpath ( ).
                      //Verify the Teams menu in the CONTENT
                      verify.containsText ( "//ul/li/a[ text( ) = 'Teams' ]", "Teams" ).
                      pause ( 4000 ).
                      //Click on the Teams menu in the CONTENT
                      click ( "//ul/li/a[ text( ) = 'Teams' ]" ).
                      useCss ( ).pause ( 4000 ).
                      //Wait for the count label is visible in the listing page
                      waitForElementVisible ( ".content-count>strong", 4000,false ).
                      pause ( 4000 ).
                      //Get Teams total count in the Teams listing page
                      getText ( '.content-count > strong', function ( actualCountResult ) {
                        if ( actualCountResult.status != -1 ) {
                          actualCount = actualCountResult.value;
                          actualCount = actualCount.substring ( 1, ( actualCount.length - 1 ) );
                          expectedCount = ( ( + currentCount ) - ( 1 ) );
                          if ( actualCount == expectedCount ) {
                            //Write in the Excel for Pass Result and Reason
                            teamDelete.writeToExcelPass ( 'boxxspring.xlsx', 'TeamsDelete', rowCount, 5 );
                          }
                          else {
                            //Write in the Excel for Fail Result and Reason
                            teamDelete.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsDelete', rowCount, 5, 6, "ActualResult: '"+ actualCount +"' in the Total Count After Deleted Teams. ExpectedResult: should be'"+ expectedCount +"' in the Total Count" );
                          }
                        }
                      } );
                    }
                    else {
                      //Write in the Excel for Fail Result and Reason
                      teamDelete.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsDelete', rowCount, 5, 6, " Searched Data is not avail in the Listing page" );                      
                    }
                  })
                }
                else {
                  //Write in the Excel for Search Fail Result and Reason
                  teamDelete.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsDelete', rowCount, 5, 6, "Searched Result Count,'"+ searchCount +"'" );
                }
              } );
            } );
          }
          else { 
            //Write in the Excel for Search Fail Result and Reason
            teamDelete.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsDelete', rowCount, 5, 6, "Teams menu is not displayed in Sidebar" );                
          }
        } );
      }
    }
    else {
      //Write in the Excel for Search Fail Result and Reason
      teamDelete.writeToExcelFail ( 'boxxspring.xlsx', 'TeamsDelete', rowCount, 5, 6, "Data is not avail in the Excel" );    
    }
    //End the Browser
    teamDelete.end ( );
  }
};